--
-- PostgreSQL database dump
--

\restrict x1LCXeK4NbnA0pEkeA20Ji5e2O8XiXo2WyKkU889m3s9VDN9RPsfnO83IQZccBU

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- (보관본에서 고침) 새 DB 에도 public 은 이미 있다 - 원본은 CREATE SCHEMA public; 이었다
CREATE SCHEMA IF NOT EXISTS public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: fn_set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dev_doc_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dev_doc_files (
    id integer NOT NULL,
    doc_id integer NOT NULL,
    file text,
    name text NOT NULL,
    bytes bigint DEFAULT 0 NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    uploaded_by text,
    url text,
    CONSTRAINT ck_dev_doc_files_one CHECK (((file IS NOT NULL) <> (url IS NOT NULL)))
);


--
-- Name: TABLE dev_doc_files; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dev_doc_files IS '개발자 정보 섹션에 올린 HTML 문서들 (iframe 으로 보여 준다)';


--
-- Name: COLUMN dev_doc_files.file; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_doc_files.file IS '올린 파일 이름 — api/data/doc_files/{doc_id}/ 안. url 과 둘 중 하나만 찬다';


--
-- Name: COLUMN dev_doc_files.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_doc_files.name IS '화면에 적을 이름 (파일이면 원래 파일 이름, 주소면 붙인 이름)';


--
-- Name: COLUMN dev_doc_files.sort_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_doc_files.sort_order IS '섹션 안에서의 탭 차례. 같으면 올린 차례(id)';


--
-- Name: COLUMN dev_doc_files.url; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_doc_files.url IS '주소로 건 경우의 주소. file 과 둘 중 하나만 찬다';


--
-- Name: dev_doc_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dev_doc_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dev_doc_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dev_doc_files_id_seq OWNED BY public.dev_doc_files.id;


--
-- Name: dev_docs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dev_docs (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    updated_by character varying(100),
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by text,
    created_at timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: TABLE dev_docs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dev_docs IS '개발자 정보 공유 문서 (WBS 대시보드 · 개발자 정보 메뉴)';


--
-- Name: COLUMN dev_docs.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_docs.id IS '문서 섹션 식별자 (serial)';


--
-- Name: COLUMN dev_docs.title; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_docs.title IS '섹션 제목. 화면 좌측 목차에 표시 (예: 계정정보)';


--
-- Name: COLUMN dev_docs.content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_docs.content IS '섹션 본문 HTML. 화면의 리치텍스트 편집기에서 작성한 결과';


--
-- Name: COLUMN dev_docs.sort_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_docs.sort_order IS '섹션 표시 순서 (작은 값 우선, 10 단위 증가)';


--
-- Name: COLUMN dev_docs.updated_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_docs.updated_by IS '최종 수정자 (미사용 — 화면에 인증이 없어 기록하지 않음)';


--
-- Name: COLUMN dev_docs.updated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_docs.updated_at IS '최종 수정 시각. 섹션 머리글에 표시';


--
-- Name: COLUMN dev_docs.deleted_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_docs.deleted_at IS '삭제 시각. null 이면 살아 있는 섹션. 목록(/api/docs)은 null 인 것만 준다.';


--
-- Name: COLUMN dev_docs.deleted_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_docs.deleted_by IS '지운 사람 (IpGate 가 가려 준 이름). 되돌릴지 물어볼 상대를 남기려는 것이다.';


--
-- Name: COLUMN dev_docs.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_docs.created_at IS '최초 작성 시각. 이 컬럼을 넣기 전에 만든 섹션은 null (모르는 값을 지어내지 않는다).';


--
-- Name: COLUMN dev_docs.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_docs.created_by IS '최초 작성자 (IpGate 가 가려 준 이름). 가려지지 않으면 null.';


--
-- Name: dev_docs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dev_docs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dev_docs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dev_docs_id_seq OWNED BY public.dev_docs.id;


--
-- Name: dev_menu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dev_menu (
    menu_key character varying(40) NOT NULL,
    menu_nm character varying(60),
    sort_order integer DEFAULT 0,
    use_yn character varying(1) DEFAULT 'Y'::character varying,
    updated_at timestamp with time zone DEFAULT now(),
    folder_id integer
);


--
-- Name: TABLE dev_menu; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dev_menu IS '대시보드 메뉴 목록 (권한 화면이 보여 줄 대상)';


--
-- Name: COLUMN dev_menu.folder_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_menu.folder_id IS '들어 있는 폴더 (dev_menu_folder.folder_id). null 이면 최상위';


--
-- Name: dev_menu_folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dev_menu_folder (
    folder_id integer NOT NULL,
    folder_nm character varying(60) NOT NULL,
    sort_order integer DEFAULT 0,
    updated_at timestamp with time zone DEFAULT now(),
    updated_by character varying(40)
);


--
-- Name: TABLE dev_menu_folder; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dev_menu_folder IS '사이드바 메뉴 폴더 (Super 만 편집)';


--
-- Name: dev_menu_folder_folder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dev_menu_folder_folder_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dev_menu_folder_folder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dev_menu_folder_folder_id_seq OWNED BY public.dev_menu_folder.folder_id;


--
-- Name: dev_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dev_user (
    bp_id character varying(2000),
    name character varying(2000),
    email character varying(2000),
    git character varying(2000),
    startkit character varying(2000),
    dxb character varying(2000),
    vm_conn character varying(2000),
    aipro character varying(2000),
    claudecode character varying(2000),
    dev_db character varying(2000),
    wiki character varying(2000),
    projectview character varying(2000),
    svn character varying(10),
    notebook character varying(100),
    hub_hdmi character varying(100),
    summer_size character varying(20),
    winter_size character varying(20),
    position_nm character varying(50),
    use_ip character varying(60),
    mac_addr character varying(60),
    notebook_no character varying(60),
    notebook_chk_no character varying(60),
    tel_no character varying(40),
    birth_dt date,
    pv_user_id character varying(40),
    block_yn character varying(1),
    monitor1_no character varying(60),
    monitor1_chk_no character varying(60),
    monitor2_no character varying(60),
    monitor2_chk_no character varying(60),
    monitor3_no character varying(60),
    monitor3_chk_no character varying(60),
    super_yn character varying(1),
    emerg_tel_no character varying(40)
);


--
-- Name: TABLE dev_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dev_user IS '개발자 마스터. 성명·직급·계정 발급 현황과 접근 허용 IP 를 관리 (WBS 대시보드 #/devusers)';


--
-- Name: COLUMN dev_user.bp_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.bp_id IS '사번(BP ID). 키. hhip_wbs_wrk2.user_bp_id / user_real_id 와 매칭';


--
-- Name: COLUMN dev_user.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.name IS '성명. 대시보드의 담당자·개발자 표기에 사용';


--
-- Name: COLUMN dev_user.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.email IS '사내 메일 주소';


--
-- Name: COLUMN dev_user.git; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.git IS 'GitLab(code.hd.com) 계정 발급 여부 (O/X)';


--
-- Name: COLUMN dev_user.startkit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.startkit IS 'StartKit 제공 여부 (O/X)';


--
-- Name: COLUMN dev_user.dxb; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.dxb IS 'DX Builder 사용 환경 준비 여부 (O/X)';


--
-- Name: COLUMN dev_user.vm_conn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.vm_conn IS '개발 VM 접속 가능 여부 (O/X)';


--
-- Name: COLUMN dev_user.aipro; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.aipro IS 'AI Pro 계정 발급 여부 (O/X)';


--
-- Name: COLUMN dev_user.claudecode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.claudecode IS 'Claude Code 사용 가능 여부 (O/X)';


--
-- Name: COLUMN dev_user.dev_db; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.dev_db IS '개발 DB 접속 계정 발급 여부 (O/X)';


--
-- Name: COLUMN dev_user.wiki; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.wiki IS '차세대 Wiki 계정 발급 여부 (O/X)';


--
-- Name: COLUMN dev_user.projectview; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.projectview IS 'ProjectView(dev-wbs.hd.com) 계정 발급 여부 (O/X)';


--
-- Name: COLUMN dev_user.svn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.svn IS 'SVN 계정 발급 여부 (O/X)';


--
-- Name: COLUMN dev_user.notebook; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.notebook IS '개발용 노트북 지급 여부 (O/X)';


--
-- Name: COLUMN dev_user.hub_hdmi; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.hub_hdmi IS 'USB 허브 / HDMI 케이블 지급 여부 (O/X)';


--
-- Name: COLUMN dev_user.summer_size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.summer_size IS '하복 사이즈';


--
-- Name: COLUMN dev_user.winter_size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.winter_size IS '동복 사이즈';


--
-- Name: COLUMN dev_user.position_nm; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.position_nm IS '직급';


--
-- Name: COLUMN dev_user.use_ip; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.use_ip IS '사용 IP';


--
-- Name: COLUMN dev_user.mac_addr; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.mac_addr IS 'MAC 주소 (노트북 유선/무선)';


--
-- Name: COLUMN dev_user.notebook_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.notebook_no IS '노트북 장비번호';


--
-- Name: COLUMN dev_user.notebook_chk_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.notebook_chk_no IS '노트북 확인번호';


--
-- Name: COLUMN dev_user.tel_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.tel_no IS '전화번호 (휴대폰/내선)';


--
-- Name: COLUMN dev_user.birth_dt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.birth_dt IS '생년월일';


--
-- Name: COLUMN dev_user.pv_user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.pv_user_id IS 'ProjectView user id (USR-...), used as the workflow charger.';


--
-- Name: COLUMN dev_user.block_yn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.block_yn IS '차단여부 — o 면 등록 IP 라도 접근 차단 (루프백 제외). 빈 값/x = 허용';


--
-- Name: COLUMN dev_user.monitor1_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.monitor1_no IS '모니터1 장비번호';


--
-- Name: COLUMN dev_user.monitor1_chk_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.monitor1_chk_no IS '모니터1 확인번호';


--
-- Name: COLUMN dev_user.monitor2_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.monitor2_no IS '모니터2 장비번호';


--
-- Name: COLUMN dev_user.monitor2_chk_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.monitor2_chk_no IS '모니터2 확인번호';


--
-- Name: COLUMN dev_user.monitor3_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.monitor3_no IS '모니터3 장비번호';


--
-- Name: COLUMN dev_user.monitor3_chk_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.monitor3_chk_no IS '모니터3 확인번호';


--
-- Name: COLUMN dev_user.super_yn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.super_yn IS 'Super 권한 — o 면 최고 관리자 (appsettings 의 Admin:BpIds 와 합집합)';


--
-- Name: COLUMN dev_user.emerg_tel_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dev_user.emerg_tel_no IS '비상연락처 (가족·동거인 등 본인 외 연락처)';


--
-- Name: dev_user_menu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dev_user_menu (
    bp_id character varying(40) NOT NULL,
    menu_key character varying(40) NOT NULL,
    allow_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    updated_by character varying(40)
);


--
-- Name: TABLE dev_user_menu; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dev_user_menu IS '개발자별 메뉴 권한 — 행이 없으면 허용. allow_yn=N 인 줄만 막는다';


--
-- Name: dev_user_pref; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dev_user_pref (
    bp_id text NOT NULL,
    pref_key text NOT NULL,
    pref_val text,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE dev_user_pref; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dev_user_pref IS 'Per-user UI preferences, keyed by dev_user.bp_id. JSON text in pref_val.';


--
-- Name: hhip_lship_change; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_lship_change (
    chg_id bigint NOT NULL,
    screen_nm character varying(200) NOT NULL,
    screen_desc text,
    req_sdt date,
    drop_yn character(1) DEFAULT 'N'::bpchar NOT NULL,
    owner_nm character varying(100),
    note text,
    created_by character varying(100),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(100),
    updated_at timestamp with time zone,
    CONSTRAINT ck_hhip_lship_change_drop CHECK ((drop_yn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


--
-- Name: TABLE hhip_lship_change; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.hhip_lship_change IS '대형선 업무설계 변경이력';


--
-- Name: COLUMN hhip_lship_change.screen_nm; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_lship_change.screen_nm IS '화면명 — 필수. 원장과 이어 두지 않아 글자로 들고 있다';


--
-- Name: COLUMN hhip_lship_change.drop_yn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_lship_change.drop_yn IS '폐기여부 Y/N — 지우지 않고 폐기로 남긴다';


--
-- Name: hhip_lship_change_chg_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.hhip_lship_change ALTER COLUMN chg_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.hhip_lship_change_chg_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hhip_test_fail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_test_fail (
    fail_id bigint NOT NULL,
    seq integer NOT NULL,
    program character varying(200),
    category character varying(100),
    step text,
    input_data text,
    expect text,
    result character varying(20),
    note text,
    verdict text,
    updated_by character varying(100),
    updated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: COLUMN hhip_test_fail.verdict; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_test_fail.verdict IS '접수/개선/먼소리/어쩌라구/ASIS랑같은데ASIS봤냐? — 화면에서 고치는 칸';


--
-- Name: hhip_test_fail_fail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.hhip_test_fail ALTER COLUMN fail_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.hhip_test_fail_fail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hhip_wbs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs (
    activity_id character varying(50),
    activity_nm character varying(50),
    "Column3" character varying(50),
    "Column4" character varying(50),
    "Column5" character varying(50),
    "Column6" character varying(50),
    "Column7" character varying(50),
    "Column8" character varying(50),
    "Column9" character varying(50),
    "Column10" character varying(50),
    "Column11" character varying(50),
    plan_sdt date,
    plan_edt date,
    "계획진척률" real,
    "실적시작일" character varying(50),
    "실적종료일" character varying(50),
    "실적진척률" real,
    "공정준수율" character varying(50),
    "담당자" character varying(50),
    "예상산출물" character varying(50),
    "* 가중치" integer,
    "자동실측" boolean,
    "업무" character varying(50)
);


--
-- Name: hhip_wbs_pv; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_pv (
    activity_id character varying(50) NOT NULL,
    pv_project_id character varying(60),
    pv_work_id character varying(60),
    pv_work_title text,
    pv_seen_at timestamp without time zone,
    pv_finish_rate numeric(6,2),
    pv_actual_rate numeric(6,2),
    pv_plan_sdt date,
    pv_plan_edt date,
    pv_actual_sdt date,
    pv_actual_edt date,
    pv_snapshot_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE hhip_wbs_pv; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.hhip_wbs_pv IS 'ProjectView work cache - identity, snapshot, send history. Cache only, never authoritative.';


--
-- Name: hhip_wbs_pv_node; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_pv_node (
    pv_task_id character varying(60) NOT NULL,
    node_no integer NOT NULL,
    node_id character varying(60),
    stage_nm text,
    node_dt date,
    worker_id character varying(40),
    worker_nm text,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE hhip_wbs_pv_node; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.hhip_wbs_pv_node IS 'ProjectView workflow nodes (stage / date / charger) per task. Cache only.';


--
-- Name: hhip_wbs_pv_task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_pv_task (
    pv_task_id character varying(60) NOT NULL,
    activity_id character varying(50),
    pv_work_id character varying(60),
    pv_task_code character varying(50),
    pv_task_title text,
    pv_plan_sdt date,
    pv_plan_edt date,
    pv_node_cnt integer,
    pv_node_empty integer,
    pv_seen_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now(),
    pv_charger_id character varying(40),
    pv_charger_nm text,
    pv_status text,
    pv_status_at date
);


--
-- Name: TABLE hhip_wbs_pv_task; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.hhip_wbs_pv_task IS 'ProjectView workflow task cache for the "fill empty date/charger" screen.';


--
-- Name: COLUMN hhip_wbs_pv_task.pv_charger_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_pv_task.pv_charger_id IS 'ProjectView user id (USR-...) found on the task itself.';


--
-- Name: COLUMN hhip_wbs_pv_task.pv_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_pv_task.pv_status IS 'Current workflow stage name of the task.';


--
-- Name: COLUMN hhip_wbs_pv_task.pv_status_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_pv_task.pv_status_at IS 'When the task entered pv_status (from task-history).';


--
-- Name: hhip_wbs_task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_task (
    task_id integer NOT NULL,
    activity_id character varying(50) NOT NULL,
    task_div character varying(50),
    memo text,
    done_yn character varying(1),
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE hhip_wbs_task; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.hhip_wbs_task IS '화면(메뉴)별 일감 관리. hhip_wbs_wrk2 와 activity_id 로 1:N 연결. WBS 대시보드 상세목록의 일감 컬럼에서 등록·수정·완료·삭제';


--
-- Name: COLUMN hhip_wbs_task.task_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_task.task_id IS '일감 식별자 (serial, PK)';


--
-- Name: COLUMN hhip_wbs_task.activity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_task.activity_id IS 'hhip_wbs_wrk2.activity_id (부모 화면). 1:N 연결 키';


--
-- Name: COLUMN hhip_wbs_task.task_div; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_task.task_div IS '일감 구분 (개발/확인/문의/버그/기타 — 자유 입력 가능)';


--
-- Name: COLUMN hhip_wbs_task.memo; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_task.memo IS '일감 내용 메모';


--
-- Name: COLUMN hhip_wbs_task.done_yn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_task.done_yn IS '일감 완료 여부 (''o'' = 완료, NULL = 미완료)';


--
-- Name: COLUMN hhip_wbs_task.sort_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_task.sort_order IS '같은 화면 안에서의 표시 순서 (작은 값 우선)';


--
-- Name: COLUMN hhip_wbs_task.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_task.created_at IS '등록 시각';


--
-- Name: COLUMN hhip_wbs_task.updated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_task.updated_at IS '최종 수정 시각';


--
-- Name: hhip_wbs_task_task_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hhip_wbs_task_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hhip_wbs_task_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hhip_wbs_task_task_id_seq OWNED BY public.hhip_wbs_task.task_id;


--
-- Name: hhip_wbs_wrk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk (
    activity_id character varying(50),
    module character varying(50),
    gubun character varying(50),
    menu_nm character varying(50),
    gubun2 character varying(50),
    gubun2_cd character varying(50),
    "Column11" character varying(50),
    "Column12" character varying(50),
    "Column13" character varying(50),
    plan_sdt date,
    plan_edt date,
    "계획진척률" real,
    "실적시작일" character varying(50),
    "실적종료일" character varying(50),
    "실적진척률" character varying(50),
    "공정준수율" character varying(50),
    "담당자" character varying(50),
    "예상산출물" character varying(50),
    "* 가중치" integer,
    "자동실측" boolean,
    "업무" character varying(50),
    "Column26" character varying(50),
    "참조" character varying(50),
    priority_order character varying(50),
    system_code character varying(50)
);


--
-- Name: hhip_wbs_wrk2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100),
    complate_yn character varying(100),
    comp_desc character varying(2000),
    user_real_id character varying,
    complate_real_yn character varying,
    recheck_yn character varying(1),
    complate_big_yn character varying(1),
    complate_real_big_yn character varying(1),
    recheck_big_yn character varying(1),
    db_ready_big_yn character varying(1),
    row_uid bigint NOT NULL,
    pv_test_case_id character varying(50)
);


--
-- Name: TABLE hhip_wbs_wrk2; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.hhip_wbs_wrk2 IS '자재관리(MM) 화면 단위 WBS 작업표. 1행 = 1화면(메뉴). 엑셀 WBS(activity_id 기준)와 동기화되며 WBS 대시보드(#/rows)의 원본 테이블';


--
-- Name: COLUMN hhip_wbs_wrk2.module; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.module IS '업무 대분류 코드 (전 행 MM = 자재관리)';


--
-- Name: COLUMN hhip_wbs_wrk2.module_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.module_name IS '업무 대분류명 (자재관리)';


--
-- Name: COLUMN hhip_wbs_wrk2.systemcode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.systemcode IS '서브시스템(모듈) 코드 — PMM001~PMM018. 소스 리포지토리/폴더명과 일치';


--
-- Name: COLUMN hhip_wbs_wrk2.system_nm; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.system_nm IS '서브시스템(모듈)명 — 예: 입고 관리, PO(발주서 관리)';


--
-- Name: COLUMN hhip_wbs_wrk2.program_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.program_id IS '프로그램 ID — {모듈}.{화면그룹} 형식. 예: PMM004.A010001';


--
-- Name: COLUMN hhip_wbs_wrk2.menu_nm; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.menu_nm IS '화면(메뉴)명 — [화면코드]명칭 형식. 예: [4190]국내자재 입고. 대시보드 목록의 주 표시 항목';


--
-- Name: COLUMN hhip_wbs_wrk2.comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.comment IS '개발 준비 상태 메모 — backend/frontend 존재 여부와 재작업 범위';


--
-- Name: COLUMN hhip_wbs_wrk2.activity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.activity_id IS 'WBS Activity ID (AAC-Annn). 엑셀 WBS와 데이터를 맞추는 매칭 키';


--
-- Name: COLUMN hhip_wbs_wrk2.plan_sdt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.plan_sdt IS '계획시작일. 엑셀 WBS가 원본이며 화면에서는 읽기 전용';


--
-- Name: COLUMN hhip_wbs_wrk2.plan_edt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.plan_edt IS '계획종료일. 대시보드 월/주 집계의 기본 기준일(basis=edt). 엑셀 WBS가 원본, 화면 읽기 전용';


--
-- Name: COLUMN hhip_wbs_wrk2.priority_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.priority_order IS '개발 우선순위 (1=선행, 2=후행). 대시보드에서 수정 가능';


--
-- Name: COLUMN hhip_wbs_wrk2.plan_sdt_c; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.plan_sdt_c IS '실적시작일. 비어 있고 계획시작일이 도래하면 착수지연(#/delay)으로 집계. 화면 읽기 전용';


--
-- Name: COLUMN hhip_wbs_wrk2.plan_edt_c; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.plan_edt_c IS '실적종료일. 비어 있고 계획종료일이 도래하면 종료지연(#/delay)으로 집계. 화면 읽기 전용';


--
-- Name: COLUMN hhip_wbs_wrk2.prog_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.prog_type IS '화면 유형 — 단일그리드(CRUD) / 마스터 디테일 / 조회·리포트 전용 등';


--
-- Name: COLUMN hhip_wbs_wrk2.prog_type_desc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.prog_type_desc IS '화면 기능 요약 (조회·입고, 분류코드 CRUD 등)';


--
-- Name: COLUMN hhip_wbs_wrk2.trg_exsit_chk; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.trg_exsit_chk IS 'AS-IS 대상 테이블의 트리거 존재 여부 확인 결과';


--
-- Name: COLUMN hhip_wbs_wrk2.trg_use_chk; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.trg_use_chk IS '해당 화면에서 실제로 발화하는 트리거명과 발화 시점. 없음/미확인/확인필요 값도 사용';


--
-- Name: COLUMN hhip_wbs_wrk2.trg_evt_rel; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.trg_evt_rel IS '트리거와 연계된 이벤트(자동 후처리 시점) 설명';


--
-- Name: COLUMN hhip_wbs_wrk2.etc_desc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.etc_desc IS '기타 특이사항 (특수 기능·주의점). 없으면 — 표기';


--
-- Name: COLUMN hhip_wbs_wrk2.new_dev2; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.new_dev2 IS '실작업대상 여부';


--
-- Name: COLUMN hhip_wbs_wrk2.asis_cs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.asis_cs IS 'AS-IS 화면의 C# 소스 파일명 (예: P_30D1030_9.cs). 이관 대상 원본 추적용';


--
-- Name: COLUMN hhip_wbs_wrk2.report_use; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.report_use IS '리포트 사용';


--
-- Name: COLUMN hhip_wbs_wrk2.sheet_use; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.sheet_use IS '엑셀 사용 여부';


--
-- Name: COLUMN hhip_wbs_wrk2.dwg_view_use; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.dwg_view_use IS '도면 조회 사용 여부';


--
-- Name: COLUMN hhip_wbs_wrk2.por_view_use; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.por_view_use IS 'POR 조회 사용 여부';


--
-- Name: COLUMN hhip_wbs_wrk2.menu_desc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.menu_desc IS '화면 설명';


--
-- Name: COLUMN hhip_wbs_wrk2.mon_req_comp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.mon_req_comp IS '9월까지 완료 요청본';


--
-- Name: COLUMN hhip_wbs_wrk2.user_bp_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.user_bp_id IS '담당자 사번(BP ID). public.dev_user.bp_id 와 매칭해 성명을 표시하며, dev_user 에 없는 값은 화면에서 미할당으로 처리. 대시보드에서 수정 가능';


--
-- Name: COLUMN hhip_wbs_wrk2.complate_yn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.complate_yn IS '완료여부';


--
-- Name: COLUMN hhip_wbs_wrk2.comp_desc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.comp_desc IS '완료에따른코멘트';


--
-- Name: COLUMN hhip_wbs_wrk2.user_real_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.user_real_id IS '실제우리들의계획사용자';


--
-- Name: COLUMN hhip_wbs_wrk2.complate_real_yn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.complate_real_yn IS '우리들의 진짜 yn';


--
-- Name: COLUMN hhip_wbs_wrk2.recheck_yn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.recheck_yn IS '재확인 요청 여부 (''o'' = 개발자에게 재확인 요청)';


--
-- Name: COLUMN hhip_wbs_wrk2.db_ready_big_yn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.db_ready_big_yn IS '대형 DB 준비여부 - o = ready';


--
-- Name: COLUMN hhip_wbs_wrk2.row_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.row_uid IS '줄 식별 번호. 화면에 보이지 않고 <어느 줄인가> 를 가리키는 데만 쓴다 (첨부 폴더 이름 · 대상 수정 · Activity ID 채우기). 사람이 고치지 않는다.';


--
-- Name: COLUMN hhip_wbs_wrk2.pv_test_case_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hhip_wbs_wrk2.pv_test_case_id IS 'ProjectView 단위테스트 코드(AAC-TC###). 단위테스트 상세 화면 주소를 만드는 데 쓴다. 단위테스트 목록의 title 과 menu_nm 을 맞춰 넣는다. 수집 경로 없음 - db/pv_test_case_id.sql 로 채운다';


--
-- Name: hhip_wbs_wrk2_bak_0819_20260819; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_0819_20260819 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    ggbun text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    user_nm character varying(1000),
    new_dev character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100),
    complate_yn character varying(100),
    comp_desc character varying(2000),
    user_real_id character varying,
    complate_real_yn character varying
);


--
-- Name: hhip_wbs_wrk2_bak_20260818; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_20260818 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    ggbun text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    user_nm character varying(1000),
    new_dev character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100)
);


--
-- Name: hhip_wbs_wrk2_bak_alloc_20260818; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_alloc_20260818 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    ggbun text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    user_nm character varying(1000),
    new_dev character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100)
);


--
-- Name: hhip_wbs_wrk2_bak_complete; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_complete (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100),
    complate_yn character varying(100),
    comp_desc character varying(2000),
    user_real_id character varying,
    complate_real_yn character varying,
    recheck_yn character varying(1),
    complate_big_yn character varying(1),
    complate_real_big_yn character varying(1),
    recheck_big_yn character varying(1),
    db_ready_big_yn character varying(1)
);


--
-- Name: hhip_wbs_wrk2_bak_dbready_20260907; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_dbready_20260907 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100),
    complate_yn character varying(100),
    comp_desc character varying(2000),
    user_real_id character varying,
    complate_real_yn character varying,
    recheck_yn character varying(1),
    complate_big_yn character varying(1),
    complate_real_big_yn character varying(1),
    recheck_big_yn character varying(1),
    db_ready_big_yn character varying(1)
);


--
-- Name: hhip_wbs_wrk2_bak_dec_20260818; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_dec_20260818 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    ggbun text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    user_nm character varying(1000),
    new_dev character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100)
);


--
-- Name: hhip_wbs_wrk2_bak_dropcol_20260819; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_dropcol_20260819 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    ggbun text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    user_nm character varying(1000),
    new_dev character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100),
    complate_yn character varying(100),
    comp_desc character varying(2000),
    user_real_id character varying,
    complate_real_yn character varying
);


--
-- Name: hhip_wbs_wrk2_bak_realdone_20260825; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_realdone_20260825 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100),
    complate_yn character varying(100),
    comp_desc character varying(2000),
    user_real_id character varying,
    complate_real_yn character varying
);


--
-- Name: hhip_wbs_wrk2_bak_realid_20260818; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_realid_20260818 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    ggbun text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    user_nm character varying(1000),
    new_dev character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100),
    complate_yn character varying(100),
    comp_desc character varying(2000),
    user_real_id character varying,
    complate_real_yn character varying
);


--
-- Name: hhip_wbs_wrk2_bak_realid_20260819; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_realid_20260819 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    ggbun text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    user_nm character varying(1000),
    new_dev character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100),
    complate_yn character varying(100),
    comp_desc character varying(2000),
    user_real_id character varying,
    complate_real_yn character varying
);


--
-- Name: hhip_wbs_wrk2_bak_realid_20260825; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_realid_20260825 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100),
    complate_yn character varying(100),
    comp_desc character varying(2000),
    user_real_id character varying,
    complate_real_yn character varying
);


--
-- Name: hhip_wbs_wrk2_bak_wbs02_20260818; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_wbs02_20260818 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    ggbun text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    user_nm character varying(1000),
    new_dev character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100)
);


--
-- Name: hhip_wbs_wrk2_bak_wbs03_20260818; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hhip_wbs_wrk2_bak_wbs03_20260818 (
    module character varying(50),
    module_name text,
    systemcode text,
    system_nm text,
    ggbun text,
    program_id text,
    menu_nm character varying(50),
    comment text,
    activity_id character varying(50),
    plan_sdt date,
    plan_edt date,
    priority_order character varying(50),
    plan_sdt_c date,
    plan_edt_c date,
    prog_type character varying(1000),
    prog_type_desc character varying(1000),
    trg_exsit_chk character varying(1000),
    trg_use_chk character varying(1000),
    trg_evt_rel character varying(1000),
    etc_desc character varying(1000),
    user_nm character varying(1000),
    new_dev character varying(1000),
    new_dev2 character varying(1000),
    asis_cs character varying(1000),
    report_use character varying(1000),
    sheet_use character varying,
    dwg_view_use character varying(100),
    por_view_use character varying(100),
    menu_desc character varying(2000),
    mon_req_comp character varying(100),
    user_bp_id character varying(100),
    complate_yn character varying(100),
    comp_desc character varying(2000),
    user_real_id character varying,
    complate_real_yn character varying
);


--
-- Name: hhip_wbs_wrk2_row_uid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.hhip_wbs_wrk2 ALTER COLUMN row_uid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.hhip_wbs_wrk2_row_uid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: if_attr; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.if_attr (
    attr_id integer NOT NULL,
    if_id integer NOT NULL,
    attr_def_id integer NOT NULL,
    attr_val text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(50),
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(50)
);


--
-- Name: TABLE if_attr; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.if_attr IS '추가 관리항목의 값';


--
-- Name: if_attr_attr_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.if_attr_attr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: if_attr_attr_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.if_attr_attr_id_seq OWNED BY public.if_attr.attr_id;


--
-- Name: if_attr_def; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.if_attr_def (
    attr_def_id integer NOT NULL,
    attr_cd character varying(50) NOT NULL,
    attr_nm character varying(100) NOT NULL,
    attr_type character varying(20) DEFAULT 'TEXT'::character varying NOT NULL,
    code_grp character varying(30),
    required_yn character varying(1) DEFAULT 'N'::character varying NOT NULL,
    default_val text,
    attr_desc text,
    sort_order integer DEFAULT 0 NOT NULL,
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT if_attr_def_attr_type_check CHECK (((attr_type)::text = ANY ((ARRAY['TEXT'::character varying, 'NUMBER'::character varying, 'DATE'::character varying, 'YN'::character varying, 'CODE'::character varying, 'JSON'::character varying])::text[]))),
    CONSTRAINT if_attr_def_required_yn_check CHECK (((required_yn)::text = ANY ((ARRAY['Y'::character varying, 'N'::character varying])::text[]))),
    CONSTRAINT if_attr_def_use_yn_check CHECK (((use_yn)::text = ANY ((ARRAY['Y'::character varying, 'N'::character varying])::text[])))
);


--
-- Name: TABLE if_attr_def; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.if_attr_def IS '추가 관리항목의 정의. 대시보드가 이걸 읽어 입력폼을 만든다';


--
-- Name: if_attr_def_attr_def_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.if_attr_def_attr_def_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: if_attr_def_attr_def_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.if_attr_def_attr_def_id_seq OWNED BY public.if_attr_def.attr_def_id;


--
-- Name: if_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.if_code (
    code_id integer NOT NULL,
    code_grp character varying(30) NOT NULL,
    code character varying(30) NOT NULL,
    code_nm character varying(100) NOT NULL,
    code_desc text,
    sort_order integer DEFAULT 0 NOT NULL,
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT if_code_use_yn_check CHECK (((use_yn)::text = ANY ((ARRAY['Y'::character varying, 'N'::character varying])::text[])))
);


--
-- Name: TABLE if_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.if_code IS '인터페이스 카탈로그 공통코드';


--
-- Name: COLUMN if_code.code_grp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.if_code.code_grp IS '코드 그룹 (IF_STATUS/IF_DIRECTION/STEP_TYPE/OBJECT_TYPE/IF_CYCLE/SYSTEM_KIND/NOTE_TYPE/ATTR_TYPE)';


--
-- Name: if_code_code_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.if_code_code_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: if_code_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.if_code_code_id_seq OWNED BY public.if_code.code_id;


--
-- Name: if_master; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.if_master (
    if_id integer NOT NULL,
    if_cd character varying(30) NOT NULL,
    if_nm character varying(200) NOT NULL,
    if_desc text,
    direction_cd character varying(30),
    src_system_id integer,
    tgt_system_id integer,
    domain_cd character varying(30),
    trigger_cd character varying(30),
    cycle_cd character varying(30),
    status_cd character varying(30) DEFAULT 'DESIGN'::character varying NOT NULL,
    owner_nm character varying(50),
    owner_bp_id character varying(50),
    plan_sdt date,
    plan_edt date,
    open_dt date,
    remark text,
    ext jsonb DEFAULT '{}'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(50),
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(50),
    CONSTRAINT if_master_use_yn_check CHECK (((use_yn)::text = ANY ((ARRAY['Y'::character varying, 'N'::character varying])::text[])))
);


--
-- Name: TABLE if_master; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.if_master IS '인터페이스 기본정보. 처리 단계는 if_step 에 둔다';


--
-- Name: COLUMN if_master.if_cd; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.if_master.if_cd IS '인터페이스 코드. 프로그램이 남기는 IF_ID 와 같은 값을 쓴다 (예: HHIP-IF-01)';


--
-- Name: COLUMN if_master.ext; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.if_master.ext IS '정형화되지 않은 추가 값. 항목을 정식으로 관리하려면 if_attr_def 를 쓴다';


--
-- Name: if_master_if_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.if_master_if_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: if_master_if_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.if_master_if_id_seq OWNED BY public.if_master.if_id;


--
-- Name: if_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.if_note (
    note_id integer NOT NULL,
    if_id integer NOT NULL,
    step_id integer,
    note_type_cd character varying(30) DEFAULT 'MEMO'::character varying NOT NULL,
    title character varying(200),
    content text DEFAULT ''::text NOT NULL,
    writer_nm character varying(50),
    note_dt date DEFAULT CURRENT_DATE NOT NULL,
    done_yn character varying(1) DEFAULT 'N'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    ext jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(50),
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(50),
    CONSTRAINT if_note_done_yn_check CHECK (((done_yn)::text = ANY ((ARRAY['Y'::character varying, 'N'::character varying])::text[])))
);


--
-- Name: TABLE if_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.if_note IS '인터페이스별 메모/이슈/변경이력. step_id 를 채우면 특정 단계에 붙는다';


--
-- Name: if_note_note_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.if_note_note_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: if_note_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.if_note_note_id_seq OWNED BY public.if_note.note_id;


--
-- Name: if_step; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.if_step (
    step_id integer NOT NULL,
    if_id integer NOT NULL,
    step_no integer NOT NULL,
    step_nm character varying(200),
    step_type_cd character varying(30),
    system_id integer,
    object_owner character varying(50),
    object_nm character varying(200),
    object_type character varying(30),
    step_desc text,
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    ext jsonb DEFAULT '{}'::jsonb NOT NULL,
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(50),
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(50),
    CONSTRAINT if_step_use_yn_check CHECK (((use_yn)::text = ANY ((ARRAY['Y'::character varying, 'N'::character varying])::text[])))
);


--
-- Name: TABLE if_step; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.if_step IS '인터페이스 처리 단계. 순서는 step_no 가 정한다';


--
-- Name: COLUMN if_step.params; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.if_step.params IS '파라미터 규격. 예: {"in":[{"name":"P_IFSEQ",...}],"out":[...]}';


--
-- Name: if_step_step_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.if_step_step_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: if_step_step_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.if_step_step_id_seq OWNED BY public.if_step.step_id;


--
-- Name: if_system; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.if_system (
    system_id integer NOT NULL,
    system_cd character varying(30) NOT NULL,
    system_nm character varying(100) NOT NULL,
    system_kind character varying(30),
    host character varying(100),
    port integer,
    db_nm character varying(100),
    schema_nm character varying(100),
    system_desc text,
    ext jsonb DEFAULT '{}'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(50),
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(50),
    CONSTRAINT if_system_use_yn_check CHECK (((use_yn)::text = ANY ((ARRAY['Y'::character varying, 'N'::character varying])::text[])))
);


--
-- Name: TABLE if_system; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.if_system IS '연계 대상 시스템/DB. 비밀번호는 보관하지 않는다';


--
-- Name: if_system_system_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.if_system_system_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: if_system_system_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.if_system_system_id_seq OWNED BY public.if_system.system_id;


--
-- Name: v_if_attr; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_if_attr AS
 SELECT m.if_id,
    m.if_cd,
    d.attr_def_id,
    d.attr_cd,
    d.attr_nm,
    d.attr_type,
    d.code_grp,
    d.required_yn,
    COALESCE(a.attr_val, d.default_val) AS attr_val,
    d.sort_order,
    a.updated_at,
    a.updated_by
   FROM ((public.if_master m
     CROSS JOIN public.if_attr_def d)
     LEFT JOIN public.if_attr a ON (((a.if_id = m.if_id) AND (a.attr_def_id = d.attr_def_id))))
  WHERE ((d.use_yn)::text = 'Y'::text);


--
-- Name: v_if_flow; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_if_flow AS
 SELECT m.if_id,
    m.if_cd,
    m.if_nm,
    string_agg(((s.step_no || '. '::text) ||
        CASE
            WHEN (s.object_owner IS NULL) THEN (COALESCE(s.object_nm, s.step_nm, ''::character varying))::text
            ELSE (((s.object_owner)::text || '.'::text) || (s.object_nm)::text)
        END), '  →  '::text ORDER BY s.step_no) AS flow
   FROM (public.if_master m
     LEFT JOIN public.if_step s ON (((s.if_id = m.if_id) AND ((s.use_yn)::text = 'Y'::text))))
  GROUP BY m.if_id, m.if_cd, m.if_nm;


--
-- Name: v_if_master; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_if_master AS
 SELECT m.if_id,
    m.if_cd,
    m.if_nm,
    m.domain_cd,
    m.direction_cd,
    cd.code_nm AS direction_nm,
    ss.system_nm AS src_system_nm,
    ts.system_nm AS tgt_system_nm,
    m.status_cd,
    cs.code_nm AS status_nm,
    m.cycle_cd,
    cc.code_nm AS cycle_nm,
    m.owner_nm,
    m.plan_sdt,
    m.plan_edt,
    m.open_dt,
    ( SELECT count(*) AS count
           FROM public.if_step s
          WHERE ((s.if_id = m.if_id) AND ((s.use_yn)::text = 'Y'::text))) AS step_cnt,
    ( SELECT count(*) AS count
           FROM public.if_note n
          WHERE (n.if_id = m.if_id)) AS note_cnt,
    ( SELECT count(*) AS count
           FROM public.if_note n
          WHERE ((n.if_id = m.if_id) AND ((n.note_type_cd)::text = 'ISSUE'::text) AND ((n.done_yn)::text = 'N'::text))) AS open_issue_cnt,
    m.remark,
    m.ext,
    m.use_yn,
    m.sort_order,
    m.updated_at,
    m.updated_by
   FROM (((((public.if_master m
     LEFT JOIN public.if_system ss ON ((ss.system_id = m.src_system_id)))
     LEFT JOIN public.if_system ts ON ((ts.system_id = m.tgt_system_id)))
     LEFT JOIN public.if_code cd ON ((((cd.code_grp)::text = 'IF_DIRECTION'::text) AND ((cd.code)::text = (m.direction_cd)::text))))
     LEFT JOIN public.if_code cs ON ((((cs.code_grp)::text = 'IF_STATUS'::text) AND ((cs.code)::text = (m.status_cd)::text))))
     LEFT JOIN public.if_code cc ON ((((cc.code_grp)::text = 'IF_CYCLE'::text) AND ((cc.code)::text = (m.cycle_cd)::text))));


--
-- Name: v_if_step; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_if_step AS
 SELECT s.step_id,
    s.if_id,
    m.if_cd,
    m.if_nm,
    s.step_no,
    s.step_nm,
    s.step_type_cd,
    ct.code_nm AS step_type_nm,
    sy.system_nm,
    s.object_owner,
    s.object_nm,
        CASE
            WHEN (s.object_owner IS NULL) THEN (s.object_nm)::text
            ELSE (((s.object_owner)::text || '.'::text) || (s.object_nm)::text)
        END AS object_full_nm,
    s.object_type,
    s.step_desc,
    s.params,
    s.ext,
    s.use_yn,
    s.updated_at
   FROM (((public.if_step s
     JOIN public.if_master m ON ((m.if_id = s.if_id)))
     LEFT JOIN public.if_system sy ON ((sy.system_id = s.system_id)))
     LEFT JOIN public.if_code ct ON ((((ct.code_grp)::text = 'STEP_TYPE'::text) AND ((ct.code)::text = (s.step_type_cd)::text))));


--
-- Name: dev_doc_files id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_doc_files ALTER COLUMN id SET DEFAULT nextval('public.dev_doc_files_id_seq'::regclass);


--
-- Name: dev_docs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_docs ALTER COLUMN id SET DEFAULT nextval('public.dev_docs_id_seq'::regclass);


--
-- Name: dev_menu_folder folder_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_menu_folder ALTER COLUMN folder_id SET DEFAULT nextval('public.dev_menu_folder_folder_id_seq'::regclass);


--
-- Name: hhip_wbs_task task_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hhip_wbs_task ALTER COLUMN task_id SET DEFAULT nextval('public.hhip_wbs_task_task_id_seq'::regclass);


--
-- Name: if_attr attr_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_attr ALTER COLUMN attr_id SET DEFAULT nextval('public.if_attr_attr_id_seq'::regclass);


--
-- Name: if_attr_def attr_def_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_attr_def ALTER COLUMN attr_def_id SET DEFAULT nextval('public.if_attr_def_attr_def_id_seq'::regclass);


--
-- Name: if_code code_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_code ALTER COLUMN code_id SET DEFAULT nextval('public.if_code_code_id_seq'::regclass);


--
-- Name: if_master if_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_master ALTER COLUMN if_id SET DEFAULT nextval('public.if_master_if_id_seq'::regclass);


--
-- Name: if_note note_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_note ALTER COLUMN note_id SET DEFAULT nextval('public.if_note_note_id_seq'::regclass);


--
-- Name: if_step step_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_step ALTER COLUMN step_id SET DEFAULT nextval('public.if_step_step_id_seq'::regclass);


--
-- Name: if_system system_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_system ALTER COLUMN system_id SET DEFAULT nextval('public.if_system_system_id_seq'::regclass);


--
-- Name: dev_doc_files dev_doc_files_doc_id_file_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_doc_files
    ADD CONSTRAINT dev_doc_files_doc_id_file_key UNIQUE (doc_id, file);


--
-- Name: dev_doc_files dev_doc_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_doc_files
    ADD CONSTRAINT dev_doc_files_pkey PRIMARY KEY (id);


--
-- Name: dev_docs dev_docs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_docs
    ADD CONSTRAINT dev_docs_pkey PRIMARY KEY (id);


--
-- Name: dev_menu_folder dev_menu_folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_menu_folder
    ADD CONSTRAINT dev_menu_folder_pkey PRIMARY KEY (folder_id);


--
-- Name: dev_menu dev_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_menu
    ADD CONSTRAINT dev_menu_pkey PRIMARY KEY (menu_key);


--
-- Name: dev_user_menu dev_user_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_user_menu
    ADD CONSTRAINT dev_user_menu_pkey PRIMARY KEY (bp_id, menu_key);


--
-- Name: dev_user_pref dev_user_pref_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_user_pref
    ADD CONSTRAINT dev_user_pref_pkey PRIMARY KEY (bp_id, pref_key);


--
-- Name: hhip_lship_change hhip_lship_change_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hhip_lship_change
    ADD CONSTRAINT hhip_lship_change_pkey PRIMARY KEY (chg_id);


--
-- Name: hhip_test_fail hhip_test_fail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hhip_test_fail
    ADD CONSTRAINT hhip_test_fail_pkey PRIMARY KEY (fail_id);


--
-- Name: hhip_wbs_pv_node hhip_wbs_pv_node_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hhip_wbs_pv_node
    ADD CONSTRAINT hhip_wbs_pv_node_pkey PRIMARY KEY (pv_task_id, node_no);


--
-- Name: hhip_wbs_pv hhip_wbs_pv_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hhip_wbs_pv
    ADD CONSTRAINT hhip_wbs_pv_pkey PRIMARY KEY (activity_id);


--
-- Name: hhip_wbs_pv_task hhip_wbs_pv_task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hhip_wbs_pv_task
    ADD CONSTRAINT hhip_wbs_pv_task_pkey PRIMARY KEY (pv_task_id);


--
-- Name: hhip_wbs_task hhip_wbs_task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hhip_wbs_task
    ADD CONSTRAINT hhip_wbs_task_pkey PRIMARY KEY (task_id);


--
-- Name: if_attr_def if_attr_def_attr_cd_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_attr_def
    ADD CONSTRAINT if_attr_def_attr_cd_key UNIQUE (attr_cd);


--
-- Name: if_attr_def if_attr_def_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_attr_def
    ADD CONSTRAINT if_attr_def_pkey PRIMARY KEY (attr_def_id);


--
-- Name: if_attr if_attr_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_attr
    ADD CONSTRAINT if_attr_pkey PRIMARY KEY (attr_id);


--
-- Name: if_code if_code_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_code
    ADD CONSTRAINT if_code_pkey PRIMARY KEY (code_id);


--
-- Name: if_master if_master_if_cd_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_master
    ADD CONSTRAINT if_master_if_cd_key UNIQUE (if_cd);


--
-- Name: if_master if_master_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_master
    ADD CONSTRAINT if_master_pkey PRIMARY KEY (if_id);


--
-- Name: if_note if_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_note
    ADD CONSTRAINT if_note_pkey PRIMARY KEY (note_id);


--
-- Name: if_step if_step_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_step
    ADD CONSTRAINT if_step_pkey PRIMARY KEY (step_id);


--
-- Name: if_system if_system_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_system
    ADD CONSTRAINT if_system_pkey PRIMARY KEY (system_id);


--
-- Name: if_system if_system_system_cd_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_system
    ADD CONSTRAINT if_system_system_cd_key UNIQUE (system_cd);


--
-- Name: if_attr uk_if_attr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_attr
    ADD CONSTRAINT uk_if_attr UNIQUE (if_id, attr_def_id);


--
-- Name: if_code uk_if_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_code
    ADD CONSTRAINT uk_if_code UNIQUE (code_grp, code);


--
-- Name: if_step uk_if_step; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_step
    ADD CONSTRAINT uk_if_step UNIQUE (if_id, step_no);


--
-- Name: hhip_wbs_wrk2_row_uid_uk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hhip_wbs_wrk2_row_uid_uk ON public.hhip_wbs_wrk2 USING btree (row_uid);


--
-- Name: ix_dev_doc_files_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dev_doc_files_doc ON public.dev_doc_files USING btree (doc_id, sort_order, id);


--
-- Name: ix_dev_menu_folder; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dev_menu_folder ON public.dev_menu USING btree (folder_id);


--
-- Name: ix_dev_user_menu_bp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dev_user_menu_bp ON public.dev_user_menu USING btree (bp_id);


--
-- Name: ix_hhip_lship_change_drop; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hhip_lship_change_drop ON public.hhip_lship_change USING btree (drop_yn);


--
-- Name: ix_hhip_lship_change_sdt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hhip_lship_change_sdt ON public.hhip_lship_change USING btree (req_sdt DESC NULLS LAST);


--
-- Name: ix_hhip_wbs_pv_node_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hhip_wbs_pv_node_task ON public.hhip_wbs_pv_node USING btree (pv_task_id);


--
-- Name: ix_hhip_wbs_pv_task_act; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hhip_wbs_pv_task_act ON public.hhip_wbs_pv_task USING btree (activity_id);


--
-- Name: ix_hhip_wbs_pv_task_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hhip_wbs_pv_task_code ON public.hhip_wbs_pv_task USING btree (pv_task_code);


--
-- Name: ix_hhip_wbs_pv_work; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hhip_wbs_pv_work ON public.hhip_wbs_pv USING btree (pv_work_id);


--
-- Name: ix_hhip_wbs_task_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hhip_wbs_task_activity ON public.hhip_wbs_task USING btree (activity_id);


--
-- Name: ix_hhip_wbs_task_done; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hhip_wbs_task_done ON public.hhip_wbs_task USING btree (activity_id, done_yn);


--
-- Name: ix_if_master_01; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_if_master_01 ON public.if_master USING btree (status_cd);


--
-- Name: ix_if_master_02; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_if_master_02 ON public.if_master USING btree (domain_cd);


--
-- Name: ix_if_master_03; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_if_master_03 ON public.if_master USING gin (ext);


--
-- Name: ix_if_note_01; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_if_note_01 ON public.if_note USING btree (if_id, note_dt DESC);


--
-- Name: ix_if_step_01; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_if_step_01 ON public.if_step USING btree (if_id, step_no);


--
-- Name: ix_if_step_02; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_if_step_02 ON public.if_step USING btree (object_owner, object_nm);


--
-- Name: ux_hhip_test_fail_seq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_hhip_test_fail_seq ON public.hhip_test_fail USING btree (seq);


--
-- Name: if_attr_def tg_if_attr_def_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tg_if_attr_def_upd BEFORE UPDATE ON public.if_attr_def FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: if_attr tg_if_attr_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tg_if_attr_upd BEFORE UPDATE ON public.if_attr FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: if_code tg_if_code_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tg_if_code_upd BEFORE UPDATE ON public.if_code FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: if_master tg_if_master_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tg_if_master_upd BEFORE UPDATE ON public.if_master FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: if_note tg_if_note_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tg_if_note_upd BEFORE UPDATE ON public.if_note FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: if_step tg_if_step_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tg_if_step_upd BEFORE UPDATE ON public.if_step FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: if_system tg_if_system_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tg_if_system_upd BEFORE UPDATE ON public.if_system FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: dev_doc_files dev_doc_files_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_doc_files
    ADD CONSTRAINT dev_doc_files_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.dev_docs(id) ON DELETE CASCADE;


--
-- Name: dev_menu fk_dev_menu_folder; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dev_menu
    ADD CONSTRAINT fk_dev_menu_folder FOREIGN KEY (folder_id) REFERENCES public.dev_menu_folder(folder_id) ON DELETE SET NULL;


--
-- Name: if_attr if_attr_attr_def_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_attr
    ADD CONSTRAINT if_attr_attr_def_id_fkey FOREIGN KEY (attr_def_id) REFERENCES public.if_attr_def(attr_def_id) ON DELETE CASCADE;


--
-- Name: if_attr if_attr_if_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_attr
    ADD CONSTRAINT if_attr_if_id_fkey FOREIGN KEY (if_id) REFERENCES public.if_master(if_id) ON DELETE CASCADE;


--
-- Name: if_master if_master_src_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_master
    ADD CONSTRAINT if_master_src_system_id_fkey FOREIGN KEY (src_system_id) REFERENCES public.if_system(system_id);


--
-- Name: if_master if_master_tgt_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_master
    ADD CONSTRAINT if_master_tgt_system_id_fkey FOREIGN KEY (tgt_system_id) REFERENCES public.if_system(system_id);


--
-- Name: if_note if_note_if_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_note
    ADD CONSTRAINT if_note_if_id_fkey FOREIGN KEY (if_id) REFERENCES public.if_master(if_id) ON DELETE CASCADE;


--
-- Name: if_note if_note_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_note
    ADD CONSTRAINT if_note_step_id_fkey FOREIGN KEY (step_id) REFERENCES public.if_step(step_id) ON DELETE SET NULL;


--
-- Name: if_step if_step_if_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_step
    ADD CONSTRAINT if_step_if_id_fkey FOREIGN KEY (if_id) REFERENCES public.if_master(if_id) ON DELETE CASCADE;


--
-- Name: if_step if_step_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.if_step
    ADD CONSTRAINT if_step_system_id_fkey FOREIGN KEY (system_id) REFERENCES public.if_system(system_id);


--
-- PostgreSQL database dump complete
--

\unrestrict x1LCXeK4NbnA0pEkeA20Ji5e2O8XiXo2WyKkU889m3s9VDN9RPsfnO83IQZccBU

