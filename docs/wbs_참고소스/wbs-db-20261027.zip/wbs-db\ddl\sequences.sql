-- WBS 시퀀스 현재값 되맞추기
-- data/json/ 쪽으로 자료를 넣었을 때만 필요하다.
-- data/sql/data_inserts.sql 을 돌렸다면 거기에 이미 들어 있다.

SELECT pg_catalog.setval('public.dev_doc_files_id_seq', 16, true);
SELECT pg_catalog.setval('public.dev_docs_id_seq', 33, true);
SELECT pg_catalog.setval('public.dev_menu_folder_folder_id_seq', 13, true);
SELECT pg_catalog.setval('public.hhip_lship_change_chg_id_seq', 35, true);
SELECT pg_catalog.setval('public.hhip_test_fail_fail_id_seq', 62, true);
SELECT pg_catalog.setval('public.hhip_wbs_task_task_id_seq', 3870, true);
SELECT pg_catalog.setval('public.hhip_wbs_wrk2_row_uid_seq', 217, true);
SELECT pg_catalog.setval('public.if_attr_attr_id_seq', 5, true);
SELECT pg_catalog.setval('public.if_attr_def_attr_def_id_seq', 6, true);
SELECT pg_catalog.setval('public.if_code_code_id_seq', 87, true);
SELECT pg_catalog.setval('public.if_master_if_id_seq', 9, true);
SELECT pg_catalog.setval('public.if_note_note_id_seq', 22, true);
SELECT pg_catalog.setval('public.if_step_step_id_seq', 19, true);
SELECT pg_catalog.setval('public.if_system_system_id_seq', 6, true);
