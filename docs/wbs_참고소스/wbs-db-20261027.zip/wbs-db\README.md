# WBS 대시보드 — DB 보관본 (PostgreSQL)

사내 개발 PC 의 `Host=localhost;Port=5432;Database=postgres` 에서 **읽기만 해서** 뜬 것이다.
`public` 스키마 전부 — 표 36 · 줄 9,411 · 뷰 4 · 함수 1 · 시퀀스 11.

뜬 날짜는 `manifest.json` 의 `generated` 에 있다.

## 들어 있는 것

```
ddl/schema.sql              표·뷰·함수·시퀀스·인덱스·제약·트리거 (pg_dump --schema-only)
ddl/sequences.sql           시퀀스 14개의 현재값 (JSON 으로 넣었을 때만 쓴다)
data/sql/data_inserts.sql   전체 자료를 INSERT 문으로 (pg_dump --data-only --column-inserts)
data/json/<표>.json         표별 자료 — 한 줄에 한 칸, 칸 차례는 원본 그대로
data/json/_bak/<표>.json    작업용 백업표 13개 (복원할 때 넣지 않아도 된다)
manifest.json               표별 건수·칸 목록, 뷰·함수·시퀀스 목록, 서버 판
```

`ddl/schema.sql` 과 `data/sql/data_inserts.sql` 이 **복원용 한 쌍**이고,
`data/json/` 은 **다른 데서 가져다 쓰기 좋으라고** 같은 자료를 한 번 더 담은 것이다.
둘 중 하나만 써도 된다 — 같은 내용이다.

## 세우는 법

```bash
createdb -h <host> -U postgres wbs
psql -h <host> -U postgres -d wbs -f ddl/schema.sql
psql -h <host> -U postgres -d wbs -f data/sql/data_inserts.sql
```

Windows 에서는 psql 이 PATH 에 없을 수 있다 — 전체 경로로 부른다.
한글이 들어간 SQL 은 **반드시 `-f` 로 넘긴다.** `-c "..."` 로 넣으면 콘솔 코드페이지 탓에
`"UTF8" 인코딩에서 사용할 수 없는 문자가 있음` 으로 거절당한다(쿼리는 멀쩡한데도 그렇다).

```
"C:\Program Files\PostgreSQL\18\bin\psql.exe" -h localhost -U postgres -d wbs -f ddl\schema.sql
```

다 넣었으면 `api/appsettings.json` 의 접속 문자열을 그 DB 로 맞춘다.

```
ConnectionStrings:Wbs = Host=...;Port=5432;Database=wbs;Username=...;Password=...
```

### 시퀀스

**위의 두 줄로 넣었으면 할 일이 없다.** `data_inserts.sql` 끝에 `setval` 14줄이 이미 들어 있다.

**`data/json/` 쪽으로 자료를 넣었다면** 시퀀스가 1 에 멈춰 있다 — 반드시 따로 맞춘다.
안 맞추면 다음 INSERT 가 **키 중복으로 터진다.**

```bash
psql -h <host> -U postgres -d wbs -f ddl/sequences.sql
```

시퀀스는 14개다. `information_schema.sequences` 로 세면 11개로 나오는데,
identity 칸(`hhip_lship_change.chg_id` · `hhip_test_fail.fail_id` · `hhip_wbs_wrk2.row_uid`)
셋이 거기 안 잡히기 때문이다 — 속지 말 것. `manifest.json` 의 `sequences` 는 14개 전부다.

## ⚠ 이 압축만으로는 화면이 다 차지 않는다

**DB 에는 파일 이름만 있고 실물은 디스크에 있다.** 소스 압축의 `api/data/` 를 같이 풀어야 한다.

| DB 표 | 실물이 있는 곳 (소스 압축) |
|---|---|
| `dev_doc_files` | `api/data/doc_files/` |
| `if_*` 첨부 | `api/data/if_files/` |
| 행 첨부 | `api/data/row_files/` |
| 올린 파일 | `api/data/uploads/` |

도식(`#/tables2` 의 업무항목·도면)은 **DB 가 아니라 파일**이다 — `api/data/vueflow/`.

## ⚠ 담긴 자료에 대하여

- **`dev_user` (9줄) 에 개인정보가 있다** — 성명·전화·비상연락처·접속 IP·MAC·장비번호.
  외부로 옮기기 전에 반드시 검토할 것. 빼고 세워도 앱은 돈다
  (`dev_user` 가 0건이면 `IpGate` 가 **전체 허용**으로 연다 — 처음부터 잠기지 않는다).
- **`dev_user_menu` (79줄) 는 권한**이다. `dev_user` 를 빼면 같이 빼야 뜻이 맞는다.
- `hhip_wbs_wrk2_bak_*` 13개는 작업하다 떠 둔 사본이다. 앱은 보지 않는다.
- `hhip_wbs` (203) · `hhip_wbs_wrk` (203) 은 앱이 어디서도 참조하지 않는 **옛 표**다.
  스키마에는 있으니 그대로 담았다.

## 참고 — `db/install/wbs_install.sql` 과 무엇이 다른가

소스 쪽 `db/install/wbs_install.sql` 은 **외부 배포용**이라 개인정보와 업무자료를 일부러 뺐고
표 17개만 담는다. 이 보관본은 **지금 돌고 있는 DB 를 통째로** 뜬 것이다 — 성격이 다르다.
처음 세우는 것이 목적이면 그쪽이, 지금 상태를 그대로 옮기는 것이 목적이면 이쪽이 맞다.

## 보관하면서 손댄 곳 · 옛 psql 함정

- **`ddl/schema.sql` 의 `CREATE SCHEMA public;` 을 `CREATE SCHEMA IF NOT EXISTS public;` 으로 고쳤다.**
  `pg_dump` 가 그대로 뱉는데, 새로 만든 DB 에도 `public` 은 이미 있으므로
  `-v ON_ERROR_STOP=1` 로 돌리면 **거기서 멈춘다.** 고친 자리에 표시를 남겨 두었다.
- **`schema.sql` 머리에 `\restrict ...` 줄이 있다.** PostgreSQL 17.6 / 18 에서 생긴 psql 명령이라
  **그보다 옛 psql 로 돌리면 `invalid command \restrict` 가 난다.** 그 줄과 끝의 `\unrestrict`
  줄을 지우면 된다(덤프 내용 자체와는 상관없다).

## 이 보관본이 맞는지 확인한 방법

빈 DB(`wbs_archive_test`)를 새로 만들어 `schema.sql` → `data_inserts.sql` 을 돌리고,
**원본 DB 와 한 건씩 맞춰 보았다. 전부 같았다.**

```
표 36 (줄 수 전부 일치) · 뷰 4 · 함수 1 · 시퀀스 14 (현재값까지 일치)
인덱스 45 · 제약 139 · 트리거 7
```

확인이 끝난 뒤 시험 DB 는 지웠다.
