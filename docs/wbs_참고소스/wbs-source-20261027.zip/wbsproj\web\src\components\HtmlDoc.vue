<script setup>
import { ref } from 'vue'

// 별도로 만들어 둔 단일 HTML 문서를 그대로 싣는 화면.
// 문서가 목차·다크모드·인쇄·줌을 스스로 갖고 있어 Vue 로 옮기지 않고 iframe 으로 띄운다.
const props = defineProps({
  src: { type: String, required: true },      // 예: /p30/flow.html
  title: { type: String, required: true },
  hint: { type: String, default: '' },
  srcPath: { type: String, default: '' },     // 원본 위치 (복사본임을 밝히기 위해)
})

const key = ref(0) // 값을 바꿔 iframe 을 다시 만들어 새로 읽게 한다

function reload() {
  key.value += 1
}
function openTab() {
  window.open(props.src, '_blank', 'noopener')
}
</script>

<template>
  <div class="panel wrap">
    <h2>
      {{ title }}
      <span v-if="hint" class="hint">{{ hint }}</span>
      <span class="sp"></span>
      <button class="rf" title="문서를 다시 읽는다" @click="reload">⟳ 새로고침</button>
      <button class="rf" title="새 탭에서 전체 화면으로 (인쇄·PDF 는 여기서 Ctrl+P)" @click="openTab">
        ↗ 새 탭
      </button>
    </h2>

    <iframe :key="key" class="doc" :src="src" :title="title" loading="lazy"></iframe>

    <p v-if="srcPath" class="src">
      원본 <code>{{ srcPath }}</code> 의 복사본 — 원본이 바뀌면 다시 복사해야 한다
    </p>
  </div>
</template>

<style scoped>
/* 본문 칸 높이를 그대로 받아 문서가 바닥까지 차게 한다 (창 높이로 재지 않는다) */
/* .panel 의 아래 여백(14px)까지 더해지면 딱 그만큼 넘쳐 스크롤바가 하나 더 생긴다 */
.wrap.panel { display: flex; flex-direction: column; height: 100%; margin-bottom: 0; }
h2 { display: flex; align-items: center; gap: 8px; }
h2 .hint { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
h2 .sp { flex: 1; }
.rf { white-space: nowrap; }

.doc {
  width: 100%;
  /* 헤더·패널 여백을 뺀 나머지를 모두 쓴다.
     ⚠️ 100vh 로 재면 안 된다 — 이 문서가 놓이는 곳은 창 전체가 아니라 <탭 줄 아래 본문 칸>
     이라, 창 높이로 재면 탭 줄과 아래 여백만큼 넘쳐 본문에 스크롤바가 하나 더 생긴다. */
  flex: 1 1 auto;
  min-height: 360px;
  border: 1px solid var(--line);
  border-radius: var(--radius);
  background: var(--panel);
  display: block;
}
.src { margin: 8px 0 0; font-size: 11px; color: var(--muted); }
</style>
