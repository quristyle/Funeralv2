using System.Text.Json;

namespace WbsApi;

/// <summary>
/// 현지 POR I/F 후행처리 — [현지 POR 후행처리] 화면(#/locpor).
///
/// SAP 이 보낸 현지 POR 을 EAI 가 <c>SST02.Z_PD_C_LOCPOR</c> 에 적재한 뒤,
/// <b>EAI 가 이어서 부르는</b> 것이 <c>M20.PKG_PD_LOCPOR_IF.SP_LOCPOR_AFTER_INSERT</c> 다.
/// 개발 중에는 그 <b>뒷부분만 따로</b> 돌려 봐야 한다 — SAP 에 다시 보내 달라고 할 수도,
/// 수신표에 줄을 또 넣을 수도 없기 때문이다. 이 화면이 그 자리를 사람 손으로 대신 누른다.
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>왜 따로 붙지 않고 세션 정리(OraKill)의 연결을 빌려 쓰나.</b>
/// 개발 DB 는 processes 가 늘 차 있어 <b>새 접속이 거절</b>된다(README · OraKill.cs 머리말).
/// 화면마다 새로 붙으면 자리를 더 먹고, 정작 필요할 때 안 열린다. 그래서 대시보드가
/// 쥐고 있는 연결 하나를 같이 쓴다 — <c>OraKill.CallAsync</c>.
///
/// <b>⚠️ 문장을 보내지 않는다.</b> SQL 도 호출문도 <c>tools/orasession/OraPool.java</c> 안에
/// 박혀 있다. 그 연결은 DBA 권한으로 도는 것이라, 밖에서 문장을 받게 만들면 그 권한이
/// 통째로 새어 나간다. 여기서 넘기는 것은 <b>어느 IFSEQ 인가</b> 하나뿐이다.
///
/// <b>⚠️ 값에 빈칸을 넣어 보내면 안 된다.</b> 상주 프로그램은 명령 한 줄을 공백으로 쪼개
/// <c>key=value</c> 로 읽는다. 빈칸이 섞이면 뒷부분이 조용히 버려진다 — 오류가 나지 않는다.
/// 그래서 여기서 글자를 미리 걸러 낸다(<see cref="Key"/>).
///
/// <b>막는 것은 IP 게이트까지다.</b> 등록된 사람이면 누구나 누를 수 있다 — 개발 중 수신분을
/// 되돌려 보는 것이 이 화면의 용도라서다. 대신 <b>누가 언제 무엇을 눌렀는지</b>는 두 군데
/// 남는다: <c>logs/api.log</c> 와 DB 의 <c>M20.Z_PD_IF_CALL_LOG</c>(프로시저가 스스로 적는다).
/// 특정 사람에게서 감추고 싶으면 [메뉴 권한] 화면에서 <c>locpor</c> 를 막으면 된다.
/// </summary>
public static class LocPor
{
    /// <summary>
    /// 상주 프로그램에 넘겨도 되는 글자만 남긴다 — 영문·숫자·<c>_ - .</c> 뿐이다.
    ///
    /// <b>걸러 내지 않고 <i>거절</i>한다.</b> 조용히 글자를 빼면 <b>다른 IFSEQ 를 돌리게</b>
    /// 된다 — 그것이 이 화면에서 가장 위험한 실수다. 실제 수신분 46건과 호출이력 전부를
    /// 확인했는데 이 범위를 벗어나는 값은 없었다(2026-10-20).
    /// </summary>
    private static bool Key(string? s, int max, out string val, out string? why)
    {
        val = (s ?? "").Trim();
        why = null;
        if (val.Length == 0) { why = "값이 비어 있습니다."; return false; }
        if (val.Length > max) { why = $"{max}자를 넘습니다."; return false; }
        foreach (var c in val)
            if (!char.IsAsciiLetterOrDigit(c) && c is not ('_' or '-' or '.'))
            {
                why = $"쓸 수 없는 글자가 있습니다 — '{c}'. 영문·숫자와 _ - . 만 됩니다.";
                return false;
            }
        return true;
    }

    /// <summary>검색어는 <b>없어도 되는</b> 값이라 거절하지 않고 쓸 수 있는 글자만 남긴다.</summary>
    private static string Filter(string? s) =>
        new string((s ?? "").Where(c => char.IsAsciiLetterOrDigit(c) || c is '_' or '-' or '.').ToArray());

    /// <summary>
    /// DB 로그(<c>CALL_MODULE</c>)에 적힐 호출자. 빈칸을 뺀다 — 이름에 빈칸이 있으면
    /// 명령 줄이 거기서 쪼개져 <c>ifseq</c> 뒤의 값이 통째로 사라진다.
    /// </summary>
    private static string Who(IpGate.Result me)
    {
        var raw = me.Name ?? me.BpId ?? "미상";
        var s = new string(raw.Where(c => !char.IsWhiteSpace(c) && c != '=').ToArray());
        if (s.Length == 0) s = "미상";
        return s.Length > 24 ? s[..24] : s;
    }

    private static string Agent(HttpContext ctx)
    {
        var ua = ctx.Request.Headers.UserAgent.ToString();
        if (string.IsNullOrWhiteSpace(ua)) return "(없음)";
        if (ua.Contains("Mozilla", StringComparison.Ordinal)) return "브라우저";
        return ua.Length > 40 ? ua[..40] : ua;
    }

    public static void Map(WebApplication app)
    {
        // 수신표 목록 — 읽기만 한다. 호출이력의 마지막 한 줄이 함께 붙어 온다
        // (이미 돌린 건을 또 돌리지 않으려면 그것이 보여야 한다).
        app.MapGet("/api/locpor/list", async (string? q, int? limit) =>
        {
            var kw = Filter(q);
            var lim = Math.Clamp(limit ?? 200, 1, 2000);
            var cmd = $"locpor limit={lim}" + (kw.Length > 0 ? $" q={kw}" : "");
            return Results.Ok(new { run = await OraKill.CallAsync(cmd) });
        });

        // 호출이력 — ifseq 를 주면 그 건만, 안 주면 이 프로시저의 최근 이력 전부.
        app.MapGet("/api/locpor/log", async (string? ifseq, int? limit) =>
        {
            var lim = Math.Clamp(limit ?? 30, 1, 500);
            var cmd = $"locporlog limit={lim}";
            if (!string.IsNullOrWhiteSpace(ifseq))
            {
                if (!Key(ifseq, 50, out var key, out var why))
                    return Results.BadRequest(new { error = $"IFSEQ 를 읽을 수 없습니다 — {why}" });
                cmd += $" ifseq={key}";
            }
            return Results.Ok(new { run = await OraKill.CallAsync(cmd) });
        });

        // ── 후행처리 호출 — 이 화면에서 유일하게 DB 를 바꾸는 자리 ──────────────
        //
        // ⚠️ 돌이킬 수 없다. 프로시저는 수신분을 업무표로 전개하고([2510] 대기목록 ·
        //    POR 원장), 그 과정에서 접수자 알림 메일까지 만든다. 화면에서 한 번 더 묻는
        //    까닭이 그것이다. 되돌리는 길은 없으니 <b>남긴다</b> — 누가 언제 무엇을.
        app.MapPost("/api/locpor/run", async (IpGate g, HttpContext ctx, JsonElement body) =>
        {
            var raw = body.TryGetProperty("ifseq", out var v) ? v.GetString() : null;
            if (!Key(raw, 50, out var key, out var why))
                return Results.BadRequest(new { error = $"IFSEQ 를 읽을 수 없습니다 — {why}" });

            var me = await g.CheckAsync(ctx);
            var by = Who(me);
            Console.WriteLine($"[locpor/run] {DateTime.Now:HH:mm:ss} ifseq={key} by={by}"
                            + $" ip={me.Ip} ua={Agent(ctx)}");

            var run = await OraKill.CallAsync($"locporrun ifseq={key} by={by}");
            run["at"] = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss");
            run["by"] = by;

            // 돌린 직후의 이력 한 줄을 함께 준다. 화면이 곧바로 또 물으면 왕복이 두 번이고,
            // 이 DB 는 그럴 여유가 없다 (OraKill.cs 머리말).
            var log = await OraKill.CallAsync($"locporlog ifseq={key} limit=1");

            Console.WriteLine($"[locpor/run] {DateTime.Now:HH:mm:ss} ifseq={key}"
                            + $" → {run.GetValueOrDefault("rtn_cd") ?? "(없음)"}"
                            + $" {run.GetValueOrDefault("rtn_msg") ?? run.GetValueOrDefault("error")}");

            return Results.Ok(new { run, log });
        });

        // ── [3320] 승인완료 직전까지 흘리기 ────────────────────────────────────
        //
        // 고른 줄의 (호선 · POR · 라인) 으로 M20.QURI_MAKE_PO_3320 을 부른다.
        // 그 프로시저는 [3310] 직발주 화면과 <같은 경로>로 돌아 PO_STAT 을 '3'
        // (Waiting Approval) 까지 밀고 발주번호를 매긴다 — [3320] 에서 승인완료를
        // 바로 누를 수 있는 자리다.
        //
        // ⚠️ 돌이킬 수 없다. 후행처리(run)가 <수신분을 업무표로 펼치는> 일이라면
        //    이쪽은 <업무 단계를 앞으로 미는> 일이고, 발주번호는 한번 매겨지면 그만이다.
        //    화면이 두 번 묻고, 여기서는 누가 무엇을 눌렀는지 남긴다.
        //
        // ⚠️ 여기서도 문장을 보내지 않는다. 호출문은 OraPool.java 에 박혀 있고 넘기는
        //    것은 키 셋뿐이다. POR 번호의 <네 자리↔여덟 자리> 결합과 CHAR 자릿수 채움은
        //    프로시저가 하므로 여기서 미리 만지지 않는다 — 두 군데가 되면 한쪽만 고쳐진다.
        app.MapPost("/api/locpor/po", async (IpGate g, HttpContext ctx, JsonElement body) =>
        {
            string? S(string n) => body.TryGetProperty(n, out var v) ? v.GetString() : null;

            if (!Key(S("ship"), 6, out var ship, out var w1))
                return Results.BadRequest(new { error = $"호선을 읽을 수 없습니다 — {w1}" });
            if (!Key(S("por"), 8, out var por, out var w2))
                return Results.BadRequest(new { error = $"POR 번호를 읽을 수 없습니다 — {w2}" });
            if (!Key(S("seq"), 4, out var seq, out var w3))
                return Results.BadRequest(new { error = $"라인을 읽을 수 없습니다 — {w3}" });

            ship = ship.ToUpperInvariant();
            por = por.ToUpperInvariant();

            var me = await g.CheckAsync(ctx);
            var by = Who(me);
            Console.WriteLine($"[locpor/po] {DateTime.Now:HH:mm:ss} {ship}/{por}/{seq} by={by}"
                            + $" ip={me.Ip} ua={Agent(ctx)}");

            var run = await OraKill.CallAsync($"locporpo ship={ship} por={por} seq={seq} by={by}");
            run["at"] = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss");
            run["by"] = by;

            Console.WriteLine($"[locpor/po] {DateTime.Now:HH:mm:ss} {ship}/{por}/{seq}"
                            + $" → {run.GetValueOrDefault("rtn_cd") ?? "(없음)"}"
                            + $" PO={run.GetValueOrDefault("po_no") ?? "-"}"
                            + $" {run.GetValueOrDefault("rtn_msg") ?? run.GetValueOrDefault("error")}");

            return Results.Ok(new { run });
        });

        // ── 전개분 되돌리기 ────────────────────────────────────────────────────
        //
        // 후행처리는 재실행 안전하게 짜여 있어서, 두 번째 실행은 <이미 있는 것을 건드리지
        // 않는다>(MERGE · NOT EXISTS). 바뀐 매핑을 시험하려면 만들어진 것을 치워야 처음처럼
        // 돈다. 세는 것과 지우는 것을 <경로부터> 갈라 둔다 — 실수로 지우는 길을 만들지 않는다.

        // 범위는 둘이다 — IFSEQ 한 묶음(기본), 또는 호선+POR 통째.
        //
        // 호선+POR 이 필요한 까닭: 한 POR 이 여러 IFSEQ 로 나뉘어 들어온다(실측 J015/AA04 는
        // 12개 · 줄 07·08). IFSEQ 범위로는 고른 묶음의 줄만 사라져 나머지가 화면에 그대로
        // 남는다. 게다가 수신표에 아예 없는 줄(사람이 손으로 넣은 것)은 IFSEQ 범위로는
        // <원리상> 못 지운다 — 범위를 수신표에서 거슬러 잡기 때문이다.
        //
        // ⚠️ 그래서 호선+POR 은 <인터페이스가 만들지 않은 줄도 지운다>. 세는 쪽이 그 수를
        //    따로 돌려주고(not_if), 화면은 그것을 반드시 적는다.
        static string? Range(string? ifseq, string? ship, string? por, out string cmd, out bool shipPor)
        {
            cmd = "";
            shipPor = !string.IsNullOrWhiteSpace(ship) || !string.IsNullOrWhiteSpace(por);
            if (shipPor)
            {
                if (!Key(ship, 6, out var s, out var w1)) return $"호선을 읽을 수 없습니다 — {w1}";
                if (!Key(por, 8, out var p, out var w2)) return $"POR 번호를 읽을 수 없습니다 — {w2}";
                cmd = $"scope=shippor ship={s.ToUpperInvariant()} por={p.ToUpperInvariant()}";
                return null;
            }
            if (!Key(ifseq, 50, out var k, out var w3)) return $"IFSEQ 를 읽을 수 없습니다 — {w3}";
            cmd = $"scope=ifseq ifseq={k}";
            return null;
        }

        // 지우는 묶음 — 화면의 단추 셋과 하나씩 짝이다.
        //   core = 전개분만 · biz = PO 뒤 업무분만 · all = 둘 다
        // ⚠️ biz·all 은 호선+POR 범위에서만 받는다. 업무분은 수신 배치가 아니라 <업무 진행>
        //    으로 생겨 어느 IFSEQ 것인지 가릴 근거가 아예 없다 (OraPool.bizPlan 주석).
        static string? PartOf(string? raw, bool shipPor, out string part)
        {
            part = string.IsNullOrWhiteSpace(raw) ? "core" : raw.Trim().ToLowerInvariant();
            if (part is not ("core" or "biz" or "all"))
                return $"지울 묶음을 읽을 수 없습니다 — '{part}'. core · biz · all 중 하나여야 합니다.";
            if (part != "core" && !shipPor)
                return "PO 업무분은 호선+POR 범위에서만 지울 수 있습니다 (IFSEQ 로는 짚을 수 없습니다).";
            return null;
        }

        // 미리보기 — 아무것도 바꾸지 않는다. <전개분>과 <업무분>을 따로 세어 준다.
        // 화면이 단추를 셋 세우므로 한 번 물어 두 건수를 다 받아 간다.
        app.MapGet("/api/locpor/scope", async (string? ifseq, string? ship, string? por) =>
        {
            if (Range(ifseq, ship, por, out var range, out _) is { } bad)
                return Results.BadRequest(new { error = bad });
            return Results.Ok(new { run = await OraKill.CallAsync($"locporscope {range}") });
        });

        // ⚠️ 지운다. 되돌릴 수 없다 — 원장(POR 헤더·라인)과 발주(PO)와 자재마스터까지 간다.
        //    화면이 먼저 세어 보여 주고 두 번 눌러야 여기까지 온다. 누가 무엇을 지웠는지는
        //    logs/api.log 에 남긴다 — DB 쪽에는 <지운 자취>를 남길 표가 없다.
        app.MapPost("/api/locpor/wipe", async (IpGate g, HttpContext ctx, JsonElement body) =>
        {
            string? S(string n) => body.TryGetProperty(n, out var v) ? v.GetString() : null;
            if (Range(S("ifseq"), S("ship"), S("por"), out var range, out var shipPor) is { } bad)
                return Results.BadRequest(new { error = bad });
            if (PartOf(S("part"), shipPor, out var part) is { } bad2)
                return Results.BadRequest(new { error = bad2 });

            var me = await g.CheckAsync(ctx);
            var by = Who(me);
            Console.WriteLine($"[locpor/wipe] {DateTime.Now:HH:mm:ss} {range} part={part} by={by}"
                            + $" ip={me.Ip} ua={Agent(ctx)}");

            var run = await OraKill.CallAsync($"locporwipe {range} part={part} by={by}");
            run["at"] = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss");
            run["by"] = by;

            Console.WriteLine($"[locpor/wipe] {DateTime.Now:HH:mm:ss} {range}"
                            + $" → 지움 {run.GetValueOrDefault("total") ?? "?"}건"
                            + $" {run.GetValueOrDefault("error")}");

            // 지운 뒤의 상태를 함께 준다 — 화면이 또 묻지 않도록. 0 이 되어 있어야 맞다.
            var scope = await OraKill.CallAsync($"locporscope {range}");
            return Results.Ok(new { run, scope });
        });
    }
}
