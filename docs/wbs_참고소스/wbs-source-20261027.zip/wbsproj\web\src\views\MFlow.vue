<script setup>
import { computed, ref } from 'vue'
import { api } from '../api'
import { state, useViewRefresh } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'

// 자재 업무흐름 시나리오 — 글 한 장(api/data/flow/scenario.md)을 도식으로 그린다.
//
// 원본은 DRM 이 감싼 pptx 였다. 파워포인트로만 열리고, 고쳐도 남에게 보여 줄 길이 없었다.
// 그래서 <내용은 글로, 모양은 화면이> 로 갈라 두었다 — 고치는 사람은 글만 고치면 된다.
//
// 적는 법(파일 머리에도 같은 설명이 들어 있다):
//   ## 제목          한 묶음(섹션)
//   형태: 흐름|지도|표   그리는 방식 (안 적으면 흐름)
//   이웃: ...        이 영역 밖의 업무 (옅게 그린다)
//   ### 코드 이름      네모 한 칸
//   @ 부서 / - 설명 / → 화살표 글씨
//   > 메모
//   | 표 | ... |     형태가 <표> 일 때

const doc = ref({ text: '', stamp: '', saved_at: null, saved_by: null, history: 0 })
const loading = ref(false)
const editing = ref(false)
const draft = ref('')
const saving = ref(false)
const msg = ref('')
const q = ref('')
const open = ref(new Set())

async function load() {
  loading.value = true
  try {
    doc.value = await api.flowDoc()
  } catch (e) {
    state.error = e.message
  } finally {
    loading.value = false
  }
}

function edit() {
  draft.value = doc.value.text
  editing.value = true
  msg.value = ''
}

function cancel() {
  if (draft.value !== doc.value.text && !confirm('고친 내용을 버립니다.')) return
  editing.value = false
  msg.value = ''
}

async function save() {
  saving.value = true
  msg.value = ''
  try {
    doc.value = await api.flowSave(draft.value, doc.value.stamp)
    editing.value = false
    msg.value = '저장했습니다.'
    setTimeout(() => (msg.value = ''), 2500)
  } catch (e) {
    // 다른 사람이 먼저 저장한 경우 — 덮어쓰지 않고 사람이 고르게 한다
    msg.value = e.message
  } finally {
    saving.value = false
  }
}

// ---------- 글 → 도식 ----------
//
// 한 줄씩 훑는다. 정규식 한 덩이로 밀어 넣지 않는 까닭 — 글을 손으로 고치는 사람이
// 어느 줄에서 틀렸는지 알 수 있어야 하고, 모르는 줄은 <그대로 메모로 남겨> 사라지지 않게 한다.
const parsed = computed(() => {
  const lines = (doc.value.text ?? '').split('\n')
  const head = { title: '', notes: [] }
  const secs = []
  let sec = null
  let step = null

  // 섹션마다 <원문의 몇 번째 줄부터 몇 번째 줄까지> 인지 적어 둔다.
  // 이것이 있어야 그 묶음만 떼어 고치고 제자리에 돌려놓을 수 있다 —
  // 없으면 제목으로 다시 찾아야 하는데, 같은 제목이 둘이면 엉뚱한 데를 덮어쓴다.
  const pushSec = (title, at) => {
    if (sec) sec.end = at
    sec = { title, kind: '흐름', neighbors: [], notes: [], steps: [], table: null, edges: [], start: at, end: lines.length }
    secs.push(sec)
    step = null
  }

  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i]
    const line = raw.trimEnd()
    const t = line.trim()
    if (t.startsWith('## ')) { pushSec(t.slice(3).trim(), i); continue }
    if (!t) continue
    if (t.startsWith('<!--')) continue

    if (t.startsWith('# ')) { head.title = t.slice(2).trim(); head.end = i + 1; continue }
    if (!sec) { if (t.startsWith('>')) { head.notes.push(t.replace(/^>\s?/, '')); head.end = i + 1 }; continue }

    if (t.startsWith('### ')) {
      step = { title: t.slice(4).trim(), dept: '', desc: [], arrows: [] }
      sec.steps.push(step)
      continue
    }
    if (/^형태\s*:/.test(t)) { sec.kind = t.split(':').slice(1).join(':').trim() || '흐름'; continue }
    if (/^이웃\s*:/.test(t)) { sec.neighbors.push(t.split(':').slice(1).join(':').trim()); continue }
    // 지도의 자료 흐름:  A → B : 글씨
    const edge = t.match(/^([\w.]+)\s*(?:→|->)\s*([\w.]+)\s*:\s*(.+)$/)
    if (edge) { sec.edges.push({ from: edge[1], to: edge[2], label: edge[3] }); continue }
    if (t.startsWith('|')) {
      const cells = t.replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim())
      if (cells.every((c) => /^:?-{2,}:?$/.test(c))) continue // 표의 구분줄
      ;(sec.table ??= []).push(cells)
      continue
    }
    if (t.startsWith('@')) { if (step) step.dept = t.slice(1).trim(); continue }
    if (t.startsWith('→') || t.startsWith('->')) {
      const v = t.replace(/^(→|->)\s*/, '')
      if (step) step.arrows.push(v)
      else sec.notes.push(v)
      continue
    }
    if (t.startsWith('- ')) { (step ? step.desc : sec.notes).push(t.slice(2).trim()); continue }
    if (t.startsWith('>')) { (step ? step.desc : sec.notes).push(t.replace(/^>\s?/, '')); continue }
    // 알 수 없는 줄도 버리지 않는다 — 버리면 고친 사람이 글을 잃는다
    ;(step ? step.desc : sec.notes).push(t)
  }
  return { head, secs, lines }
})

/** 검색 — 섹션 안 아무 글자나 걸리면 그 섹션을 남긴다 */
const secs = computed(() => {
  const s = q.value.trim().toLowerCase()
  if (!s) return parsed.value.secs
  const hit = (x) => String(x ?? '').toLowerCase().includes(s)
  return parsed.value.secs.filter(
    (x) =>
      hit(x.title) ||
      x.steps.some((st) => hit(st.title) || hit(st.dept) || st.desc.some(hit) || st.arrows.some(hit)) ||
      (x.table ?? []).some((r) => r.some(hit)) ||
      x.notes.some(hit)
  )
})

const anchor = (t) => 'sec-' + t.replace(/[^\w가-힣.]+/g, '-')
const isOpen = (t) => !open.value.has(t)
function toggle(t) {
  const s = new Set(open.value)
  s.has(t) ? s.delete(t) : s.add(t)
  open.value = s
}
const foldAll = () => (open.value = new Set(parsed.value.secs.map((s) => s.title)))
const unfoldAll = () => (open.value = new Set())

// ---------- 묶음 단위로 고치기 ----------
//
// 통째로 한 상자에 넣으면 3만 자를 스크롤하며 내 자리를 찾아야 한다.
// 그래서 <그 묶음의 글만> 떼어 주고, 저장할 때 원문의 제자리에 도로 끼운다.
// 파일은 여전히 한 장이다 — 통째로 복사해 가는 쓰임새를 잃지 않으려는 것이다.
const editSec = ref(null) // 지금 고치고 있는 묶음의 제목
const secDraft = ref('')

/** 그 묶음에 해당하는 원문 줄들 */
const sliceOf = (sec) => parsed.value.lines.slice(sec.start, sec.end).join('\n').replace(/\s+$/, '')

function startSec(sec) {
  if (editing.value) return
  secDraft.value = sliceOf(sec)
  editSec.value = sec.title
  msg.value = ''
}

function cancelSec(sec) {
  if (secDraft.value !== sliceOf(sec) && !confirm('고친 내용을 버립니다.')) return
  editSec.value = null
  msg.value = ''
}

/** 원문에서 start~end 줄을 새 글로 갈아 끼운 <전체 글> 을 만든다 */
function spliced(sec, text) {
  const l = [...parsed.value.lines]
  l.splice(sec.start, sec.end - sec.start, ...text.replace(/\s+$/, '').split('\n'), '')
  return l.join('\n')
}

async function saveSec(sec) {
  if (!secDraft.value.trim().startsWith('##')) {
    msg.value = '묶음의 첫 줄은 `## 제목` 이어야 합니다.'
    return
  }
  await put(spliced(sec, secDraft.value), () => (editSec.value = null))
}

// ---------- 끌어놓기로 묶음 옮기기 ----------
// 라이브러리 없이 브라우저의 끌어놓기만 쓴다 (사이드바 메뉴·[개발자 정보] 목차와 같은 방식).
// 한 칸씩 올리는 ▲▼ 도 남겨 둔다 — 18개 중 맨 아래를 맨 위로 보낼 때는 끌기가 편하고,
// 바로 옆자리와 바꿀 때는 단추가 빠르다. 둘은 같은 일을 하는 다른 손잡이다.
const dragSec = ref(null)
const overSec = ref(null)
const overPos = ref('')

/** 끌 수 있는 때 — 검색 중이거나 고치는 중에는 막는다 (아래 move 와 같은 까닭) */
const canDrag = computed(() => !q.value.trim() && !editSec.value && !editing.value && !saving.value)

function clearDrag() {
  dragSec.value = null
  overSec.value = null
  overPos.value = ''
}

function onDragStart(e, sec) {
  if (!canDrag.value) { e.preventDefault(); return }
  dragSec.value = sec.title
  e.dataTransfer.effectAllowed = 'move'
  // 데이터가 비면 끌기를 시작조차 하지 않는 브라우저가 있다
  e.dataTransfer.setData('text/plain', sec.title)
}

function onDragOver(e, sec) {
  if (!dragSec.value || dragSec.value === sec.title) return
  e.preventDefault()
  e.dataTransfer.dropEffect = 'move'
  const r = e.currentTarget.getBoundingClientRect()
  overSec.value = sec.title
  overPos.value = e.clientY < r.top + r.height / 2 ? 'before' : 'after'
}

function onDragLeave(sec) {
  if (overSec.value === sec.title) overSec.value = null
}

async function onDrop(e, sec) {
  e.preventDefault()
  const fromT = dragSec.value
  const pos = overPos.value
  clearDrag()
  if (!fromT || fromT === sec.title || !canDrag.value) return
  const from = parsed.value.secs.find((x) => x.title === fromT)
  const to = parsed.value.secs.find((x) => x.title === sec.title)
  if (!from || !to) return

  // 뗀 뒤에는 뒤쪽 줄번호가 당겨진다 — 그만큼 빼고 끼울 자리를 센다.
  // 원문 줄번호 그대로 쓰면 끌어 내릴 때마다 한 묶음 길이만큼 어긋난다.
  const l = parsed.value.lines
  const len = from.end - from.start
  const block = l.slice(from.start, from.end)
  const rest = [...l.slice(0, from.start), ...l.slice(from.end)]
  let at = to.start > from.start ? to.start - len : to.start
  if (pos === 'after') at += to.end - to.start
  rest.splice(at, 0, ...block)
  await put(rest.join('\n'))
}

/** 묶음 순서 바꾸기 — 글 덩이를 통째로 맞바꾼다 */
async function move(sec, dir) {
  const list = parsed.value.secs
  const i = list.indexOf(sec)
  const j = i + dir
  if (i < 0 || j < 0 || j >= list.length) return
  const a = list[Math.min(i, j)]
  const b = list[Math.max(i, j)]
  const l = parsed.value.lines
  const next = [
    ...l.slice(0, a.start),
    ...l.slice(b.start, b.end),
    ...l.slice(a.start, a.end),
    ...l.slice(b.end),
  ]
  await put(next.join('\n'))
}

/** 저장 한 길 — 성공하면 화면을 새 글로 바꾸고, 실패하면 까닭을 그대로 보여 준다 */
async function put(text, after) {
  saving.value = true
  msg.value = ''
  try {
    doc.value = await api.flowSave(text, doc.value.stamp)
    after?.()
    msg.value = '저장했습니다.'
    setTimeout(() => (msg.value = ''), 2500)
  } catch (e) {
    msg.value = e.message
  } finally {
    saving.value = false
  }
}
function goto(t) {
  const el = document.getElementById(anchor(t))
  el?.scrollIntoView({ block: 'start', behavior: 'smooth' })
}

/** 코드와 이름을 가른다 — `M.2.1 POR Management (POR 관리)` */
function split(title) {
  const m = title.match(/^((?:M\.)?[\d.]+)\s+(.*)$/)
  if (!m) return { code: '', name: title }
  const rest = m[2]
  const k = rest.match(/^(.*?)\s*\(([^)]*)\)\s*$/)
  return k ? { code: m[1], name: k[1], sub: k[2] } : { code: m[1], name: rest }
}

useViewRefresh(load)
load()
</script>

<template>
  <section class="panel head">
    <h2>
      업무흐름 시나리오
      <span class="hint">
        {{ doc.saved_at ? `수정 ${doc.saved_at}` : '' }}
        {{ doc.saved_by ? ` · ${doc.saved_by}` : '' }}{{ loading ? ' · 조회 중…' : '' }}
      </span>
      <span class="spacer"></span>
      <input v-if="!editing" v-model="q" type="text" placeholder="내용 검색" />
      <button v-if="!editing" title="파일 전체를 한 상자에서 고칩니다 (묶음별 편집은 각 묶음의 ✎)" @click="edit">✎ 전체 글</button>
      <template v-else>
        <button class="go" :disabled="saving" @click="save">{{ saving ? '저장 중…' : '저장' }}</button>
        <button :disabled="saving" @click="cancel">취소</button>
      </template>
      <RefreshBtn v-if="!editing" :fn="load" label="" title="다시 읽기" />
    </h2>

    <p class="muted note">
      원본 <code>HHIP-자재-DE-09(업무흐름시나리오) V2.0</code> 의 내용을 <strong>글 한 장</strong>으로
      옮긴 것입니다. <strong>[✎ 편집]</strong> 으로 글을 고치면 아래 그림이 그대로 바뀝니다
      (<code>api/data/flow/scenario.md</code>).
    </p>
    <p v-if="msg" class="msg" :class="{ bad: !msg.startsWith('저장') }">{{ msg }}</p>

    <!-- 모두 접기·펼치기 + 묶음 바로가기 -->
    <nav v-if="!editing && secs.length" class="jump">
      <button class="fold" title="모든 묶음을 접습니다" @click="foldAll">⊟ 모두 접기</button>
      <button class="fold" title="모든 묶음을 펼칩니다" @click="unfoldAll">⊞ 모두 펼치기</button>
      <span class="sep"></span>
      <button v-for="s in secs" :key="s.title" @click="goto(s.title)">{{ s.title }}</button>
    </nav>
  </section>

  <!-- ══════════ 편집 ══════════ -->
  <section v-if="editing" class="panel ed">
    <p class="muted rules">
      <strong>적는 법</strong> ·
      <code>## 제목</code> 묶음 ·
      <code>형태: 흐름|지도|표</code> 그리는 방식 ·
      <code>### 코드 이름</code> 네모 한 칸 ·
      <code>@ 부서</code> ·
      <code>- 설명</code> ·
      <code>→ 화살표 글씨</code> ·
      <code>이웃: …</code> 바깥 업무 ·
      <code>| 표 |</code> 는 형태가 <code>표</code> 일 때
    </p>
    <textarea v-model="draft" spellcheck="false"></textarea>
    <p class="muted cnt">{{ draft.length.toLocaleString() }}자 · 저장하면 직전 글이 남습니다(되돌릴 수 있게)</p>
  </section>

  <!-- ══════════ 보기 ══════════ -->
  <template v-else>
    <section
      v-for="(s, si) in secs"
      :id="anchor(s.title)"
      :key="s.title"
      class="panel sec"
      :class="{
        dragging: dragSec === s.title,
        'over-before': overSec === s.title && overPos === 'before',
        'over-after': overSec === s.title && overPos === 'after',
      }"
      @dragover="onDragOver($event, s)"
      @dragleave="onDragLeave(s)"
      @drop="onDrop($event, s)"
      @dragend="clearDrag"
    >
      <h3
        :class="{ ed: editSec === s.title, grab: canDrag }"
        :draggable="canDrag"
        @click="toggle(s.title)"
        @dragstart="onDragStart($event, s)"
      >
        <span v-if="canDrag" class="grip" aria-hidden="true">⠿</span>
        <span class="caret">{{ isOpen(s.title) || editSec === s.title ? '▾' : '▸' }}</span>
        {{ s.title }}
        <span class="kind">{{ s.kind }}</span>
        <span v-if="s.steps.length" class="cnt">{{ s.steps.length }}칸</span>
        <span class="spacer"></span>
        <!-- 순서·편집 단추는 머리줄을 누르는 것(접기)과 섞이면 안 된다 → .stop -->
        <template v-if="editSec !== s.title">
          <button
            class="mv"
            :disabled="q.trim() !== '' || si === 0 || saving"
            :title="q.trim() ? '검색 중에는 순서를 바꾸지 않습니다' : '위로'"
            @click.stop="move(s, -1)"
          >▲</button>
          <button
            class="mv"
            :disabled="q.trim() !== '' || si === secs.length - 1 || saving"
            :title="q.trim() ? '검색 중에는 순서를 바꾸지 않습니다' : '아래로'"
            @click.stop="move(s, 1)"
          >▼</button>
          <button class="mv ed" :disabled="saving" title="이 묶음만 고칩니다" @click.stop="startSec(s)">✎</button>
        </template>
        <template v-else>
          <button class="go" :disabled="saving" @click.stop="saveSec(s)">{{ saving ? '저장 중…' : '저장' }}</button>
          <button :disabled="saving" @click.stop="cancelSec(s)">취소</button>
        </template>
      </h3>

      <!-- 이 묶음만 고치기 -->
      <div v-if="editSec === s.title" class="seced">
        <textarea v-model="secDraft" spellcheck="false"></textarea>
        <p class="muted cnt">
          이 묶음의 글만 보입니다. 저장하면 전체 글의 제자리에 그대로 들어갑니다 ·
          {{ secDraft.length.toLocaleString() }}자
        </p>
      </div>

      <!-- 고치는 중에는 그림을 내린다 — 상자와 그림이 함께 보이면 어느 쪽이 지금 값인지 헷갈린다 -->
      <template v-if="isOpen(s.title) && editSec !== s.title">
        <p v-for="(n, i) in s.notes" :key="i" class="snote">{{ n }}</p>

        <!-- 표 — 행렬 그대로 (시스템 흐름 지도 · 업무 흐름 · 개정 이력) -->
        <div v-if="s.kind === '표' && s.table" class="tw">
          <table>
            <thead>
              <tr><th v-for="(c, i) in s.table[0]" :key="i">{{ c }}</th></tr>
            </thead>
            <tbody>
              <tr v-for="(r, i) in s.table.slice(1)" :key="i">
                <td v-for="(c, j) in r" :key="j" :class="{ first: j === 0 }">
                  <span v-for="(p, k) in c.split('<br>')" :key="k" class="chip">{{ p }}</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <template v-if="s.kind !== '표' || !s.table">
        <!-- 맞닿는 바깥 업무 — 맥락이지 이 영역의 단계가 아니다.
             네모로 같이 세우면 빈 상자가 줄 앞을 막고, 진짜 단계가 오른쪽으로 밀려난다. -->
        <p v-if="s.neighbors.length" class="neigh">
          <span class="lbl">맞닿는 업무</span>
          <span v-for="(n, i) in s.neighbors" :key="i" class="nb" :title="n">{{ n.split('@')[0].trim() }}</span>
        </p>

        <!-- 흐름 · 지도 — 네모 칸 -->
        <div class="cards" :class="s.kind === '지도' ? 'grid' : 'chain'">
          <template v-for="(st, i) in s.steps" :key="i">
            <div class="box">
              <div class="bt">
                <span v-if="split(st.title).code" class="code">{{ split(st.title).code }}</span>
                {{ split(st.title).name }}
              </div>
              <div v-if="split(st.title).sub" class="bs">{{ split(st.title).sub }}</div>
              <div v-if="st.dept" class="dept">{{ st.dept }}</div>
              <ul v-if="st.desc.length" class="desc">
                <li v-for="(d, k) in st.desc" :key="k">{{ d }}</li>
              </ul>
              <div v-if="st.arrows.length" class="outs">
                <span v-for="(a, k) in st.arrows" :key="k" class="arrow">→ {{ a }}</span>
              </div>
            </div>
            <div v-if="s.kind !== '지도' && i < s.steps.length - 1" class="link" aria-hidden="true">➜</div>
          </template>
        </div>

        </template>

        <!-- 지도의 자료 흐름 -->
        <ul v-if="s.edges.length" class="edges">
          <li v-for="(e, i) in s.edges" :key="i">
            <b>{{ e.from }}</b> → <b>{{ e.to }}</b> <span>{{ e.label }}</span>
          </li>
        </ul>
      </template>
    </section>

    <p v-if="!secs.length && !loading" class="muted empty">
      {{ q ? '검색된 내용이 없습니다.' : '아직 내용이 없습니다 — [✎ 편집] 으로 적어 주세요.' }}
    </p>
  </template>
</template>

<style scoped>
h2 { display: flex; align-items: center; gap: 8px; }
h2 .spacer { flex: 1; }
h2 input { width: 180px; }
.head { margin-bottom: 12px; }
.note { margin: 8px 0 0; font-size: 11.5px; }
.note code, .rules code {
  background: var(--fill); border-radius: 3px; padding: 1px 5px; font-size: 11px;
}
.msg { margin: 8px 0 0; font-size: 12px; color: var(--done); }
.msg.bad { color: var(--warn); }
button.go { border-color: var(--accent); color: var(--accent); }

/* 섹션 바로가기 — 18개라 목록이 길다. 한 줄로 흘리고 넘치면 접는다 */
.jump { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 10px; }
.jump button { font-size: 11px; padding: 2px 8px; color: var(--muted); }
.jump button:hover { color: var(--accent); border-color: var(--accent); }
.jump button.fold { color: var(--text); }
.jump .sep { width: 1px; align-self: stretch; background: var(--line); margin: 0 4px; }

/* ---------- 편집 ---------- */
.ed textarea {
  width: 100%;
  /* 창 높이를 빼서 맞추지 않는다 — 이 상자가 놓이는 곳은 창이 아니라 <탭 줄 아래 본문 칸>
     이라 100vh 로 재면 그만큼 넘친다. 그냥 넉넉한 비율로 두고 모자라면 사람이 늘린다. */
  height: 62vh;
  min-height: 320px;
  border: 1px solid var(--line);
  border-radius: var(--radius);
  background: var(--panel);
  color: var(--text);
  padding: 10px 12px;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 12.5px;
  line-height: 1.6;
  resize: vertical;
}
.ed textarea:focus { outline: none; border-color: var(--accent); }
.rules { margin: 0 0 8px; font-size: 11.5px; }
.cnt { margin: 6px 0 0; font-size: 11px; }

/* ---------- 보기 ---------- */
.sec { margin-bottom: 12px; scroll-margin-top: 8px; }
.sec h3 {
  display: flex; align-items: center; gap: 8px;
  margin: 0; font-size: 13.5px; cursor: pointer; user-select: none;
}
.sec h3 .caret { color: var(--muted-3); font-size: 10px; }
.sec h3 .kind {
  font-size: 10px; font-weight: 400; color: var(--muted);
  background: var(--fill); border-radius: 3px; padding: 1px 6px;
}
.sec h3 .cnt { font-size: 10.5px; font-weight: 400; color: var(--muted-2); margin: 0; }
.sec h3 .spacer { flex: 1; }
.sec h3.ed { color: var(--accent); }
/* 끌 수 있을 때만 손잡이를 보여 준다 — 못 옮기는 때(검색·편집 중)에 옮길 수 있는 것처럼 보이면 안 된다 */
.sec h3.grab { cursor: grab; }
.sec h3 .grip { color: var(--muted-3); font-size: 11px; }
.sec h3:hover .grip { color: var(--muted); }
.sec.dragging { opacity: 0.45; }
/* 놓을 자리 — 패널 위/아래에 줄 하나로 */
.sec.over-before, .sec.over-after { position: relative; }
.sec.over-before::before, .sec.over-after::after {
  content: '';
  position: absolute;
  left: 0; right: 0; height: 3px;
  background: var(--accent);
  border-radius: 2px;
}
.sec.over-before::before { top: -6px; }
.sec.over-after::after { bottom: -6px; }
/* 순서·편집 단추 — 평소엔 조용히 두고 머리줄에 손을 올리면 또렷해진다 */
.sec h3 .mv {
  font-size: 10px; padding: 0 6px; line-height: 18px;
  color: var(--muted-3); border-color: transparent; background: none;
}
.sec h3:hover .mv { color: var(--muted); border-color: var(--line); }
.sec h3 .mv:hover:not(:disabled) { color: var(--accent); border-color: var(--accent); }
.sec h3 .mv:disabled { opacity: 0.3; cursor: default; }
.sec h3 .mv.ed { font-size: 11px; }
.sec h3 .go { font-size: 11px; padding: 1px 9px; border-color: var(--accent); color: var(--accent); }
.sec h3 button:not(.mv):not(.go) { font-size: 11px; padding: 1px 9px; }

/* 묶음 한 개만 고치는 상자 */
.seced { margin-top: 10px; }
.seced textarea {
  width: 100%;
  height: 46vh;
  min-height: 220px;
  border: 1px solid var(--accent);
  border-radius: var(--radius);
  background: var(--panel);
  color: var(--text);
  padding: 10px 12px;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 12.5px;
  line-height: 1.6;
  resize: vertical;
}
.seced textarea:focus { outline: none; }
.snote {
  margin: 8px 0 0; font-size: 11.5px; color: var(--muted);
  border-left: 2px solid var(--line); padding-left: 8px;
}

/* 네모 칸 — 흐름은 가로 줄, 지도는 격자 */
.cards { display: flex; gap: 8px; margin-top: 10px; }
.cards.chain { align-items: stretch; overflow-x: auto; padding-bottom: 4px; }
.cards.grid { flex-wrap: wrap; }
.cards.grid .box { width: 236px; }
.box {
  flex: none;
  width: 250px;
  border: 1px solid var(--line);
  border-radius: var(--radius);
  background: var(--panel);
  padding: 8px 10px 9px;
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.box .bt { font-size: 12.5px; font-weight: 600; line-height: 1.35; }
.box .bt .code {
  color: var(--accent); background: var(--accent-soft);
  border-radius: 3px; padding: 0 5px; margin-right: 4px; font-size: 11px;
}
.box .bs { font-size: 11.5px; color: var(--muted); }
.box .dept {
  font-size: 10.5px; color: var(--done);
  background: var(--done-soft); border-radius: 3px; padding: 1px 6px; align-self: flex-start;
}
.box .desc { margin: 4px 0 0; padding-left: 15px; font-size: 11.5px; line-height: 1.5; }
.box .desc li { margin: 1px 0; }
.box .outs { margin-top: auto; padding-top: 6px; display: flex; flex-direction: column; gap: 2px; }
.box .arrow {
  font-size: 10.5px; color: var(--warn);
  background: var(--warn-soft); border-radius: 3px; padding: 1px 6px;
}
/* 맞닿는 바깥 업무 — 맥락으로만 적는다 (네모로 세우면 빈 상자가 줄 앞을 막는다) */
.neigh { margin: 8px 0 0; display: flex; align-items: center; gap: 5px; flex-wrap: wrap; font-size: 11px; }
.neigh .lbl { color: var(--muted-2); }
.neigh .nb {
  border: 1px dashed var(--line-strong); border-radius: 999px;
  padding: 1px 8px; color: var(--muted);
}
/* 칸과 칸 사이 화살표 */
.link { flex: none; align-self: center; color: var(--muted-3); font-size: 14px; }

/* 자료 흐름 목록 */
.edges { margin: 10px 0 0; padding-left: 18px; font-size: 11.5px; color: var(--muted); }
.edges b { color: var(--accent); font-weight: 600; }
.edges span { color: var(--text); }

/* 표 */
.tw { margin-top: 10px; overflow-x: auto; }
.tw table { border-collapse: collapse; font-size: 11.5px; width: 100%; }
.tw th, .tw td { border: 1px solid var(--line); padding: 5px 7px; vertical-align: top; text-align: left; }
.tw th { background: var(--surface); font-weight: 600; white-space: nowrap; }
.tw td.first { background: var(--surface); font-weight: 600; white-space: nowrap; }
.tw .chip { display: block; line-height: 1.6; }
.tw .chip + .chip { border-top: 1px dotted var(--line); }

.empty { text-align: center; padding: 20px 0; font-size: 12.5px; }
</style>
