<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { COLS, BASE_COLS, colStore, state, setCols } from '../store'
import { useDragMove } from '../dragmove'

// 보고 싶은 컬럼을 고르고, 보이는 순서까지 정하는 팝업.
//
// 왼쪽 = 무엇을 볼까 (묶음별 체크)  ·  오른쪽 = 어떤 순서로 볼까 (끌어서 이동)
// 둘을 나눈 이유: 묶음으로 묶어 두면 고르기는 쉽지만 순서를 보여줄 수 없다.
// 순서는 <고른 것만> 늘어놓아야 뜻이 통하므로 따로 세운다.
//
// [확인] 을 누를 때까지 실제 화면은 바뀌지 않는다 (창 안에서만 임시로 만진다).
// 그래서 이것저것 켜 보다가 [취소] 로 되돌릴 수 있다.
const emit = defineEmits(['close'])

// 머리글을 잡아 창을 옮긴다 (표를 가려서 값을 확인하기 어려울 때 치워 두려는 것)
const drag = useDragMove()

// 창을 열 때의 상태를 복사해 둔다. 배열이므로 <순서>도 그대로 들고 있다.
const order = ref([...state.cols])
const q = ref('')

const GROUPS = [...new Set(COLS.map((c) => c.g || '기타'))]
const colOf = (key) => COLS.find((c) => c.key === key)

const matches = (c) => {
  const s = q.value.trim().toLowerCase()
  if (!s) return true
  return c.label.toLowerCase().includes(s) || c.key.toLowerCase().includes(s)
}

const grouped = computed(() =>
  GROUPS.map((g) => ({ g, cols: COLS.filter((c) => (c.g || '기타') === g && matches(c)) }))
    .filter((x) => x.cols.length)
)

const on = (key) => order.value.includes(key)
const count = computed(() => order.value.length)

function toggle(key) {
  // 켤 때는 맨 뒤에 붙인다 — 끌어서 원하는 자리로 옮기면 된다
  order.value = on(key) ? order.value.filter((k) => k !== key) : [...order.value, key]
}

/** 묶음 단위 켜기/끄기 — 그 묶음이 전부 켜져 있으면 끄고, 아니면 전부 켠다 */
function toggleGroup(g) {
  const keys = COLS.filter((c) => (c.g || '기타') === g && matches(c)).map((c) => c.key)
  const allOn = keys.every((k) => on(k))
  order.value = allOn
    ? order.value.filter((k) => !keys.includes(k))
    : [...order.value, ...keys.filter((k) => !on(k))]
}
const groupState = (g) => {
  const keys = COLS.filter((c) => (c.g || '기타') === g).map((c) => c.key)
  const n = keys.filter((k) => on(k)).length
  return { n, all: keys.length, full: n === keys.length && n > 0 }
}

const setAll = () => (order.value = COLS.map((c) => c.key))
const setBase = () => (order.value = [...BASE_COLS])
const setNone = () => (order.value = [])
const revert = () => (order.value = [...state.cols])
/** 순서만 COLS 의 원래 차례로 되돌린다 (고른 것은 그대로) */
const sortDefault = () =>
  (order.value = COLS.map((c) => c.key).filter((k) => on(k)))

// ---------------------------------------------------------------- 순서 바꾸기
function move(i, to) {
  if (to < 0 || to >= order.value.length) return
  const next = [...order.value]
  const [x] = next.splice(i, 1)
  next.splice(to, 0, x)
  order.value = next
}

const dragFrom = ref(-1)
const dragOver = ref(-1)

function onDragStart(i, e) {
  dragFrom.value = i
  e.dataTransfer.effectAllowed = 'move'
  // 파이어폭스는 데이터가 없으면 끌기를 시작하지 않는다
  e.dataTransfer.setData('text/plain', String(i))
}
function onDragOver(i) {
  dragOver.value = i
}
function onDrop(i) {
  if (dragFrom.value >= 0 && dragFrom.value !== i) move(dragFrom.value, i)
  dragFrom.value = -1
  dragOver.value = -1
}
function onDragEnd() {
  dragFrom.value = -1
  dragOver.value = -1
}

function apply() {
  if (!order.value.length) return // 최소 한 개는 남긴다
  setCols(order.value)
  emit('close')
}

// Esc 로 닫고, Enter 로 적용한다
function onKey(e) {
  if (e.key === 'Escape') emit('close')
  else if (e.key === 'Enter' && !e.isComposing) apply()
}
onMounted(() => window.addEventListener('keydown', onKey))
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <div class="mask">
    <div class="dlg" :class="{ moving: drag.moving.value }" :style="drag.style.value">
      <!-- 머리글을 잡으면 창이 따라온다. 입력칸·버튼을 누른 것은 끌기로 보지 않는다. -->
      <header class="grab" @pointerdown="drag.start($event)">
        <span class="hgrip" title="여기를 잡아 창을 옮깁니다">⠿</span>
        <strong>보고 싶은 컬럼</strong>
        <span class="hint">{{ count }} / {{ COLS.length }} 선택</span>
        <span class="spacer"></span>
        <input v-model="q" type="text" placeholder="컬럼 이름 검색" />
        <button v-if="drag.moved()" title="창을 원래 자리로" @click="drag.reset()">⌖</button>
        <button class="x" title="닫기 (Esc)" @click="emit('close')">✕</button>
      </header>

      <div class="quick">
        <button @click="setAll">전체</button>
        <button @click="setBase">기본만</button>
        <button @click="setNone">전부 해제</button>
        <span class="spacer"></span>
        <button @click="sortDefault">순서 초기화</button>
        <button @click="revert">되돌리기</button>
      </div>

      <div class="body">
        <!-- 왼쪽: 무엇을 볼까 -->
        <div class="pane pick">
          <h3>보이는 컬럼</h3>
          <div class="grid">
            <section v-for="grp in grouped" :key="grp.g" class="grp">
              <h4>
                <button class="gbtn" :class="{ full: groupState(grp.g).full }" @click="toggleGroup(grp.g)">
                  {{ grp.g }}
                </button>
                <span class="gcnt">{{ groupState(grp.g).n }}/{{ groupState(grp.g).all }}</span>
              </h4>
              <label v-for="c in grp.cols" :key="c.key" class="item" :class="{ on: on(c.key) }">
                <input type="checkbox" :checked="on(c.key)" @change="toggle(c.key)" />
                <span class="lb">{{ c.label }}</span>
              </label>
            </section>
            <p v-if="!grouped.length" class="none">검색 결과가 없습니다.</p>
          </div>
        </div>

        <!-- 오른쪽: 어떤 순서로 볼까 -->
        <div class="pane ord">
          <h3>표시 순서 <span class="muted">끌어서 옮기기</span></h3>
          <ol class="list">
            <li
              v-for="(k, i) in order"
              :key="k"
              draggable="true"
              :class="{ dragging: dragFrom === i, over: dragOver === i && dragFrom !== i }"
              @dragstart="onDragStart(i, $event)"
              @dragover.prevent="onDragOver(i)"
              @drop.prevent="onDrop(i)"
              @dragend="onDragEnd"
            >
              <span class="no">{{ i + 1 }}</span>
              <span class="grip" title="끌어서 순서를 바꿉니다">⠿</span>
              <span class="lb">{{ colOf(k)?.label ?? k }}</span>
              <span class="tag">{{ colOf(k)?.g }}</span>
              <button class="mv" title="위로" :disabled="i === 0" @click="move(i, i - 1)">▲</button>
              <button class="mv" title="아래로" :disabled="i === order.length - 1" @click="move(i, i + 1)">▼</button>
              <button class="mv off" title="이 컬럼 감추기" @click="toggle(k)">✕</button>
            </li>
            <li v-if="!order.length" class="empty">고른 컬럼이 없습니다. 왼쪽에서 체크하세요.</li>
          </ol>
        </div>
      </div>

      <footer>
        <span class="where">
          <template v-if="colStore.server">
            <strong>{{ colStore.who }}</strong> 님 설정으로 <strong>서버에 보관</strong>됩니다 —
            다른 PC 에서 열어도 그대로 보입니다.
          </template>
          <template v-else>
            접속 IP 로 사용자를 가릴 수 없어 <strong>이 브라우저에만</strong> 저장됩니다.
            <span class="muted">개발자 관리에 IP 를 등록하면 계정별로 보관됩니다.</span>
          </template>
        </span>
        <span class="spacer"></span>
        <button @click="emit('close')">취소</button>
        <button class="go" :disabled="!count" @click="apply">확인</button>
      </footer>
    </div>
  </div>
</template>

<style scoped>
.mask {
  position: fixed;
  inset: 0;
  background: var(--overlay);
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 40px 20px;
  z-index: 100;
}
.dlg {
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 10px;
  width: min(1000px, 100%);
  max-height: calc(100vh - 80px);
  display: flex;
  flex-direction: column;
  box-shadow: 0 8px 28px var(--shadow);
}
.dlg header,
.quick,
.dlg footer {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  flex: none;
}
.dlg header { border-bottom: 1px solid var(--line); }
/* 머리글은 창을 옮기는 손잡이다 */
.dlg header.grab { cursor: move; user-select: none; touch-action: none; }
.dlg.moving { box-shadow: 0 14px 40px var(--shadow-2); }
.hgrip { color: var(--muted-3); font-size: 13px; }
.dlg header .hint { font-size: 11.5px; color: var(--muted); }
.dlg header input { width: 180px; }
.quick { padding-bottom: 0; }
.spacer { flex: 1; }

.body {
  flex: 1 1 auto;
  min-height: 0;
  display: grid;
  grid-template-columns: 1.35fr 1fr;
  gap: 14px;
  padding: 10px 14px 14px;
}
@media (max-width: 720px) { .body { grid-template-columns: 1fr; } }

.pane { display: flex; flex-direction: column; min-height: 0; min-width: 0; }
.pane h3 {
  margin: 0 0 6px;
  font-size: 11.5px;
  font-weight: 600;
  color: var(--muted);
}
.pane h3 .muted { font-weight: 400; font-size: 10.5px; }

.grid {
  flex: 1 1 auto;
  min-height: 0;
  overflow: auto;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 2px 16px;
  align-content: start;
}
.grp h4 {
  margin: 6px 0 3px;
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11.5px;
  font-weight: 600;
}
.gbtn { padding: 1px 8px; font-size: 11px; }
.gbtn.full { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); }
.gcnt { font-size: 10.5px; color: var(--muted); font-weight: 400; }

.item {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 3px 6px;
  border-radius: 5px;
  font-size: 12px;
  cursor: pointer;
}
.item:hover { background: var(--hover); }
.item.on .lb { font-weight: 600; }
.item .lb { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.item input { accent-color: var(--accent); cursor: pointer; }
.none { color: var(--muted); font-size: 12px; grid-column: 1 / -1; }

/* 순서 목록 */
.list {
  flex: 1 1 auto;
  min-height: 0;
  overflow: auto;
  margin: 0;
  padding: 4px;
  list-style: none;
  border: 1px solid var(--line);
  border-radius: 6px;
  background: var(--surface);
}
.list li {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 3px 5px;
  border-radius: 5px;
  font-size: 12px;
  background: var(--panel);
  border: 1px solid transparent;
  margin-bottom: 2px;
  cursor: grab;
}
.list li:hover { border-color: var(--line); }
.list li.dragging { opacity: 0.4; }
.list li.over { border-color: var(--accent); background: var(--accent-soft); }
.list li.empty { color: var(--muted); background: transparent; cursor: default; padding: 10px 6px; }
.list .no {
  width: 20px;
  text-align: right;
  font-size: 10.5px;
  color: var(--muted);
  font-variant-numeric: tabular-nums;
}
.list .grip { color: var(--muted-3); cursor: grab; }
.list .lb { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.list .tag { font-size: 10px; color: var(--muted); }
.mv {
  padding: 0 4px;
  font-size: 9px;
  line-height: 16px;
  border-color: transparent;
  color: var(--muted);
}
.mv:hover { border-color: var(--accent); color: var(--accent); }
.mv:disabled { opacity: 0.25; cursor: default; border-color: transparent; color: var(--muted); }
.mv.off:hover { border-color: var(--warn); color: var(--warn); }

.dlg footer { border-top: 1px solid var(--line); }
.where { font-size: 11px; color: var(--muted); max-width: 520px; line-height: 1.5; }
.where strong { color: var(--text); }
.where .muted { display: block; }
button.go { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
button.go:hover { color: var(--on-accent); }
button.go:disabled { opacity: 0.5; cursor: default; }
header .x { border: 0; background: transparent; font-size: 14px; color: var(--muted); padding: 2px 6px; }
header .x:hover { color: var(--text); }
</style>
