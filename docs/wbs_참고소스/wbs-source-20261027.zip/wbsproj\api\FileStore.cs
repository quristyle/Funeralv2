namespace WbsApi;

/// <summary>
/// 보관 파일 — 대시보드가 디스크에 쌓아 두는 것들을 한 화면(#/files)에서 본다.
///
/// 왜 필요한가: 파일이 네 군데에 따로 쌓인다. 붙여넣은 이미지는 본문에서 지워도 파일은
/// 남고, 첨부는 폴더 이름(= 대상 ID)으로만 주인을 알 수 있다. 어디에 무엇이 얼마나
/// 있는지 볼 데가 없으면 용량이 새는 것도, 주인 없는 파일도 아무도 모른다.
///
/// 이 클래스는 <b>읽기만</b> 한다. 지우는 것은 각 보관소의 제 API 로 한다
/// (<see cref="RowFiles"/> · <see cref="IfFiles"/>) — 지우는 규칙이 보관소마다 다르기 때문이다.
/// </summary>
public static class FileStore
{
    /// <summary>한 보관소의 정의. kind 가 'flat' 이면 파일이 바로 들어 있고, 'owner' 면 한 겹 더 있다.</summary>
    private sealed record Store(
        string Key, string Label, string Dir, string Kind, string What, string? UrlBase = null);

    private static List<Store> Stores(IWebHostEnvironment env, IConfiguration cfg, string rowRoot, string uploadDir)
    {
        var content = env.ContentRootPath;
        var projectRoot = Path.GetFullPath(Path.Combine(content, ".."));
        return
        [
            new("row_files", "화면설계 문서", rowRoot, "owner",
                "상세 목록 한 줄에 붙인 화면설계 문서. 폴더 이름은 줄 식별 번호(row_uid)다 — "
                + "Activity ID 가 아직 없는 줄에도 붙일 수 있도록."),
            new("if_files", "인터페이스 첨부", Path.Combine(content, "data", "if_files"), "owner",
                "인터페이스 카탈로그의 첨부. 폴더 이름이 if_id 다."),
            new("uploads", "붙여넣은 이미지", uploadDir, "flat",
                "개발자 정보·일감 본문에 붙여넣은 이미지. 본문에서 지워도 파일은 남는다.", "/uploads/"),
            new("devlogs", "개발서버 로그", Path.Combine(content, "data", "devlogs"), "flat",
                "로컬 개발서버(PMM BE/FE) 기동 로그와 상태 파일."),
            new("pv_exports", "ProjectView Export", PvExportDir(cfg), "flat",
                "ProjectView 에서 내려받은 WBS 엑셀. 서버 로컬 폴더이며 설정(PvSync:ExportDir)으로 바꾼다."),
            new("logs", "대시보드 로그", Path.Combine(projectRoot, "logs"), "flat",
                "start.cmd 가 남기는 API·Vite 로그. 창을 띄우지 않는 대신 여기로 간다."),
        ];
    }

    // PvSync.cs 의 ExportDir 과 같은 값을 본다 (그쪽은 private 이라 기본값을 함께 적어 둔다).
    private static string PvExportDir(IConfiguration cfg) =>
        cfg["PvSync:ExportDir"] ?? @"D:\수빅자재\projectview_exports";

    private static IEnumerable<FileInfo> FilesOf(Store s)
    {
        var d = new DirectoryInfo(s.Dir);
        if (!d.Exists) return [];
        try
        {
            return s.Kind == "owner"
                ? d.GetDirectories().SelectMany(x => x.GetFiles())
                : d.GetFiles();
        }
        catch (IOException) { return []; }        // 쓰는 중인 폴더
        catch (UnauthorizedAccessException) { return []; }
    }

    public static void Map(WebApplication app, string rowRoot, string uploadDir)
    {
        var env = app.Environment;
        var cfg = app.Configuration;

        // 보관소 요약 — 화면 상단 카드
        app.MapGet("/api/files/stores", () =>
            Results.Ok(Stores(env, cfg, rowRoot, uploadDir).Select(s =>
            {
                var files = FilesOf(s).ToList();
                return new
                {
                    key = s.Key,
                    label = s.Label,
                    dir = Path.GetFullPath(s.Dir),
                    exists = Directory.Exists(s.Dir),
                    what = s.What,
                    owners = s.Kind == "owner" && Directory.Exists(s.Dir)
                        ? new DirectoryInfo(s.Dir).GetDirectories().Length
                        : (int?)null,
                    cnt = files.Count,
                    bytes = files.Sum(f => f.Length),
                    newest = files.Count == 0 ? null : files.Max(f => f.LastWriteTime).ToString("yyyy-MM-dd HH:mm"),
                };
            })));

        // 한 보관소의 파일 목록
        //
        // uploads 만 <쓰임> 을 함께 본다. 본문에서 지워도 파일은 남아, 주인 없는 이미지가
        // 조용히 쌓이는 유일한 보관소이기 때문이다. 나머지는 폴더 이름이 곧 주인이다.
        app.MapGet("/api/files/list", async (PgPool db, string store, int? limit) =>
        {
            var s = Stores(env, cfg, rowRoot, uploadDir).FirstOrDefault(x => x.Key == store);
            if (s is null) return Results.BadRequest(new { error = $"그런 보관소가 없습니다: {store}" });

            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (s.Key == "uploads")
            {
                // 본문 어딘가에 '/uploads/<이름>' 이 들어 있으면 쓰이는 중이다.
                // 두 곳뿐이다 — 개발자 정보(dev_docs)와 일감(hhip_wbs_task).
                var texts = await db.QueryAsync("""
                    select content as t from public.dev_docs
                    union all
                    select memo    as t from public.hhip_wbs_task
                    """);
                foreach (var f in FilesOf(s))
                    if (texts.Any(r => r["t"] is string t && t.Contains("/uploads/" + f.Name, StringComparison.OrdinalIgnoreCase)))
                        used.Add(f.Name);
            }

            // 주인 이름(= 폴더)을 보기 좋은 이름으로 바꿔 줄 자료.
            // 폴더 이름만으로는 어느 화면인지 알 수 없어 목록을 못 쓴다.
            var title = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (s.Key == "row_files")
                // 폴더 이름(row_uid)만으로는 어느 화면인지 알 수 없다.
                // Activity ID 가 아직 없는 줄도 있으므로 모듈·메뉴명을 함께 붙인다.
                foreach (var r in await db.QueryAsync(
                    "select row_uid::text as uid, activity_id, systemcode, menu_nm from public.hhip_wbs_wrk2"))
                    title[(string)r["uid"]!] =
                        $"{r["systemcode"]} · {r["menu_nm"]}"
                        + (r["activity_id"] is string a && a.Length > 0 ? $" ({a})" : " (ID 미정)");
            else if (s.Key == "if_files")
                foreach (var r in await db.QueryAsync("select if_id::text as id, if_cd, if_nm from public.if_master"))
                    title[(string)r["id"]!] = $"{r["if_cd"]} · {r["if_nm"]}";

            var rows = FilesOf(s)
                .OrderByDescending(f => f.LastWriteTime)
                .Take(Math.Clamp(limit ?? 500, 1, 5000))
                .Select(f =>
                {
                    var owner = s.Kind == "owner" ? f.Directory?.Name : null;
                    // 우리가 만든 파일은 '{파일ID}__{원래이름}' 이지만, 손으로 넣어 둔 것이
                    // 섞여 있을 수 있다. 구분자가 없으면 주소를 만들지 않는다.
                    var sep = f.Name.IndexOf("__", StringComparison.Ordinal);
                    var fileId = sep > 0 ? f.Name[..sep] : null;
                    return new
                    {
                        name = s.Kind == "owner" ? RowFiles.NameOf(f.Name) : f.Name,
                        raw = f.Name,
                        owner,
                        owner_title = owner is not null && title.TryGetValue(owner, out var t) ? t : null,
                        size = f.Length,
                        modified = f.LastWriteTime.ToString("yyyy-MM-dd HH:mm"),
                        // 내려받을 수 있는 주소. 보관소마다 길이 달라 서버가 만들어 준다.
                        url = s.Key switch
                        {
                            "uploads" => s.UrlBase + f.Name,
                            "row_files" when fileId is not null => $"/api/rows/{owner}/files/{fileId}",
                            "if_files" when fileId is not null => $"/api/if/{owner}/files/{fileId}",
                            _ => null,   // 로그·엑셀은 서버 로컬 폴더다 — 주소를 열어 주지 않는다
                        },
                        used = s.Key == "uploads" ? used.Contains(f.Name) : (bool?)null,
                    };
                })
                .ToList();

            return Results.Ok(new
            {
                key = s.Key, label = s.Label, dir = Path.GetFullPath(s.Dir),
                exists = Directory.Exists(s.Dir), what = s.What, files = rows,
            });
        });
    }
}
