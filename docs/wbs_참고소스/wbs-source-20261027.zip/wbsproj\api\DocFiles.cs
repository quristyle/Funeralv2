using System.Text;
using System.Text.Json;

namespace WbsApi;

/// <summary>
/// 개발자 정보(<c>#/docs</c>) 섹션에 <b>HTML 문서를 여러 장 올려 두고 iframe 으로 보여 주는</b> 길.
///
/// 보관 위치 — <c>api/data/doc_files/{섹션 id}/{파일}</c> · 목록은 <c>public.dev_doc_files</c>
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>왜 본문(content)에 넣지 않나.</b> 올리는 것은 <i>문서 한 벌</i>이다. 스타일·스크립트가
/// 통째로 들어 있고 수백 KB 가 넘기도 한다. 섹션 본문에 풀어 넣으면
/// <list type="bullet">
/// <item>올린 쪽 CSS 가 <b>대시보드 화면 전체를 칠한다</b> — 글 하나 올렸다가 사이드바가 바뀐다</item>
/// <item>편집기가 열 수 없는 크기가 되고, 한 번 열면 태그가 뭉개진다</item>
/// </list>
/// iframe 은 그 둘을 모두 막는다 — 남의 집 CSS 가 넘어오지 않는다.
///
/// <b>왜 wwwroot 가 아닌가.</b> <c>npm run build</c> 가 <c>emptyOutDir</c> 로 wwwroot 를 비운다.
/// 거기 두면 <b>프런트를 빌드할 때마다 올려 둔 문서가 날아간다.</b>
///
/// <b>여러 장을 둘 때 조심할 것.</b>
/// <list type="bullet">
/// <item>이름이 겹칠 수 있다. 폴더를 비우지 않으니 <c>설계.html</c> 을 두 번 올리면 뒤엣것이
///       앞엣것을 덮어쓴다 — <see cref="Unique"/> 로 <c>설계-2.html</c> 을 만들어 피한다.</item>
/// <item>지울 때는 <b>그 줄의 파일만</b> 지운다. 폴더째 지우던 버릇이 남으면 한 장 내렸다가
///       나머지가 같이 사라진다.</item>
/// </list>
///
/// <b>내려 줄 때 무엇을 조심하나.</b>
/// <list type="bullet">
/// <item><c>Content-Type: text/html</c> 로 준다 — iframe 이 글로 읽어야 한다(첨부로 내려 주면 안 된다).</item>
/// <item>경로는 파일 이름만 쓴다(<see cref="Safe"/>) — <c>..</c> 로 바깥을 긁지 못하게.</item>
/// </list>
/// </summary>
public static class DocFiles
{
    private const long MaxBytes = 8L * 1024 * 1024;   // 한 장짜리 문서다. 8MB 를 넘으면 뭔가 잘못됐다.
    private const int MaxPerDoc = 30;                 // 탭으로 보여 준다. 그 이상은 사람이 못 고른다.

    private static string Root(IWebHostEnvironment env) =>
        Path.Combine(env.ContentRootPath, "data", "doc_files");

    private static string DirOf(IWebHostEnvironment env, int id) =>
        Path.Combine(Root(env), id.ToString());

    /// <summary>경로 조작·제어문자를 막는다. 확장자는 그대로 둔다.</summary>
    private static string Safe(string? name)
    {
        var n = Path.GetFileName(name ?? "").Trim();
        if (string.IsNullOrWhiteSpace(n)) n = "page.html";

        var bad = Path.GetInvalidFileNameChars().Concat(['\\', '/', ':', '*', '?', '"', '<', '>', '|']).ToHashSet();
        var sb = new StringBuilder(n.Length);
        foreach (var c in n) sb.Append(bad.Contains(c) || char.IsControl(c) ? '_' : c);

        n = sb.ToString().TrimStart('.');
        if (n.Length == 0) n = "page.html";
        return n.Length > 120 ? n[^120..] : n;
    }

    /// <summary>
    /// 폴더 안에서 겹치지 않는 이름을 고른다 — <c>설계.html</c> → <c>설계-2.html</c> → <c>설계-3.html</c>.
    /// 여러 장을 두면서부터 필요해졌다. 한 장만 두던 시절에는 폴더를 비우고 넣어서 겹칠 일이 없었다.
    /// </summary>
    private static string Unique(string dir, string name)
    {
        if (!File.Exists(Path.Combine(dir, name))) return name;

        var stem = Path.GetFileNameWithoutExtension(name);
        var ext = Path.GetExtension(name);
        for (var i = 2; i < 1000; i++)
        {
            var cand = $"{stem}-{i}{ext}";
            if (!File.Exists(Path.Combine(dir, cand))) return cand;
        }
        return $"{stem}-{Guid.NewGuid():N}{ext}";   // 여기까지 올 일은 없다
    }

    /// <summary>
    /// 섹션을 <b>영영 지울 때</b>(purge) 올려 둔 문서도 함께 치운다.
    /// 표의 줄은 <c>on delete cascade</c> 로 따라 지워진다 — 여기서는 파일만 본다.
    ///
    /// 휴지통으로 보내는 평소의 삭제에서는 <b>부르지 않는다</b> — 되살릴 수 있는 글인데
    /// 파일만 먼저 없애면, 되살려 놓고 보니 <i>빈 iframe</i> 이 남는다.
    /// </summary>
    public static void Purge(IWebHostEnvironment env, int id)
    {
        var dir = DirOf(env, id);
        if (!Directory.Exists(dir)) return;
        try { Directory.Delete(dir, true); }
        catch (Exception e) { Console.WriteLine($"[docs/iframe] id={id} 파일 치우기 실패 — {e.Message}"); }
    }

    private const string Cols = """
        select id, doc_id, file, url, name, bytes, sort_order, uploaded_by
             , to_char(uploaded_at,'YYYY-MM-DD HH24:MI') as uploaded_at
          from public.dev_doc_files
        """;

    public static void Map(WebApplication app)
    {
        // 전체 목록 — 화면이 처음 뜰 때 한 번 받아 섹션별로 갈라 쓴다.
        // 섹션마다 한 번씩 물으면 21번을 묻게 된다.
        app.MapGet("/api/docs/iframes", async (PgPool db) =>
            Results.Ok(await db.QueryAsync(Cols + " order by doc_id, sort_order, id")));

        // 한 섹션의 목록
        app.MapGet("/api/docs/{id:int}/iframe", async (PgPool db, int id) =>
            Results.Ok(await db.QueryAsync(
                Cols + " where doc_id = $1::int order by sort_order, id", [id])));

        // 올리기 — 여러 장을 한꺼번에 받는다. 있던 것 뒤에 붙는다(덮어쓰지 않는다).
        app.MapPost("/api/docs/{id:int}/iframe", async (PgPool db, IpGate g, HttpContext ctx,
                                                       IWebHostEnvironment env, int id) =>
        {
            var form = await ctx.Request.ReadFormAsync();
            var files = form.Files.Where(f => f.Length > 0).ToList();
            if (files.Count == 0) return Results.BadRequest(new { error = "파일이 없습니다." });

            var found = await db.QueryAsync("select title from public.dev_docs where id = $1::int", [id]);
            if (found.Count == 0) return Results.NotFound(new { error = "그 섹션을 찾지 못했습니다.", id });

            var have = await db.QueryAsync(
                "select count(*) as n, coalesce(max(sort_order),0) as mx from public.dev_doc_files where doc_id = $1::int",
                [id]);
            var count = Convert.ToInt32(have[0]["n"] ?? 0L);
            var order = Convert.ToInt32(have[0]["mx"] ?? 0L);
            if (count + files.Count > MaxPerDoc)
                return Results.BadRequest(new { error = $"한 섹션에 {MaxPerDoc} 장까지입니다 (지금 {count} 장)." });

            var me = await g.CheckAsync(ctx);
            var who = string.IsNullOrWhiteSpace(me.Name) ? me.BpId : me.Name;
            var dir = DirOf(env, id);
            Directory.CreateDirectory(dir);

            var added = new List<Dictionary<string, object?>>();
            var skipped = new List<object>();

            foreach (var file in files)
            {
                var name = Safe(file.FileName);
                var ext = Path.GetExtension(name).ToLowerInvariant();
                if (ext is not (".html" or ".htm"))
                {
                    skipped.Add(new { name = file.FileName, why = "HTML 파일만 올릴 수 있습니다 (.html · .htm)." });
                    continue;
                }
                if (file.Length > MaxBytes)
                {
                    skipped.Add(new { name = file.FileName, why = $"8MB 를 넘습니다 ({file.Length / 1024 / 1024}MB)." });
                    continue;
                }

                var stored = Unique(dir, name);
                await using (var w = File.Create(Path.Combine(dir, stored)))
                    await file.CopyToAsync(w);

                order += 10;
                var row = await db.QueryAsync("""
                    insert into public.dev_doc_files (doc_id, file, name, bytes, sort_order, uploaded_by)
                    values ($1::int, $2::text, $3::text, $4::bigint, $5::int, $6::text)
                    returning id, doc_id, file, name, bytes, sort_order, uploaded_by
                            , to_char(uploaded_at,'YYYY-MM-DD HH24:MI') as uploaded_at
                    """, [id, stored, file.FileName, file.Length, order, who]);
                added.Add(row[0]);

                Console.WriteLine($"[docs/iframe] {DateTime.Now:HH:mm:ss} id={id} +\"{file.FileName}\""
                                + $" {file.Length / 1024}KB by={who}");
            }

            if (added.Count == 0)
                return Results.BadRequest(new { error = skipped.Count > 0 ? "올리지 못했습니다." : "파일이 없습니다.", skipped });

            return Results.Ok(new { id, added, skipped });
        }).DisableAntiforgery();

        // 주소(URL)로 걸기 — 파일을 올리는 대신 남의 화면을 그대로 띄운다.
        //
        // 받아다 중계하지 않는다. 중계하면 그 사이트의 로그인이 끊겨 사내 화면이 거의 다
        // 안 열리고, 남의 사이트를 우리 주소로 내보내는 꼴이 된다. 화면이 그 주소를 iframe 에
        // 그대로 건다 — 상대가 X-Frame-Options 로 막아 두었으면 빈 칸으로 보이고,
        // 그 사정은 화면이 적어 준다.
        app.MapPost("/api/docs/{id:int}/iframe/url", async (PgPool db, IpGate g, HttpContext ctx,
                                                            int id, JsonElement body) =>
        {
            var raw = (body.TryGetProperty("url", out var u) ? u.GetString() : null)?.Trim() ?? "";
            var label = (body.TryGetProperty("name", out var nm) ? nm.GetString() : null)?.Trim();

            if (raw.Length == 0) return Results.BadRequest(new { error = "주소를 적어 주세요." });
            // 스킴을 안 적는 일이 잦다. https 로 메워 준다 — 적어 넣으라고 되묻지 않는다.
            if (!raw.Contains("://")) raw = "https://" + raw;
            if (!Uri.TryCreate(raw, UriKind.Absolute, out var uri)
                || (uri.Scheme != "http" && uri.Scheme != "https"))
                return Results.BadRequest(new { error = "http · https 주소만 걸 수 있습니다." });
            if (raw.Length > 2000) return Results.BadRequest(new { error = "주소가 너무 깁니다." });

            var found = await db.QueryAsync("select title from public.dev_docs where id = $1::int", [id]);
            if (found.Count == 0) return Results.NotFound(new { error = "그 섹션을 찾지 못했습니다.", id });

            var have = await db.QueryAsync(
                "select count(*) as n, coalesce(max(sort_order),0) as mx from public.dev_doc_files where doc_id = $1::int",
                [id]);
            if (Convert.ToInt32(have[0]["n"] ?? 0L) >= MaxPerDoc)
                return Results.BadRequest(new { error = $"한 섹션에 {MaxPerDoc} 장까지입니다." });

            // 이름을 안 붙이면 주소에서 딴다 — 탭에 긴 주소가 통째로 들어가면 못 읽는다
            // 해시로 길을 나누는 화면(#/tables)이 사내에 많다. 조각(Fragment)을 빼고 따면
            // 탭에 <호스트 이름>만 남아, 같은 서버의 화면 둘을 걸면 이름이 똑같아진다.
            if (string.IsNullOrWhiteSpace(label))
                label = uri.Host + (uri.AbsolutePath.Length > 1 ? uri.AbsolutePath : "") + uri.Fragment;
            if (label.Length > 120) label = label[..120];

            var me = await g.CheckAsync(ctx);
            var who = string.IsNullOrWhiteSpace(me.Name) ? me.BpId : me.Name;
            var row = await db.QueryAsync("""
                insert into public.dev_doc_files (doc_id, url, name, bytes, sort_order, uploaded_by)
                values ($1::int, $2::text, $3::text, 0, $4::int, $5::text)
                returning id, doc_id, file, url, name, bytes, sort_order, uploaded_by
                        , to_char(uploaded_at,'YYYY-MM-DD HH24:MI') as uploaded_at
                """, [id, raw, label, Convert.ToInt32(have[0]["mx"] ?? 0L) + 10, who]);

            Console.WriteLine($"[docs/iframe] {DateTime.Now:HH:mm:ss} id={id} +url \"{raw}\" by={who}");
            return Results.Ok(new { id, added = new[] { row[0] }, skipped = Array.Empty<object>() });
        });

        // 보여 주기 — iframe 이 이 주소를 연다
        app.MapGet("/api/docs/{id:int}/iframe/{fid:int}", async (PgPool db, IWebHostEnvironment env,
                                                                 HttpContext ctx, int id, int fid) =>
        {
            var rows = await db.QueryAsync(
                "select file, url from public.dev_doc_files where id = $1::int and doc_id = $2::int", [fid, id]);
            if (rows.Count == 0) return Results.NotFound("올려 둔 문서가 없습니다.");

            // 주소로 건 줄은 화면이 그 주소를 바로 연다. 여기까지 오는 것은 옛 주소를 들고
            // 온 경우뿐이라 그쪽으로 보내 준다.
            if (rows[0]["url"] is string link && link.Length > 0) return Results.Redirect(link);

            var path = Path.Combine(DirOf(env, id), Safe(rows[0]["file"] as string));
            if (!File.Exists(path)) return Results.NotFound("파일을 찾지 못했습니다.");

            var html = await File.ReadAllTextAsync(path);
            // 올린 뒤에 파일을 손으로 고치는 일이 있다(가로 여백을 없앤다든지).
            // 주소의 ?v= 꼬리는 <화면이 다시 올릴 때만> 바뀌므로, 그런 손질은 꼬리가 그대로다 —
            // 막지 않으면 브라우저가 고치기 전 사본을 계속 꺼내 보여 준다. 실제로 밟았다.
            ctx.Response.Headers.CacheControl = "no-cache, must-revalidate";
            return Results.Text(html, "text/html; charset=utf-8");
        });

        // 한 장 내리기 — 그 줄의 파일만 지운다. 폴더는 두어야 한다(나머지가 그 안에 있다).
        app.MapDelete("/api/docs/{id:int}/iframe/{fid:int}", async (PgPool db, IpGate g, HttpContext ctx,
                                                                    IWebHostEnvironment env, int id, int fid) =>
        {
            var rows = await db.QueryAsync(
                "select file, name from public.dev_doc_files where id = $1::int and doc_id = $2::int", [fid, id]);
            if (rows.Count == 0) return Results.NotFound(new { error = "대상 없음", id, fid });

            // 주소로 건 줄은 지울 파일이 없다 (file 이 비어 있다).
            var stored = rows[0]["file"] as string ?? "";
            if (stored.Length > 0)
            {
                var path = Path.Combine(DirOf(env, id), Safe(stored));
                if (File.Exists(path)) { try { File.Delete(path); } catch { /* 표시만 지워도 안 보인다 */ } }
            }

            var n = await db.ExecuteAsync("delete from public.dev_doc_files where id = $1::int", [fid]);
            var me = await g.CheckAsync(ctx);
            Console.WriteLine($"[docs/iframe] {DateTime.Now:HH:mm:ss} id={id} -\"{rows[0]["name"]}\""
                            + $" by={me.Name ?? me.BpId}");
            return Results.Ok(new { removed = n, id, fid });
        });

        // 차례 바꾸기 — 받은 순서대로 sort_order 를 다시 매긴다.
        // 화면의 탭을 왼쪽·오른쪽으로 옮길 때 쓴다.
        app.MapPut("/api/docs/{id:int}/iframe/order", async (PgPool db, int id, JsonElement body) =>
        {
            if (!body.TryGetProperty("ids", out var arr) || arr.ValueKind != JsonValueKind.Array)
                return Results.BadRequest(new { error = "ids 가 필요합니다." });

            var order = 0;
            var n = 0;
            foreach (var el in arr.EnumerateArray())
            {
                if (el.ValueKind != JsonValueKind.Number) continue;
                order += 10;
                n += await db.ExecuteAsync(
                    "update public.dev_doc_files set sort_order = $1::int where id = $2::int and doc_id = $3::int",
                    [order, el.GetInt32(), id]);
            }
            return Results.Ok(new { ordered = n, id });
        });
    }
}
