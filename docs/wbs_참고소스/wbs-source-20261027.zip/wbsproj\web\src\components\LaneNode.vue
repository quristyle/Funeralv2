<script setup>
// 레인(업무 단계) 띠.
//
// 화면 위에 고정해 두었더니 <확대·이동하면 칸과 어긋났다> — 띠는 "지금 보는 곳이 어느
// 단계인가" 를 알려 주는 것인데, 칸을 따라가지 않으면 거짓말을 하게 된다.
// 그래서 캔버스 안의 칸으로 만들어 함께 움직이게 했다.
//
// 띠 자체는 손이 통과한다(pointer-events:none) — 띠 위에서도 캔버스를 끌 수 있어야 한다.
// 다만 <이름표만> 손을 받는다. 누르면 그 단계의 테이블만 보여 준다.
defineProps({ data: { type: Object, required: true } })
</script>

<template>
  <div class="lane" :class="{ on: data.on }" :style="{ width: data.w + 'px', height: data.h + 'px' }">
    <div class="ttl" :title="data.on ? '다시 누르면 전체로 돌아갑니다' : '이 단계의 테이블만 봅니다'">
      {{ data.name }}
    </div>
  </div>
</template>

<style scoped>
.lane {
  box-sizing: border-box;
  border-left: 1px dashed var(--line);
  border-right: 1px dashed var(--line);
  background: linear-gradient(var(--panel), transparent 120px);
  opacity: 0.55;
  pointer-events: none;   /* 띠 위에서도 캔버스를 끌 수 있어야 한다 */
}
/* 고른 단계 — 띠째로 세워 둔다. 머리글자만 바뀌면 어디까지가 그 단계인지 모른다 */
.lane.on {
  opacity: 1;
  background: linear-gradient(var(--accent-soft), transparent 180px);
  border-left-color: var(--accent);
  border-right-color: var(--accent);
  border-left-style: solid;
  border-right-style: solid;
}
.ttl {
  font-size: 13px;
  font-weight: 600;
  color: var(--muted);
  text-align: center;
  padding: 8px 4px;
  letter-spacing: 0.2px;
  pointer-events: auto;   /* 이름표만 손을 받는다 */
  cursor: pointer;
  border-radius: 0;
}
.ttl:hover { color: var(--accent); background: var(--accent-soft); }
.lane.on .ttl { color: var(--accent); }
</style>
