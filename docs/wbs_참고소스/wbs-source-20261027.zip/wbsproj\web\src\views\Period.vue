<script setup>
import BarChart from '../components/BarChart.vue'
import RefreshBtn from '../components/RefreshBtn.vue'
import { state, monthItems, weekItems, pickMonth, pickWeek, loadStats } from '../store'

const emit = defineEmits(['drill'])

function onMonth(b) {
  pickMonth(b)
  if (state.sel.month) emit('drill')
}
function onWeek(b) {
  pickWeek(b)
  if (state.sel.week) emit('drill')
}
</script>

<template>
  <div class="grid2">
    <section class="panel">
      <h2>
        월단위 건수 <span class="hint">막대 클릭 시 상세 목록으로 이동</span>
        <span class="spacer"></span>
        <RefreshBtn :fn="loadStats" />
      </h2>
      <BarChart :items="monthItems" :active="state.sel.month" @pick="onMonth" />
    </section>

    <section class="panel">
      <h2>
        주단위 건수 <span class="hint">ISO 주 · 월요일 시작</span>
        <span class="spacer"></span>
        <RefreshBtn :fn="loadStats" />
      </h2>
      <BarChart :items="weekItems" :active="state.sel.week" @pick="onWeek" />
    </section>
  </div>
</template>

<style scoped>
h2 .spacer { flex: 1; }
</style>
