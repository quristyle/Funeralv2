<script setup>
import { computed, markRaw, nextTick, onMounted, onUnmounted, provide, reactive, ref, watch } from 'vue'
import { VueFlow, useVueFlow, MarkerType } from '@vue-flow/core'
import { Background } from '@vue-flow/background'
import { ControlButton, Controls } from '@vue-flow/controls'
import { MiniMap } from '@vue-flow/minimap'
import { api } from '../api'
import { state } from '../store'
import TableNode from '../components/TableNode.vue'
import LaneNode from '../components/LaneNode.vue'
import WayEdge from '../components/WayEdge.vue'

import '@vue-flow/core/dist/style.css'
import '@vue-flow/core/dist/theme-default.css'
import '@vue-flow/controls/dist/style.css'
import '@vue-flow/minimap/dist/style.css'

// 자재 테이블 계통도 — 보고 <고치는> 쪽.
//
// 기존 #/tables 는 그대로 둔다. 저쪽은 읽기 전용이고 배치가 코드에 박혀 있어
// 한 칸을 옮기려면 flow.html 을 고쳐야 한다. 이 화면은 끌어 옮기고 이어서 저장한다.
//
// 처음 모습은 저쪽 데이터에서 구워 왔다(tools/graph/gen-tables.mjs) —
// 48칸 · 71이음선. 다시 구우려면 그 스크립트를 돌리고 [기본 배치로] 를 누른다.

/**
 * 어느 스키마의 계통도인가. 도면은 스키마마다 <한 장> 이다.
 *
 * 한 장에 둘을 섞지 않는 까닭: 같은 이름의 표가 두 스키마에 다 있다
 * (M10 에도 M20 에도 T30B_1120 이 있다). 섞으면 <어느 쪽 표인지> 가릴 길이 없다.
 * 처음에는 M20 을 M10 의 사본으로 두었고, 이후로는 따로 자란다.
 *
 * 마지막으로 본 쪽을 이 PC 에 적어 둔다 — 서버에 둘 것이 아니다(사람마다 보는 쪽이 다르다).
 */
/**
 * 보던 상태를 이 PC 에 적어 둔다 — 다시 열면 <보던 그대로> 다.
 *
 * 한 덩이(VIEW_LS)로 모은 까닭: 조각마다 키를 따로 두면 하나 늘릴 때마다 읽고 쓰는 자리를
 * 두 군데씩 고치게 되고, 한쪽을 빠뜨리면 <켜 두었는데 안 켜져 있는> 것이 생긴다.
 *
 * 서버가 아니라 localStorage 인 까닭: 사람마다 보는 쪽·거르는 것·상자 자리가 다르다.
 * 도면 자체(칸과 선)만 서버의 것이다.
 *
 * 찾는 글자(q)는 일부러 뺐다 — 다시 열었을 때 글자가 남아 있으면 칸 대부분이 흐린 채로
 * 떠서 <고장 난 화면> 으로 보인다.
 */
const VIEW_LS = 'wbs.tables2.view'
const savedView = (() => {
  try { return JSON.parse(localStorage.getItem(VIEW_LS) || 'null') || {} } catch { return {} }
})()
let viewReady = false
function saveView() {
  if (!viewReady) return     // 첫 그리기 중의 기본값으로 덮어쓰지 않는다
  try {
    localStorage.setItem(VIEW_LS, JSON.stringify({
      flows2: [...flowSel.value],   // ⚠ 옛 `flow`(묶음 하나)를 대신한다 — 여럿 고를 수 있다
      lane: laneSel.value,
      // ⚠ 키 이름이 `kinds` 에서 바뀌었다 — 뜻이 뒤집혔기 때문이다.
      //   옛 `kinds` 는 <거를 종류(빈 배열 = 안 거름 = 전부)>, 지금 `kinds2` 는 <보일 종류>다.
      //   같은 키에 적으면 「모두 끄기」 한 것이 다음에 켤 때 <전부>로 되살아난다.
      kinds2: [...edgeSel.value],
      onlyLinked: onlyLinked.value,
      hoverHi: hoverHi.value,
      showMap: showMap.value,
      autoSave: autoSave.value,
      v2: true,
      // ⚠ 선 보기 기본이 <전부>에서 <모두 끄기> 로 뒤집힌 판. 이 표가 없는 저장분은
      //   한 번 무시하고 끈 채로 연다 — v2 가 autoSave 에 했던 것과 같다.
      v3: true,
    }))
  } catch { /* 못 적어도 이번 화면에서는 그대로 쓴다 */ }
}

/**
 * 가상의 격자. 칸을 끌면 이 눈금에 자석처럼 붙는다.
 *
 * 20 인 까닭: 처음 배치의 모든 값이 20 의 배수다(칸 200×40 · 열 240 · 줄 80 · 여백 40/100).
 * 격자와 배치가 어긋나면 <첫 드래그에서 칸이 튄다> — 아무것도 안 했는데 자리가 바뀐다.
 * 바탕의 점무늬도 같은 눈금으로 그려, 붙을 자리가 눈에 보이게 한다.
 */
const GRID = 20

/**
 * 자동저장.
 *
 * 끌어 놓을 때마다 [저장] 을 누르는 것이 번거롭다는 요청이다. 다만 <바뀔 때마다 바로>는
 * 보내지 않는다 — 칸 하나를 옮기는 동안에도 여러 번 바뀐다. 잠깐 멎으면(1.2초) 한 번 보낸다.
 *
 * ⚠️ 남이 먼저 저장했으면 서버가 409 로 막는다(덮어쓰기 방지). 그때 자동저장을 켜 둔 채로
 *    두면 1.2초마다 같은 거절을 되풀이한다. 그래서 <스스로 꺼지고> 사람에게 알린다.
 */
// 기본은 <켜짐> 이다. "바뀌면 저장되어야 한다" 가 이 화면의 약속이라,
// 꺼 두는 것이 예외다. 예전에 꺼 둔 설정이 남아 있어도 한 번은 켜고 시작한다(v2).
const autoSave = ref(savedView.v2 ? savedView.autoSave !== false : true)
let autoTimer = null
function toggleAuto() {
  autoSave.value = !autoSave.value
  saveView()
  if (autoSave.value && dirty.value) queueAuto()
}
function queueAuto() {
  if (!autoSave.value) return
  clearTimeout(autoTimer)
  autoTimer = setTimeout(() => { if (autoSave.value && dirty.value && !busy.value) save() }, 600)
}
onUnmounted(() => clearTimeout(autoTimer))

const SCHEMAS = ['M10', 'M20']
const SCHEMA_LS = 'wbs.tables2.schema'
const schema = ref((() => {
  try {
    const v = localStorage.getItem(SCHEMA_LS)
    return SCHEMAS.includes(v) ? v : 'M10'
  } catch { return 'M10' }
})())
const graphName = computed(() => 'tables-' + schema.value.toLowerCase())

/**
 * 스키마를 바꾼다.
 *
 * ⚠️ 바꾸면 도면을 통째로 다시 읽는다. 저장하지 않은 것이 있으면 <말없이 사라진다> —
 *    그래서 되돌리고 알려 준다. 묻는 창을 띄우지 않는 것은 이 화면의 다른 곳과 같은 규칙이고,
 *    대신 <아무 일도 일어나지 않게> 막는다.
 */
async function changeSchema(next) {
  if (next === schema.value) return
  if (dirty.value) {
    toast(`저장하지 않은 것이 있어 ${next} 로 바꾸지 않았습니다 — [저장] 하거나 [⟳ 다시 읽기] 뒤에 바꾸세요.`, 7000)
    return
  }
  schema.value = next
  try { localStorage.setItem(SCHEMA_LS, next) } catch { /* 이번 화면에서는 그대로 쓴다 */ }
  // 거르던 것은 푼다 — 다른 도면에 옛 조건이 걸려 있으면 "왜 비었지" 가 된다
  flowSel.value = new Set()
  laneSel.value = null
  edgeSel.value = new Set()      // ⚠ «푼다» = 기본값 = 모두 끄기. 볼 선은 사람이 골라 켠다
  q.value = ''
  onlyLinked.value = false
  sel.value = null
  // 업무항목은 스키마마다 따로다 — 고른 것을 들고 넘어가면 다른 도면의 없는 항목을 가리킨다
  itemSel.value = null
  itemEdit.value = false
  pkOwner.value = next        // DB 에서 찾기의 기본 스키마도 따라간다
  pkRows.value = []
  await load()
}

const nodes = ref([])
const edges = ref([])
const lanes = ref([])
const meta = ref({})
const flows = ref([])
const stamp = ref('')
const hasSeed = ref(false)
const loading = ref(false)
const busy = ref('')
const msg = ref('')
/**
 * 나쁜 소식인가. 색을 가르려고 글을 읽는다 — 부르는 곳이 열 곳이 넘어
 * 자리마다 색을 들려 보내면 한두 곳은 반드시 빠뜨린다.
 */
const msgBad = computed(() => /실패|못 |않았|이미 있는|거절|끊|버립니다|⚠/.test(msg.value))

/** 잠깐 띄웠다 사라지는 알림. 띄우는 곳마다 setTimeout 을 쓰면 서로 타이머를 덮는다. */
let toastTimer = null
function toast(text, ms = 4000) {
  msg.value = text
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => (msg.value = ''), ms)
}
onUnmounted(() => clearTimeout(toastTimer))
const dirty = ref(false)

const nodeTypes = { table: markRaw(TableNode), lane: markRaw(LaneNode) }
// 모든 이음선은 <경유점을 끌 수 있는> 우리 것으로 그린다.
// 점이 하나도 없는 선은 Vue Flow 의 베지어와 같은 모양이라, 바꿔 달아도 지금 그림은 그대로다.
const edgeTypes = { way: markRaw(WayEdge) }

/**
 * 레인을 <캔버스 안의 칸> 으로 만든다.
 *
 * 처음에는 화면 위에 고정한 띠였는데, 확대·이동하면 칸과 어긋났다 — 띠는
 * "지금 보는 곳이 어느 단계인가" 를 알려 주는 것이라 칸을 따라가지 않으면 거짓말이 된다.
 * 끌리지도 눌리지도 이어지지도 않게 막고, 테이블 칸 뒤에 깔리도록 zIndex 를 낮춘다.
 */
function laneNodes() {
  if (!lanes.value.length) return []
  const ys = nodes.value.filter((n) => n.type === 'table').map((n) => n.position.y)
  const bottom = (ys.length ? Math.max(...ys) : 600) + 160
  return lanes.value.map((l) => ({
    id: '__lane' + l.i,
    type: 'lane',
    position: { x: l.x, y: 8 },
    data: { name: (l.i + 1) + '. ' + l.name, w: l.w, h: bottom, lane: l.i, on: laneSel.value === l.i },
    draggable: false, selectable: false, connectable: false, focusable: false,
    zIndex: -1,
    style: { zIndex: -1 },
  }))
}
const { fitView, project, getViewport, setViewport, addSelectedNodes, findNode, updateNodeInternals } = useVueFlow()

/**
 * 전체 보기 — 표 전부가 한 화면에 들어오게 맞춘다.
 *
 * ⚠️ 인자 없는 `fitView()` 는 이 화면에서 <b>아무 일도 하지 않는다.</b> 칸을 지정한
 * `fitView({ nodes: [...] })` 는 멀쩡히 돈다(찾기에서 쓰고 있다) — 전부를 맞출 때만 조용히
 * 멎는다. 왼쪽 아래 [전체 보기] 단추가 안 먹던 까닭이 이것이고, 그래서 <b>표 전부의 id 를
 * 하나하나 적어 넘긴다.</b>
 *
 * 덤으로 얻는 것도 있다 — <b>레인(업무 단계 띠)이 범위에서 빠진다.</b> 레인은 맨 아래까지
 * 내려 그어 둔 배경이라, 함께 맞추면 표가 없는 빈 아래쪽까지 넣으려고 그림이 더 작아진다.
 */
function fitAll() {
  const tables = nodes.value.filter((n) => n.type === 'table')
  const box = document.querySelector('.flowwrap')?.getBoundingClientRect()
  if (!tables.length || !box?.width) return

  let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity
  for (const n of tables) {
    const el = document.querySelector(`.vue-flow__node[data-id="${CSS.escape(n.id)}"]`)
    const w = el?.offsetWidth || 196
    const h = el?.offsetHeight || 48
    x1 = Math.min(x1, n.position.x)
    y1 = Math.min(y1, n.position.y)
    x2 = Math.max(x2, n.position.x + w)
    y2 = Math.max(y2, n.position.y + h)
  }
  const PAD = 28
  const z = Math.max(0.12, Math.min(2.4,
    Math.min((box.width - PAD * 2) / (x2 - x1), (box.height - PAD * 2) / (y2 - y1))))
  // ⚠️ duration 을 주지 말 것 — 애니메이션으로 옮기는 길은 이 화면에서 조용히 멎는다.
  //    (그래서 [전체 보기] 가 <가끔> 듣는 것처럼 보였다. 띄울 때의 0 짜리만 듣고 있었다.)
  setViewport({
    x: (box.width - (x2 - x1) * z) / 2 - x1 * z,
    y: (box.height - (y2 - y1) * z) / 2 - y1 * z,
    zoom: z,
  })
}

// ---------- 이음선 모양 ----------
// 네 가지를 색·선으로 가른다. 기존 화면과 같은 약속이다 —
// 두 화면이 다른 색을 쓰면 같은 그림을 두 번 배워야 한다.
/** 지점 이름 — 저장되는 것은 t·r·b·l 이고 사람에게는 이렇게 보인다 */
const PORT = { t: '위', r: '오른쪽', b: '아래', l: '왼쪽' }

/**
 * 흐름 순번의 빛깔. 이음선 컴포넌트(WayEdge)와 <같은 차례> 여야 한다 —
 * 어긋나면 상세에서 고른 빛깔과 그림의 빛깔이 달라진다.
 */
const SEQ_COLORS = ['#1D6F9E', '#2E7D4F', '#B5630B', '#6A4FBF', '#0E7C86', '#B3263E', '#5C6C7A', '#A8327D']
const SEQ_NAMES = ['파랑', '초록', '주황', '보라', '청록', '빨강', '회색', '자홍']

const EDGE_KINDS = [
  { ty: 'proc', label: '처리', color: '#5C6C7A', dash: false },
  { ty: 'trigger', label: '트리거', color: '#B33636', dash: true },
  { ty: 'ext', label: '외부', color: '#6A4FBF', dash: true },
  { ty: 'batch', label: '배치', color: '#2E7D4F', dash: false },
  // 읽기 — 화면이 <보기만> 하는 표. 고치는 선과 섞으면 <이 화면이 무엇을 바꾸는가> 가 묻혀서
  // 빛깔을 죽이고 점선으로 둔다. 위쪽 [선 보기] 에서 통째로 끌 수 있다.
  { ty: 'read', label: '읽기', color: '#9AA3AB', dash: true },
]
const kindOf = (ty) => EDGE_KINDS.find((k) => k.ty === ty) ?? EDGE_KINDS[0]

/** 저장된 모양(data.ty)을 Vue Flow 가 그릴 수 있는 style/marker 로 편다. */
/**
 * 저장된 모양(data.ty)을 Vue Flow 가 그릴 수 있는 style/marker 로 편다.
 *
 * st.hi  주목한 칸에 닿는 선 — 굵게 · 강조색 · 글귀를 또렷하게. 맨 위로 올린다.
 * st.dim 그 밖의 선 — 지우지 않고 아주 흐리게. 지우면 그림의 뼈대가 사라진다.
 */
function dressEdge(e, st = {}) {
  const k = kindOf(e.data?.ty)
  const hi = !!st.hi
  const dim = !!st.dim
  const w = (e.data?.key ? 2.2 : 1.2) + (hi ? 1 : 0)
  const color = hi ? 'var(--accent)' : k.color
  return {
    ...e,
    type: 'way',
    zIndex: hi ? 20 : 0,
    animated: false,
    style: {
      stroke: color,
      strokeWidth: w,
      strokeDasharray: k.dash ? '6 4' : undefined,
      opacity: dim ? 0.07 : 1,
    },
    labelBgStyle: { fill: 'var(--panel)', fillOpacity: hi ? 1 : 0.9 },
    labelStyle: {
      fontSize: hi ? 11 : 9.5,
      fontWeight: hi ? 700 : 400,
      fill: hi ? 'var(--accent)' : 'var(--muted)',
      opacity: dim ? 0.07 : 1,
    },
    labelBgPadding: [3, 1],
    markerEnd: { type: MarkerType.ArrowClosed, color, width: hi ? 15 : 13, height: hi ? 15 : 13 },
  }
}

// ---------- 읽기 ----------
async function load() {
  loading.value = true
  try {
    const d = await api.graphGet(graphName.value)
    stamp.value = d.stamp
    hasSeed.value = !!d.hasSeed
    // ⚠️ 고른 것을 먼저 푼다. 다시 읽은 도면에 <그 칸> 이 없으면(이름을 바꿨거나 지웠거나
    //    스키마가 바뀌었거나) 관계 계산이 빈 집합을 내고 48칸이 통째로 흐려진다.
    //    아무 필터도 안 걸었는데 화면이 하얘지는 꼴이라, 고장으로 보인다. (실제로 밟았다.)
    sel.value = null
    hoverId.value = null
    meta.value = { from: d.graph.from, made: d.graph.made, size: d.graph.size, schema: d.graph.schema }
    lanes.value = d.graph.lanes ?? []
    flows.value = d.graph.flows ?? []
    nodes.value = (d.graph.nodes ?? []).map((n) => ({ ...n, type: 'table' }))
    nodes.value = [...laneNodes(), ...nodes.value]
    edges.value = (d.graph.edges ?? []).map((e) => dressEdge(e))
    dirty.value = false
    state.error = ''
    viewReady = true      // 여기서부터 <사람이 고른 것> 이다
    paint()
    await nextTick()
    fitAll()
    // 꼬리표와 업무항목은 나중에 와도 된다 — 기다리면 DB 가 느린 날 그림이 늦게 뜬다
    loadOwners()
    loadItems().then(paint)
  } catch (e) {
    state.error = `계통도를 읽지 못했습니다: ${e.message}`
  } finally {
    loading.value = false
  }
}
onMounted(load)

// ---------- 저장 ----------
/** 그릴 때 붙인 것(style·marker)은 빼고 <뜻> 만 남겨 저장한다. */
function plain() {
  return {
    // 구울 때 적어 둔 메타(from·made·size)를 그대로 들고 간다 —
    // 빼고 저장하면 한 번 저장한 순간 <어디서 온 도면인지> 가 사라진다.
    ...meta.value,
    v: 1,
    lanes: lanes.value,
    flows: flows.value,
    // ⚠️ 레인은 그릴 때 깔아 주는 것이다. 함께 저장하면 다음에 읽을 때 또 깔려 <두 벌>이 된다.
    nodes: nodes.value.filter((n) => n.type === 'table').map((n) => ({
      id: n.id, type: 'table',
      position: { x: Math.round(n.position.x), y: Math.round(n.position.y) },
      // 그릴 때만 쓰는 표시는 빼고 저장한다 — 파일에 남아 봐야 다음에 paint 가 다시 셈한다.
      // (w·h 는 사람이 정한 크기라 남긴다.)
      data: {
        ...n.data,
        dim: undefined, flash: undefined,
        hot: undefined, near: undefined, found: undefined, inItem: undefined,
      },
    })),
    edges: edges.value.map((e) => ({
      id: e.id, source: e.source, target: e.target,
      sourceHandle: e.sourceHandle ?? null, targetHandle: e.targetHandle ?? null,
      label: e.label ?? '', type: 'way',
      // 경유점도 함께 적는다 — 빼면 사람이 돌려 놓은 선이 다음에 열 때 제자리로 돌아간다.
      // 없을 때는 아예 넣지 않는다(빈 배열 71개가 파일에 쌓일 이유가 없다).
      data: {
        ty: e.data?.ty ?? 'proc',
        key: e.data?.key ? 1 : 0,
        ...(e.data?.pts?.length ? { pts: e.data.pts.map((p) => ({ x: Math.round(p.x), y: Math.round(p.y) })) } : {}),
        // 흐름 순번 — 없으면 아예 적지 않는다(안 매긴 선 수십 개에 0 이 쌓일 이유가 없다)
        ...(Number(e.data?.seq) > 0 ? { seq: Number(e.data.seq), flow: Number(e.data.flow) || 0 } : {}),
      },
    })),
  }
}

async function save() {
  busy.value = 'save'
  msg.value = ''
  try {
    const r = await api.graphSet(graphName.value, stamp.value, plain())
    stamp.value = r.stamp
    dirty.value = false
    toast(`저장했습니다 — 칸 ${r.nodes} · 이음선 ${r.edges}`, 2500)
    state.error = ''
  } catch (e) {
    // 409 면 서버가 <지금 도면> 을 함께 준다. 덮지 않고 사람에게 고르게 한다.
    // 자동저장을 켜 둔 채면 같은 거절을 1.2초마다 되풀이하므로 스스로 끈다.
    if (autoSave.value) {
      autoSave.value = false
      saveView()
      toast('자동저장을 껐습니다 — 저장이 거절되어 되풀이하지 않습니다.', 8000)
    }
    state.error = `저장하지 못했습니다: ${e.message}`
  } finally {
    busy.value = ''
  }
}

async function resetToSeed() {
  if (resetArm.value !== true) { armReset(); return }
  resetArm.value = false
  busy.value = 'reset'
  try {
    const d = await api.graphReset(graphName.value)
    stamp.value = d.stamp
    lanes.value = d.graph.lanes ?? []
    nodes.value = (d.graph.nodes ?? []).map((n) => ({ ...n, type: 'table' }))
    nodes.value = [...laneNodes(), ...nodes.value]
    edges.value = (d.graph.edges ?? []).map((e) => dressEdge(e))
    dirty.value = false
    paint()
    toast('기본 배치로 되돌렸습니다 (직전 도면은 .bak 으로 남겨 두었습니다).', 5000)
    await nextTick()
    fitAll()
  } catch (e) {
    state.error = `되돌리지 못했습니다: ${e.message}`
  } finally {
    busy.value = ''
  }
}
// 되돌리기는 지금 배치를 통째로 버린다 — 창을 띄우지 않고 한 박자만 둔다
const resetArm = ref(false)
let resetTimer = null
function armReset() {
  resetArm.value = true
  clearTimeout(resetTimer)
  resetTimer = setTimeout(() => (resetArm.value = false), 4000)
}

// ---------- 잇기 ----------
// 손잡이를 끌어 놓으면 여기로 온다. 새 이음선의 종류는 위에서 고른 것을 쓴다.
const newType = ref('proc')
let eno = 0

/**
 * 잇기 모드 — <누르고 누르기>.
 *
 * 손잡이를 끌어서도 이어지지만, 48칸짜리 도면은 대개 축소해 놓고 본다.
 * 그 배율에서 손잡이는 5px 남짓이라 <확대해야만 이을 수 있는> 도구가 된다.
 * 그래서 배율과 상관없이 쓰는 길을 둔다 — 켜고, 출발 칸을 누르고, 도착 칸을 누른다.
 */
const linking = ref(false)
/** { id, handle } — handle 이 null 이면 <지점을 안 고른 것>이고 Vue Flow 가 알아서 잡는다 */
const linkFrom = ref(null)
function toggleLink() {
  linking.value = !linking.value
  linkFrom.value = null
  sel.value = null
}

/**
 * 잇기 모드의 한 걸음. 칸을 누르면 지점은 맡기고, 손잡이를 누르면 <그 지점> 으로 붙인다.
 *
 * 지점을 고를 수 있어야 하는 까닭: 왼쪽 칸을 오른쪽 칸에 이으면서 위쪽 지점끼리 묶으면
 * 선이 칸을 가로질러 지나간다. 48칸 도면에서는 그 선 하나로 그림이 안 읽힌다.
 */
function linkStep(id, handle = null) {
  if (!linkFrom.value) { linkFrom.value = { id, handle }; return }
  if (linkFrom.value.id === id && linkFrom.value.handle === handle) { linkFrom.value = null; return }
  if (linkFrom.value.id === id) { linkFrom.value = { id, handle }; return }   // 같은 칸의 다른 지점 → 출발을 옮긴다
  onConnect({
    source: linkFrom.value.id, sourceHandle: linkFrom.value.handle,
    target: id, targetHandle: handle,
  })
  linkFrom.value = null        // 이어 붙여 계속 잇는다 — 한 번에 여러 줄기를 그리는 일이 많다
}
const linkClick = (id) => linkStep(id, null)

// 칸 컴포넌트가 손잡이를 눌렀을 때 쓰는 길. data 에 함수를 넣으면 저장에 딸려 가므로 provide 로 준다.
provide('tablesLink', {
  on: linking,
  from: linkFrom,
  pick: (id, handle) => linkStep(id, handle),
})

/**
 * 칸 크기 — 칸 컴포넌트(TableNode)가 모서리를 끌 때 쓰는 길.
 * data 에 함수를 넣으면 저장에 딸려 가므로 provide 로 준다(잇기·경유점과 같은 규칙).
 *
 * 0 을 받으면 <기본 크기로> 다 — 칸에서 지워 CSS 가 정한 196×44 로 돌아가게 한다.
 */
provide('tablesSize', {
  set: (id, w, h) => {
    nodes.value = nodes.value.map((n) => {
      if (n.id !== id) return n
      const d = { ...n.data }
      if (w > 0) d.w = w; else delete d.w
      if (h > 0) d.h = h; else delete d.h
      return { ...n, data: d }
    })
    // ⚠️ 칸만 키우면 <선이 따라오지 않는다>. Vue Flow 는 칸의 크기와 손잡이 자리를
    //    붙을 때 한 번 재어 두고 쓰는데, CSS 로 커진 것은 그 값을 바꾸지 않는다.
    //    그래서 선 끝이 커지기 전 모서리에 그대로 박혀 있다 (실제로 밟았다).
    //    다시 재라고 일러 준다 — DOM 이 새 크기로 그려진 뒤여야 하므로 nextTick 뒤에.
    nextTick(() => updateNodeInternals([id]))
  },
  // 끄는 동안에는 저장을 깨우지 않는다 — 한 번 끌 때 수십 번 올라간다
  done: () => { dirty.value = true },
})

// ---------- 이음선 경유점 ----------
//
// 선을 두 번 누르면 그 자리에 점이 생기고, 점을 끌면 선이 돌아간다. 두 번 누르면 없어진다.
// 이음선 컴포넌트(WayEdge)가 쓰는 길 — data 에 함수를 넣으면 저장에 딸려 가므로 여기로 준다.
function patchEdgeData(eid, fn) {
  edges.value = edges.value.map((e) => {
    if (e.id !== eid) return e
    const pts = fn([...(e.data?.pts ?? [])])
    return { ...e, data: { ...e.data, pts } }
  })
}

/**
 * 순번표를 보여 줄 때 — <업무항목을 고른 동안>만.
 *
 * 순번은 «그 업무 안에서 몇 번째인가» 다. 업무를 고르지 않았을 때도 띄우면
 * 도면 전체에 숫자 수십 개가 깔리는데, 그때의 숫자는 가리키는 데가 없어 읽을 수가 없다.
 */
const seqOn = computed(() => !!curItem.value)

provide('tablesWay', {
  seqOn,
  /** 끌고 있는 동안 — 자리만 바꾼다. 저장은 손을 뗄 때 한 번만 한다 */
  move: (eid, i, p) => patchEdgeData(eid, (pts) => (pts[i] ? (pts[i] = p, pts) : pts)),
  /**
   * 돋아난 점을 처음 움직인 순간 — 그 자리에 경유점을 끼운다.
   * i 는 <몇 번째 구간인가> 라 그대로 끼울 자리가 된다(구간 0 = 출발~첫 점 사이).
   */
  insert: (eid, i, p) => {
    patchEdgeData(eid, (pts) => (pts.splice(i, 0, p), pts))
    dirty.value = true
  },
  /**
   * 누른 자리에 점을 끼운다. <어느 두 점 사이인가> 를 찾아 그 사이에 넣는다 —
   * 끝에 붙이면 선이 되돌아갔다 오는 모양이 된다.
   */
  add: (eid, p) => {
    const e = edges.value.find((x) => x.id === eid)
    if (!e) return
    const src = nodes.value.find((n) => n.id === e.source)
    const tgt = nodes.value.find((n) => n.id === e.target)
    const chain = [
      src ? { x: src.position.x + 98, y: src.position.y + 22 } : p,
      ...(e.data?.pts ?? []),
      tgt ? { x: tgt.position.x + 98, y: tgt.position.y + 22 } : p,
    ]
    let at = 0, best = Infinity
    for (let i = 0; i < chain.length - 1; i++) {
      const a = chain[i], b = chain[i + 1]
      const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2
      const d = (mx - p.x) ** 2 + (my - p.y) ** 2
      if (d < best) { best = d; at = i }
    }
    patchEdgeData(eid, (pts) => (pts.splice(at, 0, p), pts))
    dirty.value = true
    toast('경유점을 놓았습니다 — 끌어서 선을 돌리고, 두 번 누르면 없어집니다.', 5000)
  },
  remove: (eid, i) => {
    patchEdgeData(eid, (pts) => (pts.splice(i, 1), pts))
    dirty.value = true
  },
  /** 손을 뗀 뒤 — 여기서만 저장을 깨운다(끄는 동안 저장하면 한 번 끌 때 수십 번 올라간다) */
  done: () => { dirty.value = true },
})
function onConnect(c) {
  if (!c.source || !c.target) return
  if (c.source === c.target) { toast('같은 테이블끼리는 잇지 않습니다.'); return }
  const dup = edges.value.find((e) => e.source === c.source && e.target === c.target)
  if (dup) { msg.value = `이미 있는 이음선입니다 — ${c.source} → ${c.target}`; setTimeout(() => (msg.value = ''), 3000); return }

  const id = `u${Date.now().toString(36)}${++eno}`
  edges.value = [...edges.value, dressEdge({
    id, source: c.source, target: c.target,
    sourceHandle: c.sourceHandle, targetHandle: c.targetHandle,
    label: '', type: 'default', data: { ty: newType.value, key: 0 },
  })]
  dirty.value = true
  sel.value = { kind: 'edge', id }
  paint()
}

// ---------- 고른 것 ----------
const sel = ref(null)     // { kind:'node'|'edge', id }
const selNode = computed(() => (sel.value?.kind === 'node' ? nodes.value.find((n) => n.id === sel.value.id) : null))
const selEdge = computed(() => (sel.value?.kind === 'edge' ? edges.value.find((e) => e.id === sel.value.id) : null))

function onNodeClick({ node }) {
  // 레인 이름표 — 그 단계의 표만 본다. 또 누르면 전체로.
  if (node.type === 'lane') {
    laneSel.value = laneSel.value === node.data.lane ? null : node.data.lane
    paint()
    return
  }
  if (linking.value) { linkClick(node.id); return }
  // 업무항목 편집 중에는 누르기가 <담기/빼기> 다. 고르기(강조)는 잠시 비켜선다 —
  // 둘을 같이 하면 누를 때마다 화면이 흐려졌다 또렷해졌다 해서 무엇이 담겼는지 안 보인다.
  if (itemEdit.value && curItem.value) { toggleItemTable(node.id); return }
  // 같은 칸을 또 누르면 풀린다 — 기존 화면과 같다. 풀 길이 없으면 도면 전체를 다시 보려고
  // 빈 바탕을 찾아 눌러야 한다.
  const same = sel.value?.kind === 'node' && sel.value.id === node.id
  sel.value = same ? null : { kind: 'node', id: node.id }
  paint()
}
function onEdgeClick({ edge }) {
  sel.value = { kind: 'edge', id: edge.id }
  paint()
}
function onPaneClick() {
  sel.value = null
  hoverId.value = null
  paint()
}
// 바뀐 곳마다 queueAuto() 를 흩뿌리지 않고 한 군데서 올린다 — 흩뿌리면 반드시 하나를 빠뜨린다
watch(dirty, (v) => { if (v) queueAuto() })

const onNodeDragStop = () => (dirty.value = true)

// 올려놓기만 해도 관계가 드러난다 — 고른 것이 없을 때만.
// 고른 뒤에도 따라 바뀌면 <무엇을 보고 있었는지> 가 손을 옮길 때마다 사라진다.
function onNodeMouseEnter({ node }) {
  if (!hoverHi.value) return
  if (sel.value?.kind === 'node' || linking.value || node.type !== 'table') return
  hoverId.value = node.id
  paint()
}
function onNodeMouseLeave() {
  if (hoverId.value === null) return
  hoverId.value = null
  paint()
}

/**
 * 테이블 이름을 바꾼다.
 *
 * ⚠️ 이름이 곧 <열쇠> 다. 이음선은 source/target 에 이 이름을 적어 두므로,
 *    칸만 고치면 선 71개가 <없는 칸> 을 가리키게 되어 그림에서 통째로 사라진다.
 *    그래서 걸린 선까지 함께 고친다. (저장 전에는 화면에만 있으니 되돌리려면 ⟳ 다시 읽기)
 */
function renameNode(raw) {
  const n = selNode.value
  if (!n) return
  const next = String(raw ?? '').trim().toUpperCase()
  if (!next || next === n.id) return
  if (nodes.value.some((x) => x.type === 'table' && x.id === next)) {
    toast(`이미 있는 이름입니다 — ${next}`)
    return
  }
  const old = n.id
  nodes.value = nodes.value.map((x) =>
    x.id !== old ? x : { ...x, id: next, data: { ...x.data, id: next } })
  edges.value = edges.value.map((e) =>
    e.source !== old && e.target !== old
      ? e
      : dressEdge({ ...e, source: e.source === old ? next : e.source, target: e.target === old ? next : e.target }))
  // 업무항목도 이 이름을 적어 두고 있다 — 안 고치면 <없는 표> 를 가리킨 채 남는다
  syncItemTables((ts) => (ts.includes(old) ? ts.map((t) => (t === old ? next : t)) : ts))
  sel.value = { kind: 'node', id: next }
  dirty.value = true
  paint()
  toast(`${old} → ${next} 로 바꿨습니다 — 걸린 이음선도 함께 고쳤습니다.`, 5000)
}

/**
 * 스키마를 손으로 적는다.
 *
 * 평소 꼬리표는 DB 에서 알아 온다(loadOwners). 손으로 적으면 그쪽이 다시 덮어쓰지 않도록
 * <사람이 정했다> 는 표시(ownerSet)를 함께 남긴다 — 안 남기면 다음에 읽을 때 조용히 되돌아간다.
 * 비우면 다시 DB 가 정하게 된다.
 */
function setOwner(raw) {
  const v = String(raw ?? '').trim().toUpperCase()
  patchNode(v ? { owner: v, ownerSet: 1 } : { owner: '', ownerSet: 0 })
}

function patchNode(patch) {
  const n = selNode.value
  if (!n) return
  n.data = { ...n.data, ...patch }
  dirty.value = true
}
function patchEdge(patch) {
  const e = selEdge.value
  if (!e) return
  const i = edges.value.findIndex((x) => x.id === e.id)
  const next = { ...e, ...patch, data: { ...e.data, ...(patch.data ?? {}) } }
  edges.value = [...edges.value.slice(0, i), dressEdge(next), ...edges.value.slice(i + 1)]
  dirty.value = true
}

/** 이음선 하나만 지운다 — 칸 상세의 조각에서 바로 부른다 */
function dropEdge(eid) {
  const e = edges.value.find((x) => x.id === eid)
  if (!e) return
  edges.value = edges.value.filter((x) => x.id !== eid)
  dirty.value = true
  paint()
  toast(`이음선을 지웠습니다 — ${e.source} → ${e.target}`)
}

/** 화살표를 뒤집는다 — 방향을 잘못 그은 것을 지우고 다시 긋지 않아도 되게 */
function flipEdge() {
  const e = selEdge.value
  if (!e) return
  const dup = edges.value.find((x) => x.id !== e.id && x.source === e.target && x.target === e.source)
  if (dup) { toast(`이미 있는 이음선입니다 — ${e.target} → ${e.source}`); return }
  const i = edges.value.findIndex((x) => x.id === e.id)
  edges.value = [
    ...edges.value.slice(0, i),
    dressEdge({ ...e, source: e.target, target: e.source, sourceHandle: e.targetHandle, targetHandle: e.sourceHandle }),
    ...edges.value.slice(i + 1),
  ]
  dirty.value = true
  paint()
  toast(`방향을 뒤집었습니다 — ${e.target} → ${e.source}`)
}

/** 그 선을 고른다 — 글귀·종류·주요경로는 이음선 패널에서 고친다 */
function pickEdge(eid) {
  sel.value = { kind: 'edge', id: eid }
  paint()
}

/**
 * 이음선의 <끝>을 다른 칸으로 옮긴다. 선 끝을 끌어다 다른 칸에 놓으면 여기로 온다.
 *
 * 지우고 다시 긋는 것과 다르다 — 글귀·종류·주요경로를 그대로 들고 간다.
 * 다시 그으면 그것들을 또 적어야 한다.
 */
function onEdgeUpdate({ edge, connection }) {
  if (!connection.source || !connection.target) return
  if (connection.source === connection.target) { toast('같은 테이블끼리는 잇지 않습니다.'); return }
  const dup = edges.value.find(
    (x) => x.id !== edge.id && x.source === connection.source && x.target === connection.target)
  if (dup) { toast(`이미 있는 이음선입니다 — ${connection.source} → ${connection.target}`); return }

  const i = edges.value.findIndex((x) => x.id === edge.id)
  if (i < 0) return
  const next = {
    ...edges.value[i],
    source: connection.source,
    target: connection.target,
    sourceHandle: connection.sourceHandle,
    targetHandle: connection.targetHandle,
  }
  edges.value = [...edges.value.slice(0, i), dressEdge(next), ...edges.value.slice(i + 1)]
  dirty.value = true
  paint()
  toast(`${edge.source} → ${edge.target} 를 ${next.source} → ${next.target} 로 옮겼습니다.`, 5000)
}

function removeSel() {
  if (selEdge.value) {
    const e = selEdge.value
    edges.value = edges.value.filter((x) => x.id !== e.id)
    toast(`이음선을 지웠습니다 — ${e.source} → ${e.target}`)
  } else if (selNode.value) {
    const id = selNode.value.id
    // 칸을 지우면 거기 걸린 이음선도 함께 간다 — 남겨 두면 <아무 데도 안 닿는 선>이 된다
    const gone = edges.value.filter((e) => e.source === id || e.target === id).length
    nodes.value = nodes.value.filter((n) => n.id !== id)
    edges.value = edges.value.filter((e) => e.source !== id && e.target !== id)
    // 업무항목에서도 뺀다 — 남겨 두면 "표 7개" 라고 적힌 채 여섯 개만 선다
    syncItemTables((ts) => (ts.includes(id) ? ts.filter((t) => t !== id) : ts))
    toast(`${id} 를 지웠습니다` + (gone ? ` — 걸린 이음선 ${gone}개도 함께` : ''), 5000)
  } else return
  sel.value = null
  dirty.value = true
  paint()
}

// ---------- 테이블 추가 ----------
const newId = ref('')
const newKr = ref('')
const newKind = ref('ledger')
function addTable() {
  const id = newId.value.trim().toUpperCase()
  if (!id) { toast('테이블 이름을 적어 주세요.'); return }
  if (nodes.value.some((n) => n.id === id)) { toast(`이미 있는 테이블입니다 — ${id}`); return }

  // 지금 보고 있는 자리 한가운데에 놓는다 — 도면 밖에 떨어뜨리면 찾으러 가야 한다
  const vp = getViewport()
  const box = document.querySelector('.flowwrap')?.getBoundingClientRect()
  const pos = {
    x: Math.round((-vp.x + (box ? box.width / 2 : 400)) / vp.zoom) - 104,
    y: Math.round((-vp.y + (box ? box.height / 2 : 300)) / vp.zoom) - 42,
  }
  nodes.value = [...nodes.value, {
    id, type: 'table', position: pos,
    data: { id, kr: newKr.value.trim() || id, kind: newKind.value, rows: null, pk: '', writers: [] },
  }]
  newId.value = ''
  newKr.value = ''
  dirty.value = true
  sel.value = { kind: 'node', id }
  flash([id])
  nextTick(() => addSelectedNodes([findNode(id)].filter(Boolean)))
}

// ---------- 어느 스키마의 표인가 ----------
//
// 고른 스키마에 <없는> 표는 칸 머리에 그 스키마를 적어 준다
// (M10 을 보고 있을 때 MTB_POR_OHD 에 'NEW05' 가 붙는다).
//
// ⚠️ 시노님에 속으면 안 된다. M10 에도 MTB_POR_OHD 가 있지만 그것은 <SYNONYM> 이고
//    실체는 NEW05 의 TABLE 이다. 이름이 있다고 "여기 표" 로 치면 꼬리표가 안 붙는다.
//    그래서 종류(kind)까지 받아, 고른 스키마에 <진짜 표/뷰> 가 있을 때만 제 것으로 본다.
const REAL = new Set(['TABLE', 'VIEW', 'MATERIALIZED VIEW'])

/** 데이터에 적혀 있는 힌트 — DB 에 닿지 못해도 이것만으로 NEW05·ERP_IF 는 보인다. */
function hintOf(n) {
  const m = String(n.data?.pk ?? '').match(/^([A-Za-z0-9_]+)\s*스키마/)
  if (m) return m[1].toUpperCase()
  return n.data?.kind === 'ext' ? '외부' : ''
}

/**
 * DB 에 물어 각 칸의 <실제 주인> 을 정한다. 못 물어도 힌트로 메운다 —
 * 이 꼬리표 때문에 화면이 안 뜨는 일은 없어야 한다.
 */
async function loadOwners() {
  const ids = nodes.value.filter((n) => n.type === 'table').map((n) => n.id)
  if (!ids.length) return
  let rows = []
  try {
    const d = await api.oraTableOwners(ids)
    if (d.run?.ok) rows = d.run.rows ?? []
  } catch { /* DB 가 막혀도 힌트로 간다 */ }

  const by = {}
  for (const r of rows) (by[r.name] ??= []).push(r)

  nodes.value = nodes.value.map((n) => {
    if (n.type !== 'table') return n
    // 사람이 적어 둔 것은 건드리지 않는다 — 덮으면 적은 것이 조용히 사라진다
    if (n.data.ownerSet) return n
    const mine = (by[n.id] ?? []).some((r) => r.owner === schema.value && REAL.has(r.kind))
    let owner = ''
    if (!mine) {
      // 진짜 표가 있는 스키마를 고른다. 백업(_BAK)은 뒤로 미룬다 — 주인이라기엔 사본이다.
      const real = (by[n.id] ?? []).filter((r) => REAL.has(r.kind))
      const best = real.find((r) => !r.owner.endsWith('_BAK')) ?? real[0]
      owner = best?.owner ?? hintOf(n)
    }
    return n.data.owner === owner ? n : { ...n, data: { ...n.data, owner } }
  })
}

// ---------- 강조 · 흐리기 ----------
//
// 기존 화면(flow.html)이 하던 것을 그대로 옮겼다. 두 가지가 겹친다 —
//   흐름 필터: 그 묶음에 들지 않은 칸을 흐린다
//   고르기   : 고른 칸과 <그 칸에 닿는 것> 만 또렷하게 두고 나머지를 더 흐린다
// 한 곳(paint)에서 함께 셈해야 한다. 따로 칠하면 흐름을 걸어 둔 채 칸을 고를 때
// 둘이 서로를 덮어써서 <흐린데 또렷한> 칸이 생긴다.

const hoverId = ref(null)
/**
 * 보여 줄 이음선 종류. <b>여기 든 종류만 그린다</b> — 안 든 것은 흐리는 것이 아니라 안 그린다.
 *
 * ⚠️ <b>기본은 빈 집합 — 모두 끄기다.</b> 볼 선은 사람이 골라 켠다.
 *
 * ⚠️ 예전에는 <빈 집합 = 전부>였다. 아무것도 안 골랐는데 선이 다 보여, 「다 껐는데 왜 그대로인가」
 *    가 됐다. 지금은 **고른 것만 보인다** — 하나도 안 고르면 선이 한 줄도 안 그려진다.
 *    고르지 않은 종류를 흐리기만 하면 칸 551개 · 선 1995개가 DOM 에 그대로 남아 계속 무겁다.
 *
 * ⚠️ 작성 도구의 <새로 잇는 선의 종류> 와 혼동하지 말 것. 이쪽은 <무엇을 볼지>,
 *    저쪽은 <무엇을 그릴지> 다. 그래서 이름표를 서로 다르게 붙였다.
 */
const allKinds = () => new Set(EDGE_KINDS.map((k) => k.ty))
const edgeSel = ref((() => {
  // 모르는 종류가 적혀 있으면 버린다 — 도면 규격이 늘거나 줄 때 남는다.
  const sane = (a) => a.filter((t) => EDGE_KINDS.some((k) => k.ty === t))
  // ⚠ 기본은 <모두 끄기> 다(v3). 선 1995개를 다 그린 첫 화면은 글자가 선에 묻혀 아무것도
  //   안 읽힌다 — 칸부터 보고, 볼 선을 사람이 골라 켜는 쪽이 맞다.
  //   예전에 켜 둔 설정이 남아 있어도 한 번은 끄고 시작한다. 안 그러면 이 화면을 이미 써 본
  //   사람에게는 바뀐 것이 하나도 없다(autoSave 가 v2 로 했던 것과 같은 수법이다).
  if (!savedView.v3) return new Set()
  // 지금 규격(`kinds2`) — 적힌 그대로가 <보일 종류>다. 빈 배열이면 정말로 <하나도 안 봄> 이다.
  if (Array.isArray(savedView.kinds2)) return new Set(sane(savedView.kinds2))
  return new Set()
})())
/** 전부 켜져 있는가 — 단추 글자와 [✕] 를 보일지가 여기에 달렸다. */
const allKindsOn = computed(() => edgeSel.value.size === EDGE_KINDS.length)
/** 단추에 적을 한 줄. 「전체」·「없음」·「트리거·배치」. */
const kindSummary = computed(() => {
  if (allKindsOn.value) return '전체'
  if (!edgeSel.value.size) return '없음'
  return EDGE_KINDS.filter((k) => edgeSel.value.has(k.ty)).map((k) => k.label).join('·')
})
/**
 * 볼 선 종류를 바꾸는 <한 길>. 종류를 하나 집든 한꺼번에 끄든 여기로 모은다.
 *
 * ⚠ 비게 되면 [선 있는 칸만] 도 함께 끈다. 켜 둔 채로 두면 눌러서 끌 수도 없는데
 *   (그때는 잠겨 있다) 값만 살아 있어, 나중에 선 하나를 켜는 순간 칸이 왕창 흐려진다 —
 *   선 하나 켠 사람이 보기에는 <선을 켰더니 칸이 사라졌다> 이다.
 */
function setEdgeKinds(next) {
  edgeSel.value = next
  if (!next.size) onlyLinked.value = false
  paint()
}
function toggleEdgeKind(ty) {
  const n2 = new Set(edgeSel.value)
  n2.has(ty) ? n2.delete(ty) : n2.add(ty)
  setEdgeKinds(n2)
}
/** 한꺼번에 켜고 끈다. 종류가 늘어도 손이 한 번이다. */
function setAllKinds(on) { setEdgeKinds(on ? allKinds() : new Set()) }
/**
 * 기본으로 되돌린다 = <모두 끄기>. Esc 가 부른다.
 *
 * ⚠ 예전에는 이것이 <전부 보기> 였다. 기본이 뒤집혔으니 뜻도 따라 뒤집는다 —
 *   안 그러면 Esc 한 번에 안 켜 둔 선 1995개가 통째로 돌아온다.
 */
function resetEdgeKinds() { setAllKinds(false) }

/** 선 보기 드롭다운이 펴져 있는가. 종류가 늘어 단추를 늘어놓을 자리가 없어 접어 넣었다. */
const kindOpen = ref(false)
// 바깥을 누르면 접는다. 단추 자신과 펼친 목록은 @click.stop 으로 이 핸들러를 안 탄다 —
// 목록 안에서 종류를 여럿 집는 동안 접히면 다중선택이 안 된다.
function closeKindMenu() { kindOpen.value = false }
// 머리줄의 드롭다운은 한 번에 하나만 편다. 둘 다 펴면 목록이 겹쳐 아래 것이 가려진다 —
// @click.stop 때문에 다른 단추를 눌러도 바깥닫기가 안 불려, 여는 쪽에서 직접 접어 준다.
function toggleKindMenu() { kindOpen.value = !kindOpen.value; if (kindOpen.value) flowOpen.value = false }
onMounted(() => window.addEventListener('click', closeKindMenu))
onUnmounted(() => window.removeEventListener('click', closeKindMenu))

/**
 * 선이 <지금 또렷하게 남아 있는> 테이블만 보기.
 *
 * 선 종류를 걸면 선은 걸러지는데 칸은 48개가 그대로 서 있어, 트리거 선 열다섯 줄을
 * 마흔여덟 칸 사이에서 눈으로 좇아야 했다. 이 스위치를 켜면 <그 선이 닿는 칸>만 남는다.
 *
 * 선 종류 필터를 걸지 않았을 때도 쓸모가 있다 — 아무 데도 안 닿는 외톨이 칸이 걸러진다.
 */
// ⚠ 볼 선이 하나도 없으면 꺼진 채로 연다. 셈할 선이 없어 켜 봐야 칸만 전부 흐려지고,
//   그 상태에서는 체크박스가 잠겨 있어 사람이 끌 수도 없다(setEdgeKinds 참고).
const onlyLinked = ref(savedView.onlyLinked === true && edgeSel.value.size > 0)
function toggleOnlyLinked() { onlyLinked.value = !onlyLinked.value; paint() }

/** 종류별 이음선 수 — 단추에 적어 준다. 0건짜리를 눌러 놓고 왜 빈 화면인지 묻지 않도록. */
const edgeCount = computed(() => {
  const m = Object.fromEntries(EDGE_KINDS.map((k) => [k.ty, 0]))
  // ⚠ paint 의 거르기와 같은 `kindOf` 로 센다. 글자 그대로 세면 모르는 종류가 어느 칸에도
  //   안 들어가, 적힌 수를 다 더해도 머리줄의 <이음선 N> 에 못 미친다(M20 에서 1991 vs 1995).
  for (const e of edges.value) m[kindOf(e.data?.ty).ty]++
  return m
})

// ---------- 업무항목 ----------
//
// 업무 하나(예: <구매요구 등록>)가 어느 표들을 쓰는지 사람이 모아 둔 묶음이다.
// 고르면 그 표만 또렷해진다 — 흐름(flows)·단계(lanes)와 같은 <좁히는> 조건이다.
//
// 흐름·단계와 다른 점: 저 둘은 도면을 구울 때 정해진 것이고, 이쪽은 <쓰면서 늘려 가는> 것이다.
// 그래서 서버의 다른 파일에 둔다(api/Graph.cs 의 .items.json) — [기본 배치로] 가 도면을
// seed 로 되돌려도 모아 둔 업무항목은 그대로 남아야 한다.
//
// 담기는 모양: { id, name, tables:[표 이름…] }
const items = ref([])
const itemStamp = ref('')
const itemSel = ref(null)      // 고른 업무항목 id. null 이면 전체
const itemEdit = ref(false)    // 편집모드 — 칸을 눌러 넣고 뺀다
const itemBusy = ref(false)

const curItem = computed(() => items.value.find((x) => x.id === itemSel.value) ?? null)

/**
 * 업무항목을 고르면 <그 표와 그 사이 선만> 그린다. 나머지는 흐리는 것이 아니라 안 그린다.
 *
 * 흐리기만 하면 보이지 않아도 DOM 에는 그대로 남는다 — M20 도면은 칸 551개·선 1995개라
 * 끌기·확대가 계속 무겁다. 업무 하나는 표가 서넛이니 안 그리면 그 부담이 통째로 사라진다.
 *
 * 끄면 예전처럼 <전체를 두고 나머지를 흐리는> 그림이 된다 — 그림의 뼈대를 보면서 일할 때
 * 필요하다. 고른 것은 브라우저에 남긴다.
 */
const SOLO_LS = 'wbs.tables2.soloItem'
const soloItem = ref((() => {
  try { return localStorage.getItem(SOLO_LS) !== '0' } catch { return true }
})())

function toggleSolo() {
  soloItem.value = !soloItem.value
  try { localStorage.setItem(SOLO_LS, soloItem.value ? '1' : '0') } catch { /* 못 적어도 이번만 쓴다 */ }
  paint()
  // 남은 것이 화면 밖일 수 있다 — 골라 놓고 빈 화면을 보는 일이 없게 맞춰 준다
  if (soloItem.value && itemKeep.value?.size) {
    nextTick(() => fitView({ nodes: [...itemKeep.value], padding: 0.4, duration: 320 }))
  }
}

/** 고른 업무항목이 쓰는 칸 집합. 안 골랐으면 null(= 전체). */
const itemKeep = computed(() => {
  const it = curItem.value
  if (!it) return null
  return new Set(it.tables ?? [])
})

async function loadItems() {
  try {
    const d = await api.graphItems(graphName.value)
    itemStamp.value = d.stamp
    items.value = (d.data?.items ?? []).map((x) => ({ ...x, tables: x.tables ?? [] }))
    if (!items.value.some((x) => x.id === itemSel.value)) itemSel.value = null
    return true
  } catch (e) {
    toast(`업무항목을 읽지 못했습니다: ${e.message}`)
    return false
  }
}

/** 다시 읽는 중인가 — 머리줄의 ↻ 가 이 동안 멈춰 선다. */
const itemLoading = ref(false)

/**
 * 업무항목만 서버에서 다시 읽는다 (머리줄의 ↻).
 *
 * 정본은 서버 파일(`*.items.json`) 이고, 옆자리 사람이 고치기도 하고 손으로 넣기도 한다.
 * 그동안 이 화면을 켜 둔 사람의 목록은 <열었을 때 그대로> 라, 맞추려면 화면을 통째로
 * 새로고침하는 수밖에 없었다 — 그러면 끌어 둔 칸 자리·펴 둔 상자까지 다시 잡아야 한다.
 *
 * ⚠ 저장 중에는 읽지 않는다. 읽으면 stamp 가 저장 응답의 것보다 앞서거나 뒤처져,
 *   다음 저장이 <남이 고쳤다>(409) 로 헛되이 막힌다.
 * ⚠ 다 읽고 paint() 한다. 고른 업무항목에 담긴 표가 바뀌었을 수 있다 —
 *   안 칠하면 목록의 숫자만 바뀌고 도면의 강조는 옛것으로 남는다.
 */
async function reloadItems() {
  if (itemLoading.value || itemBusy.value) return
  itemLoading.value = true
  const was = items.value.length
  try {
    if (!await loadItems()) return   // 실패 알림은 loadItems 가 이미 띄웠다
    paint()
    const now = items.value.length
    toast(now === was
      ? `업무항목을 다시 읽었습니다 — ${now}개 (그대로입니다).`
      : `업무항목을 다시 읽었습니다 — ${was}개 → ${now}개.`)
  } finally {
    itemLoading.value = false
  }
}

/**
 * 업무항목을 적는다. 바뀔 때마다 바로 적는다 — 이 화면의 다른 것들과 같은 규칙이다
 * (따로 [저장] 을 두면, 눌러 넣은 표가 저장된 줄 알고 화면을 닫는다).
 *
 * 그 사이 다른 사람이 고쳤으면(409) 덮지 않는다. 지금 것을 다시 읽고 <방금 것은 안 들어갔다>
 * 고 알린다 — 조용히 덮으면 남의 업무항목이 말없이 사라진다.
 */
let itemTimer = null
function saveItems(now = false) {
  clearTimeout(itemTimer)
  const run = async () => {
    itemBusy.value = true
    try {
      const r = await api.graphItemsSet(graphName.value, itemStamp.value, items.value)
      itemStamp.value = r.stamp
    } catch (e) {
      if (/다른 사람이/.test(e.message)) {
        await loadItems()
        toast('⚠ 그 사이 다른 사람이 업무항목을 고쳤습니다. 지금 것을 다시 읽었습니다 — 방금 바꾼 것은 들어가지 않았습니다.', 7000)
      } else toast(`업무항목 저장 실패: ${e.message}`)
    } finally {
      itemBusy.value = false
    }
  }
  now ? run() : (itemTimer = setTimeout(run, 500))
}
onUnmounted(() => clearTimeout(itemTimer))

const newItem = ref('')
const renaming = ref(null)   // 이름을 고치고 있는 업무항목 id

// ---- 그리드 거르기 ----
//
// 업무항목이 140개가 넘는다. 이름은 「[2310] 일반재 POR 접수」 처럼 <코드 + 이름> 이라,
// 코드와 이름을 따로 거를 수 있게 갈라 둔다 — 「2310」 으로 바로 찾고,
// 코드를 모를 때는 「발주」 처럼 이름으로 좁힌다.
const fCode = ref('')
const fName = ref('')

/** 이름에서 앞머리 [코드] 를 떼어 따로 둔다. 없으면 코드 칸은 비워 둔다 */
const itemRows = computed(() => items.value.map((it) => {
  const m = /^\s*\[([^\]]+)\]\s*(.*)$/.exec(it.name)
  return { ...it, code: m ? m[1] : '', title: m ? m[2] : it.name }
}))

const shownItems = computed(() => {
  const c = fCode.value.trim().toLowerCase()
  const n = fName.value.trim().toLowerCase()
  if (!c && !n) return itemRows.value
  return itemRows.value.filter((it) =>
    (!c || it.code.toLowerCase().includes(c)) &&
    (!n || it.title.toLowerCase().includes(n) || it.name.toLowerCase().includes(n)))
})

// ---- 새 업무항목 만들기 (팝업) ----
//
// 머리줄의 ＋ 로 연다. 목록 위에 입력칸을 늘 띄워 두던 자리인데, 140줄짜리 표에서는
// 그 한 줄이 목록을 밀어내기만 한다 — 새로 만드는 일은 가끔이다.
const addOpen = ref(false)
const addBox = ref(null)

function openAddDlg() {
  newItem.value = ''
  addOpen.value = true
  nextTick(() => addBox.value?.focus())
}
function addFromDlg() {
  if (!newItem.value.trim()) return
  addItem()                 // 만들고 바로 고른 뒤 편집모드로 들어간다
  addOpen.value = false
}
function addItem() {
  const name = newItem.value.trim()
  if (!name) return
  const id = 'it' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
  items.value = [...items.value, { id, name, tables: [] }]
  newItem.value = ''
  itemSel.value = id
  itemEdit.value = true          // 만들자마자 담을 수 있게 — 만들고 체크를 또 누르게 하지 않는다
  if (linking.value) toggleLink() // 두 모드가 같은 클릭을 먹는다. 하나만 켠다
  paint()
  saveItems(true)
}

function pickItem(id) {
  itemSel.value = itemSel.value === id ? null : id
  if (!itemSel.value) itemEdit.value = false
  paint()
  // 그 표들만 남겼으면 화면도 거기로 맞춘다 — 안 맞추면 남은 서넛이 화면 밖이라
  // <골랐는데 빈 화면> 이 된다. 지금 보던 자리를 지키는 것보다 이쪽이 낫다.
  if (soloItem.value && itemKeep.value?.size) {
    nextTick(() => fitView({ nodes: [...itemKeep.value], padding: 0.4, duration: 320 }))
  }
}

function renameItem(it, raw) {
  const name = String(raw ?? '').trim()
  if (!name || name === it.name) return
  items.value = items.value.map((x) => (x.id === it.id ? { ...x, name } : x))
  saveItems()
}

function dropItem(it) {
  items.value = items.value.filter((x) => x.id !== it.id)
  if (itemSel.value === it.id) { itemSel.value = null; itemEdit.value = false }
  paint()
  saveItems(true)
  toast(`업무항목 「${it.name}」 을 지웠습니다.`)
}

function toggleItemEdit() {
  itemEdit.value = !itemEdit.value
  // 잇기와 편집모드는 같은 <칸 누르기> 를 먹는다. 둘 다 켜 두면 무엇이 일어날지 알 수 없다.
  if (itemEdit.value && linking.value) toggleLink()
  // ⚠ 다시 그려야 한다. 켜면 선이 사라지고 숨겼던 칸이 돌아오며, 담긴 칸에 체크가 붙는다 —
  //   예전에는 이 호출이 없어 <체크를 켜도 아무 일이 없다가 칸을 한 번 눌러야> 바뀌었다.
  paint()
  // 체크를 풀면 그 업무로 화면을 되돌린다 — 담으러 돌아다니다 보면 엉뚱한 자리에 있다.
  if (!itemEdit.value && soloItem.value && itemKeep.value?.size) {
    nextTick(() => fitView({ nodes: [...itemKeep.value], padding: 0.4, duration: 320 }))
  }
}

/** 칸 하나를 지금 업무항목에 넣거나 뺀다. 같은 칸을 또 누르면 빠진다. */
function toggleItemTable(id) {
  const it = curItem.value
  if (!it) return
  const has = (it.tables ?? []).includes(id)
  items.value = items.value.map((x) =>
    x.id !== it.id ? x : { ...x, tables: has ? x.tables.filter((t) => t !== id) : [...x.tables, id] })
  paint()
  saveItems()
}

/**
 * 도면에서 칸 이름이 바뀌거나 칸이 사라지면 업무항목도 따라간다.
 *
 * 안 따라가면 업무항목이 <없는 표> 를 가리킨 채 남는다. 고르면 아무것도 안 서는데
 * 목록에는 "표 7개" 로 적혀 있어, 무엇이 잘못됐는지 알 길이 없다.
 */
function syncItemTables(fn) {
  let hit = false
  const next = items.value.map((it) => {
    const t2 = fn(it.tables ?? [])
    if (t2 === it.tables) return it
    hit = true
    return { ...it, tables: t2 }
  })
  if (!hit) return
  items.value = next
  saveItems()
}

/** 고른 업무 단계(레인). null 이면 전체. 머리의 이름표를 눌러 고른다. */
const laneSel = ref(Number.isInteger(savedView.lane) ? savedView.lane : null)
/** 올려놓기만 해도 관계를 보여 줄지 — 끄면 고를 때만 보여 준다(상단 스위치) */
const hoverHi = ref(savedView.hoverHi !== false)
/** 지금 주목하는 칸 — 고른 것이 먼저고, 없으면 올려놓은 것. (기존 화면과 같다) */
const focusId = computed(() => (sel.value?.kind === 'node' ? sel.value.id : hoverId.value))

/**
 * 적고 있는 글자에 걸리는 칸. 빈 칸이면 null(= 전체).
 *
 * 다 적고 Enter 를 쳐야 보여 주면, 무엇을 적어야 걸리는지 모르는 채로 적게 된다.
 * '112' 만 쳐도 1120·1121 이 함께 서는 것이 찾는 사람의 머릿속과 같다.
 * 아래 드롭다운은 그대로 둔다 — 하나로 좁혀 <찾아가는> 길이고, 이쪽은 <훑어보는> 길이다.
 */
const qKeep = computed(() => {
  const kw = q.value.trim().toLowerCase()
  if (!kw) return null
  return new Set(nodes.value
    .filter((n) => n.type === 'table' &&
      (n.id.toLowerCase().includes(kw) || String(n.data.kr ?? '').toLowerCase().includes(kw)))
    .map((n) => n.id))
})

/**
 * 고른 흐름 묶음에 든 칸 집합. null 이면 전체(= 거르지 않음).
 *
 * 여럿 고르면 <합집합>이다 — 교집합이면 「구매요구 + 견적·발주」가 거의 늘 빈 집합이 된다.
 * 묶음끼리 겹치는 칸이 서넛뿐이라, 이어지는 두 흐름을 같이 보려는 손짓과 정반대가 된다.
 */
const flowKeep = computed(() => {
  if (!flowSel.value.size) return null
  const s = new Set()
  for (const f of flows.value) if (flowSel.value.has(f.id) && f.nodes) for (const n of f.nodes) s.add(n)
  // 고른 묶음이 도면에서 사라졌을 수도 있다(다른 스키마의 옛 저장본). 빈 집합을 그대로
  // 물리면 도면이 통째로 흐려지므로 <거르지 않음> 으로 떨어뜨린다.
  return s.size ? s : null
})

/**
 * 고른 업무 단계(레인)에 든 칸 집합. null 이면 전체.
 *
 * 칸의 col 로 가른다 — 자리를 옮겨도 <어느 단계의 표인가> 는 바뀌지 않아야 한다.
 * 화면 좌표로 가르면 칸 하나를 옆으로 끌어 놓는 순간 단계가 바뀌어 버린다.
 */
const laneKeep = computed(() => {
  if (laneSel.value == null) return null
  return new Set(nodes.value
    .filter((n) => n.type === 'table' && n.data.col === laneSel.value)
    .map((n) => n.id))
})

/** 주목한 칸에 닿는 칸들 (자기 자신 포함) */
const related = computed(() => {
  const id = focusId.value
  if (!id) return null
  // 가리키는 칸이 사라졌으면 고르지 않은 것으로 본다 — 빈 집합을 내면 전부 흐려진다
  if (!nodes.value.some((n) => n.type === 'table' && n.id === id)) return null
  const s2 = new Set([id])
  for (const e of edges.value) {
    if (e.source === id) s2.add(e.target)
    if (e.target === id) s2.add(e.source)
  }
  return s2
})

/**
 * 칠한다. 칸·이음선의 겉모습은 전부 여기서만 바뀐다.
 * 거르기를 바꾸는 길이 여럿이라(탭·레인·선 종류·체크박스·찾기) <적어 두는 일>도 여기서 한다 —
 * 길마다 적으면 한 군데를 빠뜨려 "껐는데 다시 켜져 있는" 것이 생긴다.
 */
/**
 * 방금 놓은 칸을 잠깐 깜빡이게 한다.
 *
 * 48칸 사이에 끼어 들어가면 어디 떨어졌는지 눈으로 못 찾는다. 화면을 그쪽으로 옮겨 주긴
 * 하지만, 옮긴 자리에서도 <어느 것이 새 칸인지> 는 또 다른 문제다.
 *
 * ⚠️ flash 는 저장에 실리면 안 된다 — 다음에 열 때마다 깜빡인다. 끝나면 지운다.
 */
let flashTimer = null
function flash(ids) {
  const set = new Set(ids)
  if (!set.size) return
  nodes.value = nodes.value.map((n) => (set.has(n.id) ? { ...n, data: { ...n.data, flash: 1 } } : n))
  clearTimeout(flashTimer)
  flashTimer = setTimeout(() => {
    nodes.value = nodes.value.map((n) => (n.data?.flash ? { ...n, data: { ...n.data, flash: 0 } } : n))
  }, 2600)
}
onUnmounted(() => clearTimeout(flashTimer))

function paint() {
  // 흐름·단계는 둘 다 <좁히는> 조건이다. 둘이 걸리면 교집합이다 —
  // 한쪽이 다른 쪽을 덮으면 "걸었는데 왜 안 줄지" 가 된다.
  // 흐름·단계·찾는 글자는 모두 <좁히는> 조건이다. 걸린 것끼리 교집합을 낸다 —
  // 한쪽이 다른 쪽을 덮으면 "걸었는데 왜 안 줄지" 가 된다.
  const and = (a, b) => (a && b ? new Set([...a].filter((x) => b.has(x))) : (a ?? b))
  const keep = and(and(and(flowKeep.value, laneKeep.value), qKeep.value), itemKeep.value)
  const rel = related.value
  const id = focusId.value
  // 업무항목을 골랐으면 <그 묶음은 늘 선다>. 칸 하나를 눌러도 나머지가 흐려지지 않는다.
  //
  // 고르기(related)는 원래 <고른 칸과 거기 닿는 것만> 남기고 나머지를 흐린다. 그 규칙이
  // 업무항목 위에 그대로 얹히면, 표 넷짜리 업무를 골라 놓고 그중 하나를 누르는 순간
  // 닿아 있는 한 칸만 남는다 — 업무를 보려고 골랐는데 업무가 사라진다. (실제로 밟았다.)
  //
  // 그래도 누른 칸을 알아볼 수는 있어야 하므로, <흐리는 일>만 멈추고 hot·near 강조는 그대로 둔다.
  const pin = itemKeep.value
  const pinned = (x) => !!pin && pin.has(x)

  // 편집모드 — 칸을 눌러 담는 동안이다. 이때는 그림의 규칙이 둘 달라진다.
  //   ① 칸은 <전부> 보인다. 담을 표를 고르는 자리라, [이 업무만 그리기] 로 숨기면
  //      담겨 있지 않은 표를 누를 수가 없다 — 담는 일 자체가 안 된다.
  //   ② 선은 <하나도> 안 그린다. 담고 빼는 동안 선은 쓰이지 않는데, 1995개가 그대로
  //      남아 있으면 누를 때마다 그 부담을 다시 치른다.
  const picking = itemEdit.value && !!curItem.value

  let nodeChanged = false
  const prevNodes = nodes.value
  nodes.value = nodes.value.map((n) => {
    if (n.type === 'lane') {
      const on = n.data.lane === laneSel.value
      if (n.data.on === on) return n
      nodeChanged = true
      return { ...n, data: { ...n.data, on } }
    }
    if (n.type !== 'table') return n
    const outFlow = keep ? !keep.has(n.id) : false
    const outRel = rel ? !rel.has(n.id) && !pinned(n.id) : false
    const dim = outFlow || outRel
    const hot = !!id && n.id === id
    const near = !!rel && !outFlow && rel.has(n.id) && !hot
    // 적고 있는 글자에 걸린 칸 — 흐리지 않은 것만으로는 48칸 사이에서 눈에 안 띈다
    const found = !!qKeep.value && qKeep.value.has(n.id) && !dim
    // 업무항목 편집 중에만 <담겼는지> 를 칸에 적는다. 평소에 적으면 48칸에 체크가 깔려
    // 정작 무엇을 보고 있었는지가 묻힌다.
    const inItem = itemEdit.value && !!itemKeep.value && itemKeep.value.has(n.id)
    // 업무항목만 그리기 — 흐리는 대신 <아예 안 그린다>. 칸 551개·선 1995개를 흐린 채로
    // 두면 보이지 않아도 DOM 에 그대로 남아 끌기·확대가 계속 무겁다.
    // ⚠ 편집모드에서는 숨기지 않는다 — 담을 표를 눌러야 하므로 전부 보여야 한다(위 주석 ①).
    const hide = !picking && soloItem.value && !!pin && !pinned(n.id)
    if (n.data.dim === dim && n.data.hot === hot && n.data.near === near
        && n.data.found === found && n.data.inItem === inItem && !!n.hidden === hide) return n
    nodeChanged = true
    return { ...n, hidden: hide, data: { ...n.data, dim, hot, near, found, inItem } }
  })
  // 바뀐 칸이 없으면 배열째 그대로 둔다 (선 쪽 주석 참고)
  if (!nodeChanged) nodes.value = prevNodes

  saveView()

  const kinds = edgeSel.value
  // ⚠️ 선은 <바뀐 것만> 새로 만든다. 이 화면의 M20 도면은 선이 1995개다 — 예전에는
  //    paint() 가 돌 때마다 그 전부를 새 객체로 갈아끼웠고(style·labelStyle·markerEnd 까지
  //    객체 넷씩), Vue Flow 가 선을 통째로 다시 그렸다. paint() 는 칸을 누를 때도, 찾는
  //    글자를 한 자 칠 때도 돈다 — 실측 <글자 한 자에 0.6~1.1초> 가 여기서 나왔다.
  //    칸(nodes)에는 이 가드가 처음부터 있었는데 선에만 없었다.
  let edgeChanged = false
  const dressed = edges.value.map((e) => {
    const inFlow = !keep || (keep.has(e.source) && keep.has(e.target))
    // 종류 필터는 <선에만> 건다. 칸까지 지우면 "그 선이 어느 표 사이의 것인가" 가 안 보인다.
    // ⚠ [선 보기] 에서 고르지 않은 종류는 <흐리는 것이 아니라 안 그린다>(아래 hide).
    //   흐리기만 하면 1995개가 DOM 에 그대로 남아, 다 꺼 놓고도 끌기·확대가 계속 무겁다.
    // ⚠ `kindOf` 를 거친다 — 도면에 <선 종류가 아닌 글자>가 적힌 줄이 있다(M20 의 `iface` 4줄.
    //   표 종류 고르개의 값이 선으로 새어 든 것이다). 그 줄도 그릴 때는 kindOf 가 '처리' 로
    //   떨어뜨려 처리색으로 그려 왔다. 여기서만 글자 그대로 맞춰 보면 <어느 종류를 켜도
    //   안 나오는 선 4줄> 이 조용히 생긴다. 그려지는 종류와 걸러지는 종류는 같아야 한다.
    const inKind = kinds.has(kindOf(e.data?.ty).ty)
    const hit = !!id && (e.source === id || e.target === id)
    // 칸과 같은 규칙 — 업무항목 안의 선은 칸 하나를 눌러도 흐려지지 않는다.
    // 선까지 흐리면 칸만 남아 <그 업무가 어떻게 이어지는지> 가 사라진다.
    const inPin = pinned(e.source) && pinned(e.target)
    const dim = !inFlow || !inKind || (!!id && !hit && !inPin)
    const hi = hit && inFlow && inKind
    // 안 그릴 선 셋 — 셋 중 하나만 걸려도 DOM 에서 빠진다.
    //   ① 편집모드면 종류를 가리지 않고 전부(위 picking 주석 ②) — 체크를 풀면 바로 돌아온다.
    //   ② [선 보기] 에서 고르지 않은 종류. 하나도 안 골랐으면 선이 한 줄도 안 남는다 — 그게 뜻이다.
    //   ③ [이 업무만 그리기] — 고른 묶음 안에서 <양끝이 모두> 든 선만 남긴다.
    const hide = picking || !inKind || (soloItem.value && !!pin && !inPin)
    const sig = (dim ? 'd' : '-') + (hi ? 'h' : '-') + (hide ? 'x' : '-')
    if (e.__sig === sig) return { e, dim, dressed: e }
    edgeChanged = true
    const out = dressEdge(e, { dim, hi })
    out.hidden = hide
    out.__sig = sig
    return { e, dim, dressed: out }
  })
  // 바뀐 선이 하나도 없으면 배열째 그대로 둔다 — 새 배열만 물려도 Vue Flow 는 한 번 훑는다.
  if (edgeChanged) edges.value = dressed.map((x) => x.dressed)

  // [선 있는 칸만] — 또렷하게 남은 선이 닿는 칸만 세우고 나머지를 흐린다.
  // 선을 먼저 셈한 뒤에 해야 한다 — 칸을 먼저 흐리면 <그 칸에 닿는 선>도 함께 흐려져
  // 서로 물고 들어가 아무것도 안 남는다.
  //
  // ⚠ 선 보기가 <모두 끄기>(기본값) 면 건너뛴다. 그릴 선이 없으니 <선이 닿는 칸> 도 없어
  //   칸 543개가 통째로 흐려진다 — 켜 둔 채로 화면을 열면 까닭 모를 빈 화면이 된다.
  //   머리줄의 체크박스도 그때는 잠가 둔다.
  if (onlyLinked.value && edgeSel.value.size) {
    const live = new Set()
    for (const x of dressed) if (!x.dim) { live.add(x.e.source); live.add(x.e.target) }
    nodes.value = nodes.value.map((n) => {
      if (n.type !== 'table') return n
      const dim2 = n.data.dim || !live.has(n.id)
      return n.data.dim === dim2 ? n : { ...n, data: { ...n.data, dim: dim2 } }
    })
  }
}

// ---------- DB 에서 테이블 찾아 놓기 ----------
//
// 손으로 이름을 적어 넣는 것만으로는 모자랐다 — 수빅 DB 의 M20 스키마에 404개가 있고,
// 이름을 정확히 알아야만 적을 수 있다. 그래서 <물어보고 고르는> 창을 둔다.
//
// 목록은 대시보드가 쥐고 있는 Oracle 연결로 받는다(api/OraKill.cs 의 /api/ora/tables).
// 지금 이 DB 는 processes 가 차 있어 새 접속이 거절되므로, 목록 하나 보자고 따로 붙는
// 길을 내면 정작 필요할 때 안 열린다.
/**
 * 캔버스 위에 떠 있는 <레이어 상자> 하나를 만든다. 접히고, 머리를 잡아 옮겨진다.
 *
 * 둘이 쓴다 — 오른쪽의 [상세·추가] 와 왼쪽의 [작성 도구].
 * 한 벌로 묶어 둔 까닭: 따로 만들면 한쪽만 고쳐져 <하나는 접히는데 하나는 안 접히는>
 * 꼴이 난다. 자리·접힘은 이 PC 에 적는다(localStorage) — 서버에 둘 것이 아니고,
 * 사람마다 손에 맞는 자리가 다르다.
 *
 * @param key  localStorage 키
 * @param dir  옮길 수 있는 방향 — 'right' 는 오른쪽에 붙은 상자(왼쪽으로 끈다),
 *             'left' 는 왼쪽에 붙은 상자(오른쪽으로 끈다). 화면 밖으로 내보내지 않는다.
 */
function useLayer(key, sel, openByDefault = true) {
  const open = ref(openByDefault)
  const pos = ref({ x: 0, y: 0 })
  const moving = ref(false)
  // 사람이 잡아 늘린 크기. null 이면 CSS 의 기본 크기를 쓴다 —
  // 0 이나 기본값을 넣어 두면 <손대지 않은 것> 과 <기본 크기로 줄인 것> 이 구별되지 않는다.
  const size = ref(null)
  try {
    const v = JSON.parse(localStorage.getItem(key) || 'null')
    if (v) {
      if (typeof v.open === 'boolean') open.value = v.open
      if (v.pos && Number.isFinite(v.pos.x)) pos.value = v.pos
      if (v.size && Number.isFinite(v.size.w) && Number.isFinite(v.size.h)) size.value = v.size
    }
  } catch { /* 없으면 기본 자리·기본 크기 */ }

  const save = () => {
    try { localStorage.setItem(key, JSON.stringify({ open: open.value, pos: pos.value, size: size.value })) }
    catch { /* 못 적어도 이번 화면에서는 그대로 쓴다 */ }
  }
  const style = computed(() => ({
    transform: `translate(${pos.value.x}px, ${pos.value.y}px)`,
    transition: moving.value ? 'none' : undefined,
    // 폭만 CSS 를 덮고, 높이는 <편> 상태에서만 준다 — 접은 상자에 높이를 주면
    // 머리 한 줄만 남은 자리에 빈 칸이 길게 딸려 다닌다.
    width: size.value ? size.value.w + 'px' : undefined,
    height: size.value && open.value ? size.value.h + 'px' : undefined,
    maxHeight: size.value && open.value ? 'none' : undefined,
  }))

  const cardEl = () => document.querySelector(sel)
  const boxRect = () => document.querySelector('.flowwrap')?.getBoundingClientRect() ?? null

  /**
   * 넘어도 되는 만큼을 셈한다 — <지금 상자 자리> 기준의 움직일 수 있는 범위.
   *
   * 예전에는 `-40 ~ 폭-140` 같은 어림수로 막았다. 상자마다 붙은 자리(left:8 · left:194 ·
   * right:8)와 크기가 달라서, 같은 숫자로 막으면 어떤 상자는 한참 남고 어떤 상자는
   * <머리만 걸친 채> 밖으로 나갔다. 이제 상자의 실제 네 변을 캔버스 네 변에 댄다.
   */
  function limits(r, box) {
    // 상자가 캔버스보다 크면(좁은 창에서 긴 목록) 가둘 수가 없다 —
    // 그때는 왼쪽·위에 붙인다. 머리(손잡이)가 보이는 쪽이 그쪽이다.
    const lo = { x: box.left - r.left, y: box.top - r.top }
    const hi = { x: box.right - r.right, y: box.bottom - r.bottom }
    return {
      x: [lo.x, Math.max(lo.x, hi.x)],
      y: [lo.y, Math.max(lo.y, hi.y)],
    }
  }
  const clamp = (v, [lo, hi]) => Math.min(hi, Math.max(lo, v))

  /**
   * 지금 자리가 캔버스 밖이면 안으로 되민다.
   *
   * 끌 때만 막아서는 모자란다 — 상자는 <스스로도> 커진다(목록이 늘거나 접힌 것을 펴거나
   * 창이 좁아지거나). 아래쪽에 붙여 둔 상자를 펴면 그만큼 캔버스 밖으로 자란다.
   */
  function clampNow() {
    const el = cardEl(), box = boxRect()
    if (!el || !box) return
    const r = el.getBoundingClientRect()
    if (!r.width || !box.width) return     // 아직 안 그려졌다
    const lim = limits(r, box)
    const dx = clamp(0, lim.x), dy = clamp(0, lim.y)
    if (!dx && !dy) return
    pos.value = { x: pos.value.x + dx, y: pos.value.y + dy }
    save()
  }

  let ro = null
  onMounted(async () => {
    await nextTick()
    clampNow()      // 지난번에 적어 둔 자리가 지금 창에서는 밖일 수 있다
    const el = cardEl()
    if (el && window.ResizeObserver) {
      ro = new ResizeObserver(() => clampNow())
      ro.observe(el)
    }
    window.addEventListener('resize', clampNow)
  })
  onUnmounted(() => { ro?.disconnect(); window.removeEventListener('resize', clampNow) })

  /**
   * 머리를 잡으면 옮기고, <그냥 누르면> 접고 편다 (아코디언).
   *
   * 접는 ▾ 단추는 11px 짜리라 눈에 잘 안 띈다 — 머리를 눌러 봤는데 아무 일도 없으면
   * «접히지 않는다» 고 느낀다. 그래서 움직이지 않고 뗀 것은 <누른 것> 으로 본다.
   * 4px 은 손이 떨린 정도다. 그보다 많이 움직였으면 옮길 뜻이었다고 본다.
   */
  function drag(e) {
    // 머리에 놓인 단추(⌖ · ▾)를 누른 것이면 그 단추가 할 일이 따로 있다
    if (e.target.closest('.pbtn')) return
    e.preventDefault()
    moving.value = true
    let far = false
    const x0 = e.clientX, y0 = e.clientY
    const p0 = { ...pos.value }
    const el = e.currentTarget
    // 붙잡기는 되면 좋고 안 되어도 그만이다 — 던지면 <아래 listener 를 다는 일>까지 함께 날아가
    // 끌기가 통째로 죽는다. 조용히 아무 일도 안 일어나는 꼴이라 까닭을 찾기 어렵다.
    try { el.setPointerCapture?.(e.pointerId) } catch { /* 붙잡지 못해도 끌기는 된다 */ }
    // 캔버스 밖으로 내보내지 않는다 — 한 번 나가면 되돌릴 손잡이까지 같이 사라진다.
    // 잡은 순간의 네 변으로 범위를 셈해 두고, 움직인 거리를 그 안에 가둔다.
    const box = boxRect()
    const r0 = cardEl()?.getBoundingClientRect()
    const lim = box && r0 ? limits(r0, box) : null
    const move = (ev) => {
      let dx = ev.clientX - x0, dy = ev.clientY - y0
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) far = true
      if (!far) return          // 아직 <누른 것> 인지 <옮기는 것> 인지 모른다 — 떨림으로 움직이지 않는다
      if (lim) { dx = clamp(dx, lim.x); dy = clamp(dy, lim.y) }
      pos.value = { x: p0.x + dx, y: p0.y + dy }
    }
    const up = () => {
      moving.value = false
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      window.removeEventListener('pointercancel', up)
      if (far) save()
      else { open.value = !open.value; save() }   // 안 움직였다 = 접거나 편다
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', up)
  }
  /**
   * 오른쪽 아래 모서리를 잡아 크기를 바꾼다. 바꾼 크기는 이 PC 에 남는다.
   *
   * 브라우저가 거저 주는 <c>resize: both</c> 를 쓰지 않은 까닭:
   *   · 그 속성은 <c>overflow</c> 가 visible 이 아니어야 먹는데, 그러면 상자의 그림자가
   *     잘려 캔버스 위에 떠 있는 느낌이 사라진다
   *   · 모서리 손잡이 모양을 브라우저가 정해서, 이 화면의 <각지게> 와 따로 논다
   * 여기서도 캔버스 밖으로는 못 키운다 — 키워 놓고 보니 단추가 밖이면 누를 수가 없다.
   */
  const sizing = ref(false)
  const MIN = { w: 150, h: 90 }
  function resize(e) {
    e.preventDefault()
    e.stopPropagation()          // 머리를 잡은 것이 아니다 — 끌어서 옮기기로 넘어가지 않게
    const el = cardEl()
    const box = boxRect()
    if (!el || !box) return
    const r0 = el.getBoundingClientRect()
    sizing.value = true
    const x0 = e.clientX, y0 = e.clientY
    const w0 = r0.width, h0 = r0.height
    // 지금 자리에서 캔버스 오른쪽·아래까지 남은 만큼이 최대 크기다
    const maxW = Math.max(MIN.w, box.right - r0.left)
    const maxH = Math.max(MIN.h, box.bottom - r0.top)
    const t = e.currentTarget
    // 붙잡기는 되면 좋고 안 되어도 그만이다 — 던지면 <아래 listener 를 다는 일>까지 함께 날아가
    // 끌기가 통째로 죽는다. 조용히 아무 일도 안 일어나는 꼴이라 까닭을 찾기 어렵다.
    try { t.setPointerCapture?.(e.pointerId) } catch { /* 붙잡지 못해도 끌기는 된다 */ }
    const move = (ev) => {
      size.value = {
        w: Math.round(Math.min(maxW, Math.max(MIN.w, w0 + (ev.clientX - x0)))),
        h: Math.round(Math.min(maxH, Math.max(MIN.h, h0 + (ev.clientY - y0)))),
      }
    }
    const up = () => {
      sizing.value = false
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      window.removeEventListener('pointercancel', up)
      save()
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', up)
  }

  // ⚠️ reactive 로 감싸 돌려준다. 그냥 { open, pos, ... } 를 돌려주면 템플릿에서
  //    panel.open 이 <Ref 객체 그대로> 다 — Ref 는 늘 truthy 라 v-if 가 안 접히고,
  //    :style 에 Ref 를 주면 통째로 무시되어 끌어도 안 움직인다. (둘 다 실제로 밟았다.)
  //    reactive 는 안의 ref 를 풀어 주므로 템플릿도 스크립트도 .value 없이 쓴다.
  return reactive({
    open, pos, moving, style, drag, size, sizing, resize,
    toggle: () => { open.value = !open.value; save() },
    // 자리와 크기를 함께 되돌린다. 따로 두면 <크기를 되돌리는 길> 을 또 찾아야 한다
    home: () => { pos.value = { x: 0, y: 0 }; size.value = null; save() },
  })
}

/** 오른쪽 — 고른 것의 상세 · 테이블 추가 */
const itemLayer = useLayer('wbs.tables2.items', '.itemcard')
const panel = useLayer('wbs.tables2.panel', '.sidecard')
/** 왼쪽 — 작성 도구(잇기 · 저장 · 되돌리기). 보기/필터 단추와 섞여 있어 갈라 두었다. */
const tool = useLayer('wbs.tables2.tool', '.toolcard')

/** 미니맵 — 켜고 끈다. 넓게 보려고 끄는 일이 잦다. */
const showMap = ref(savedView.showMap !== false)
function toggleMap() { showMap.value = !showMap.value; saveView() }

/**
 * 찾기 창이 무엇을 찾는가 — 표냐 프로시저냐.
 *
 * 한 창에 둔 까닭: 하는 일이 같다(DB 에서 골라 도면에 놓는다). 창을 둘로 나누면
 * 스키마·검색어·고른 것을 두 벌로 들고 있어야 하고, 한쪽만 고치게 된다.
 */
const pickWhat = ref('table')   // table | proc
const picker = ref(false)
const pkOwner = ref(schema.value)
const pkQ = ref('')
const pkRows = ref([])
const pkBusy = ref(false)
const pkErr = ref('')
const pkMore = ref(false)
const pkSel = ref(new Set())
const pkKind = ref('ledger')

/** 이미 도면에 있는 이름. 중복으로 놓지 않으려고 미리 뽑아 둔다. */
const placed = computed(() => new Set(nodes.value.filter((n) => n.type === 'table').map((n) => n.id)))

const pkView = computed(() =>
  pkRows.value.map((t) => ({ ...t, already: placed.value.has(t.name) })))
const pkAddable = computed(() => pkView.value.filter((t) => !t.already))
const pkPickedCount = computed(() => pkSel.value.size)

async function pkLoad() {
  pkBusy.value = true
  pkErr.value = ''
  try {
    if (pickWhat.value === 'proc') {
      const d = await api.oraProcs(pkOwner.value, pkQ.value, 500)
      if (!d.run?.ok) throw new Error(d.run?.error || 'DB 에서 목록을 받지 못했습니다.')
      // 표와 같은 모양으로 맞춰 둔다 — 아래 화면과 놓는 코드가 한 벌로 돌아간다
      pkRows.value = (d.run.procs ?? []).map((x) => ({
        name: x.name, comment: x.pkg !== x.name ? x.pkg : '', rows: null, otype: x.kind,
      }))
      pkMore.value = !!d.run.more
      return
    }
    const d = await api.oraTables(pkOwner.value, pkQ.value, 500)
    if (!d.run?.ok) throw new Error(d.run?.error || 'DB 에서 목록을 받지 못했습니다.')
    pkRows.value = (d.run.tables ?? []).map((x) => ({ ...x, otype: 'TABLE' }))
    pkMore.value = !!d.run.more
  } catch (e) {
    pkErr.value = e.message
    pkRows.value = []
  } finally {
    pkBusy.value = false
  }
}
/**
 * [DB 에서 찾기] 창도 머리를 잡아 옮긴다.
 *
 * 레이어들과 달리 이 창은 화면 가운데 떠 있는 modal 이라, 뒤에 있는 도면을 가린다 —
 * 「이 표가 이미 놓여 있나」를 보려면 창을 비켜 놓아야 했다.
 *
 * 레이어의 useLayer 를 쓰지 않는 까닭: 저쪽은 캔버스(.flowwrap) 안에 가두고 접기·크기까지
 * 묶여 있는데, 이 창은 화면(viewport) 기준이고 접히지도 않는다. 억지로 한 벌로 묶으면
 * 두 쓰임 중 하나는 늘 어색해진다.
 */
const DLG_LS = 'wbs.tables2.pickpos'
const dlgPos = ref((() => {
  try {
    const v = JSON.parse(localStorage.getItem(DLG_LS) || 'null')
    return v && Number.isFinite(v.x) ? v : { x: 0, y: 0 }
  } catch { return { x: 0, y: 0 } }
})())
const dlgMoving = ref(false)
const dlgStyle = computed(() => ({
  transform: `translate(${dlgPos.value.x}px, ${dlgPos.value.y}px)`,
  transition: dlgMoving.value ? 'none' : undefined,
}))

/** 창이 화면 밖으로 나가지 않게 되민다. 창 크기가 바뀐 뒤에 열면 옛 자리가 밖일 수 있다. */
function clampDlg() {
  const el = document.querySelector('.dlg')
  if (!el) return
  const r = el.getBoundingClientRect()
  const M = 8
  let dx = 0, dy = 0
  if (r.width <= innerWidth - M * 2) {
    if (r.left < M) dx = M - r.left
    else if (r.right > innerWidth - M) dx = innerWidth - M - r.right
  } else dx = M - r.left
  if (r.height <= innerHeight - M * 2) {
    if (r.top < M) dy = M - r.top
    else if (r.bottom > innerHeight - M) dy = innerHeight - M - r.bottom
  } else dy = M - r.top
  if (!dx && !dy) return
  dlgPos.value = { x: dlgPos.value.x + dx, y: dlgPos.value.y + dy }
}

function dlgDrag(e) {
  // 머리에 놓인 단추·입력칸을 누른 것이면 옮기기가 아니다 — 탭이 안 눌리면 고장으로 보인다
  if (e.target.closest('button, input, select, a')) return
  e.preventDefault()
  dlgMoving.value = true
  const x0 = e.clientX, y0 = e.clientY
  const p0 = { ...dlgPos.value }
  const el = e.currentTarget
  const r0 = el.closest('.dlg').getBoundingClientRect()
  const M = 8
  const lim = {
    x: [M - r0.left, Math.max(M - r0.left, innerWidth - M - r0.right)],
    y: [M - r0.top, Math.max(M - r0.top, innerHeight - M - r0.bottom)],
  }
  const cl = (v, [lo, hi]) => Math.min(hi, Math.max(lo, v))
  // 붙잡기는 되면 좋고 안 되어도 그만이다 — 던지면 <아래 listener 를 다는 일>까지 함께 날아가
  // 끌기가 통째로 죽는다. 조용히 아무 일도 안 일어나는 꼴이라 까닭을 찾기 어렵다.
  try { el.setPointerCapture?.(e.pointerId) } catch { /* 붙잡지 못해도 끌기는 된다 */ }
  const move = (ev) => {
    dlgPos.value = {
      x: p0.x + cl(ev.clientX - x0, lim.x),
      y: p0.y + cl(ev.clientY - y0, lim.y),
    }
  }
  const up = () => {
    dlgMoving.value = false
    window.removeEventListener('pointermove', move)
    window.removeEventListener('pointerup', up)
    window.removeEventListener('pointercancel', up)
    try { localStorage.setItem(DLG_LS, JSON.stringify(dlgPos.value)) } catch { /* 이번만 */ }
  }
  window.addEventListener('pointermove', move)
  window.addEventListener('pointerup', up)
  window.addEventListener('pointercancel', up)
}

function openPicker(what = 'table') {
  pickWhat.value = what
  picker.value = true
  nextTick(clampDlg)
  pkSel.value = new Set()
  pkRows.value = []
  pkKind.value = what === 'proc' ? 'proc' : 'ledger'
  pkLoad()
}
function switchWhat(what) {
  if (pickWhat.value === what) return
  pickWhat.value = what
  pkSel.value = new Set()
  pkRows.value = []
  pkKind.value = what === 'proc' ? 'proc' : 'ledger'
  pkLoad()
}
function pkToggle(t) {
  if (t.already) return              // 이미 놓인 것은 고를 수 없다
  const s2 = new Set(pkSel.value)
  s2.has(t.name) ? s2.delete(t.name) : s2.add(t.name)
  pkSel.value = s2
}
function pkAll() {
  pkSel.value = new Set(pkAddable.value.map((t) => t.name))
}

/**
 * 고른 것들을 도면에 놓는다.
 *
 * 지금 보고 있는 자리 근처에 격자로 깐다 — 한 점에 쌓아 두면 서로 가려 끌어낼 수가 없고,
 * 도면 밖에 떨어뜨리면 찾으러 가야 한다.
 */
function pkPlace() {
  const want = [...pkSel.value].filter((nm) => !placed.value.has(nm))
  if (!want.length) { picker.value = false; return }

  const vp = getViewport()
  const box = document.querySelector('.flowwrap')?.getBoundingClientRect()
  const cx = (-vp.x + (box ? box.width / 2 : 400)) / vp.zoom
  const cy = (-vp.y + (box ? box.height / 2 : 300)) / vp.zoom
  const perRow = Math.max(1, Math.min(5, Math.ceil(Math.sqrt(want.length))))

  const info = Object.fromEntries(pkRows.value.map((t) => [t.name, t]))
  const made = want.map((nm, i) => ({
    id: nm,
    type: 'table',
    position: {
      x: Math.round(cx - 104 + (i % perRow) * 240),
      y: Math.round(cy - 42 + Math.floor(i / perRow) * 120),
    },
    data: {
      id: nm,
      kr: info[nm]?.comment || nm,
      kind: pkKind.value,
      rows: info[nm]?.rows ?? null,
      pk: '', writers: [],
      otype: info[nm]?.otype ?? '',
      note: `${pkOwner.value} 스키마에서 가져왔습니다`
        + (info[nm]?.otype && info[nm].otype !== 'TABLE' ? ` · ${info[nm].otype}` : '')
        + (info[nm]?.rows != null ? ' · 행수는 통계값(어림)입니다' : ''),
    },
  }))
  nodes.value = [...nodes.value, ...made]
  dirty.value = true
  picker.value = false
  toast(`${made.length}개를 놓았습니다 — 자리를 잡고 [저장] 하세요.`, 6000)
  paint()
  flash(made.map((m) => m.id))
  nextTick(() => fitView({ nodes: made.map((m) => m.id), padding: 1.2, duration: 400 }))
}

// ---------- 흐름 필터 ----------
//
// 기존 화면과 같은 묶음이다. 걸리지 않은 칸은 <지우지 않고 흐린다> —
// 지우면 그 칸이 어디에 있었는지가 사라져 도면을 다시 읽어야 한다.
//
// ⚠ 한 묶음만 고르던 것(탭 단추)에서 <여럿 고르기>로 바뀌었다. 「구매요구 + 견적·발주」처럼
//   이어지는 두 흐름을 같이 봐야 하는 일이 잦은데, 탭은 한 번에 하나뿐이라 번갈아 눌러야 했다.
//   고른 묶음들의 칸을 <합집합>으로 모은다.
//
// ⚠ 선 보기와 <빈 집합의 뜻이 다르다>. 거기는 <한 줄도 안 봄> 이지만 이쪽은 <전체>다.
//   흐름 아홉 묶음을 다 합쳐도 543칸 중 86칸뿐이라, 빈 집합을 <아무 칸도 안 봄> 으로 읽으면
//   도면이 통째로 흐려진다 — 거를 뜻이 없을 때 쓰는 자리가 사라진다.
//   그래서 <비움 = 전체>, <아홉 개 다 켜기 = 흐름에 든 86칸만> 으로 서로 다른 두 상태다.
const flowSel = ref((() => {
  if (Array.isArray(savedView.flows2)) return new Set(savedView.flows2)
  // 옛 저장본은 묶음 하나를 글자로 적었다('all' 이 <안 거름>). 그대로 한 개짜리 집합으로 옮긴다.
  const old = savedView.flow
  return typeof old === 'string' && old && old !== 'all' ? new Set([old]) : new Set()
})())
/** 고를 수 있는 묶음 — 도면이 주는 목록에서 [전체]를 뺀다. 합집합이라 [전체]는 뜻이 없다. */
const pickFlows = computed(() => flows.value.filter((f) => f.id !== 'all' && f.nodes))
const allFlowsOn = computed(() => pickFlows.value.length > 0 && flowSel.value.size === pickFlows.value.length)
/** 단추에 적을 한 줄. 이름이 길어(「견적 · 발주」) 셋부터는 수로 줄인다. */
const flowSummary = computed(() => {
  const on = pickFlows.value.filter((f) => flowSel.value.has(f.id))
  if (!on.length) return '전체'
  if (on.length > 2) return `흐름 ${on.length}개`
  // ⚠ 가운뎃점으로 잇지 말 것 — 묶음 이름에 이미 「견적 · 발주」처럼 가운뎃점이 들어 있어
  //   「구매요구 · 견적 · 발주」가 되면 두 묶음인지 세 묶음인지 읽히지 않는다.
  return on.map((f) => f.name).join(' + ')
})
function toggleFlow(id) {
  const n2 = new Set(flowSel.value)
  n2.has(id) ? n2.delete(id) : n2.add(id)
  flowSel.value = n2
  paint()
}
function setAllFlows(on) { flowSel.value = on ? new Set(pickFlows.value.map((f) => f.id)) : new Set(); paint() }
/**
 * [전체] — 옛 탭의 그것과 같다. 흐름만이 아니라 <걸어 둔 것을 모두> 푼다.
 *
 * 흐름만 비우면 단계·선 보기·찾기가 걸린 채 남아, 「전체를 눌렀는데 왜 그대로인가」가 된다.
 * 단추 이름에 그대로 적어 둔다 — 흐름 목록 안에 있는데 다른 것까지 푸는 것은 설명이 필요하다.
 */
function resetAllFilters() {
  flowSel.value = new Set()
  laneSel.value = null
  edgeSel.value = new Set()    // ⚠ «푼다» = 기본값 = 모두 끄기. 전부 켜면 선 1995개가 돌아온다
  q.value = ''
  onlyLinked.value = false
  paint()
}

/** 흐름 드롭다운이 펴져 있는가. 선 보기와 같은 규칙으로 바깥을 누르면 접는다. */
const flowOpen = ref(false)
function closeFlowMenu() { flowOpen.value = false }
function toggleFlowMenu() { flowOpen.value = !flowOpen.value; if (flowOpen.value) kindOpen.value = false }
onMounted(() => window.addEventListener('click', closeFlowMenu))
onUnmounted(() => window.removeEventListener('click', closeFlowMenu))

// ---------- 고른 칸의 상세 ----------
//
// 기존 화면의 오른쪽 패널과 같은 것을 보여 준다 — 키·행수·들어옴·나감·쓰기 주체·
// 트리거 파생·메모·주의. <그림에서 선을 눈으로 좇는 것> 만으로는 71줄을 따라갈 수 없어
// 글로도 한 번 적어 주는 자리다.
const KIND_TEXT = {
  master: '기준정보', ledger: '원장 — 진실의 원천', derived: '파생 — 배치가 재계산',
  snap: '스냅샷 — 시점 고정', ext: '외부 시스템', batch: '배치',
  proc: '프로시저 — 담는 것이 아니라 도는 것', iface: '인터페이스 — 바깥과 주고받는 자리',
  eai: 'EAI — 중계를 거쳐 오가는 자리',
}
const detail = computed(() => {
  const n = selNode.value
  if (!n) return null
  const ins = edges.value.filter((e) => e.target === n.id)
  const outs = edges.value.filter((e) => e.source === n.id)
  return {
    n,
    kindText: KIND_TEXT[n.data.kind] ?? n.data.kind,
    rows: n.data.rows == null ? '-' : Number(n.data.rows).toLocaleString('ko-KR'),
    // eid 를 함께 싣는다 — 조각에서 바로 <그 선> 을 지우거나 고르려면 선을 집을 수 있어야 한다
    ins: ins.map((e) => ({ eid: e.id, id: e.source, l: e.label, ty: e.data?.ty })),
    outs: outs.map((e) => ({ eid: e.id, id: e.target, l: e.label, ty: e.data?.ty })),
  }
})
/** 쓰기 주체의 머리글자가 뜻을 가른다 — ▶ 트리거 · ◈ 배치 (기존 화면과 같은 약속) */
const writerCls = (w) => (w.startsWith('▶') ? 'trg' : w.startsWith('◈') ? 'bat' : '')

// ---------- 찾기 ----------
const q = ref('')
// 적는 대로 다시 칠한다. 48칸 × 71선이라 셈이 싸다 — 늦출 이유가 없다.
watch(q, () => paint())

const hits = computed(() => {
  const kw = q.value.trim().toLowerCase()
  if (!kw) return []
  return nodes.value.filter((n) => n.type === 'table' &&
    (n.id.toLowerCase().includes(kw) || String(n.data.kr ?? '').toLowerCase().includes(kw))).slice(0, 12)
})
function goTo(id) {
  const n = findNode(id)
  if (!n) return
  sel.value = { kind: 'node', id }
  paint()
  fitView({ nodes: [id], padding: 0.6, duration: 320 })
  addSelectedNodes([n])
}

// ---------- 내려받기 ----------
function exportJson() {
  const blob = new Blob([JSON.stringify(plain(), null, 1)], { type: 'application/json' })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  const d = new Date()
  const p = (x) => String(x).padStart(2, '0')
  a.download = `자재_테이블계통도_${schema.value}_${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}.json`
  a.click()
  URL.revokeObjectURL(a.href)
}

// Esc — 잇던 것을 물리고, 모드까지 끈다. 모드에 갇히는 일이 없어야 한다.
/** 글자를 적고 있는 중인가 — 그때의 Backspace·Delete 는 <글자를 지우는> 키다 */
function typing() {
  const el = document.activeElement
  if (!el) return false
  const t = el.tagName
  return t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT' || el.isContentEditable
}

function onKey(e) {
  // 고른 칸·선 지우기 — Backspace 와 Delete 둘 다 받는다.
  //
  // ⚠️ Vue Flow 가 제 손으로 지우게 두지 않는다(:delete-key-code="null").
  //    그쪽이 지우면 배열은 바뀌는데 dirty 가 서지 않아 <지웠는데 저장이 안 되는> 꼴이 된다.
  //    (Backspace 가 실제로 그랬다.) 여기서 removeSel 로 보내 지우기도 한 길로 모은다.
  if ((e.key === 'Delete' || e.key === 'Backspace') && sel.value && !typing()) {
    e.preventDefault()
    removeSel()
    return
  }
  if (e.key !== 'Escape') return
  if (picker.value) { picker.value = false; return }
  // 펴 둔 목록이 먼저다 — 안 그러면 Esc 한 번에 목록이 접히면서 거르기까지 풀린다.
  if (kindOpen.value) { kindOpen.value = false; return }
  if (flowOpen.value) { flowOpen.value = false; return }
  if (flowSel.value.size && !sel.value && !linkFrom.value && !linking.value) { flowSel.value = new Set(); paint(); return }
  if (laneSel.value != null && !sel.value && !linkFrom.value && !linking.value) { laneSel.value = null; paint(); return }
  // ⚠ 조건이 «전부는 아니면» 이 아니라 «하나라도 켜져 있으면» 이다 — 기본이 <모두 끄기> 라
  //   아무것도 안 켜진 것이 <안 걸린> 상태다. 전과 반대다.
  //   이 조건을 안 뒤집으면 기본 상태에서 Esc 가 이 가지에 걸려 아무 일도 않고 끝나,
  //   아래의 [선 있는 칸만]·찾는 글자 지우기까지 막힌다.
  if (edgeSel.value.size && !sel.value && !linkFrom.value && !linking.value) { resetEdgeKinds(); return }
  if (onlyLinked.value && !sel.value && !linkFrom.value && !linking.value) { onlyLinked.value = false; paint(); return }
  if (q.value.trim() && !sel.value && !linkFrom.value && !linking.value) { q.value = ''; return }
  if (linkFrom.value) { linkFrom.value = null; return }
  if (linking.value) { linking.value = false; return }
  sel.value = null
}
onMounted(() => window.addEventListener('keydown', onKey))
onUnmounted(() => window.removeEventListener('keydown', onKey))

const counts = computed(() => ({
  n: nodes.value.filter((n) => n.type === 'table').length,
  e: edges.value.length,
}))
</script>

<template>
  <!-- 화면을 꽉 채운다. 계통도는 넓을수록 읽기 쉬운 그림이라
       이 화면만은 패널 테두리·여백을 두지 않는다. -->
  <div class="wrap">
    <div class="bar">
      <b class="ttl">테이블 계통도</b>
      <!-- 어느 스키마의 계통도인가. 도면은 스키마마다 한 장이라, 바꾸면 통째로 다시 읽는다. -->
      <select
        class="sch" :value="schema"
        :title="`지금은 ${schema} 스키마의 계통도입니다. 바꾸면 그 스키마의 도면을 읽습니다.`"
        @change="changeSchema($event.target.value)"
      >
        <option v-for="x in SCHEMAS" :key="x" :value="x">{{ x }}</option>
      </select>
      <span class="hint">칸 {{ counts.n }} · 이음선 {{ counts.e }}</span>

      <span class="gap"></span>

      <!-- 찾기 -->
      <div class="find">
        <input v-model="q" type="search" placeholder="테이블 찾기 (T30B_1120 · 발주)" />
        <span v-if="q.trim()" class="qn">{{ qKeep ? qKeep.size : 0 }}건</span>
        <ul v-if="hits.length" class="hits">
          <li v-for="h in hits" :key="h.id" @mousedown.prevent="goTo(h.id); q = ''">
            <b>{{ h.id }}</b><span>{{ h.data.kr }}</span>
          </li>
        </ul>
      </div>

      <!-- 흐름 묶음 — <여럿 고를 수 있다>. 고른 묶음들의 칸을 합쳐서 또렷하게 둔다.
           ⚠️ 예전에는 탭 단추 아홉 장이었다. 한 번에 하나뿐이라 「구매요구 → 견적·발주」처럼
              이어지는 두 흐름을 같이 보려면 번갈아 눌러야 했고, 단추가 머리줄의 절반을 먹었다.
           ⚠️ [선 보기] 와 <빈 상태의 뜻이 다르다> — 이쪽은 비우면 «전체»다. 까닭은 script 참조. -->
      <span class="lbl">흐름</span>
      <div class="kdd">
        <button
          class="kdt flw" :class="{ some: flowSel.size, open: flowOpen }"
          :title="flowSel.size
            ? `흐름 ${flowSummary} — 그 묶음의 칸만 또렷하게. 여럿 고르면 합쳐서 봅니다.`
            : '흐름 묶음으로 좁히지 않고 전체를 봅니다. 여럿 고를 수 있습니다.'"
          @click.stop="toggleFlowMenu"
        >
          <span class="t">{{ flowSummary }}</span>
          <span v-if="flowSel.size" class="n">{{ flowKeep ? flowKeep.size : 0 }}</span>
          <span class="car">{{ flowOpen ? '▴' : '▾' }}</span>
        </button>
        <!-- 누를 때마다 접히면 다중선택이 안 되므로 @click.stop 으로 바깥닫기를 막는다 -->
        <div v-if="flowOpen" class="kmenu wide" @click.stop>
          <button
            v-for="f in pickFlows"
            :key="f.id"
            class="kitem"
            :class="{ on: flowSel.has(f.id) }"
            :title="`${f.name} — 테이블 ${f.nodes.length}개`"
            @click="toggleFlow(f.id)"
          >
            <span class="ck">{{ flowSel.has(f.id) ? '✔' : '' }}</span>
            <span class="nm">{{ f.name }}</span>
            <span class="n">{{ f.nodes.length }}</span>
          </button>
          <div class="kfoot">
            <button :disabled="allFlowsOn" title="아홉 묶음을 다 켭니다 — 흐름에 든 칸만 남습니다(전체와 다릅니다)"
                    @click="setAllFlows(true)">모두 켜기</button>
            <button title="흐름 · 단계 · 선 보기 · 찾기까지 걸어 둔 것을 모두 풉니다"
                    @click="resetAllFilters">전체 (모두 풀기)</button>
          </div>
        </div>
      </div>

      <!-- 선 종류 거르기 — <고른 것만 그린다>. 여럿 고를 수 있다(트리거만, 또는 트리거+배치).
           ⚠️ 단추를 늘어놓지 않고 접어 넣는다. 종류가 늘면 머리줄이 줄바꿈되면서 그 아래
              [선 있는 칸만] · 찾기 칸이 밀려 내려간다 — 도면이 그만큼 깎인다.
           ⚠️ 작성 도구의 <새로 잇는 선의 종류> 와 혼동하지 말 것. 거기는 그릴 선을 고르는
              자리고 여기는 볼 선을 고르는 자리다. -->
      <span class="lbl">선 보기</span>
      <div class="kdd">
        <button
          class="kdt" :class="{ some: !allKindsOn, none: !edgeSel.size, open: kindOpen }"
          :title="`보여 줄 이음선 종류 — 지금 ${kindSummary}. 고른 종류만 그립니다(안 고른 것은 지웁니다).`"
          @click.stop="toggleKindMenu"
        >
          <!-- 펴 보지 않아도 <무엇이 켜져 있는지> 가 보이게 색 막대를 그대로 단다 -->
          <span class="sw">
            <i v-for="k in EDGE_KINDS" :key="'s' + k.ty"
               :class="{ dash: k.dash, off: !edgeSel.has(k.ty) }" :style="{ '--c': k.color }"></i>
          </span>
          <span class="t">{{ kindSummary }}</span>
          <span class="car">{{ kindOpen ? '▴' : '▾' }}</span>
        </button>
        <!-- 목록 — 누를 때마다 접히면 다중선택이 안 되므로 @click.stop 으로 바깥닫기를 막는다 -->
        <div v-if="kindOpen" class="kmenu" @click.stop>
          <button
            v-for="k in EDGE_KINDS"
            :key="'f' + k.ty"
            class="kitem"
            :class="{ on: edgeSel.has(k.ty), zero: !edgeCount[k.ty] }"
            :style="{ '--c': k.color }"
            :title="edgeCount[k.ty] ? `'${k.label}' 선 ${edgeCount[k.ty]}개` : `'${k.label}' 선은 이 도면에 없습니다`"
            @click="toggleEdgeKind(k.ty)"
          >
            <span class="ck">{{ edgeSel.has(k.ty) ? '✔' : '' }}</span>
            <i :class="{ dash: k.dash }"></i>
            <span class="nm">{{ k.label }}</span>
            <span class="n">{{ edgeCount[k.ty] }}</span>
          </button>
          <div class="kfoot">
            <button :disabled="allKindsOn" title="모두 켭니다 — 선 전부가 그려져 무겁습니다" @click="setAllKinds(true)">모두 켜기</button>
            <button :disabled="!edgeSel.size" title="모두 끕니다 — 선이 한 줄도 안 보입니다 (기본값 · Esc 와 같습니다)" @click="setAllKinds(false)">모두 끄기</button>
          </div>
        </div>
      </div>
      <!-- 선이 남아 있는 칸만. 선 종류를 걸어도 칸은 48개가 그대로 서 있어
           열다섯 줄을 마흔여덟 칸 사이에서 좇아야 했다. -->
      <label class="chk" :class="{ on: onlyLinked && edgeSel.size, off: !edgeSel.size }"
             :title="edgeSel.size
               ? '또렷하게 남은 선이 닿는 테이블만 보여 줍니다. 아무 데도 안 닿는 칸은 흐려집니다.'
               : '선 보기가 「없음」 이라 쓸 수 없습니다 — 볼 선을 먼저 켜세요.'">
        <input type="checkbox" :disabled="!edgeSel.size" :checked="onlyLinked" @change="toggleOnlyLinked" />
        선 있는 칸만
      </label>

      <span class="gap"></span>

      <!-- 보기 스위치 — 거르고 보는 것만 여기 둔다. 작성 도구는 캔버스 위 왼쪽 레이어로 갈랐다. -->
      <!-- 아이콘만 둔다. 글자를 빼는 대신 눌린 모양(.sw.on)과 title 로 뜻을 전한다 —
           이 바는 흐름 탭 아홉 + 선 종류 넷이 이미 자리를 다 먹는다. -->
      <button
        class="sw ico" :class="{ on: hoverHi }"
        :aria-pressed="hoverHi"
        :title="hoverHi
          ? '올려놓기 강조 — 켜짐. 칸에 손만 올려도 그 칸에 닿는 것만 또렷해집니다. 누르면 끕니다.'
          : '올려놓기 강조 — 꺼짐. 지금은 <누를 때만> 보여 줍니다. 누르면 켭니다.'"
        @click="hoverHi = !hoverHi; hoverId = null; paint()"
      >☞</button>
      <button
        class="sw ico" :class="{ on: autoSave }"
        :aria-pressed="autoSave"
        :title="autoSave
          ? '자동저장 — 켜짐. 바꾸고 잠깐 멎으면 저장합니다. 누르면 끕니다.'
          : '자동저장 — 꺼짐. 작성 도구의 [저장] 으로 직접 저장합니다. 누르면 켭니다.'"
        @click="toggleAuto"
      >⟳<sub>A</sub></button>
      <button
        class="sw ico" :class="{ on: showMap }"
        :aria-pressed="showMap"
        :title="showMap ? '미니맵 — 켜짐. 누르면 숨깁니다.' : '미니맵 — 꺼짐. 누르면 오른쪽 아래에 띄웁니다.'"
        @click="toggleMap"
      >▦</button>

      <span class="gap"></span>
      <span v-if="dirty" class="dirty" title="아직 저장하지 않은 것이 있습니다 — 왼쪽 [작성 도구] 에서 저장하세요">● 저장 안 됨</span>
    </div>

    <div class="flowwrap">
      <!-- 이음선은 'default' = 베지어 곡선이다. 객체(칸)는 각지게, 선은 휘게.
           ⚠️ 주석을 아래 속성 목록 <안에> 넣으면 거기서 태그가 끊겨 나머지 속성이
              글자로 캔버스에 새어 나온다 (실제로 밟았다). 주석은 태그 밖에 둔다. -->
      <VueFlow
        v-model:nodes="nodes"
        v-model:edges="edges"
        :node-types="nodeTypes"
        :edge-types="edgeTypes"
        :min-zoom="0.12"
        :max-zoom="2.4"
        :default-edge-options="{ type: 'way' }"
        :connection-radius="28"
        :delete-key-code="null"
        :nodes-draggable="false"
        :nodes-connectable="false"
        edges-updatable
        snap-to-grid
        :snap-grid="[GRID, GRID]"
      :class="{ linking, picking: itemEdit && !!curItem }"
        fit-view-on-init
        @connect="onConnect"
        @node-click="onNodeClick"
        @edge-click="onEdgeClick"
        @pane-click="onPaneClick"
        @node-drag-stop="onNodeDragStop"
        @edge-update="onEdgeUpdate"
        @node-mouse-enter="onNodeMouseEnter"
        @node-mouse-leave="onNodeMouseLeave"
      >
        <Background :gap="GRID" :size="1" pattern-color="var(--line)" />
        <!-- [전체 보기] 만 우리 것으로 바꾼다 — Vue Flow 의 기본 단추는 아무 일도 하지 않는다
             (까닭은 fitAll 주석 참고). 자리와 생김새는 나머지 셋과 같게 둔다. -->
        <Controls position="bottom-left">
          <template #control-fit-view>
            <ControlButton title="전체 보기 — 모든 테이블이 한 화면에 들어오게" @click="fitAll()">
              <svg width="14" height="14" viewBox="0 0 16 16" aria-hidden="true">
                <path
                  d="M1.5 5.5v-4h4M10.5 1.5h4v4M14.5 10.5v4h-4M5.5 14.5h-4v-4"
                  fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="square"
                />
              </svg>
            </ControlButton>
          </template>
        </Controls>
        <!-- 미니맵에서 레인은 뺀다 — 레인이 도면만큼 커서, 넣어 두면 미니맵이
                     통째로 회색 덩어리가 되어 <어디에 무엇이 있는지> 를 못 보여 준다. -->
                <MiniMap
                  v-if="showMap"
                  pannable zoomable position="bottom-right"
                  :node-color="(n) => (n.type === 'lane' ? 'transparent' : '#9AA8B4')"
                  :node-stroke-color="(n) => (n.type === 'lane' ? 'transparent' : '#9AA8B4')"
                />

        <!-- 고른 것 손보기 — 머리를 잡아 옮기고, ▾ 로 접는다 -->
      </VueFlow>

      <!-- 알림은 toast 로. 바 아래 띠로 두었더니 뜰 때마다 캔버스 높이가 줄었다 늘어
           그림이 들썩였다. 떠 있는 것은 자리를 차지하지 않는다.
           손이 통과하게 두어(pointer-events:none) 그 아래 칸도 그대로 집힌다. -->
      <transition name="toast">
        <div v-if="msg" class="toast" :class="{ bad: msgBad }" role="status">{{ msg }}</div>
      </transition>

      <!-- 업무항목 — 업무 하나가 쓰는 표를 사람이 모아 두는 자리.
           흐름(위쪽 탭)은 도면을 구울 때 정해진 묶음이고, 이쪽은 쓰면서 늘려 가는 묶음이다.
           그래서 탭 옆이 아니라 따로 둔다. -->
      <div class="itemcard" :class="{ moving: itemLayer.moving, sizing: itemLayer.sizing }" :style="itemLayer.style">
        <div class="phd" @pointerdown="itemLayer.drag">
          <span class="grip" title="끌면 옮기고, 그냥 누르면 접힙니다">⠿</span>
          <b class="pt">업무항목</b>
          <span class="n">{{ items.length }}</span>
          <span v-if="itemBusy" class="dot" title="저장 중">●</span>
          <span class="gap"></span>
          <!-- 다시 읽기 — 정본은 서버 파일이라 남이 고친 것이 여기 목록에는 안 보인다.
               화면 전체를 새로고침하지 않고 이 목록만 맞춘다. -->
          <button
            class="pbtn spin" :class="{ busy: itemLoading }" :disabled="itemLoading || itemBusy"
            title="업무항목 목록을 서버에서 다시 읽습니다 (도면은 그대로)"
            @click.stop="reloadItems"
          >↻</button>
          <button v-if="itemLayer.pos.x || itemLayer.pos.y || itemLayer.size" class="pbtn" title="제자리·기본 크기로" @click.stop="itemLayer.home">⌖</button>
          <button class="pbtn" :title="itemLayer.open ? '접기' : '펴기'" @click.stop="itemLayer.toggle">
            {{ itemLayer.open ? '▾' : '▸' }}
          </button>
        </div>

        <div v-if="itemLayer.open" class="card items">
          <!-- 표(그리드). 140개가 넘어가면서 그냥 늘어놓은 목록으로는 찾을 수가 없다 —
               머리줄에 거르는 칸을 둬서 적는 즉시 좁힌다. -->
          <div class="igrid">
            <div class="ghead">
              <span class="c-code">코드</span>
              <span class="c-name">업무항목</span>
              <span class="c-n" title="담긴 표·프로시저 수">표</span>
              <button class="c-add" title="새 업무항목 만들기" @click="openAddDlg">＋</button>
            </div>
            <div class="gfilter">
              <input v-model="fCode" class="c-code" placeholder="2310" aria-label="코드로 거르기" />
              <input v-model="fName" class="c-name" placeholder="이름으로 거르기" aria-label="이름으로 거르기" />
              <span class="c-n">{{ shownItems.length }}</span>
              <button
                class="c-add clr" :disabled="!fCode && !fName"
                title="거르기를 풉니다" @click="fCode = ''; fName = ''"
              >✕</button>
            </div>

            <div class="gbody">
              <p v-if="!items.length" class="none">
                아직 없습니다. 오른쪽 위 <b>＋</b> 로 만들면, 칸을 눌러 그 업무가 쓰는 표를 담을 수 있습니다.
              </p>
              <p v-else-if="!shownItems.length" class="none">거른 조건에 맞는 업무항목이 없습니다.</p>

              <div
                v-for="it in shownItems" :key="it.id"
                class="grow" :class="{ on: it.id === itemSel }"
              >
                <template v-if="renaming === it.id">
                  <input
                    :ref="(el) => el && el.focus()"
                    class="rn" :value="it.name"
                    @keydown.enter.prevent="$event.target.blur()"
                    @keydown.esc.prevent="renaming = null"
                    @blur="renameItem(it, $event.target.value); renaming = null"
                  />
                </template>
                <template v-else>
                  <button
                    class="nm"
                    :title="`${it.name} — 표 ${it.tables.length}개. 누르면 그 표만 또렷해집니다 (또 누르면 전체).`"
                    @click="pickItem(it.id)"
                  >
                    <span class="c-code">{{ it.code }}</span>
                    <span class="c-name">{{ it.title }}</span>
                    <span class="c-n">{{ it.tables.length }}</span>
                  </button>
                  <button class="ib" title="이름 바꾸기" @click="renaming = it.id">✎</button>
                  <button class="ib rm" title="이 업무항목을 지웁니다 (도면의 표는 그대로)" @click="dropItem(it)">✕</button>
                </template>
              </div>
            </div>
          </div>

          <template v-if="curItem">
            <hr />
            <label class="row ed" :class="{ on: soloItem }"
                   title="켜면 고른 업무의 표와 그 사이 선만 그립니다. 끄면 전체를 두고 나머지를 흐립니다 — 그림의 뼈대가 보이는 대신 무겁습니다.">
              <input type="checkbox" :checked="soloItem" @change="toggleSolo" />
              이 업무만 그리기
            </label>
            <label class="row ed" :class="{ on: itemEdit }"
                   title="켜고 칸을 누르면 이 업무항목에 담깁니다. 담긴 칸을 또 누르면 빠집니다.">
              <input type="checkbox" :checked="itemEdit" @change="toggleItemEdit" />
              편집모드 — 칸을 눌러 담기
            </label>
            <p v-if="itemEdit" class="step">
              흐린 칸을 누르면 「{{ curItem.name }}」 에 담깁니다. 담긴 칸(✔)을 또 누르면 빠집니다.
              <br />고르기·강조는 편집모드를 끄면 돌아옵니다.
            </p>
            <p v-else class="hintxt">
              지금 「{{ curItem.name }}」 의 표 {{ curItem.tables.length }}개만 또렷합니다.
            </p>
          </template>
        </div>
        <span
          v-if="itemLayer.open" class="rsz" title="끌어서 크기를 바꿉니다 (⌖ 로 기본 크기)"
          @pointerdown="itemLayer.resize"
        ></span>
      </div>

      <!-- 새 업무항목 — 바깥을 눌러도 닫히지 않고 ✕ 로만 닫는다 (이 화면의 다른 창과 같은 규칙) -->
      <div v-if="addOpen" class="dlgwrap" @click.self.stop>
        <div class="dlg2">
          <h3>
            새 업무항목
            <button class="x" title="닫기" @click="addOpen = false">✕</button>
          </h3>
          <label>
            이름
            <input
              ref="addBox" v-model="newItem"
              placeholder="[2310] 일반재 POR 접수"
              @keydown.enter.prevent="addFromDlg"
              @keydown.esc.prevent="addOpen = false"
            />
          </label>
          <p class="muted note">
            앞머리에 <b>[코드]</b> 를 적어 두면 그리드의 «코드» 칸으로 갈라져 코드만으로 찾을 수 있습니다.
            만들면 바로 <b>편집모드</b>로 들어갑니다 — 칸을 눌러 담으세요.
          </p>
          <div class="btns">
            <button class="go" :disabled="!newItem.trim()" @click="addFromDlg">만들기</button>
            <button @click="addOpen = false">취소</button>
          </div>
        </div>
      </div>

      <!-- 작성 도구 — 보기/필터(위쪽 바)와 갈라 둔 자리.
           쓰는 때가 다르다: 위는 <볼 때> 늘 쓰고, 이쪽은 <고칠 때만> 쓴다.
           섞어 두면 그릴 생각이 없을 때도 저장·되돌리기 단추가 손끝에 닿는다. -->
      <div class="toolcard" :class="{ moving: tool.moving, sizing: tool.sizing }" :style="tool.style">
        <div class="phd" @pointerdown="tool.drag">
          <span class="grip" title="끌면 옮기고, 그냥 누르면 접힙니다">⠿</span>
          <b class="pt">작성 도구</b>
          <span v-if="dirty" class="dot" title="저장하지 않은 것이 있습니다">●</span>
          <span class="gap"></span>
          <button v-if="tool.pos.x || tool.pos.y || tool.size" class="pbtn" title="제자리·기본 크기로" @click.stop="tool.home">⌖</button>
          <button class="pbtn" :title="tool.open ? '접기' : '펴기'" @click.stop="tool.toggle">
            {{ tool.open ? '▾' : '▸' }}
          </button>
        </div>

        <div v-if="tool.open" class="card tool">
          <!-- 잇기 -->
          <button
            class="wide link" :class="{ on: linking }"
            title="켜고 출발 칸 → 도착 칸을 차례로 누르면 이어집니다 (Esc 로 빠져나옴).
칸에 손을 올려 네 면의 손잡이를 끌어도 됩니다 — 확대했을 때 편합니다."
            @click="toggleLink"
          >{{ linking ? '↝ 잇는 중 — 멈추려면 다시' : '↝ 잇기' }}</button>
          <p v-if="linking" class="step">
            <template v-if="linkFrom">
              {{ linkFrom.id }}<template v-if="linkFrom.handle">·{{ PORT[linkFrom.handle] }}</template>
              → 도착 칸(또는 그 지점)을 누르세요
            </template>
            <template v-else>출발 칸을 누르세요 — 네 지점 중 하나를 눌러 고를 수 있습니다</template>
          </p>

          <p class="lb">새로 잇는 선의 종류</p>
          <div class="kinds">
            <button
              v-for="k in EDGE_KINDS"
              :key="k.ty"
              class="kbtn"
              :class="{ on: newType === k.ty }"
              :style="{ '--c': k.color }"
              :title="`새로 잇는 선을 '${k.label}' 로 만듭니다`"
              @click="newType = k.ty"
            ><i :class="{ dash: k.dash }"></i>{{ k.label }}</button>
          </div>

          <hr />

          <button class="wide go" :disabled="busy === 'save' || !dirty" @click="save">
            {{ busy === 'save' ? '저장 중…' : dirty ? '저장 *' : '저장' }}
          </button>
          <p v-if="autoSave" class="autonote">자동저장 켜짐 — 바꾸고 잠깐 멎으면 저장합니다.</p>
          <div class="row2">
            <button :disabled="loading" title="서버에서 다시 읽습니다 (저장하지 않은 것은 사라집니다)" @click="load">
              ⟳ 다시 읽기
            </button>
            <button :disabled="!!busy" title="지금 도면을 JSON 으로 받습니다" @click="exportJson">⤓ JSON</button>
          </div>
          <button
            v-if="hasSeed" class="wide warnb" :disabled="!!busy"
            :title="resetArm ? '한 번 더 누르면 지금 배치를 버리고 처음 모습으로 돌아갑니다' : '처음 구웠을 때의 배치로 되돌립니다'"
            @click="resetToSeed"
          >{{ resetArm ? '한 번 더 — 지금 배치를 버립니다' : '기본 배치로' }}</button>
        </div>
        <span
          v-if="tool.open" class="rsz" title="끌어서 크기를 바꿉니다 (⌖ 로 기본 크기)"
          @pointerdown="tool.resize"
        ></span>
      </div>

      <!-- 고른 것 손보기 — 머리를 잡아 옮기고 ▾ 로 접는다.
           Vue Flow 의 <Panel> 을 쓰지 않는 까닭: 그쪽은 내가 준 transform 을 덮어써
           끌어도 움직이지 않았고, 캔버스 높이만큼 늘어나 그 아래 칸을 가로막았다. -->
      <div class="sidecard" :class="{ moving: panel.moving, sizing: panel.sizing }" :style="panel.style">
        <div class="phd" @pointerdown="panel.drag">
          <span class="grip" title="끌면 옮기고, 그냥 누르면 접힙니다">⠿</span>
          <b class="pt">{{ detail ? '테이블' : selEdge ? '이음선' : '테이블 추가' }}</b>
          <span class="gap"></span>
          <button v-if="panel.pos.x || panel.pos.y || panel.size" class="pbtn" title="제자리·기본 크기로" @click.stop="panel.home">⌖</button>
          <button class="pbtn" :title="panel.open ? '접기' : '펴기'" @click.stop="panel.toggle">
            {{ panel.open ? '▾' : '▸' }}
          </button>
        </div>
        <template v-if="panel.open">
          <div v-if="detail" class="card wide">
            <div class="chd"><span class="ttl2">{{ detail.n.data.kr }}</span></div>
            <p class="sub"><b>{{ detail.n.data.id }}</b> · {{ detail.kindText }}</p>

            <dl class="kv">
              <dt>키</dt><dd class="mono">{{ detail.n.data.pk || '-' }}</dd>
              <dt>행수</dt><dd class="mono">{{ detail.rows }}</dd>

              <dt>들어옴</dt>
              <dd>
                <div v-if="detail.ins.length" class="chips">
                  <span v-for="c in detail.ins" :key="c.eid" :class="c.ty">
                    <b class="go2" :title="`${c.id} 로 갑니다`" @click="goTo(c.id)">{{ c.id }}</b><em v-if="c.l"> · {{ c.l }}</em>
                    <i class="ed" title="이 이음선 고치기 (글귀 · 종류)" @click.stop="pickEdge(c.eid)">✎</i>
                    <i class="rm" title="이 이음선만 지우기" @click.stop="dropEdge(c.eid)">✕</i>
                  </span>
                </div>
                <span v-else class="none">없음</span>
              </dd>

              <dt>나감</dt>
              <dd>
                <div v-if="detail.outs.length" class="chips">
                  <span v-for="c in detail.outs" :key="c.eid" :class="c.ty">
                    <b class="go2" :title="`${c.id} 로 갑니다`" @click="goTo(c.id)">{{ c.id }}</b><em v-if="c.l"> · {{ c.l }}</em>
                    <i class="ed" title="이 이음선 고치기 (글귀 · 종류)" @click.stop="pickEdge(c.eid)">✎</i>
                    <i class="rm" title="이 이음선만 지우기" @click.stop="dropEdge(c.eid)">✕</i>
                  </span>
                </div>
                <span v-else class="none">없음</span>
              </dd>

              <template v-if="detail.n.data.writers?.length">
                <dt>쓰기 주체</dt>
                <dd><div class="chips plain">
                  <span v-for="(w, i) in detail.n.data.writers" :key="'w' + i" :class="writerCls(w)">{{ w }}</span>
                </div></dd>
              </template>

              <template v-if="detail.n.data.trg">
                <dt>트리거 파생</dt><dd class="trgtext">{{ detail.n.data.trg }}</dd>
              </template>
            </dl>

            <p v-if="detail.n.data.note" class="note2">{{ detail.n.data.note }}</p>
            <div v-if="detail.n.data.warn" class="warnbox">⚠ {{ detail.n.data.warn }}</div>

            <!-- 고치는 것은 접어 둔다 — 이 패널은 <읽는 자리> 가 본 쓰임이다 -->
            <details class="edit">
              <summary>고치기</summary>
              <!-- 이름은 열쇠다. 바꾸면 걸린 이음선까지 함께 고친다(renameNode).
                   적는 동안 고치면 글자 하나마다 선을 다시 꿰게 되므로 <칸을 벗어날 때> 만 한다. -->
              <label>테이블명
                <input
                  :value="detail.n.data.id"
                  title="바꾸면 이 칸에 걸린 이음선도 함께 고칩니다 (칸을 벗어날 때 적용)"
                  @change="renameNode($event.target.value)"
                  @keydown.enter="$event.target.blur()"
                />
              </label>
              <label>스키마
                <input
                  :value="detail.n.data.owner"
                  :placeholder="`비우면 DB 가 정합니다 (지금 ${schema})`"
                  title="다른 스키마의 표면 적어 둡니다. 비우면 DB 에서 알아 온 값으로 돌아갑니다."
                  @change="setOwner($event.target.value)"
                />
              </label>
              <label>설명<input :value="detail.n.data.kr" @change="patchNode({ kr: $event.target.value })" @keydown.enter="$event.target.blur()" /></label>
              <label>종류
                <select :value="detail.n.data.kind" @change="patchNode({ kind: $event.target.value })">
                  <option value="master">기준</option><option value="ledger">원장</option>
                  <option value="derived">파생</option><option value="snap">스냅샷</option>
                  <option value="ext">외부</option><option value="batch">배치</option>
                  <option value="proc">프로시저</option><option value="iface">인터페이스</option><option value="eai">EAI</option>
                </select>
              </label>
              <label>PK<input :value="detail.n.data.pk" @change="patchNode({ pk: $event.target.value })" @keydown.enter="$event.target.blur()" /></label>
              <label>메모<textarea rows="3" :value="detail.n.data.note" @change="patchNode({ note: $event.target.value })"></textarea></label>
              <button class="del" @click="removeSel">이 칸과 걸린 이음선 지우기</button>
            </details>
          </div>

          <div v-else-if="selEdge" class="card">
            <div class="chd">이음선</div>
            <p class="ends"><b>{{ selEdge.source }}</b> → <b>{{ selEdge.target }}</b></p>
            <label>글귀<input :value="selEdge.label" @change="patchEdge({ label: $event.target.value })" @keydown.enter="$event.target.blur()" /></label>
            <label>종류
              <select :value="selEdge.data?.ty" @change="patchEdge({ data: { ty: $event.target.value } })">
                <option v-for="k in EDGE_KINDS" :key="k.ty" :value="k.ty">{{ k.label }}</option>
              </select>
            </label>
            <label class="row">
              <input type="checkbox" :checked="!!selEdge.data?.key"
                     @change="patchEdge({ data: { key: $event.target.checked ? 1 : 0 } })" />
              주요 경로 (굵게)
            </label>
            <!-- 흐름 순번 — 자료가 몇 번째로 흐르는지. 갈래가 여럿이면 빛깔로 가른다
                 (같은 1번이라도 빛깔이 다르면 다른 갈래다). 비우면 번호를 떼어 낸다. -->
            <div class="ports">
              <label>순번
                <input
                  type="number" min="0" max="99" :value="selEdge.data?.seq ?? ''"
                  placeholder="비움" title="0 이나 비우면 번호를 떼어 냅니다"
                  @change="patchEdge({ data: { seq: Number($event.target.value) || 0 } })"
                />
              </label>
              <label>흐름(빛깔)
                <select :value="selEdge.data?.flow ?? 0" @change="patchEdge({ data: { flow: Number($event.target.value) } })">
                  <option v-for="(c, i) in SEQ_COLORS" :key="i" :value="i">{{ i + 1 }} · {{ SEQ_NAMES[i] }}</option>
                </select>
              </label>
            </div>
            <div class="ports">
              <label>출발 지점
                <select :value="selEdge.sourceHandle ?? ''" @change="patchEdge({ sourceHandle: $event.target.value || null })">
                  <option value="">맡김</option>
                  <option v-for="(nm, k) in PORT" :key="'s'+k" :value="k">{{ nm }}</option>
                </select>
              </label>
              <label>도착 지점
                <select :value="selEdge.targetHandle ?? ''" @change="patchEdge({ targetHandle: $event.target.value || null })">
                  <option value="">맡김</option>
                  <option v-for="(nm, k) in PORT" :key="'t'+k" :value="k">{{ nm }}</option>
                </select>
              </label>
            </div>
            <button class="wide2" title="들어옴 ↔ 나감 — 화살표 방향을 뒤집습니다" @click="flipEdge">
              ⇄ 방향 뒤집기
            </button>
            <p class="tiny">
              <b>끝을 옮기려면</b> 도면에서 선의 끝점을 끌어 다른 칸에 놓습니다 —
              글귀·종류는 그대로 따라갑니다. 붙는 <b>지점</b>은 위에서 고릅니다.
            </p>
            <button class="del" @click="removeSel">이 이음선 지우기</button>
          </div>

          <div v-else class="card add">

            <label>이름<input v-model="newId" placeholder="T30X_9999" @keydown.enter="addTable" /></label>
            <label>설명<input v-model="newKr" placeholder="무엇을 담는 표인지" @keydown.enter="addTable" /></label>
            <label>종류
              <select v-model="newKind">
                <option value="master">기준</option><option value="ledger">원장</option>
                <option value="derived">파생</option><option value="snap">스냅샷</option>
                <option value="ext">외부</option><option value="batch">배치</option>
                  <option value="proc">프로시저</option><option value="iface">인터페이스</option><option value="eai">EAI</option>
              </select>
            </label>
            <button class="go" @click="addTable">＋ 지금 보는 자리에 놓기</button>
            <button class="find2" title="수빅 DB 의 스키마에서 테이블을 찾아 고릅니다" @click="openPicker('table')">
              ⌕ DB 에서 테이블 찾기
            </button>
            <button class="find2" title="패키지·프로시저를 찾아 도면에 놓습니다 (무엇이 이 표를 쓰는가)"
                    @click="openPicker('proc')">
              ⌕ 패키지 · 프로시저 찾기
            </button>
            <p class="tiny">
              칸에 손을 올리면 네 면에 <b>손잡이</b>가 뜹니다. 끌어다 다른 칸에 놓으면 이어집니다.
              칸·이음선을 누르면 여기서 손봅니다.
            </p>
          </div>
        </template>
        <span
          v-if="panel.open" class="rsz" title="끌어서 크기를 바꿉니다 (⌖ 로 기본 크기)"
          @pointerdown="panel.resize"
        ></span>
      </div>

    </div>

    <!-- DB 에서 찾기 -->
    <div v-if="picker" class="mask" @click.self="picker = false">
      <div class="dlg" :class="{ moving: dlgMoving }" :style="dlgStyle">
        <header @pointerdown="dlgDrag">
          <!-- 이 창은 접히지 않는다(모달이다) — 머리는 옮기기만 한다 -->
          <span class="grip" title="여기를 잡아 옮깁니다">⠿</span>
          <strong>DB 에서 찾기</strong>
          <div class="tabs2">
            <button :class="{ on: pickWhat === 'table' }" @click="switchWhat('table')">테이블</button>
            <button :class="{ on: pickWhat === 'proc' }" @click="switchWhat('proc')">패키지 · 프로시저</button>
          </div>
          <span class="hint">수빅 DB · 이미 놓인 것은 고를 수 없습니다</span>
          <span class="gap"></span>
          <button class="x" title="닫기 (Esc)" @click="picker = false">✕</button>
        </header>

        <div class="pbar">
          <label class="sm">스키마
            <input v-model="pkOwner" type="text" style="width: 72px" @keydown.enter="pkLoad" />
          </label>
          <input
            v-model="pkQ" type="search"
            :placeholder="pickWhat === 'proc' ? '이름으로 찾기 (P_30B · SAVE_POR)' : '이름 · 설명으로 찾기 (T30B · POR)'"
            @keydown.enter="pkLoad"
          />
          <button class="go" :disabled="pkBusy" @click="pkLoad">{{ pkBusy ? '찾는 중…' : '찾기' }}</button>
          <span class="gap"></span>
          <span class="hint">
            {{ pkView.length }}건<template v-if="pkMore"> (더 있습니다 — 좁혀 보세요)</template>
            · 놓을 수 있는 것 {{ pkAddable.length }}
          </span>
          <button :disabled="!pkAddable.length" @click="pkAll">보이는 것 전부 고르기</button>
        </div>

        <p v-if="pkErr" class="perr">{{ pkErr }}</p>

        <div class="plist">
          <table>
            <thead>
              <tr>
                <th class="w1"></th>
                <th>{{ pickWhat === 'proc' ? '프로시저' : '테이블' }}</th>
                <th>{{ pickWhat === 'proc' ? '패키지' : '설명' }}</th>
                <th class="num">{{ pickWhat === 'proc' ? '종류' : '행수(어림)' }}</th>
              </tr>
            </thead>
            <tbody>
              <tr
                v-for="t in pkView"
                :key="t.name"
                :class="{ already: t.already, on: pkSel.has(t.name) }"
                @click="pkToggle(t)"
              >
                <td class="w1">
                  <input type="checkbox" :checked="pkSel.has(t.name)" :disabled="t.already" @click.stop="pkToggle(t)" />
                </td>
                <td class="mono">
                  {{ t.name }}
                  <span v-if="t.already" class="tagp">이미 있음</span>
                </td>
                <td class="muted">{{ t.comment || '—' }}</td>
                <td class="num muted">
                  {{ pickWhat === 'proc' ? (t.otype || '-') : (t.rows == null ? '-' : Number(t.rows).toLocaleString('ko-KR')) }}
                </td>
              </tr>
              <tr v-if="!pkView.length && !pkBusy">
                <td colspan="4" class="pempty">찾은 것이 없습니다.</td>
              </tr>
            </tbody>
          </table>
        </div>

        <footer>
          <label class="sm">놓을 때 종류
            <select v-model="pkKind">
              <option value="master">기준</option><option value="ledger">원장</option>
              <option value="derived">파생</option><option value="snap">스냅샷</option>
              <option value="ext">외부</option><option value="batch">배치</option>
                  <option value="proc">프로시저</option><option value="iface">인터페이스</option><option value="eai">EAI</option>
            </select>
          </label>
          <span class="hint">
            {{ pickWhat === 'proc' ? '프로시저는 보통 [배치] 로 둡니다.' : '설명이 있으면 그것을 칸 이름으로 씁니다.' }}
          </span>
          <span class="gap"></span>
          <button @click="picker = false">취소</button>
          <button class="go" :disabled="!pkPickedCount" @click="pkPlace">
            {{ pkPickedCount ? `고른 ${pkPickedCount}개 놓기` : '고른 것 없음' }}
          </button>
        </footer>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* 화면 전체를 쓴다 — 바깥 패널 여백을 두지 않는다 (menuList 의 full:true 와 짝이다) */
.wrap { display: flex; flex-direction: column; height: calc(100vh - 92px); min-height: 420px; }

.bar {
  display: flex; align-items: center; gap: 7px; flex-wrap: wrap;
  padding: 7px 10px; border: 1px solid var(--line); border-bottom: 0;
  border-radius: 0; background: var(--panel); flex: none;
}
.bar button, .bar select, .bar input { font-size: 11.5px; }
.bar button { padding: 3px 9px; }
.ttl { font-size: 13px; }
/* 스키마 고르기 — 지금 보는 것이 <어느 쪽인가> 는 늘 눈에 보여야 한다 */
.sch { font-weight: 700; color: var(--accent); border-color: var(--accent); padding: 2px 6px; }
.hint { font-size: 11px; color: var(--muted); }
.gap { flex: 1; }
.lbl { font-size: 11px; color: var(--muted); }
.lbl.step { color: var(--accent); font-weight: 600; }
/* 선 보기 — 접어 넣은 다중선택. 0건짜리는 흐리게 두되 지우지 않는다
   (지우면 <그런 종류가 있다> 는 것조차 안 보인다). */
.kdd { position: relative; display: inline-flex; }
.bar .kdt {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 3px 7px; font-size: 11px;
}
/* 색 막대 — 펴 보지 않아도 무엇이 켜져 있는지가 보인다. 꺼진 것은 지우지 않고 흐린다 */
.kdt .sw { display: inline-flex; align-items: center; gap: 2px; }
.kdt .sw i { width: 9px; height: 0; border-top: 2px solid var(--c); display: inline-block; }
.kdt .sw i.dash { border-top-style: dashed; }
.kdt .sw i.off { opacity: 0.18; }
.kdt .t { font-weight: 600; }
.kdt .car { color: var(--muted); font-size: 9px; }
/* 흐름 — 색 막대가 없는 대신 <몇 칸이 남았는지> 를 단추에 적는다.
   86칸짜리 묶음을 골랐는지 10칸짜리를 골랐는지가 펴 보지 않고도 보여야 한다. */
.kdt .n {
  font-size: 10px; color: var(--muted); font-variant-numeric: tabular-nums;
  padding: 0 3px; border-left: 1px solid var(--line);
}
.bar .kdt.flw { min-width: 86px; justify-content: space-between; }
.bar .kdt.flw.some .n { color: inherit; border-color: currentColor; }
/* 걸려 있으면 눈에 띄어야 한다 — 「다 보고 있다」와 「걸러 보고 있다」는 다른 상태다 */
.bar .kdt.some { border-color: var(--accent); color: var(--accent); background: var(--accent-soft); }
/* 하나도 안 켜면 선이 한 줄도 없다. 빈 화면을 보고 까닭을 못 찾는 일이 없게 붉게 세운다 */
.bar .kdt.none { border-color: #B33636; color: #B33636; background: transparent; }
.bar .kdt.open { border-color: var(--accent); }

.kmenu {
  position: absolute; top: calc(100% + 3px); left: 0; z-index: 40;
  min-width: 164px; padding: 3px; max-height: 60vh; overflow: auto;
  border: 1px solid var(--line); background: var(--panel);
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.18);
}
.kitem {
  display: flex; align-items: center; gap: 6px; width: 100%;
  padding: 4px 6px; font-size: 11px; text-align: left;
  border: 0; background: transparent; color: var(--text); cursor: pointer;
}
.kitem:hover { background: var(--bg); }
/* 체크 — 선 종류는 그 선 빛깔로, 흐름은 --c 가 없으므로 강조색으로 떨어진다 */
.kitem .ck { width: 11px; color: var(--c, var(--accent)); font-weight: 700; }
.kitem i { width: 15px; height: 0; border-top: 2px solid var(--c); display: inline-block; flex: none; }
.kitem i.dash { border-top-style: dashed; }
.kitem .nm { flex: 1; }
.kitem .n { font-size: 10px; color: var(--muted); font-variant-numeric: tabular-nums; }
.kitem.on .nm { color: var(--c, var(--accent)); font-weight: 700; }
.kitem.zero { opacity: 0.45; }
/* 흐름 이름이 「견적 · 발주」처럼 길다 — 선 종류보다 한 뼘 넓게 둔다 */
.kmenu.wide { min-width: 188px; }
.kfoot { display: flex; gap: 3px; margin-top: 3px; padding-top: 3px; border-top: 1px solid var(--line); }
.kfoot button { flex: 1; padding: 3px 0; font-size: 10.5px; }
.kfoot button:disabled { opacity: 0.4; cursor: default; }
/* 체크박스 하나 — 단추들 사이에서 <켜고 끄는 것> 임이 모양으로 보여야 한다 */
.chk {
  display: inline-flex; align-items: center; gap: 4px;
  font-size: 11px; color: var(--muted); cursor: pointer;
  padding: 3px 8px; border: 1px solid var(--line); background: var(--panel);
}
.chk:hover { border-color: var(--accent); color: var(--accent); }
.chk.on { border-color: var(--accent); color: var(--accent); background: var(--accent-soft); font-weight: 600; }
/* 선 보기가 「없음」 이면 셈할 선이 없어 잠근다 — 눌러도 안 되는 까닭은 title 에 적어 둔다 */
.chk.off { opacity: .45; cursor: default; }
.chk.off:hover { border-color: var(--line); color: var(--muted); }
.chk input { margin: 0; }

/* 보기 스위치 — 아이콘 하나뿐이라 <눌려 있다> 는 것이 모양으로 보여야 한다.
   색만 바꾸면 켜진 건지 그냥 강조색인지 구별되지 않아, 눌린 자국(안쪽 그림자)을 준다. */
.sw.ico {
  width: 26px; padding: 3px 0; text-align: center;
  font-size: 12px; line-height: 1.2; color: var(--muted-3);
}
.sw.ico:hover { color: var(--accent); border-color: var(--accent); }
.sw.ico sub { font-size: 7px; vertical-align: sub; }
.sw.ico.on {
  color: var(--accent); border-color: var(--accent); background: var(--accent-soft);
  box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.18);
  transform: translateY(1px);
}

button.link.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
/* 잇는 중에는 칸 위에서 커서가 <고르는 손> 이 된다 — 모드에 들어와 있다는 것이 늘 보여야 한다 */
:deep(.vue-flow.linking .vue-flow__node-table) { cursor: crosshair; }
button.go { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
button.go:disabled { opacity: 0.45; cursor: default; }
button.warnb { color: var(--warn); border-color: var(--warn-line); }

/* 이음선 종류 고르기 — 색을 단추에 그대로 보여 준다. 글자만으로는 도면의 그 선이 어느 것인지 모른다 */
.kinds { display: flex; gap: 3px; }
.kbtn { display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px; }
.kbtn i { width: 14px; height: 0; border-top: 2px solid var(--c); display: inline-block; }
.kbtn i.dash { border-top-style: dashed; }
.kbtn.on { border-color: var(--c); color: var(--c); background: var(--bg); }

.find { position: relative; }
.find input { min-width: 190px; }
.qn {
  position: absolute; right: 7px; top: 50%; transform: translateY(-50%);
  font-size: 10px; color: var(--accent); font-weight: 600; pointer-events: none;
}
.hits {
  position: absolute; z-index: 20; top: 100%; left: 0; right: 0; margin: 3px 0 0; padding: 3px;
  list-style: none; background: var(--panel); border: 1px solid var(--line);
  border-radius: 0; box-shadow: 0 8px 22px var(--shadow); max-height: 260px; overflow: auto;
}
.hits li { display: flex; gap: 7px; padding: 3px 7px; cursor: pointer; font-size: 11px; }
.hits li:hover { background: var(--hover); }
.hits li span { color: var(--muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* 선 끝점 — 잡아서 다른 칸으로 옮기는 자리다.
   Vue Flow 는 여기에 투명한 원(r=10)만 깔아 둔다. 커서는 바뀌지만 <어디를> 잡아야 하는지
   보이지 않아, 선 위를 더듬게 된다. 그래서 선에 손이 가면 양 끝을 드러낸다.

   ⚠️ r 은 건드리지 않는다. r 을 줄이면 잡는 범위도 같이 줄어, 커서가 옛 범위와 새 범위
      사이에 있을 때 hover 가 켜졌다 꺼졌다 하며 깜빡인다. 색만 바꾼다. */
:deep(.vue-flow__edgeupdater) {
  cursor: grab;
  transition: fill-opacity 0.12s, stroke-opacity 0.12s;
}
:deep(.vue-flow__edge:hover .vue-flow__edgeupdater) {
  fill: var(--accent);
  fill-opacity: 0.14;
  stroke: var(--accent);
  stroke-opacity: 0.55;
  stroke-width: 1.5;
}
/* 끝점에 바로 손이 닿았을 때 — 여기를 놓으면 잡힌다는 뜻이라 또렷하게.
   ⚠️ 선택자를 <선 hover 안의 끝점 hover> 로도 적어야 한다. 끝점만 적으면 위의
      `.vue-flow__edge:hover .vue-flow__edgeupdater` 가 더 구체적이라 이겨서,
      끝점에 손을 올려도 아무 일도 일어나지 않는다. (실제로 밟았다 — 끝점에 손이
      닿는 순간은 선에도 닿아 있는 순간이라, 늘 저쪽 규칙이 먼저 걸린다.) */
:deep(.vue-flow__edge:hover .vue-flow__edgeupdater:hover),
:deep(.vue-flow__edgeupdater:hover) {
  fill-opacity: 0.3;
  stroke-opacity: 1;
  stroke-width: 2;
}
:deep(.vue-flow__edgeupdater:active) { cursor: grabbing; }

/* 선 자체도 손이 가면 굵어진다 — 71줄 사이에서 <지금 가리키는 선> 이 어느 것인지 */
:deep(.vue-flow__edge:hover .vue-flow__edge-path) { stroke-width: 2.6; }

/* 알림 toast — 캔버스 위에 떠 있고 자리를 차지하지 않는다.
   아래 가운데에 둔 까닭: 위쪽은 바·레이어가, 오른쪽 아래는 미니맵이 이미 쓴다. */
.toast {
  position: absolute; left: 50%; bottom: 18px; transform: translateX(-50%);
  z-index: 20; max-width: min(620px, 80%);
  padding: 7px 14px; font-size: 11.5px; line-height: 1.5;
  background: var(--accent); color: var(--on-accent);
  border: 1px solid var(--accent);
  box-shadow: 0 6px 20px var(--shadow);
  pointer-events: none;   /* 그 아래 칸도 그대로 집힌다 */
}
.toast.bad { background: var(--danger); border-color: var(--danger); color: #fff; }
.toast-enter-active, .toast-leave-active { transition: opacity 0.18s, transform 0.18s; }
.toast-enter-from, .toast-leave-to { opacity: 0; transform: translateX(-50%) translateY(6px); }

.flowwrap {
  position: relative; flex: 1; min-height: 0;
  border: 1px solid var(--line); border-top: 0; border-radius: 0; overflow: hidden;
  background: var(--bg);
}

/* 오른쪽 손보기 칸 — 접히고 옮겨진다. 캔버스 위에 겹쳐 두되 <제 크기만큼만> 자리를
   차지한다. Vue Flow 의 Panel 은 캔버스 높이만큼 늘어나 그 아래 칸을 가로막았다. */
.sidecard {
  position: absolute; top: 8px; right: 8px; z-index: 6;
  /* 추가 칸은 입력 셋뿐이라 좁아도 된다 — 넓으면 그 아래 도면을 그만큼 더 가린다 */
  width: 198px; max-height: calc(100% - 16px);
  display: flex; flex-direction: column;
}
/* 상세는 들어옴·나감 조각이 길어 조금 넓게 둔다 */
.sidecard:has(.card.wide) { width: 300px; }

/* 이 화면 안의 단추·입력칸도 각지게. 전역(style.css)은 건드리지 않는다 —
   취향을 밝힌 자리가 이 화면이고, 다른 화면까지 바꾸는 것은 이 요청의 범위가 아니다. */
.wrap :deep(button),
.wrap :deep(input),
.wrap :deep(select),
.wrap :deep(textarea) { border-radius: 0; }

/* 작성 도구 — 캔버스 왼쪽 위. 보기/필터와 쓰는 때가 달라 갈라 두었다.
   줌 컨트롤(왼쪽 아래)과 겹치지 않게 위쪽에 붙인다. */
.toolcard {
  position: absolute; top: 8px; left: 8px; z-index: 6;
  width: 178px; display: flex; flex-direction: column;
}
.toolcard.moving { user-select: none; }

/* 업무항목 — 작성 도구 오른쪽에 붙여 둔다. 둘 다 왼쪽 위라 겹치지 않게 자리를 비켜 준다
   (끌어 옮긴 자리는 이 PC 에 남는다). */
.itemcard {
  position: absolute; top: 8px; left: 194px; z-index: 6;
  /* 표가 된 뒤로는 196px 로는 모자란다 — 코드·이름·표수 세 칸에 단추 둘이 들어간다.
     좁으면 이름 칸이 «거...» 로 뭉개져 목록 구실을 못 한다. 더 넓히려면 모서리를 끈다. */
  width: 304px; max-height: calc(100% - 16px);
  display: flex; flex-direction: column;
}
.itemcard.moving { user-select: none; }

/* 크기 조절 손잡이 — 오른쪽 아래 모서리. 세 레이어가 함께 쓴다.
   각지게 둔다(브라우저가 주는 resize:both 를 안 쓴 까닭은 useLayer 의 resize 주석 참고). */
.rsz {
  position: absolute; right: -1px; bottom: -1px; z-index: 2;
  width: 14px; height: 14px; cursor: nwse-resize;
  background:
    linear-gradient(135deg, transparent 0 48%, var(--line) 48% 60%, transparent 60%),
    linear-gradient(135deg, transparent 0 68%, var(--line) 68% 80%, transparent 80%);
}
.rsz:hover { background:
    linear-gradient(135deg, transparent 0 48%, var(--accent) 48% 60%, transparent 60%),
    linear-gradient(135deg, transparent 0 68%, var(--accent) 68% 80%, transparent 80%); }
.toolcard.sizing, .itemcard.sizing, .sidecard.sizing { user-select: none; }

/* 크기를 정해 주면 머리는 그대로 두고 <본문만> 줄어들며 넘치는 것은 스스로 굴린다.
   min-height:0 이 없으면 flex 칸이 내용만큼 버텨서, 끌어 줄여도 상자가 안 줄어든다. */
.toolcard > .card, .itemcard > .card, .sidecard > .card { min-height: 0; }
.toolcard[style*="height"] > .card,
.itemcard[style*="height"] > .card,
.sidecard[style*="height"] > .card { flex: 1; overflow: auto; }
.itemcard .n { font-size: 10px; color: var(--muted); }
.itemcard .dot { color: var(--accent); font-size: 9px; }
.card.items { overflow: auto; }
.card.items .addrow { display: flex; gap: 4px; margin-bottom: 6px; }
.card.items .addrow input { flex: 1; min-width: 0; padding: 3px 5px; font-size: 11px; }
.card.items .addrow button { flex: none; padding: 3px 7px; font-size: 12px; }
.card.items .none { margin: 2px 0 0; font-size: 10.5px; color: var(--muted); line-height: 1.55; }

/* 업무항목 표 — 코드 · 이름 · 표수 세 칸. 네 자리를 한 벌로 묶어 머리·거르기·줄이
   모두 같은 폭으로 선다. 따로 적으면 한 군데만 고쳐져 칸이 어긋난다. */
.igrid { display: flex; flex-direction: column; min-height: 0; }
.igrid .c-code { flex: 0 0 46px; }
.igrid .c-name { flex: 1 1 auto; min-width: 0; }
.igrid .c-n { flex: 0 0 26px; text-align: right; }
.igrid .c-add { flex: 0 0 20px; }

.ghead, .gfilter { display: flex; align-items: center; gap: 2px; }
.ghead {
  padding: 0 0 3px; font-size: 10px; color: var(--muted); font-weight: 700;
  border-bottom: 1px solid var(--line);
}
.ghead .c-add {
  padding: 0; font-size: 13px; line-height: 1;
  border: 1px solid var(--accent); background: var(--accent-soft); color: var(--accent);
}
.gfilter { padding: 3px 0; }
.gfilter input {
  min-width: 0; padding: 2px 4px; font-size: 10.5px;
  border: 1px solid var(--line); background: var(--bg); color: var(--text);
}
.gfilter input:focus { outline: none; border-color: var(--accent); }
.gfilter .c-n { font-size: 10px; color: var(--muted); }
.gfilter .c-add {
  padding: 0; font-size: 10px; border: 1px solid var(--line);
  background: transparent; color: var(--muted);
}
.gfilter .c-add:disabled { opacity: 0.3; }

/* 몸통만 굴린다 — 머리줄과 거르는 칸은 늘 보여야 한다 */
.gbody { overflow: auto; max-height: 320px; margin-top: 2px; }
.grow { display: flex; align-items: stretch; gap: 2px; margin-bottom: 2px; }
.grow .nm {
  flex: 1; min-width: 0; display: flex; align-items: center; gap: 2px;
  padding: 2px 3px; font-size: 11px; text-align: left;
  border: 1px solid var(--line); background: transparent; color: var(--text);
}
.grow .c-code { font-size: 10px; color: var(--muted); font-weight: 700; }
.grow .c-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.grow .c-n { font-size: 9.5px; color: var(--muted); }
.grow.on .nm { border-color: var(--accent); background: var(--accent-soft); color: var(--accent); font-weight: 600; }
.grow.on .c-code, .grow.on .c-n { color: var(--accent); }
.grow .rn { flex: 1; min-width: 0; padding: 2px 4px; font-size: 11px; }

/* 새 업무항목 창 — DB 찾기 창과 같은 규칙(✕ 로만 닫기) */
.dlg2 {
  width: min(380px, 92vw); padding: 13px 15px 11px;
  background: var(--panel); border: 1px solid var(--line); border-radius: 0;
  box-shadow: 0 10px 30px var(--shadow);
}
.dlg2 h3 { display: flex; align-items: center; margin: 0 0 10px; font-size: 13.5px; }
.dlg2 h3 .x { margin-left: auto; padding: 1px 6px; border-radius: 0; border: 1px solid var(--line); background: transparent; }
.dlg2 label { display: block; font-size: 11px; color: var(--muted); }
.dlg2 label input {
  display: block; width: 100%; box-sizing: border-box; margin-top: 3px; padding: 5px 7px;
  font-size: 12.5px; border-radius: 0; border: 1px solid var(--line);
  background: var(--bg); color: var(--text);
}
.dlg2 .note { margin: 7px 0 11px; font-size: 10.5px; line-height: 1.6; }
.dlg2 .btns { display: flex; gap: 5px; justify-content: flex-end; }
.dlg2 .btns .go { border-color: var(--accent); color: var(--accent); background: var(--accent-soft); }

.ilist { list-style: none; margin: 0; padding: 0; }
.ilist li { display: flex; align-items: stretch; gap: 2px; margin-bottom: 2px; }
.ilist .nm {
  flex: 1; min-width: 0; display: flex; align-items: center; gap: 5px;
  padding: 3px 6px; font-size: 11px; text-align: left;
  border: 1px solid var(--line); background: transparent; color: var(--text);
}
.ilist .nm .t { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ilist .nm .c { flex: none; font-size: 9.5px; color: var(--muted); }
.ilist li.on .nm { border-color: var(--accent); background: var(--accent-soft); color: var(--accent); font-weight: 600; }
.ilist li.on .nm .c { color: var(--accent); }
.ilist .ib {
  flex: none; padding: 0 5px; font-size: 10px;
  border: 1px solid var(--line); background: transparent; color: var(--muted);
}
.ilist .ib:hover { color: var(--text); border-color: var(--muted); }
/* ⚠️ 지우기 단추에 .del 을 쓰지 말 것 — 이 파일 아래쪽의 `.card .del { width: 100% }`
   (상세 카드의 [삭제] 용)가 함께 걸려, 작은 ✕ 가 칸 너비를 통째로 먹는다.
   그러면 옆의 이름 단추가 14px 로 찌그러져 <이름이 안 보이는> 꼴이 된다. (실제로 밟았다.) */
.ilist .ib.rm:hover { color: var(--danger, #b4232a); border-color: var(--danger, #b4232a); }
.ilist .rn { flex: 1; min-width: 0; padding: 3px 5px; font-size: 11px; }

.card.items label.row.ed.on { color: var(--accent); font-weight: 600; }
/* 안내 글. 작성 도구의 .step 은 `.card.tool .step` 으로 묶여 있어 여기까지 오지 않는다 —
   같은 이름을 쓰면서 모양만 안 따라오는 자리라, 여기서 따로 적어 준다. */
.card.items .step {
  margin: 5px 0 0; font-size: 10.5px; font-weight: 600; color: var(--accent); line-height: 1.55;
}
.card.items .hintxt { margin: 4px 0 0; font-size: 10px; color: var(--muted); line-height: 1.5; }

/* 편집모드에서는 흐린 칸도 눌러야 한다 — 0.16 로는 어디 있는지 안 보여 누를 수가 없다 */
.flowwrap :deep(.vue-flow.picking) .tnode.dim { opacity: 0.5; }
.flowwrap :deep(.vue-flow.picking) .vue-flow__node { cursor: copy; }

.toolcard .dot { color: var(--accent); font-size: 9px; }

.card.tool hr { border: 0; border-top: 1px solid var(--line); margin: 9px 0 8px; }
.card.tool .lb { margin: 9px 0 4px; font-size: 10px; color: var(--muted); }
.card.tool .wide { width: 100%; padding: 4px; font-size: 11.5px; margin-bottom: 4px; }
.card.tool .row2 { display: flex; gap: 4px; }
.card.tool .row2 button { flex: 1; padding: 3px; font-size: 11px; }
.autonote { margin: 2px 0 0; font-size: 10px; color: var(--accent); line-height: 1.5; }
.card.tool .step {
  margin: 5px 0 0; font-size: 10.5px; font-weight: 600; color: var(--accent);
  line-height: 1.5; word-break: break-all;
}
.card.tool .kinds { display: flex; flex-wrap: wrap; gap: 3px; }
.card.tool .kbtn { font-size: 10.5px; padding: 2px 7px; }
button.link.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }

/* 위쪽 바의 <저장 안 됨> 알림 — 저장 단추는 왼쪽 도구에 있으므로 여기서는 알리기만 한다 */
.dirty { font-size: 11px; color: var(--accent); font-weight: 600; }
.sidecard.moving { user-select: none; }
.phd {
  display: flex; align-items: center; gap: 6px;
  width: 100%; box-sizing: border-box;
  padding: 5px 8px; font-size: 11.5px;
  background: var(--panel); border: 1px solid var(--line); border-radius: 0;
  box-shadow: 0 6px 20px var(--shadow);
  cursor: move; user-select: none; touch-action: none;
}
/* 상세가 떠 있을 때는 아래 카드가 넓으므로 머리도 함께 넓힌다 */

.phd .grip { color: var(--muted-3); font-size: 11px; letter-spacing: -2px; }
.phd .pt { font-size: 11.5px; }
.phd .gap { flex: 1; }
.pbtn { border: 0; background: none; color: var(--muted); font-size: 11px; padding: 1px 5px; cursor: pointer; }
.pbtn:hover { color: var(--accent); }
.pbtn:disabled { opacity: .45; cursor: default; }
.pbtn:disabled:hover { color: var(--muted); }
/* 다시 읽는 동안 ↻ 를 돌린다 — 목록이 그대로일 때도 <눌리긴 했다> 가 보여야 한다 */
.pbtn.spin.busy { animation: pbtn-spin .7s linear infinite; }
@keyframes pbtn-spin { to { transform: rotate(360deg); } }
@media (prefers-reduced-motion: reduce) { .pbtn.spin.busy { animation: none; } }
.sidecard .card { margin-top: 5px; }
.card {
  width: 100%; box-sizing: border-box; padding: 9px 10px; font-size: 11.5px;
  background: var(--panel); border: 1px solid var(--line); border-radius: 0;
  box-shadow: 0 6px 20px var(--shadow);
}
.chd { font-weight: 600; margin-bottom: 7px; display: flex; align-items: center; }
.chd .x { margin-left: auto; cursor: pointer; color: var(--muted); }
.chd .x:hover { color: var(--text); }
.card label { display: block; margin-bottom: 6px; font-size: 10.5px; color: var(--muted); }
.card label.row { display: flex; align-items: center; gap: 5px; color: var(--text); }
.card input, .card select, .card textarea {
  width: 100%; font-size: 11.5px; padding: 3px 6px; margin-top: 2px;
}
.card label.row input { width: auto; margin: 0; }
.card .ends { margin: 0 0 7px; font-size: 11px; color: var(--muted); }
.card .del {
  width: 100%; margin-top: 4px; font-size: 11px; padding: 3px;
  color: var(--danger-text); border-color: var(--danger-line);
}
.card .del:hover { background: var(--danger-soft); border-color: var(--danger); }
.card .go { width: 100%; margin-top: 2px; padding: 4px; }
.card .tiny { margin: 8px 0 0; font-size: 10.5px; color: var(--muted); line-height: 1.6; }
.card .find2 { width: 100%; margin-top: 5px; padding: 4px; font-size: 11px; }
.card .find2:hover { border-color: var(--accent); color: var(--accent); }

/* DB 에서 찾기 창 — 다른 창들과 같은 규칙(바깥을 눌러도 닫히지 않음 · ✕ · Esc)을 따른다.
   다만 이 창은 <고르고 버리는> 자리라 바깥 클릭으로 닫아도 잃을 것이 없어 열어 두었다. */
.mask {
  position: fixed; inset: 0; z-index: 90; background: var(--overlay);
  display: flex; align-items: flex-start; justify-content: center; padding: 56px 20px;
}
.dlg {
  width: min(880px, 100%); max-height: calc(100vh - 112px);
  display: flex; flex-direction: column; overflow: hidden;
  background: var(--panel); border: 1px solid var(--line); border-radius: 0;
  box-shadow: 0 8px 28px var(--shadow);
}
/* 무엇을 찾는가 — 표냐 프로시저냐. 창을 둘로 나누지 않고 여기서 가른다. */
.tabs2 { display: flex; gap: 3px; }
.tabs2 button { font-size: 11px; padding: 3px 9px; }
.tabs2 button.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }

.dlg header, .dlg footer, .pbar {
  display: flex; align-items: center; gap: 7px; padding: 9px 12px; flex: none; flex-wrap: wrap;
}
/* 머리를 잡아 옮긴다. 단추·입력칸 위에서는 글자 고르기 금지를 풀어 둔다 —
   머리 전체를 user-select:none 으로 덮으면 스키마 칸의 글자를 못 고른다. */
.dlg header { border-bottom: 1px solid var(--line); cursor: move; user-select: none; }
.dlg header input { cursor: auto; user-select: auto; }
.dlg header .grip { color: var(--muted); font-size: 11px; cursor: move; }
.dlg.moving { user-select: none; }
.dlg footer { border-top: 1px solid var(--line); }
.pbar { border-bottom: 1px solid var(--line); }
.pbar input[type='search'] { min-width: 230px; }
.dlg .x { border: 0; background: none; font-size: 14px; color: var(--muted); padding: 2px 6px; }
.dlg .x:hover { color: var(--text); }
.sm { font-size: 10.5px; color: var(--muted); display: flex; align-items: center; gap: 4px; }
.perr {
  margin: 0; padding: 6px 12px; font-size: 11.5px;
  background: var(--danger-soft); color: var(--danger-text); border-bottom: 1px solid var(--danger-line);
}
.plist { flex: 1; min-height: 0; overflow: auto; }
.plist table { border-collapse: collapse; width: 100%; font-size: 11.5px; }
.plist th, .plist td { border-bottom: 1px solid var(--line); padding: 3px 8px; text-align: left; }
.plist th {
  position: sticky; top: 0; z-index: 1; background: var(--panel);
  color: var(--muted); font-weight: 600; font-size: 11px;
}
.plist .w1 { width: 28px; }
.plist .num { text-align: right; font-variant-numeric: tabular-nums; }
.plist .mono { font-variant-numeric: tabular-nums; white-space: nowrap; }
.plist tbody tr { cursor: pointer; }
.plist tbody tr:hover { background: var(--hover); }
.plist tbody tr.on { background: var(--accent-soft); }
/* 이미 놓인 것 — 숨기지 않고 <있다> 고 알려 준다. 안 보이면 왜 없는지 찾게 된다. */
.plist tbody tr.already { color: var(--muted-3); cursor: default; }
.plist tbody tr.already:hover { background: none; }
.tagp {
  margin-left: 6px; font-size: 9.5px; padding: 0 5px;
  border: 1px solid var(--line); color: var(--muted);
}
.pempty { text-align: center; color: var(--muted); padding: 22px; }

/* 상세 — 읽는 자리라 조금 넓게, 길어지면 안에서 구른다 */
.card.wide { max-height: calc(100vh - 230px); overflow: auto; }
.ttl2 { font-size: 12.5px; font-weight: 700; }
.sub { margin: 0 0 9px; font-size: 10.5px; color: var(--muted); }
.sub b { color: var(--text); font-weight: 600; }

.kv { display: grid; grid-template-columns: 58px 1fr; gap: 4px 8px; margin: 0; font-size: 11px; }
.kv dt { color: var(--muted); font-size: 10.5px; padding-top: 2px; }
.kv dd { margin: 0; }
.kv .mono { font-variant-numeric: tabular-nums; word-break: break-all; }
.kv .none { color: var(--muted-3); font-size: 10.5px; }
.trgtext { font-size: 10.5px; color: var(--muted); line-height: 1.6; word-break: break-all; }

/* 들어옴·나감 조각 — 누르면 그 칸으로 간다. 선을 눈으로 좇지 않아도 된다 */
.chips { display: flex; flex-wrap: wrap; gap: 3px; }
.chips span {
  font-size: 10px; padding: 1px 6px; cursor: pointer;
  border: 1px solid var(--line); color: var(--muted); background: var(--bg);
  max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.chips span:hover { border-color: var(--accent); color: var(--accent); }
.chips span em { font-style: normal; color: var(--muted-3); }
.chips span b.go2 { font-weight: 600; cursor: pointer; }
.chips span b.go2:hover { text-decoration: underline; }
/* 조각 안의 작은 손잡이 — 평소엔 흐리고 조각에 손이 가면 드러난다.
   늘 또렷하면 조각 글씨보다 단추가 먼저 눈에 든다. */
.chips span i.ed, .chips span i.rm {
  font-style: normal; margin-left: 4px; opacity: 0; cursor: pointer; font-size: 9.5px;
}
.chips span:hover i.ed, .chips span:hover i.rm { opacity: 0.75; }
.chips span i.ed:hover { opacity: 1; color: var(--accent); }
.chips span i.rm:hover { opacity: 1; color: var(--danger-text); }
.card .wide2 { width: 100%; margin-top: 6px; font-size: 11px; padding: 3px; }
.card .ports { display: flex; gap: 6px; }
.card .ports label { flex: 1; }
.chips span.trigger { border-color: var(--danger-line); color: var(--danger-text); }
.chips span.batch { border-color: var(--done-line); color: var(--done); }
.chips span.ext { border-color: #6A4FBF; color: #6A4FBF; }
.chips.plain span { cursor: default; }
.chips.plain span:hover { border-color: var(--line); color: var(--muted); }
.chips span.trg { border-color: var(--danger-line); color: var(--danger-text); }
.chips span.bat { border-color: var(--done-line); color: var(--done); }

.note2 { margin: 9px 0 0; font-size: 10.5px; color: var(--muted); line-height: 1.65; }
.warnbox {
  margin-top: 8px; padding: 5px 8px; font-size: 10.5px; line-height: 1.6;
  background: var(--danger-soft); border: 1px solid var(--danger-line); color: var(--danger-text);
}
.edit { margin-top: 10px; border-top: 1px solid var(--line); padding-top: 7px; }
.edit summary { font-size: 10.5px; color: var(--muted); cursor: pointer; }
.edit summary:hover { color: var(--accent); }
.edit label { margin-top: 6px; }
</style>
