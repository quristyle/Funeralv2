<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { api } from '../api'
import { state, useViewRefresh } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'

// pmm001~018 의 -be / -fe 프로젝트에서 가장 최근 Job 상태를 모아 한 화면에 보여준다.
const data = ref({ configured: false, rows: [], loadedAt: null })
const loading = ref(false)
const auto = ref(0) // 자동 새로고침 주기(초). 0 = 끔
let timer = null

const STATUS = {
  success: { label: '성공', cls: 'ok' },
  failed: { label: '실패', cls: 'ng' },
  running: { label: '실행중', cls: 'run' },
  pending: { label: '대기', cls: 'wait' },
  created: { label: '생성됨', cls: 'wait' },
  canceled: { label: '취소', cls: 'off' },
  skipped: { label: '건너뜀', cls: 'off' },
  manual: { label: '수동', cls: 'man' },
  none: { label: 'Job 없음', cls: 'off' },
}
const st = (s) => STATUS[s] ?? { label: s || '-', cls: 'off' }

async function load(force = true) {
  loading.value = true
  try {
    data.value = await api.ciStatus(force)
  } catch (e) {
    state.error = e.message
  } finally {
    loading.value = false
  }
}

// 모듈 행 × (BE/FE) 열 매트릭스
const matrix = computed(() => {
  const m = new Map()
  for (const r of data.value.rows ?? []) {
    const row = m.get(r.module) ?? { module: r.module, be: null, fe: null }
    row[r.kind] = r
    m.set(r.module, row)
  }
  return [...m.values()].sort((a, b) => a.module.localeCompare(b.module))
})

const counts = computed(() => {
  const c = {}
  for (const r of data.value.rows ?? []) {
    const k = r.error ? 'error' : r.status || 'none'
    c[k] = (c[k] ?? 0) + 1
  }
  return c
})
const total = computed(() => (data.value.rows ?? []).length)

// 실패·실행중만 모아 보기
const attention = computed(() =>
  (data.value.rows ?? []).filter((r) => r.error || ['failed', 'running', 'pending'].includes(r.status))
)

const when = (r) => {
  const t = r.finished_at || r.started_at || r.created_at
  if (!t) return ''
  const d = new Date(t)
  const min = Math.floor((Date.now() - d.getTime()) / 60000)
  if (min < 1) return '방금'
  if (min < 60) return `${min}분 전`
  if (min < 60 * 24) return `${Math.floor(min / 60)}시간 전`
  return d.toLocaleDateString('ko-KR')
}
const dur = (r) => (r?.duration == null ? '' : `${Math.round(r.duration)}s`)

// 칸에 마우스를 올렸을 때 보여줄 상세
const tip = (j) =>
  [
    j.path,
    j.error ? '오류: ' + j.error : '상태: ' + st(j.status).label,
    j.job_name ? 'Job: ' + j.job_name : '',
    j.ref ? '브랜치: ' + j.ref : '',
    j.commit_id ? '커밋: ' + j.commit_id + (j.commit_title ? ' ' + j.commit_title : '') : '',
    j.user_name || j.commit_author ? '실행: ' + (j.user_name || j.commit_author) : '',
    j.finished_at ? '종료: ' + new Date(j.finished_at).toLocaleString('ko-KR') : '',
  ]
    .filter(Boolean)
    .join('\n')

const dense = ref(false) // 조밀 모드 — 브랜치·커밋 줄을 숨겨 더 많은 행을 한눈에

// 세로가 길어지지 않도록 좌/우 두 덩어리로 나눠 배치 (PMM001~009 | PMM010~018)
const split = ref(true)
const groups = computed(() => {
  if (!split.value) return [matrix.value]
  const half = Math.ceil(matrix.value.length / 2)
  return [matrix.value.slice(0, half), matrix.value.slice(half)]
})

function setAuto(sec) {
  auto.value = sec
  if (timer) clearInterval(timer)
  timer = sec ? setInterval(() => load(true), sec * 1000) : null
}

useViewRefresh(() => load(true))
onMounted(() => load(false))
onUnmounted(() => timer && clearInterval(timer))
</script>

<template>
  <div class="topbar">
    <span class="hint">
      {{ data.group }} · {{ total }}개 프로젝트
      <template v-if="data.loadedAt"> · 마지막 갱신 {{ data.loadedAt }}</template>
      <template v-if="loading"> · 조회 중…</template>
    </span>
    <span class="spacer"></span>
    <span class="hint">자동</span>
    <select :value="auto" @change="setAuto(Number($event.target.value))">
      <option :value="0">끔</option>
      <option :value="30">30초</option>
      <option :value="60">1분</option>
      <option :value="300">5분</option>
    </select>
    <RefreshBtn :fn="() => load(true)" label="전체 새로고침" />
  </div>

  <!-- 토큰 미설정 안내 -->
  <section v-if="!data.configured" class="panel setup">
    <h2>GitLab 토큰이 설정되지 않았습니다</h2>
    <p class="muted">
      빌드 상태를 읽으려면 조회 전용 토큰이 필요합니다. 아래 순서로 한 번만 설정하면 됩니다.
    </p>
    <ol>
      <li>
        GitLab → 우측 상단 프로필 →
        <strong>Preferences → Access Tokens</strong> 에서 토큰 생성
        (scope: <code>read_api</code> 만 체크, 만료일은 넉넉히)
      </li>
      <li>
        서버의 <code>D:\수빅자재\wbsproj\api\appsettings.json</code> 에서
        <code>Gitlab.Token</code> 값에 붙여넣기
        <pre>"Gitlab": {
  "BaseUrl": "https://code.hd.com",
  "Group": "g6x0/xu62/material-management",
  "Token": "glpat-여기에붙여넣기"
}</pre>
      </li>
      <li>API 재시작 (<code>serve.cmd</code> 또는 <code>start.cmd</code>) 후 이 화면 새로고침</li>
    </ol>
    <p class="muted">
      토큰 없이도 아래 표의 프로젝트명을 클릭하면 GitLab Jobs 화면으로 바로 이동합니다.
    </p>
  </section>

  <!-- 상태 요약 -->
  <div v-if="data.configured" class="cards">
    <div class="card"><div class="k">전체</div><div class="v">{{ total }}</div></div>
    <div class="card"><div class="k">성공</div><div class="v ok">{{ counts.success ?? 0 }}</div></div>
    <div class="card"><div class="k">실패</div><div class="v ng">{{ counts.failed ?? 0 }}</div></div>
    <div class="card"><div class="k">실행중</div><div class="v run">{{ counts.running ?? 0 }}</div></div>
    <div class="card"><div class="k">대기</div><div class="v">{{ (counts.pending ?? 0) + (counts.created ?? 0) }}</div></div>
    <div class="card"><div class="k">Job 없음 · 오류</div><div class="v">{{ (counts.none ?? 0) + (counts.error ?? 0) }}</div></div>
  </div>

  <!-- 주의 대상 -->
  <section v-if="data.configured && attention.length" class="panel">
    <h2>확인 필요 <span class="hint">실패 · 실행중 · 대기 · 오류 {{ attention.length }}건</span></h2>
    <div class="scroll">
      <table>
        <thead>
          <tr>
            <th>프로젝트</th><th>상태</th><th>Job</th><th>브랜치</th>
            <th>커밋</th><th>실행자</th><th>시각</th><th class="num">소요</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in attention" :key="r.path">
            <td class="nowrap">
              <a :href="r.jobs_url" target="_blank" rel="noopener">{{ r.module }}-{{ r.kind }}</a>
            </td>
            <td><span class="badge" :class="st(r.error ? 'x' : r.status).cls">{{ r.error || st(r.status).label }}</span></td>
            <td class="nowrap muted">{{ r.job_name || '' }}</td>
            <td class="nowrap muted">{{ r.ref || '' }}</td>
            <td class="nowrap" :title="r.commit_title || ''">{{ r.commit_id || '' }}</td>
            <td class="nowrap muted">{{ r.user_name || r.commit_author || '' }}</td>
            <td class="nowrap muted">{{ when(r) }}</td>
            <td class="num muted">{{ dur(r) }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <!-- 전체 매트릭스: 모듈 × (BE, FE) × (현재 상태, 최근 성공) -->
  <section class="panel">
    <h2>
      모듈별 Job 상태
      <span class="hint">현재 = 가장 최근 Job · 최근 성공 = 마지막으로 성공한 Job · 클릭 시 새 탭</span>
      <span class="spacer"></span>
      <label class="chk2"><input v-model="split" type="checkbox" /> 좌우 2단</label>
      <label class="chk2"><input v-model="dense" type="checkbox" /> 조밀하게</label>
    </h2>

    <div class="split" :class="{ one: !split }">
      <div v-for="(g, gi) in groups" :key="gi" class="scroll">
      <table class="mx" :class="{ dense }">
        <thead>
          <tr>
            <th rowspan="2" class="mod">모듈</th>
            <th colspan="2" class="grp be">Backend</th>
            <th colspan="2" class="grp fe">Frontend</th>
          </tr>
          <tr>
            <th>현재</th><th>최근 성공</th>
            <th>현재</th><th>최근 성공</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="m in g" :key="m.module">
            <td class="mod">{{ m.module }}</td>

            <template v-for="k in ['be', 'fe']" :key="k">
              <!-- 현재 상태 -->
              <td class="cell">
                <a
                  v-if="m[k]"
                  :href="m[k].job_url || m[k].jobs_url"
                  target="_blank" rel="noopener"
                  class="box" :class="st(m[k].error ? 'x' : m[k].status).cls"
                  :title="tip(m[k])"
                >
                  <span class="s">{{ m[k].error ? '오류' : st(m[k].status).label }}</span>
                  <span class="d">{{ when(m[k]) }}{{ dur(m[k]) ? ' · ' + dur(m[k]) : '' }}</span>
                  <span v-if="!dense" class="c">{{ m[k].ref }}{{ m[k].commit_id ? ' · ' + m[k].commit_id : '' }}</span>
                </a>
                <span v-else class="muted">—</span>
              </td>

              <!-- 최근 성공 -->
              <td class="cell">
                <a
                  v-if="m[k]?.last_success"
                  :href="m[k].last_success.job_url || m[k].jobs_url"
                  target="_blank" rel="noopener"
                  class="box ok" :class="{ same: m[k].job_id === m[k].last_success.job_id }"
                  :title="tip(m[k].last_success)"
                >
                  <span class="s">
                    {{ m[k].job_id === m[k].last_success.job_id ? '현재와 동일' : '성공' }}
                  </span>
                  <span class="d">
                    {{ when(m[k].last_success) }}{{ dur(m[k].last_success) ? ' · ' + dur(m[k].last_success) : '' }}
                  </span>
                  <span v-if="!dense" class="c">
                    {{ m[k].last_success.ref }}{{ m[k].last_success.commit_id ? ' · ' + m[k].last_success.commit_id : '' }}
                  </span>
                </a>
                <span v-else-if="m[k] && !m[k].error" class="none">성공 이력 없음</span>
                <span v-else class="muted">—</span>
              </td>
            </template>
          </tr>
          <tr v-if="!g.length">
            <td colspan="5" class="muted ctr" style="padding: 20px">
              {{ loading ? '조회 중…' : '표시할 프로젝트가 없습니다.' }}
            </td>
          </tr>
        </tbody>
      </table>
      </div>
    </div>
    <p class="muted note">
      각 프로젝트마다 <strong>가장 최근 Job</strong> 과 <strong>마지막 성공 Job</strong> 을 GitLab API 로 읽어옵니다
      (프로젝트당 2회 · 총 {{ total * 2 }}회 조회). 서버에서 {{ data.baseUrl }} 로 직접 조회하며 결과는 60초간 캐시됩니다.
    </p>
  </section>
</template>

<style scoped>
.topbar {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
  padding: 7px 12px;
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 8px;
}
.topbar .spacer { flex: 1; }
.topbar .hint { font-size: 12px; color: var(--muted); }
h2 .spacer { flex: 1; }
.nowrap { white-space: nowrap; }
.ctr { text-align: center; }
.note { margin: 8px 0 0; }
.chk2 { font-size: 11.5px; color: var(--muted); display: flex; align-items: center; gap: 4px; cursor: pointer; }
.chk2 input { cursor: pointer; }

.setup ol { margin: 10px 0 0; padding-left: 20px; font-size: 12.5px; line-height: 1.9; }
.setup pre {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 4px;
  padding: 8px 10px;
  margin: 6px 0;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 11.5px;
  line-height: 1.5;
}

.card .v.ok { color: var(--done); }
.card .v.ng { color: var(--danger); }
.card .v.run { color: var(--accent); }

/* 상태 배지 / 매트릭스 칸 */
.badge {
  display: inline-block;
  padding: 1px 8px;
  border-radius: 10px;
  font-size: 11px;
  font-weight: 600;
  white-space: nowrap;
}
/* 세로가 길어지지 않도록 좌우 2단 배치 (좁은 화면에서는 1단) */
.split { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 14px; }
.split.one { grid-template-columns: minmax(0, 1fr); }
@media (max-width: 1200px) {
  .split { grid-template-columns: minmax(0, 1fr); }
}

/* 가로 폭을 모두 사용 — 4개 상태 칸이 균등하게 늘어난다 */
.mx { width: 100%; table-layout: fixed; }
.mx th.mod, .mx td.mod { width: 78px; font-weight: 600; white-space: nowrap; }
.mx th.grp { text-align: center; font-size: 11px; letter-spacing: 0.3px; }
.mx th.grp.be { background: var(--hover); }
.mx th.grp.fe { background: var(--violet-soft); }
.mx thead tr:nth-child(2) th { text-align: center; font-weight: 400; font-size: 11px; }
.mx .cell { padding: 3px 4px; }
.mx .none { font-size: 11px; color: var(--muted); padding-left: 4px; }

.box {
  display: flex;
  flex-direction: column;
  gap: 1px;
  padding: 5px 9px;
  border-radius: 6px;
  border: 1px solid var(--line);
  text-decoration: none;
  line-height: 1.25;
  overflow: hidden;
}
.box .s { font-size: 11.5px; font-weight: 600; }
.box .d { font-size: 10.5px; opacity: 0.75; }
.box .c {
  font-size: 10px;
  opacity: 0.6;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.box:hover { outline: 2px solid var(--accent); outline-offset: -2px; }
/* 최근 성공이 현재 Job 과 같은 경우는 톤을 낮춰 중복 강조를 피한다 */
.box.same { background: var(--done-soft); color: var(--done); border-color: var(--done-line); }

.mx.dense .box { padding: 3px 8px; }
.mx.dense .box .s { font-size: 11px; }

.ok, .box.ok { background: var(--done-soft); border-color: var(--done); color: var(--done); }
.ng, .box.ng { background: var(--danger-soft); border-color: var(--danger-line); color: var(--danger-text); }
.run, .box.run { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); }
.wait, .box.wait { background: var(--warn-soft); border-color: var(--warn-line); color: var(--warn); }
.man, .box.man { background: var(--violet-soft); border-color: var(--violet-line); color: var(--violet); }
.off, .box.off { background: var(--surface); border-color: var(--line); color: var(--muted); }
.x, .box.x { background: var(--danger-soft); border-color: var(--danger-line); color: var(--danger-text); }
</style>
