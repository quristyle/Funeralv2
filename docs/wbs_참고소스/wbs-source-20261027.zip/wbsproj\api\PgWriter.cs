using System.Buffers.Binary;
using System.Text;

namespace WbsApi;

/// <summary>PostgreSQL 메시지 페이로드용 빅엔디언 버퍼 작성기.</summary>
public sealed class PgWriter
{
    private byte[] _buf = new byte[256];
    private int _pos;

    private void Need(int n)
    {
        if (_pos + n <= _buf.Length) return;
        var cap = _buf.Length;
        while (cap < _pos + n) cap *= 2;
        Array.Resize(ref _buf, cap);
    }

    public void Byte(byte b) { Need(1); _buf[_pos++] = b; }

    public void Int16(short v) { Need(2); BinaryPrimitives.WriteInt16BigEndian(_buf.AsSpan(_pos), v); _pos += 2; }

    public void Int32(int v) { Need(4); BinaryPrimitives.WriteInt32BigEndian(_buf.AsSpan(_pos), v); _pos += 4; }

    public void Raw(ReadOnlySpan<byte> b) { Need(b.Length); b.CopyTo(_buf.AsSpan(_pos)); _pos += b.Length; }

    /// <summary>널 종료 문자열.</summary>
    public void Str(string s)
    {
        var n = Encoding.UTF8.GetByteCount(s);
        Need(n + 1);
        Encoding.UTF8.GetBytes(s, _buf.AsSpan(_pos));
        _pos += n;
        _buf[_pos++] = 0;
    }

    public byte[] ToArray() => _buf.AsSpan(0, _pos).ToArray();
}
