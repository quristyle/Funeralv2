<script setup>
import { computed, onMounted, ref } from 'vue'
import { api } from '../api'
import PvDialog from '../components/PvDialog.vue'
import { buildPvFlowScript, buildPvRecordScript } from '../pvFlow'

// ProjectView 워크플로(task-nodes)의 빈 일자·담당자를 채우는 화면.
//
// 왜 스크립트인가 — task-nodes 저장은 PUT + JSON 본문이라 CORS 프리플라이트가 도는데
// ProjectView 가 OPTIONS 에 405 를 준다. Export 내려받기처럼 대시보드에서 직접 부를 수 없어,
// 진척률·실적시작일 전송과 같은 방식(ProjectView 탭 콘솔 실행)을 쓴다.

const template = ref('AAC-A1022')   // 일자·담당자가 모두 채워진 학습용 액티비티
const defaultNm = ref('이순열')     // 기본 담당자
const stageRule = ref('PI검토=김선아') // 단계별 담당자 (쉼표로 여러 개)
const skipStages = ref('완료')      // 아예 건드리지 않을 단계

/** 'PI검토=김선아, 완료=홍길동' → { 'PI검토': '김선아', 완료: '홍길동' } */
function parseRule(t) {
  const out = {}
  for (const part of String(t).split(',')) {
    const i = part.indexOf('=')
    if (i < 0) continue
    const k = part.slice(0, i).trim()
    const v = part.slice(i + 1).trim()
    if (k && v) out[k] = v
  }
  return out
}

const codes = ref([])
const err = ref('')
const script = ref('')
const scriptTitle = ref('')
const scriptMeta = ref('')
const raw = ref('')                 // 붙여넣은 결과 JSON
const rep = ref(null)

async function loadCodes() {
  err.value = ''
  try {
    const rows = await api.rows({ scope: 'all', limit: 5000 })
    codes.value = [...new Set(rows.map((r) => r.activity_id).filter(Boolean))].sort()
  } catch (e) {
    err.value = e.message
  }
}

function openRecord() {
  scriptTitle.value = 'ProjectView 요청 녹화 스크립트'
  scriptMeta.value = '읽기 전용 · 워크플로 조회 요청을 잡아낸다'
  script.value = buildPvRecordScript(new Date().toLocaleString('ko-KR'))
}

function openScript() {
  if (!codes.value.length) {
    err.value = '액티비티 목록을 읽지 못했습니다.'
    return
  }
  scriptTitle.value = 'ProjectView 워크플로 채우기 스크립트'
  scriptMeta.value =
    '액티비티 ' + codes.value.length + '건 · 기본 ' + defaultNm.value + ' · ' + stageRule.value
  script.value = buildPvFlowScript(
    codes.value,
    template.value.trim() || 'AAC-A1022',
    defaultNm.value.trim() || '이순열',
    parseRule(stageRule.value),
    skipStages.value.split(',').map((x) => x.trim()).filter(Boolean),
    new Date().toLocaleString('ko-KR')
  )
}

/** 콘솔 출력을 통째로 붙여넣어도 JSON 객체만 골라낸다 */
function readReport() {
  err.value = ''
  rep.value = null
  try {
    const t = raw.value.trim()
    if (!t) throw new Error('붙여넣은 내용이 없습니다.')
    const s = t.indexOf('{')
    const e = t.lastIndexOf('}')
    if (s < 0 || e < s) throw new Error('JSON 을 찾지 못했습니다.')
    const o = JSON.parse(t.slice(s, e + 1))
    if (!o.template || !o.plan) throw new Error('워크플로 결과 JSON 이 아닙니다.')
    rep.value = o
  } catch (x) {
    err.value = x.message
  }
}

const sampleKeys = computed(() =>
  rep.value?.template?.sampleNode ? Object.keys(rep.value.template.sampleNode) : []
)
const chargerPairs = computed(() => {
  const v = rep.value?.template?.workerIds ?? {}
  return Object.keys(v).map((k) => ({ k, v: typeof v[k] === 'object' ? JSON.stringify(v[k]) : String(v[k]) }))
})
const short = (v) => {
  const s = typeof v === 'object' ? JSON.stringify(v) : String(v ?? '')
  return s.length > 40 ? s.slice(0, 40) + '…' : s
}

onMounted(loadCodes)
</script>

<template>
  <div class="topbar">
    <span class="hint">
      ProjectView 액티비티 → 일감 → <strong>워크플로 노드</strong>의 비어 있는 일자·담당자를 채웁니다.
      일자는 그 일감의 <strong>완료일</strong>, 담당자는 <strong>{{ stageRule }}</strong> · 그 밖의 단계는 <strong>{{ defaultNm }}</strong> 이고,
      <strong>{{ skipStages }}</strong> 단계는 비워 둡니다.
    </span>
  </div>

  <p v-if="err" class="errbox">{{ err }}</p>

  <!-- 1) 스크립트 만들기 -->
  <section class="panel">
    <h2>
      <span class="step">1</span> 스크립트 만들기
      <span class="hint">대상 액티비티 {{ codes.length }}건 (대시보드 전체)</span>
      <span class="spacer"></span>
      <button title="워크플로를 읽어 오는 요청이 무엇인지 잡아내는 진단용 스크립트" @click="openRecord">요청 녹화 스크립트</button>
      <button class="pv" :disabled="!codes.length" @click="openScript">스크립트 만들기</button>
    </h2>

    <div class="opts">
      <label class="fld">
        <span>학습 액티비티</span>
        <input v-model="template" size="12" />
      </label>
      <label class="fld">
        <span>기본 담당자</span>
        <input v-model="defaultNm" size="8" />
      </label>
      <label class="fld">
        <span>단계별 담당자</span>
        <input v-model="stageRule" size="22" placeholder="PI검토=김선아" />
      </label>
      <label class="fld">
        <span>건드리지 않을 단계</span>
        <input v-model="skipStages" size="14" placeholder="완료" />
      </label>
    </div>

    <p class="muted note">
      워크플로 노드에는 <strong>담당자 이름이 없고 <code>workerId</code>(USR-…) 만</strong> 들어 있습니다.
      그래서 스크립트가 프로젝트 사용자 목록에서 이름으로 id 를 찾아 넣습니다 —
      이름을 추측하거나 학습 액티비티에서 가장 많은 값을 베끼지 않습니다.
      (학습 액티비티는 단계마다 담당자가 다르므로 그 방식은 엉뚱한 사람이 들어갑니다.)
      채울 <strong>필드 이름</strong>은 <code>{{ template }}</code> 의 워크플로를 읽어
      <em>“거기엔 값이 있고 대상엔 비어 있는 키”</em> 로 알아냅니다.
      일자는 그중 <strong>계획 완료일 키만</strong> 채우고 시작일·실적일자는 건드리지 않습니다.
      <strong>{{ skipStages }}</strong> 단계의 노드는 일자·담당자 모두 손대지 않습니다.
    </p>
    <p class="muted note warn">
      안전장치 — <strong>빈 값만</strong> 채웁니다(덮어쓰기 없음) · 일감의 계획일자는 바꾸지 않습니다
      (<code>isChangePlanDate=false</code>) · 완료일이 없는 일감은 건너뜁니다 ·
      붙여넣어 실행하면 <strong>확인만</strong> 하고, 콘솔에 <code>pvSend()</code> 를 입력해야 저장됩니다.
      첫 실행은 스크립트의 <code>MAX_TASKS</code> 를 <code>1</code> 로 바꿔 한 건만 반영해 보세요.
    </p>
    <p class="muted note">
      읽기는 일감 상세 조회(<code>DTS_PST_00052</code>), 저장은 <code>task-nodes</code>(<code>DTS_PST_00063</code>) 를 씁니다.
      <code>task-nodes</code> 는 저장 전용이라 GET 하면 405 입니다.
      ProjectView 에 로그인만 되어 있으면 어느 화면에서 실행해도 됩니다.
    </p>
  </section>

  <!-- 2) 결과 확인 -->
  <section class="panel">
    <h2>
      <span class="step">2</span> 결과 확인
      <span class="hint">콘솔 실행 결과가 클립보드에 복사됩니다 — 여기에 붙여넣으세요</span>
      <span class="spacer"></span>
      <button :disabled="!raw.trim()" @click="readReport">읽기</button>
    </h2>

    <textarea
      v-model="raw"
      class="paste"
      spellcheck="false"
      placeholder='{"stamp":"...","template":{...},"plan":[...]}  — 콘솔 출력을 통째로 붙여넣어도 됩니다'
    ></textarea>

    <template v-if="rep">
      <div class="cards">
        <div class="card"><div class="k">대상 액티비티</div><div class="v">{{ rep.scope.activities }}</div></div>
        <div class="card"><div class="k">읽은 일감</div><div class="v">{{ rep.scope.tasksRead }}</div></div>
        <div class="card"><div class="k">읽은 노드</div><div class="v">{{ rep.scope.nodesRead }}</div></div>
        <div class="card hi"><div class="k">채울 일감</div><div class="v">{{ rep.totals.tasks }}</div></div>
        <div class="card hi"><div class="k">채울 노드</div><div class="v">{{ rep.totals.nodes }}</div></div>
        <div class="card"><div class="k">제외 단계 노드</div><div class="v">{{ rep.totals.skippedNodes ?? 0 }}</div></div>
      </div>

      <h3>학습 결과 — {{ rep.template.code }} (일감 {{ rep.template.tasks }}건 · 노드 {{ rep.template.nodes }}개)</h3>
      <p v-if="rep.nodeSource" class="muted note src">
        워크플로 조회 경로 —
        <code>{{ rep.nodeSource.url }}</code>
        <span class="muted"> (dataServiceId={{ rep.nodeSource.dts }} · {{ rep.nodeSource.tried }}건 시험 후 성공 · 저장은 <code>DTS_PST_00063</code>)</span>
      </p>
      <div class="two">
        <div>
          <p class="lbl">일자로 판단한 키</p>
          <table v-if="rep.template.dateKeys?.length">
            <thead><tr><th>키</th><th>학습 예시</th><th>완료일과 일치</th><th class="num">대상 빈 노드</th></tr></thead>
            <tbody>
              <tr v-for="d in rep.template.dateKeys" :key="d.키">
                <td><code>{{ d.키 }}</code></td><td>{{ d.학습예시 }}</td>
                <td>{{ d.완료일과일치 }}</td><td class="num">{{ d.대상빈노드 }}</td>
              </tr>
            </tbody>
          </table>
          <p v-else class="muted note bad">일자 키를 찾지 못했습니다.</p>
        </div>
        <div>
          <p class="lbl">담당자로 판단한 키</p>
          <table v-if="rep.template.chargerKeys?.length">
            <thead><tr><th>키</th><th>칸</th><th>채울 규칙</th><th class="num">대상 빈 노드</th></tr></thead>
            <tbody>
              <tr v-for="m in rep.template.chargerKeys" :key="m.키">
                <td><code>{{ m.키 }}</code></td><td>{{ m.칸 }}</td>
                <td>{{ m.채울규칙 }}</td>
                <td class="num">{{ m.대상빈노드 }}</td>
              </tr>
            </tbody>
          </table>
          <p v-else class="muted note bad">담당자 키를 찾지 못했습니다.</p>
        </div>
      </div>

      <p v-if="rep.template.dateSkipped?.length" class="muted note warn">
        완료일이 아니어서 건드리지 않는 일자 키: <code>{{ rep.template.dateSkipped.join(', ') }}</code>
      </p>
      <p class="muted note">
        <strong>담당자 id</strong> —
        <template v-for="c in chargerPairs" :key="c.k"><strong>{{ c.k }}</strong> = <code>{{ c.v }}</code> &nbsp;</template>
        <span class="ok">· 사용자 {{ rep.template.users }}명 · 워크플로 단계 {{ rep.template.stages?.nodes }}개에서 확인</span>
      </p>

      <details class="raw">
        <summary>노드 전체 필드 {{ sampleKeys.length }}개 보기</summary>
        <table class="kv">
          <tbody>
            <tr v-for="k in sampleKeys" :key="k">
              <td class="kk"><code>{{ k }}</code></td>
              <td>{{ short(rep.template.sampleNode[k]) }}</td>
            </tr>
          </tbody>
        </table>
      </details>

      <h3>채울 목록 {{ rep.plan.length }}건</h3>
      <div class="scroll tall">
        <table>
          <thead>
            <tr><th>액티비티</th><th>일감</th><th>제목</th><th class="num">노드</th><th class="num">채울 노드</th><th>넣을 완료일</th></tr>
          </thead>
          <tbody>
            <tr v-for="(p, i) in rep.plan" :key="p.일감 + i">
              <td class="nowrap">{{ p.액티비티 }}</td>
              <td class="nowrap">{{ p.일감 }}</td>
              <td>{{ p.제목 }}</td>
              <td class="num">{{ p.노드 }}</td>
              <td class="num hi">{{ p.채울노드 }}</td>
              <td class="nowrap">{{ p.넣을완료일 }}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <p v-if="rep.skipped?.length" class="muted note warn">
        건너뜀 {{ rep.skipped.length }}건 —
        <code>{{ rep.skipped.slice(0, 12).map((s) => s.일감).join(', ') }}</code>
        <template v-if="rep.skipped.length > 12"> …</template>
        (완료일 없음)
      </p>
      <p v-if="rep.noWork?.length" class="muted note warn">
        액티비티 조회 실패 {{ rep.noWork.length }}건 —
        <code>{{ rep.noWork.slice(0, 12).map((s) => s.액티비티).join(', ') }}</code>
        <template v-if="rep.noWork.length > 12"> …</template>
      </p>
      <p v-if="rep.readFail?.length" class="muted note bad">
        워크플로 조회 실패 {{ rep.readFail.length }}건 —
        <code>{{ rep.readFail.slice(0, 12).map((s) => s.일감).join(', ') }}</code>
        <template v-if="rep.readFail.length > 12"> …</template>
      </p>
      <p class="muted note">
        위 내용이 맞으면 ProjectView 콘솔에 <code>pvSend()</code> 를 입력해 반영합니다.
        반영 후 ProjectView 화면을 새로고침하면 값이 보입니다.
      </p>
    </template>
  </section>

  <PvDialog
    v-if="script"
    :script="script"
    :title="scriptTitle"
    :meta="scriptMeta"
    sends="바뀌는 값: 워크플로 노드의 비어 있는 일자·담당자만 (기존 값·계획일자는 그대로)"
    @close="script = ''"
  />
</template>

<style scoped>
.topbar { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }
h2 .spacer { flex: 1; }
h2 .step {
  display: inline-block;
  width: 18px;
  height: 18px;
  line-height: 18px;
  text-align: center;
  border-radius: 50%;
  background: var(--accent);
  color: var(--on-accent);
  font-size: 11px;
  margin-right: 4px;
}
h3 { font-size: 12.5px; margin: 14px 0 6px; }
.opts { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
.fld { display: flex; align-items: center; gap: 6px; font-size: 12px; }
.fld span { color: var(--muted); font-size: 11px; }
.two { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.two table { width: 100%; }
.lbl { font-size: 11px; color: var(--muted); margin: 0 0 4px; }
.paste {
  width: 100%;
  min-height: 96px;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 11.5px;
  line-height: 1.5;
  border: 1px solid var(--line);
  border-radius: 6px;
  padding: 8px 10px;
  background: var(--surface);
  resize: vertical;
  white-space: pre;
  overflow: auto;
}
.src { margin: 4px 0 0; }
.raw { margin-top: 10px; font-size: 12px; }
.raw summary { cursor: pointer; color: var(--accent); }
.kv { margin-top: 6px; }
.kv .kk { width: 220px; }
.scroll.tall { max-height: calc(100vh - 380px); overflow: auto; }
.scroll.tall thead th { position: sticky; top: 0; background: var(--panel); box-shadow: inset 0 -1px 0 var(--line); z-index: 1; }
.nowrap { white-space: nowrap; }
.num { text-align: right; }
.hi { color: var(--accent); font-weight: 600; }
.card.hi .v { color: var(--accent); }
.note { margin: 8px 0 0; }
.note.warn { color: var(--warn); }
.bad { color: var(--danger-text); }
.ok { color: var(--done); }
button.pv { border-color: var(--accent); color: var(--accent); }
button.pv:hover:not(:disabled) { background: var(--accent-soft); }
button.pv:disabled { border-color: var(--line); color: var(--muted); }
.errbox {
  background: var(--danger-soft);
  border: 1px solid var(--danger-line);
  color: var(--danger-text);
  padding: 7px 11px;
  border-radius: 6px;
  font-size: 12px;
  margin: 0 0 12px;
}
</style>
