// 메뉴 <목록>만 둔다 — Vue 컴포넌트를 부르지 않는다.
//
// 권한 화면(Perms.vue)도 이 목록이 필요한데, 컴포넌트까지 들어 있는 파일(menu.js)을
// 부르면 menu.js → Perms.vue → menu.js 로 돌아 순환 참조가 된다.
// 그래서 <무엇이 있는지>(여기)와 <무엇으로 그리는지>(menu.js)를 갈라 둔다.

export const MENU_META = [
  { key: 'summary', label: '요약', icon: '▤', desc: '전체 현황과 담당자별 진행률' },
  { key: 'period', label: '기간별 현황', icon: '▥', desc: '월단위 / 주단위 건수' },
  { key: 'users', label: '개발자별 현황', icon: '▦', desc: '월 × 담당자 매트릭스' },
  { key: 'modules', label: '모듈별 현황', icon: '▧', desc: 'PMM 모듈별 건수와 기간' },
  { key: 'progress', label: '진척률 현황', icon: '◑', desc: '계획진척률 · 실적완료율 (오늘 기준)' },
  { key: 'delay', label: '지연 현황', icon: '⚠', desc: '착수지연 · 종료지연 (오늘 기준)' },
  { key: 'rows', label: '상세 목록', icon: '≡', desc: '조회 · 필터 · 정렬 · 수정', full: true },
  { key: 'ci', label: '빌드 상태', icon: '⚙', desc: 'GitLab 최근 Job 상태 (BE/FE 36개)' },
  { key: 'glmon', label: 'GitLab 모니터링', icon: '◎', desc: '저장소 · 커밋 · MR · 빌드 품질 종합' },
  // 기동되는 곳은 <대시보드 API 가 도는 PC> 다. 보는 사람 PC 가 아니다 (DevUi.vue · api/DevRun.cs)
  {
    key: 'devui',
    label: '로컬 개발서버',
    icon: '▶',
    desc: 'PMM BE/FE 기동 · 중지 · 로그 — 내 PC / 서버 전환',
    // full: [내 PC] 는 iframe 이 화면 바닥까지 찬다. 아래 여백이 남으면 그만큼 페이지가 또 스크롤된다.
    full: true,
  },
  // 빌드가 무엇을 당겨 쓰는지 — 빌드 상태(ci)·배포(devui) 와 같은 줄기라 그 옆에 둔다
  {
    key: 'libs',
    label: '라이브러리 저장소',
    icon: '▣',
    desc: '사내 Nexus 의 라이브러리 · 버전 · 크기 · 등록일 (PMM 사용분 포함)',
  },
  // SAP 수신분을 골라 EAI 가 부르는 후행처리를 사람이 대신 누른다 (api/LocPor.cs)
  // ⚠️ 실행은 돌이킬 수 없다. 숨겨야 할 사람이 있으면 [메뉴 권한] 에서 이 키를 막는다.
  {
    key: 'locpor',
    label: '현지 POR 후행처리',
    icon: '⏵',
    desc: 'SST02.Z_PD_C_LOCPOR 수신분을 골라 SP_LOCPOR_AFTER_INSERT 호출',
    full: true,
  },
  {
    key: 'orakill',
    label: 'DB 세션 정리',
    icon: '✂',
    desc: '개발 DB 의 묵은 세션을 끊어 processes 자리를 비운다 · 자동 실행',
    admin: true,
  },
  // 단위테스트 FAIL 목록 — 엑셀 한 장을 떠 둔 표. 맨 오른쪽 칸만 적는다 (api/TestFail.cs)
  {
    key: 'testfail',
    label: '단위테스트 FAIL',
    icon: '✗',
    desc: 'FAIL 난 테스트 62건 · 접수/개선 답 달기',
    full: true,
  },
  // 대형선 업무설계가 바뀔 때마다 한 줄씩 (api/LshipChange.cs)
  {
    key: 'lshipchg',
    label: '대형선 설계 변경이력',
    icon: '⟳',
    desc: '화면명 · 설명 · 요청시작일 · 폐기여부 · 담당자 · 비고',
    full: true,
  },
  { key: 'iface', label: '인터페이스 관리', icon: '⇄', desc: 'EAI 인터페이스 카탈로그 · 처리 단계 · 이슈' },
  { key: 'pvsync', label: 'ProjectView 동기화', icon: '⇅', desc: 'ProjectView 의 계획·실적 날짜를 대시보드로 가져오기' },
  { key: 'pvflow', label: '워크플로 채우기', icon: '⊹', desc: 'ProjectView 워크플로의 빈 일자·담당자 채우기' },
  {
    key: 'mflow',
    label: '업무흐름 시나리오',
    icon: '⇉',
    desc: '자재 업무 흐름 · 시스템 흐름 지도 · 영역별 업무 단계 (글을 고치면 그림이 바뀐다)',
  },
  // 별도로 만들어 둔 HTML 문서 — 같은 컴포넌트에 경로만 달리 넘긴다
  {
    key: 'flow',
    label: '자재업무 흐름도',
    icon: '◈',
    desc: '업무 밸류체인 · 상태코드 · 배치 · 외부 연계 지도',
    // 단일 HTML 문서는 바닥까지 차게 둔다 — 아래 여백이 남으면 그만큼 또 스크롤된다
    full: true,
    props: {
      src: '/p30/index.html',
      title: '자재업무 데이터 흐름도',
      hint: '밸류체인 · 상태코드 · 원장/파생 · 트랜잭션 해부 · 트리거 연쇄 · 배치 · 외부 연계 · 개발 함정',
      srcPath: 'docs/HHIP-P30-자재관리/web/index.html',
    },
  },
  // 같은 정보를 <고칠 수 있게> 보여 주는 쪽. 위의 tables 는 그대로 둔다 —
  // 저쪽은 배치가 코드에 박혀 있어 읽기 전용이고, 이쪽은 끌어 옮겨 저장한다.
  {
    key: 'tables2',
    label: '테이블 계통도 (편집)',
    icon: '✥',
    desc: 'Vue Flow · 끌어 옮기기 · 테이블끼리 잇기 · 저장',
    full: true,
  },
  {
    key: 'tables',
    label: '테이블 계통도',
    icon: '⊞',
    desc: '테이블을 노드로 그린 데이터 흐름 · 업무별 필터',
    // 단일 HTML 문서는 바닥까지 차게 둔다 — 아래 여백이 남으면 그만큼 또 스크롤된다
    full: true,
    props: {
      src: '/p30/flow.html',
      title: '자재 테이블 계통도',
      hint: '업무 탭으로 필터 · 노드 클릭 시 상세 · 빨간 점선은 트리거 자동 파생',
      srcPath: 'docs/HHIP-P30-자재관리/web/flow.html',
    },
  },
  {
    key: 'pdflow',
    label: 'PD 설계 프로세스',
    icon: '◇',
    desc: '설계 프로세스 흐름 Level 1·2·3 + L3~L5 상세',
    // 단일 HTML 문서는 바닥까지 차게 둔다 — 아래 여백이 남으면 그만큼 또 스크롤된다
    full: true,
    props: {
      src: '/pd/process.html',
      title: 'PD 설계 프로세스 흐름 다이어그램',
      hint: 'Level 1·2·3 개괄 + L3~L5 상세 · 문서 자체에 확대/축소와 단계 이동이 있다',
      srcPath: 'D:\\수빅자재\\PD 설계 프로세스 흐름 다이어그램 (Level 1·2·3 + L3~L5 상세).html',
    },
  },
  { key: 'docs', label: '개발자 정보', icon: '✎', desc: '팀 공유 문서 · 편집 가능' },
  // 디스크에 쌓이는 것들을 한자리에서 본다 — 어디에 무엇이 얼마나 있는지 볼 데가 없었다
  { key: 'files', label: '보관 파일', icon: '🗀', desc: '첨부 · 붙여넣은 이미지 · 로그가 쌓이는 곳과 용량' },
  { key: 'devusers', label: '개발자 관리', icon: '☺', desc: 'dev_user 등록 · 수정' },
  // 권한을 나눠 주는 화면이라 최고 관리자에게만 보인다 (권한으로 가릴 대상이 아니다)
  { key: 'perms', label: '메뉴 권한', icon: '⊝', desc: '개발자별로 쓸 수 있는 메뉴 지정', admin: true },
]

/** 권한으로 막을 수 없는 메뉴 — 막으면 갈 곳이 없어진다. 서버도 같은 규칙을 둔다. */
export const ALWAYS_ON = new Set(['summary'])
