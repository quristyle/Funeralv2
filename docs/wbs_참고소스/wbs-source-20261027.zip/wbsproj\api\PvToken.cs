using System.Text;
using System.Text.Json;

namespace WbsApi;

/// <summary>
/// ProjectView 로그인 토큰(promise-token) 보관소.
///
/// 서버가 ProjectView 에서 Excel Export 를 직접 내려받으려면 로그인 자격이 필요하다.
/// 이 토큰은 <b>메모리에만</b> 둔다 — 파일·DB 에 쓰지 않으므로 서버를 다시 띄우면 사라지고,
/// 화면에도 앞뒤 일부만 가려서 보여 준다. 유효기간이 지나면 다시 등록해야 한다.
/// </summary>
public static class PvToken
{
    private static readonly object Lock = new();
    private static string? _token;
    private static DateTime _savedAt;

    public static string? Value
    {
        get { lock (Lock) return _token; }
    }

    public static void Set(string? token)
    {
        lock (Lock)
        {
            _token = string.IsNullOrWhiteSpace(token) ? null : token.Trim();
            _savedAt = DateTime.Now;
        }
    }

    /// <summary>JWT 의 exp 를 읽어 만료 시각을 알아낸다 (JWT 가 아니면 null).</summary>
    private static DateTime? Expiry(string token)
    {
        try
        {
            var parts = token.Split('.');
            if (parts.Length < 2) return null;

            var p = parts[1].Replace('-', '+').Replace('_', '/');
            p = p.PadRight(p.Length + (4 - p.Length % 4) % 4, '=');
            using var doc = JsonDocument.Parse(Encoding.UTF8.GetString(Convert.FromBase64String(p)));
            return doc.RootElement.TryGetProperty("exp", out var e) && e.TryGetInt64(out var sec)
                ? DateTimeOffset.FromUnixTimeSeconds(sec).ToLocalTime().DateTime
                : null;
        }
        catch { return null; }
    }

    /// <summary>화면 표시용 상태 — 토큰 값 자체는 절대 돌려주지 않는다.</summary>
    public static object Status()
    {
        lock (Lock)
        {
            if (_token is null) return new { registered = false };

            var exp = Expiry(_token);
            return new
            {
                registered = true,
                masked = _token.Length > 14 ? $"{_token[..8]}…{_token[^6..]}" : "………",
                length = _token.Length,
                saved = _savedAt.ToString("yyyy-MM-dd HH:mm"),
                expires = exp?.ToString("yyyy-MM-dd HH:mm"),
                expired = exp is not null && exp < DateTime.Now,
            };
        }
    }
}
