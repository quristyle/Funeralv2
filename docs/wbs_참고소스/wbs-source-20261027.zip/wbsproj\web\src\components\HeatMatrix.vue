<script setup>
import { computed } from 'vue'

const props = defineProps({
  rows: { type: Array, default: () => [] }, // [{ user_bp_id, user_nm, bucket, cnt, done }]
  // 열 머리글을 바꿔 표시할 때 사용: { [bucket]: { text, title } }
  labels: { type: Object, default: () => ({}) },
  colHead: { type: String, default: '월' },
})
const emit = defineEmits(['pick'])

const months = computed(() => [...new Set(props.rows.map((r) => r.bucket))].sort())
const head = (b) => props.labels[b]?.text ?? b
const headSub = (b) => props.labels[b]?.sub ?? ''
const headTitle = (b) => props.labels[b]?.title ?? b

// 성명순 정렬. 키는 bp_id 를 유지하고 표시만 '성명 + ID' 로 한다.
const users = computed(() => {
  const m = new Map()
  for (const r of props.rows) if (!m.has(r.user_bp_id)) m.set(r.user_bp_id, r.user_nm ?? r.user_bp_id)
  return [...m]
    .map(([id, nm]) => ({ id, nm }))
    .sort((a, b) => a.nm.localeCompare(b.nm, 'ko') || a.id.localeCompare(b.id))
})

const cell = computed(() => {
  const m = new Map()
  for (const r of props.rows) m.set(`${r.user_bp_id}|${r.bucket}`, r.cnt)
  return m
})
const doneCell = computed(() => {
  const m = new Map()
  for (const r of props.rows) if (r.done) m.set(`${r.user_bp_id}|${r.bucket}`, r.done)
  return m
})
const getDone = (u, m) => doneCell.value.get(`${u}|${m}`) ?? 0
const rowDone = (u) => months.value.reduce((s, m) => s + getDone(u, m), 0)
const colDone = (m) => users.value.reduce((s, u) => s + getDone(u.id, m), 0)
const grandDone = computed(() => props.rows.reduce((s, r) => s + (r.done ?? 0), 0))
const max = computed(() => Math.max(1, ...props.rows.map((r) => r.cnt)))

const get = (u, m) => cell.value.get(`${u}|${m}`) ?? 0
const rowTotal = (u) => months.value.reduce((s, m) => s + get(u, m), 0)
const colTotal = (m) => users.value.reduce((s, u) => s + get(u.id, m), 0)
const grand = computed(() => props.rows.reduce((s, r) => s + r.cnt, 0))

function bg(v) {
  if (!v) return 'transparent'
  const a = 0.08 + (v / max.value) * 0.62
  // 강조색은 테마마다 다르다 — 채널을 변수(--accent-rgb)에서 받아 섞는다.
  //  색을 여기 적어 두면 어두운 화면에서 이 표만 옛 파란색으로 남는다.
  return `rgba(var(--accent-rgb), ${a.toFixed(3)})`
}
function fg(v) {
  return v / max.value > 0.55 ? 'var(--on-accent)' : 'var(--text)'
}
</script>

<template>
  <div class="scroll">
    <table class="heat">
      <thead>
        <tr>
          <th>담당자</th>
          <th v-for="m in months" :key="m" class="num" :title="headTitle(m)">
            {{ head(m) }}<span v-if="headSub(m)" class="sub">{{ headSub(m) }}</span>
          </th>
          <th class="num tot">합계</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="u in users" :key="u.id">
          <td class="user">
            <span class="nm">{{ u.nm }}</span>
            <!-- dev_user 에 없는 값은 성명 자리에 원값이 오므로 ID 를 중복 표시하지 않는다 -->
            <span v-if="u.id !== u.nm" class="id">{{ u.id }}</span>
          </td>
          <td
            v-for="m in months"
            :key="m"
            class="num c"
            :style="{ background: bg(get(u.id, m)), color: fg(get(u.id, m)) }"
            @click="get(u.id, m) && emit('pick', { user: u.id, bucket: m })"
          >
            {{ get(u.id, m) || '' }}<span v-if="getDone(u.id, m)" class="dn">✓{{ getDone(u.id, m) }}</span>
          </td>
          <td class="num tot">
            {{ rowTotal(u.id) }}<span v-if="rowDone(u.id)" class="dn">✓{{ rowDone(u.id) }}</span>
          </td>
        </tr>
      </tbody>
      <tfoot>
        <tr>
          <td>{{ colHead }} 합계</td>
          <td v-for="m in months" :key="m" class="num tot">
            {{ colTotal(m) }}<span v-if="colDone(m)" class="dn">✓{{ colDone(m) }}</span>
          </td>
          <td class="num tot">
            {{ grand }}<span v-if="grandDone" class="dn">✓{{ grandDone }}</span>
          </td>
        </tr>
      </tfoot>
    </table>
    <p v-if="!rows.length" class="muted">데이터 없음</p>
  </div>
</template>

<style scoped>
.heat td, .heat th { border: 1px solid var(--line); padding: 4px 10px; }
.heat .user { white-space: nowrap; }
.heat .user .nm { font-weight: 600; }
.heat .user .id { color: var(--muted); font-size: 11px; margin-left: 6px; font-variant-numeric: tabular-nums; }
.heat .c { cursor: pointer; min-width: 62px; }
.heat .c:hover { outline: 2px solid var(--accent); outline-offset: -2px; }
.heat .tot { font-weight: 600; background: var(--surface); }
.heat .dn { color: var(--done); font-size: 10.5px; margin-left: 4px; font-weight: 600; }
/* 주 머리글의 마지막 날짜(월.일)를 아래 줄에 작게 */
.heat th .sub { display: block; font-weight: 400; font-size: 10px; color: var(--muted); margin-top: 1px; }
tfoot td { font-weight: 600; background: var(--surface); }
</style>
