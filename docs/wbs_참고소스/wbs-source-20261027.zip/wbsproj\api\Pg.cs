using System.Buffers.Binary;
using System.Collections.Concurrent;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;

namespace WbsApi;

/// <summary>
/// 외부 패키지(Npgsql) 없이 BCL만으로 구현한 최소 PostgreSQL 클라이언트.
/// 프론트엔드 프로토콜 3.0 / SCRAM-SHA-256 인증 / 확장 질의(Parse-Bind-Execute)로
/// 파라미터 바인딩을 사용하므로 SQL 인젝션에 안전하다.
/// </summary>
public sealed class PgConn : IDisposable
{
    private readonly TcpClient _tcp;
    private readonly NetworkStream _st;
    private readonly byte[] _hdr = new byte[5];

    private PgConn(TcpClient tcp)
    {
        _tcp = tcp;
        _st = tcp.GetStream();
    }

    public bool Alive => _tcp.Connected;

    public static async Task<PgConn> ConnectAsync(PgOptions o, CancellationToken ct = default)
    {
        var tcp = new TcpClient { NoDelay = true };
        await tcp.ConnectAsync(o.Host, o.Port, ct);
        var c = new PgConn(tcp);
        try
        {
            await c.StartupAsync(o, ct);
            return c;
        }
        catch
        {
            c.Dispose();
            throw;
        }
    }

    // ---------- 연결/인증 ----------

    private async Task StartupAsync(PgOptions o, CancellationToken ct)
    {
        var w = new PgWriter();
        w.Int32(196608); // 3.0
        w.Str("user"); w.Str(o.User);
        w.Str("database"); w.Str(o.Database);
        w.Str("client_encoding"); w.Str("UTF8");
        w.Str("application_name"); w.Str("wbsproj-api");
        w.Byte(0);
        await SendAsync(null, w, ct); // 시작 메시지는 타입 바이트가 없다

        while (true)
        {
            var (type, body) = await ReadAsync(ct);
            switch (type)
            {
                case (byte)'R':
                    var code = BinaryPrimitives.ReadInt32BigEndian(body);
                    if (code == 0) break;                       // AuthenticationOk
                    if (code == 10) { await ScramAsync(o, body, ct); break; }
                    throw new PgException($"지원하지 않는 인증 방식입니다 (code {code}). pg_hba.conf 를 scram-sha-256 으로 설정하세요.");
                case (byte)'E': throw PgException.From(body);
                case (byte)'Z': return;                          // ReadyForQuery
                case (byte)'S': case (byte)'K': case (byte)'N': break;
                default: break;
            }
        }
    }

    private async Task ScramAsync(PgOptions o, byte[] authBody, CancellationToken ct)
    {
        const string mech = "SCRAM-SHA-256";
        var mechs = ReadCStrings(authBody.AsSpan(4));
        if (!mechs.Contains(mech)) throw new PgException($"서버가 {mech} 를 제공하지 않습니다.");

        var nonce = Convert.ToBase64String(RandomNumberGenerator.GetBytes(18));
        var clientFirstBare = $"n=,r={nonce}";

        var w = new PgWriter();
        w.Str(mech);
        var cfm = Encoding.UTF8.GetBytes("n,," + clientFirstBare);
        w.Int32(cfm.Length);
        w.Raw(cfm);
        await SendAsync((byte)'p', w, ct);

        var (t1, b1) = await ReadAsync(ct);
        if (t1 == (byte)'E') throw PgException.From(b1);
        if (t1 != (byte)'R' || BinaryPrimitives.ReadInt32BigEndian(b1) != 11)
            throw new PgException("SASLContinue 응답이 아닙니다.");

        var serverFirst = Encoding.UTF8.GetString(b1, 4, b1.Length - 4);
        var parts = serverFirst.Split(',');
        var rNonce = parts.First(p => p.StartsWith("r=")).Substring(2);
        var salt = Convert.FromBase64String(parts.First(p => p.StartsWith("s=")).Substring(2));
        var iter = int.Parse(parts.First(p => p.StartsWith("i=")).Substring(2));
        if (!rNonce.StartsWith(nonce)) throw new PgException("서버 nonce 불일치.");

        // 비밀번호는 SASLPrep 대상이나, ASCII 범위면 원문과 동일하다.
        var saltedPassword = Rfc2898DeriveBytes.Pbkdf2(
            Encoding.UTF8.GetBytes(o.Password), salt, iter, HashAlgorithmName.SHA256, 32);
        var clientKey = HmacSha256(saltedPassword, "Client Key");
        var storedKey = SHA256.HashData(clientKey);

        var clientFinalNoProof = $"c=biws,r={rNonce}";
        var authMessage = $"{clientFirstBare},{serverFirst},{clientFinalNoProof}";
        var clientSig = HmacSha256(storedKey, authMessage);
        var proof = new byte[clientKey.Length];
        for (var i = 0; i < proof.Length; i++) proof[i] = (byte)(clientKey[i] ^ clientSig[i]);

        var w2 = new PgWriter();
        w2.Raw(Encoding.UTF8.GetBytes($"{clientFinalNoProof},p={Convert.ToBase64String(proof)}"));
        await SendAsync((byte)'p', w2, ct);

        var (t2, b2) = await ReadAsync(ct);
        if (t2 == (byte)'E') throw PgException.From(b2);
        if (t2 != (byte)'R') throw new PgException("SASLFinal 응답이 아닙니다.");
    }

    private static byte[] HmacSha256(byte[] key, string msg)
    {
        using var h = new HMACSHA256(key);
        return h.ComputeHash(Encoding.UTF8.GetBytes(msg));
    }

    // ---------- 질의 ----------

    /// <summary>확장 질의로 SQL 실행. 파라미터는 $1..$n 으로 참조한다.</summary>
    public async Task<PgResult> QueryAsync(string sql, object?[]? args = null, CancellationToken ct = default)
    {
        args ??= [];

        var p = new PgWriter();                      // Parse
        p.Str(""); p.Str(sql); p.Int16(0);
        await SendAsync((byte)'P', p, ct);

        var b = new PgWriter();                      // Bind (모든 값 텍스트 포맷)
        b.Str(""); b.Str(""); b.Int16(0);
        b.Int16((short)args.Length);
        foreach (var a in args)
        {
            if (a is null) { b.Int32(-1); continue; }
            var bytes = Encoding.UTF8.GetBytes(a switch
            {
                DateOnly d => d.ToString("yyyy-MM-dd"),
                DateTime dt => dt.ToString("yyyy-MM-dd HH:mm:ss"),
                bool bo => bo ? "t" : "f",
                IFormattable f => f.ToString(null, System.Globalization.CultureInfo.InvariantCulture),
                _ => a.ToString() ?? ""
            });
            b.Int32(bytes.Length); b.Raw(bytes);
        }
        b.Int16(0);
        await SendAsync((byte)'B', b, ct);

        var dsc = new PgWriter(); dsc.Byte((byte)'P'); dsc.Str("");   // Describe portal
        await SendAsync((byte)'D', dsc, ct);

        var ex = new PgWriter(); ex.Str(""); ex.Int32(0);             // Execute
        await SendAsync((byte)'E', ex, ct);

        await SendAsync((byte)'S', new PgWriter(), ct);         // Sync

        var res = new PgResult();
        PgException? err = null;
        while (true)
        {
            var (type, body) = await ReadAsync(ct);
            switch (type)
            {
                case (byte)'T': ReadRowDescription(body, res); break;
                case (byte)'D': res.Rows.Add(ReadDataRow(body, res)); break;
                case (byte)'C': res.Command = ReadCString(body, 0, out _); break;
                case (byte)'E': err = PgException.From(body); break;
                case (byte)'Z': if (err is not null) throw err; return res;
                default: break; // 1,2,n,N,S,I,s 등은 무시
            }
        }
    }

    public async Task<int> ExecuteAsync(string sql, object?[]? args = null, CancellationToken ct = default)
    {
        var r = await QueryAsync(sql, args, ct);
        var tail = r.Command?.Split(' ').LastOrDefault();
        return int.TryParse(tail, out var n) ? n : r.Rows.Count;
    }

    private static void ReadRowDescription(byte[] body, PgResult res)
    {
        res.Columns.Clear(); res.TypeOids.Clear();
        var n = BinaryPrimitives.ReadInt16BigEndian(body);
        var pos = 2;
        for (var i = 0; i < n; i++)
        {
            res.Columns.Add(ReadCString(body, pos, out pos));
            res.TypeOids.Add(BinaryPrimitives.ReadInt32BigEndian(body.AsSpan(pos + 6))); // table oid(4)+col(2) 건너뜀
            pos += 18;
        }
    }

    private static object?[] ReadDataRow(byte[] body, PgResult res)
    {
        var n = BinaryPrimitives.ReadInt16BigEndian(body);
        var row = new object?[n];
        var pos = 2;
        for (var i = 0; i < n; i++)
        {
            var len = BinaryPrimitives.ReadInt32BigEndian(body.AsSpan(pos)); pos += 4;
            if (len < 0) { row[i] = null; continue; }
            var s = Encoding.UTF8.GetString(body, pos, len); pos += len;
            row[i] = Convert1(s, i < res.TypeOids.Count ? res.TypeOids[i] : 25);
        }
        return row;
    }

    /// <summary>주요 타입만 JSON 친화 타입으로 변환. 나머지는 문자열 그대로.</summary>
    private static object Convert1(string s, int oid) => oid switch
    {
        16 => s == "t",                                                   // bool
        20 or 21 or 23 => long.TryParse(s, out var l) ? l : s,            // int8/int2/int4
        700 or 701 or 1700 => double.TryParse(s, System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var dd) ? dd : s,
        _ => s
    };

    // ---------- 소켓 입출력 ----------

    private async Task SendAsync(byte? type, PgWriter w, CancellationToken ct)
    {
        var payload = w.ToArray();
        var len = payload.Length + 4;
        var buf = new byte[(type.HasValue ? 1 : 0) + len];
        var off = 0;
        if (type.HasValue) buf[off++] = type.Value;
        BinaryPrimitives.WriteInt32BigEndian(buf.AsSpan(off), len);
        payload.CopyTo(buf, off + 4);
        await _st.WriteAsync(buf, ct);
        await _st.FlushAsync(ct);
    }

    private async Task<(byte Type, byte[] Body)> ReadAsync(CancellationToken ct)
    {
        await ReadExactAsync(_hdr, 5, ct);
        var len = BinaryPrimitives.ReadInt32BigEndian(_hdr.AsSpan(1)) - 4;
        var body = len > 0 ? new byte[len] : [];
        if (len > 0) await ReadExactAsync(body, len, ct);
        return (_hdr[0], body);
    }

    private async Task ReadExactAsync(byte[] buf, int count, CancellationToken ct)
    {
        var read = 0;
        while (read < count)
        {
            var n = await _st.ReadAsync(buf.AsMemory(read, count - read), ct);
            if (n == 0) throw new PgException("서버가 연결을 끊었습니다.");
            read += n;
        }
    }

    private static string ReadCString(byte[] b, int pos, out int next)
    {
        var end = Array.IndexOf(b, (byte)0, pos);
        if (end < 0) end = b.Length;
        next = end + 1;
        return Encoding.UTF8.GetString(b, pos, end - pos);
    }

    private static List<string> ReadCStrings(ReadOnlySpan<byte> span)
    {
        var list = new List<string>();
        var arr = span.ToArray();
        var pos = 0;
        while (pos < arr.Length)
        {
            var s = ReadCString(arr, pos, out pos);
            if (s.Length == 0) break;
            list.Add(s);
        }
        return list;
    }

    public void Dispose()
    {
        try { _st.Dispose(); } catch { }
        try { _tcp.Dispose(); } catch { }
    }
}

public sealed class PgResult
{
    public List<string> Columns { get; } = [];
    public List<int> TypeOids { get; } = [];
    public List<object?[]> Rows { get; } = [];
    public string? Command { get; set; }

    /// <summary>JSON 직렬화용 사전 목록으로 변환.</summary>
    public List<Dictionary<string, object?>> ToDicts()
    {
        var list = new List<Dictionary<string, object?>>(Rows.Count);
        foreach (var r in Rows)
        {
            var d = new Dictionary<string, object?>(Columns.Count);
            for (var i = 0; i < Columns.Count; i++) d[Columns[i]] = i < r.Length ? r[i] : null;
            list.Add(d);
        }
        return list;
    }
}

public sealed class PgException : Exception
{
    public PgException(string msg) : base(msg) { }

    public static PgException From(byte[] body)
    {
        var sb = new StringBuilder();
        var pos = 0;
        while (pos < body.Length && body[pos] != 0)
        {
            var field = (char)body[pos++];
            var end = Array.IndexOf(body, (byte)0, pos);
            if (end < 0) end = body.Length;
            var val = Encoding.UTF8.GetString(body, pos, end - pos);
            pos = end + 1;
            if (field is 'M' or 'D' or 'H') sb.Append(val).Append(' ');
        }
        return new PgException(sb.ToString().Trim());
    }
}

public sealed record PgOptions(string Host, int Port, string User, string Password, string Database)
{
    /// <summary>"Host=..;Port=..;Database=..;Username=..;Password=.." 형식 파싱.</summary>
    public static PgOptions Parse(string cs)
    {
        var kv = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var part in cs.Split(';', StringSplitOptions.RemoveEmptyEntries))
        {
            var i = part.IndexOf('=');
            if (i > 0) kv[part[..i].Trim()] = part[(i + 1)..].Trim();
        }
        return new PgOptions(
            kv.GetValueOrDefault("Host", "localhost"),
            int.Parse(kv.GetValueOrDefault("Port", "5432")),
            kv.GetValueOrDefault("Username", kv.GetValueOrDefault("User ID", "postgres")),
            kv.GetValueOrDefault("Password", ""),
            kv.GetValueOrDefault("Database", "postgres"));
    }
}

/// <summary>연결 재사용을 위한 최소 풀. 개발용이라 정책은 단순하게 유지한다.</summary>
public sealed class PgPool(PgOptions opt, int max = 8) : IDisposable
{
    private readonly ConcurrentBag<PgConn> _bag = [];
    private readonly SemaphoreSlim _sem = new(max, max);

    public async Task<T> UseAsync<T>(Func<PgConn, Task<T>> work, CancellationToken ct = default)
    {
        await _sem.WaitAsync(ct);
        PgConn? c = null;
        try
        {
            if (!_bag.TryTake(out c) || !c.Alive)
            {
                c?.Dispose();
                c = await PgConn.ConnectAsync(opt, ct);
            }
            var r = await work(c);
            _bag.Add(c);
            c = null;
            return r;
        }
        catch (PgException)
        {
            // SQL 오류는 연결이 살아있으므로 재사용 가능
            if (c is not null) { _bag.Add(c); c = null; }
            throw;
        }
        finally
        {
            c?.Dispose();
            _sem.Release();
        }
    }

    public Task<List<Dictionary<string, object?>>> QueryAsync(string sql, object?[]? args = null, CancellationToken ct = default)
        => UseAsync(async c => (await c.QueryAsync(sql, args, ct)).ToDicts(), ct);

    public Task<int> ExecuteAsync(string sql, object?[]? args = null, CancellationToken ct = default)
        => UseAsync(c => c.ExecuteAsync(sql, args, ct), ct);

    public void Dispose()
    {
        while (_bag.TryTake(out var c)) c.Dispose();
        _sem.Dispose();
    }
}
