-- ---------------------------------------------------------------------------
-- Drop the send-history columns.
--
-- Why: they were only ever written by POST /api/pv/sent, whose only caller was
-- the PvCache screen, and that screen is being removed. Zero rows ever carried
-- a value (verified before dropping), so nothing is lost.
--
-- What replaces it: re-running a send script. It reads each work first and
-- skips anything already at the target value, so a second run costs almost
-- nothing and effectively retries only what did not land.
--
-- Trade-off accepted: there is now NO record of what the dashboard wrote to
-- ProjectView. If that becomes a problem, the columns come back and the
-- paste-back goes into the send dialog (PvDialog) rather than its own screen.
--
-- pv_filled_at / pv_filled_nodes go too: same writer, and pv_node_empty
-- already says what still needs filling - and that value is refreshed on
-- every collect, so it can never go stale.
-- ---------------------------------------------------------------------------

alter table public.hhip_wbs_pv
  drop column if exists pv_sent_rate,
  drop column if exists pv_sent_at,
  drop column if exists pv_sent_result,
  drop column if exists pv_sent_note,
  drop column if exists pv_sent_sdt,
  drop column if exists pv_sent_sdt_at;

alter table public.hhip_wbs_pv_task
  drop column if exists pv_filled_at,
  drop column if exists pv_filled_nodes;
