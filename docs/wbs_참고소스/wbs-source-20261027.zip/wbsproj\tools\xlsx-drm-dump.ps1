﻿# DRM 으로 감싼 엑셀을 TSV 로 떠낸다.
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File tools/xlsx-drm-dump.ps1 <엑셀> <나올 TSV>
#
# 왜 COM 인가 — DRM 이 감싼 xlsx 는 머리글이 'PK' 가 아니라 'HHIDRMC' 다. zip 리더도
# exceljs 도 열지 못하고, 엑셀이 열 때만 DRM 이 풀린다. 그래서 이 PC 의 엑셀을 빌린다.
#
# ⚠️ 이 파일은 반드시 BOM 을 붙여 저장할 것. PowerShell 5.1 은 BOM 없는 .ps1 을 ANSI 로 읽어
#    한글 경로가 깨지고 "파일을 찾을 수 없습니다" 가 난다 (실제로 밟았다).
$ErrorActionPreference = 'Stop'

$src = $args[0]
$out = $args[1]
if (-not $src -or -not $out) {
  throw '쓰는 법: xlsx-drm-dump.ps1 <엑셀 경로> <나올 TSV 경로>'
}
if (-not (Test-Path -LiteralPath $src)) { throw "엑셀을 찾지 못했습니다: $src" }

$xl = New-Object -ComObject Excel.Application
$xl.Visible = $false
$xl.DisplayAlerts = $false
try {
  # 읽기 전용으로 연다 — 원본을 건드리지 않는다
  $wb = $xl.Workbooks.Open($src, 0, $true)
  foreach ($ws in $wb.Worksheets) {
    Write-Output ("=== SHEET: " + $ws.Name + " === rows=" + $ws.UsedRange.Rows.Count +
                  " cols=" + $ws.UsedRange.Columns.Count)
  }

  # 첫 시트만 뜬다. 여러 장이 필요해지면 그때 인자를 하나 더 받는다.
  $ws = $wb.Worksheets.Item(1)
  $ur = $ws.UsedRange
  $rows = $ur.Rows.Count
  $cols = $ur.Columns.Count

  $lines = New-Object System.Collections.Generic.List[string]
  for ($r = 1; $r -le $rows; $r++) {
    $cells = New-Object System.Collections.Generic.List[string]
    for ($c = 1; $c -le $cols; $c++) {
      # .Text 는 <보이는 대로> 다 — 날짜 서식이 걸린 칸을 숫자(45000)로 받지 않으려는 것이다
      $v = $ws.Cells.Item($r, $c).Text
      if ($null -eq $v) { $v = '' }
      # 칸 안의 줄바꿈·탭은 공백으로. 남겨 두면 TSV 의 줄/칸 구분이 깨진다.
      $cells.Add(($v -replace "`r`n", ' ' -replace "`n", ' ' -replace "`t", ' '))
    }
    $lines.Add(($cells -join "`t"))
  }

  # BOM 없는 UTF-8 로 쓴다 — 받는 쪽(node)이 BOM 을 글자로 읽는다
  [System.IO.File]::WriteAllLines($out, $lines, (New-Object System.Text.UTF8Encoding $false))
  Write-Output ("WROTE " + $out + " lines=" + $lines.Count)
  $wb.Close($false)
} finally {
  $xl.Quit()
  [System.Runtime.InteropServices.Marshal]::ReleaseComObject($xl) | Out-Null
}
