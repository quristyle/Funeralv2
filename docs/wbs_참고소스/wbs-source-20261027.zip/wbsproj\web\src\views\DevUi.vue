<script setup>
import { computed, nextTick, onActivated, onDeactivated, onUnmounted, ref, watch } from 'vue'
import { useDragMove } from '../dragmove'
import { api } from '../api'

// PMM 프로젝트의 BE/FE 를 기동·중지한다. 대상이 둘이고 그래서 화면이 둘이다.
//
//  [서버]  대시보드 API(api/DevRun.cs)가 <자기가 도는 장비>에서 띄운다.
//          사내 주소로 들어와 눌러도 누르는 사람 PC 가 아니다. 그래서 기본적으로
//          서버 로컬·최고 관리자에게만 열린다(서버가 canControl 로 알려 준다).
//
//  [내 PC] 보는 사람 PC 에 떠 있는 개발서버 콘솔(tools/devserver, dev-ui.bat → 4620)을
//          iframe 으로 싣는다. 브라우저만이 대시보드와 제 루프백에 동시에 닿을 수 있어서
//          이렇게 하면 대시보드 서버를 거치지 않고 제 PC 를 조종하게 된다.
//
// ⚠️ [내 PC] 를 iframe 으로 두는 까닭 — iframe 안의 호출은 4620 → 4620 으로 <같은 출처>라
//    CORS 가 필요 없다. 우리 표에서 fetch 로 직접 부르려면 콘솔이 CORS 를 열어야 하는데,
//    그러면 아무 웹페이지나 남의 PC 개발서버를 올리고 내릴 수 있게 된다. 콘솔 쪽에서도
//    같은 이유로 열지 않기로 했다. 모양을 통일하겠다고 이 결정을 뒤집지 말 것.
// 화면이 서버에 상태를 물어보는 주기. 기본 2초 — 기동·중지를 누르면 몇 초 안에
// <컴파일중 → 기동중 → 실행중> 으로 넘어가야 눌린 것 같기 때문이다.
//
// 다만 이 주기가 <모든 것> 의 주기는 아니다. 세 가지가 따로 돈다:
//   · 로컬(이 주기)         — netstat 한 번. 대시보드 서버에서만 돈다.
//   · 도커  Deploy:CacheSeconds     (기본 60초) — 컨테이너 수십 개를 두드린다
//   · 이미지 Deploy:ImageCacheSeconds (기본 300초) — 사내 GitLab 으로 나가는 호출이다
// 뒤의 둘은 서버가 묵혀 두고 주므로 여기서 아무리 자주 물어도 그 주기보다 빨라지지 않는다.
// 지금 당장 보려면 머리줄의 ⟳ 를 누른다.
const POLL_KEY = 'wbs.devui.poll'
const POLL_CHOICES = [
  { ms: 1000, label: '1초' },
  { ms: 2000, label: '2초' },
  { ms: 5000, label: '5초' },
  { ms: 10000, label: '10초' },
  { ms: 30000, label: '30초' },
  { ms: 60000, label: '1분' },
  { ms: 0, label: '멈춤' },
]
const DEFAULT_POLL_MS = 2000
const MODE_KEY = 'wbs.devui.mode'
const PORT_KEY = 'wbs.devui.port'
const DEFAULT_PORT = 4620

function readLs(k) {
  try {
    return localStorage.getItem(k)
  } catch {
    return null
  }
}
function writeLs(k, v) {
  try {
    localStorage.setItem(k, v)
  } catch {
    /* 저장 못 해도 이번 화면에서는 그대로 쓴다 */
  }
}

const savedMode = readLs(MODE_KEY)
const mode = ref(savedMode === 'mine' || savedMode === 'server' ? savedMode : null) // null = 아직 안 정함

function setMode(m) {
  mode.value = m
  writeLs(MODE_KEY, m)
}

// ============================================================================
// 서버 모드
// ============================================================================
const data = ref({ projects: [], canControl: false, why: '', root: '', host: '', rootOk: true })
const err = ref('')
const busy = ref(new Set()) // 방금 누른 버튼 — 서버 응답이 올 때까지 다시 못 누르게 한다
let timer = null

const STATUS = {
  stopped: { label: '중지', cls: 'off' },
  idle: { label: '중지', cls: 'off' },
  compiling: { label: '컴파일중', cls: 'wait' },
  starting: { label: '기동중', cls: 'wait' },
  running: { label: '실행중', cls: 'ok' },
  stopping: { label: '중지중', cls: 'wait' },
  external: { label: '외부', cls: 'ext' },
  failed: { label: '실패', cls: 'ng' },
  exited: { label: '종료됨', cls: 'ng' },
}
const st = (s) => STATUS[s?.status] ?? { label: s?.status || '-', cls: 'off' }

const STARTABLE = (s) => !['running', 'compiling', 'starting', 'external'].includes(s.status)
const STOPPABLE = (s) => !['stopped', 'idle'].includes(s.status)

// ▶ 는 늘 restart 를 보낸다. 같은 단추라도 지금 상태에 따라 벌어지는 일이 다르므로
// 누르기 전에 무엇이 일어날지 풍선말로 밝힌다 — 특히 <외부> 는 남의 프로세스를 잡는다.
function restartHint(s) {
  if (s.status === 'external')
    return `재기동 — 포트 ${s.port} 를 잡고 있는 외부 프로세스를 내리고 여기서 다시 띄웁니다.`
  if (STOPPABLE(s)) return '재기동 — 내렸다가 다시 띄웁니다.'
  return '기동'
}

// ---------- 토스트 ----------
// 누른 것의 결과는 잠깐 떴다 사라진다. 예전에는 화면 맨 위에 띠로 남아 <닫기> 를 눌러야 했는데,
// 누른 자리에서 멀고 치우는 것이 또 일이었다.
//
// ⚠️ err(머리말 띠)는 그대로 둔다 — 그쪽은 <동작의 결과> 가 아니라 <대시보드에 닿지 않는다> 는
//    상태다. 저절로 사라지면 안 되는 종류라서 토스트로 옮기지 않는다.
const toasts = ref([])
let toastSeq = 0

function toast(text, kind = 'ok') {
  if (!text) return
  const id = (toastSeq += 1)
  // 잘못된 쪽은 더 오래 둔다 — 읽어야 할 내용이 들어 있다.
  const ms = kind === 'ng' ? 12000 : 5000
  toasts.value = [...toasts.value, { id, kind, text }]
  setTimeout(() => dropToast(id), ms)
}
const dropToast = (id) => (toasts.value = toasts.value.filter((t) => t.id !== id))

async function load() {
  try {
    data.value = await api.devState()
    err.value = ''
    // 한 번도 안 골랐으면 여기서 정한다 — 서버를 실제로 조종할 수 있는 사람에게는
    // [서버]가, 그 밖의 사람에게는 [내 PC]가 쓸모 있는 화면이다.
    if (mode.value === null) mode.value = data.value.canControl ? 'server' : 'mine'
  } catch (e) {
    err.value = e.message
    if (mode.value === null) mode.value = 'mine'
  }
}

// 고른 주기는 브라우저에 기억한다(접어 둔 것·작업공간 차례와 같은 자리).
// 느리게 두는 사람은 늘 느리게 두고 싶어 한다 — 들어올 때마다 다시 고르게 하지 않는다.
const pollMs = ref(
  (() => {
    // ⚠️ Number(null) 은 0 이고 0 은 <멈춤> 이라는 멀쩡한 선택지다 — 그래서 값이 없는 것과
    //    멈춤을 숫자로 가르면 안 된다. 처음 들어온 사람이 멈춤으로 시작해 버린다.
    const raw = readLs(POLL_KEY)
    if (raw === null || raw === '') return DEFAULT_POLL_MS
    const v = Number(raw)
    return POLL_CHOICES.some((c) => c.ms === v) ? v : DEFAULT_POLL_MS
  })(),
)

function setPoll(ms) {
  pollMs.value = Number(ms)
  writeLs(POLL_KEY, String(pollMs.value))
  if (mode.value === 'server') {
    startPoll()
    // 멈춤에서 되살렸을 때 다음 주기까지 멍하니 기다리지 않게 한 번 바로 부른다
    if (pollMs.value) load()
  }
}

function startPoll() {
  stopPoll()
  // 0 = 멈춤. 자동으로 묻지 않고 ⟳ 로만 본다 — 남의 PC 에서 하루 종일 켜 둘 때 쓴다.
  if (!pollMs.value) return
  timer = setInterval(load, pollMs.value)
}
function stopPoll() {
  if (timer) clearInterval(timer)
  timer = null
}

const q = ref('')
const filter = ref('all') // all | running | stopped | problem
const group = ref('all') // 작업공간 (Design Management · Material Management …)

// 작업공간 차례 — 사람이 정한 순서를 브라우저에 기억해 둔다(접어 둔 것과 같은 자리).
// 서버는 이름 순으로 줄 뿐이라 자주 보는 작업공간이 늘 아래에 깔린다.
const WS_ORDER_KEY = 'wbs.devui.wsorder'
const wsOrder = ref(JSON.parse(readLs(WS_ORDER_KEY) || '[]'))

function saveWsOrder(list) {
  wsOrder.value = list
  writeLs(WS_ORDER_KEY, JSON.stringify(list))
}

const groups = computed(() => {
  const seen = []
  for (const p of data.value.projects ?? []) if (p.group && !seen.includes(p.group)) seen.push(p.group)
  // 기억해 둔 차례를 먼저, 거기 없는 것(새로 받아 온 작업공간)은 뒤에 그대로 붙인다.
  // 기억에서 지우지 않는 까닭 — 잠깐 안 보이는 것일 수 있다(폴더를 옮겼다 되돌리는 일이 잦다).
  const known = wsOrder.value.filter((g) => seen.includes(g))
  return [...known, ...seen.filter((g) => !known.includes(g))]
})

// ▲▼ 는 <보이는 이웃> 자리로 옮긴다. 거르는 중에 숨은 것과 자리를 바꾸면
// 눌렀는데 아무 일도 안 일어난 것처럼 보인다. 적어 두는 것은 늘 전체 차례다.
function moveWs(name, dir) {
  const vis = grouped.value.map((g) => g.name)
  const target = vis[vis.indexOf(name) + dir]
  if (target === undefined) return
  const list = [...groups.value]
  const i = list.indexOf(name)
  if (i < 0) return
  list.splice(i, 1)
  const to = list.indexOf(target)
  if (to < 0) return
  list.splice(dir < 0 ? to : to + 1, 0, name)
  saveWsOrder(list)
}
const wsFirst = (name) => grouped.value[0]?.name === name
const wsLast = (name) => grouped.value[grouped.value.length - 1]?.name === name

// 끌어서 옮기기 — [보이는 컬럼] 대화상자와 같은 짜임이다(ColumnDialog.vue).
// 손잡이는 머리줄만, 받는 곳은 칸 전체다. 칸이 길어 머리줄만 받으면 겨누기가 어렵다.
const wsDragFrom = ref('')
const wsDragOver = ref('')
function wsDragStart(name, e) {
  wsDragFrom.value = name
  e.dataTransfer.effectAllowed = 'move'
  // 파이어폭스는 데이터가 없으면 끌기를 시작하지 않는다
  e.dataTransfer.setData('text/plain', name)
}
function wsDrop(name) {
  const from = wsDragFrom.value
  if (from && from !== name) {
    const list = [...groups.value]
    const i = list.indexOf(from)
    if (i >= 0) {
      list.splice(i, 1)
      const to = list.indexOf(name)
      if (to >= 0) list.splice(to, 0, from)
      saveWsOrder(list)
    }
  }
  wsDragEnd()
}
function wsDragEnd() {
  wsDragFrom.value = ''
  wsDragOver.value = ''
}

// 새로 받아 온 프로젝트를 대시보드 재시작 없이 목록에 넣는다
// 새로고침 하나로 다 한다 — 예전에는 [다시 훑기](폴더 다시 찾기)와 ⟳(도커·이미지)가
// 따로였는데, 하는 일이 달라도 생김새가 같아 같은 기능으로 읽혔다. 둘을 합쳤다.
//
// 순서가 중요하다 — 폴더를 먼저 찾아야(Discover) 새로 받아 온 프로젝트가 배포 대상 표에
// 들어가고, 그 다음에 두드려야 그것까지 함께 읽힌다. 거꾸로 하면 새 프로젝트는 다음 번에야 나온다.
const depBusy = ref(false)

async function refreshAll() {
  const before = (data.value.projects ?? []).length
  busy.value = new Set([...busy.value, 'scan'])
  depBusy.value = true
  try {
    // 폴더 다시 찾기는 서버를 움직이는 일이라 조종 권한이 있을 때만 보낸다.
    // 없는 사람에게는 서버가 ok:false 로 사유를 주는데, 그것은 <새로고침이 실패했다> 가
    // 아니라 <원래 못 하는 일> 이라 알릴 것이 없다. 그 사람도 상태는 그대로 다시 읽는다.
    if (data.value.canControl) {
      const r = await api.devAction('rescan', {})
      // 달라졌을 때만 알린다 — 누를 때마다 뜨면 금세 안 읽게 된다.
      if (r.ok !== false && r.projects != null && r.projects !== before)
        toast(`프로젝트 ${before} → ${r.projects}개 · 서비스 ${r.services ?? '?'}개`)
    }
    await api.devDeploy(true)
  } catch (e) {
    toast(e.message, 'ng')
  } finally {
    const n = new Set(busy.value)
    n.delete('scan')
    busy.value = n
    depBusy.value = false
    await load() // 새 결과는 devState 에 얹혀 온다
  }
}

const refreshHint = computed(() =>
  [
    '지금 다시 읽습니다 — 한 번에 셋 다:',
    data.value.canControl
      ? '  · 폴더 다시 찾기 (새로 clone 받은 프로젝트를 목록에 넣습니다)'
      : '  · 폴더 다시 찾기 (조종 권한이 없어 건너뜁니다)',
    '  · 도커 컨테이너 다시 두드리기',
    '  · GitLab 이미지 다시 읽기',
    '',
    `저절로는 로컬 ${pollMs.value ? `${pollMs.value / 1000}초` : '멈춤'}` +
      ` · 도커 ${deploy.value.ttl ?? 60}초 · 이미지 ${Math.round((deploy.value.imgTtl ?? 300) / 60)}분`,
  ].join('\n'),
)

const rows = computed(() => {
  const needle = q.value.trim().toLowerCase()
  return (data.value.projects ?? []).filter((p) => {
    if (group.value !== 'all' && p.group !== group.value) return false
    // 이름(VITE_APP_TITLE)으로도 찾게 한다 — 번호를 모르고 <발주서> 로 찾는 쪽이 보통이다
    const hay = `${p.label} ${p.id} ${p.title ?? ''}`.toLowerCase()
    if (needle && !hay.includes(needle)) return false
    const ss = [p.be, p.fe].filter(Boolean).map((s) => s.status)
    if (filter.value === 'running') return ss.some((s) => ['running', 'external'].includes(s))
    if (filter.value === 'stopped') return ss.every((s) => ['stopped', 'idle'].includes(s))
    if (filter.value === 'problem') return ss.some((s) => ['failed', 'exited'].includes(s))
    return true
  })
})

const counts = computed(() => {
  let be = 0
  let fe = 0
  let beTotal = 0
  let feTotal = 0
  for (const p of data.value.projects ?? []) {
    if (p.be) {
      beTotal += 1
      if (['running', 'external'].includes(p.be.status)) be += 1
    }
    if (p.fe) {
      feTotal += 1
      if (['running', 'external'].includes(p.fe.status)) fe += 1
    }
  }
  return { be, fe, beTotal, feTotal }
})

// ---------- 배포 상태 — 이미지 · 도커 ----------
// 줄마다 세 칸을 왼쪽부터 <이미지 → 도커 → 로컬> 순으로 둔다. 흐름이 그 순서다:
// GitLab 이 굽고(이미지), 개발 서버가 올리고(도커), 내 PC/서버에서 돈다(로컬).
//
// ⚠️ 판정을 브라우저에서 하지 않는 까닭 셋 — 서버(api/DevDeploy.cs)가 대신 두드린다.
//   ① 공개 URL(https://dev-isos-hhip.hd.com/mfe/pmmNNN/remoteEntry.js)은 미인증이면
//      <무엇이든 302> 라 배포 여부를 가릴 수 없다. 가리려면 컨테이너 포트를 직접 쳐야 하는데,
//   ② 대시보드를 https(5443)로 보고 있으면 http:// 컨테이너로 나가는 요청은 섞인 콘텐츠로
//      브라우저가 막는다. ③ 게다가 보는 사람마다 수십 번씩 두드리게 된다.
// 그래서 여기서는 받아 적기만 한다. 공개 URL 은 <눌러서 여는 링크> 로만 쓴다.
const deploy = computed(() => data.value.deploy ?? { enabled: false, items: {} })
const dep = (p, tier) => deploy.value.items?.[p.id]?.[tier] ?? null

const CLS = { up: 'ok', busy: 'wait', bad: 'ng', down: 'off', none: 'off', unknown: 'dimpill' }
const clsOf = (x) => CLS[x?.state] ?? 'dimpill'

function stamp(ms) {
  if (!ms) return ''
  const d = new Date(ms)
  const p2 = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}:${p2(d.getMinutes())}`
}
// 칸이 좁아 연도는 뺀다 — 풍선말에는 늘 연도까지 있다.
// 다만 <올해가 아닌 것> 은 연도를 남긴다. 2년 전에 구운 이미지가 "01-28" 로만 보이면
// 지난달 것으로 읽힌다 (cf03-client 가 실제로 그렇다).
const shortStamp = (ms) => {
  if (!ms) return ''
  const s = stamp(ms)
  return new Date(ms).getFullYear() === new Date().getFullYear() ? s.slice(5) : s.slice(2, 10)
}

// ---- ① 이미지 (GitLab) ----
const imgOf = (p, tier) => dep(p, tier)?.img ?? null
// 칸에 적을 말은 짧게, 긴 사연은 풍선말로.
// <도는 중> 은 실패가 아니다 — CI 가 한 번 돌면 열 몇 개가 동시에 그 상태가 된다.
const imgShort = (i) =>
  i?.state === 'up'
    ? '성공'
    : i?.state === 'busy'
      ? '빌드중'
      : i?.state === 'bad' || i?.state === 'down'
        ? '실패'
        : '없음'

function imgTitle(p, tier, d) {
  const t = `${p.label} ${tier.toUpperCase()}`
  const i = d?.img
  if (!i) {
    if (deploy.value.imgOn === false)
      return `${t} · 이미지 — GitLab 토큰이 없어 못 읽습니다 (appsettings 의 Gitlab:Token).`
    if (!d?.gitPath) return `${t} · 이미지 — 이 폴더의 .git/config 에서 GitLab 경로를 못 찾았습니다.`
    return `${t} · 이미지 — 아직 읽지 못했습니다.`
  }
  const l = [`${t} · 이미지 빌드: ${i.label}`]
  if (i.at) l.push(`이미지 생성(${i.job ?? '잡'} 완료): ${stamp(i.at)}`)
  if (i.sha) l.push(`커밋 ${i.sha}${i.title ? ` · ${i.title}` : ''}`)
  if (i.ref) l.push(`브랜치 ${i.ref}`)
  // 잡 이름이 build:image 가 아니면 <무엇에서 뽑은 시각인지> 를 밝혀야 한다.
  if (i.job && i.job !== 'build:image') l.push(`※ build:image 가 없어 "${i.job}" 잡에서 읽었습니다`)
  if (d.gitPath) l.push(`저장소 ${d.gitPath}`)
  if (i.url) l.push('(눌러서 그 잡을 GitLab 에서 엽니다)')
  return l.join('\n')
}

// ---- ② 도커 ----
const dkOf = (p, tier) => dep(p, tier)?.docker ?? null
const dkShort = (k) =>
  k?.state === 'up' ? '배포됨' : k?.state === 'down' ? '안 뜸' : k?.state === 'unknown' ? '모름' : '이상'

// 도커 칸에 적을 시각 — <반영된 시각> 은 우리가 바뀌는 것을 본 때만 뜻이 있다.
// 못 본 동안의 일은 알 수 없으므로 비워 둔다. 이미지 시각을 대신 끌어다 쓰지 않는다 —
// 그러면 <구워만 두고 안 올린 것> 이 올린 것처럼 보인다.
const dkWhen = (k) => (k?.confirmed ? k.at : null)

function dkTitle(p, tier, d) {
  const t = `${p.label} ${tier.toUpperCase()}`
  const k = d?.docker
  if (!k) return `${t} · 도커 — 아직 확인하지 못했습니다.`
  const l = [`${t} · 도커 배포: ${k.label}`]
  if (k.url) l.push(`확인: ${k.url}${k.code ? ` → HTTP ${k.code}` : ' → 연결 안 됨'}`)
  if (k.port) l.push(`포트 ${k.host}:${k.port}  (출처: ${k.portSrc})`)
  if (k.why) l.push(k.why)
  l.push('')
  if (k.confirmed && k.at) {
    l.push(`도커 반영: ${stamp(k.at)}`)
    l.push('  (대시보드가 바뀌는 것을 본 시각입니다 — 확인 주기만큼 늦을 수 있습니다)')
  } else if (k.since) {
    l.push(`도커 반영: 모름 — ${stamp(k.since)} 부터 보고 있는데 아직 안 바뀌었습니다.`)
    l.push('  컨테이너는 <언제 올라왔는지> 를 알려 주지 않습니다(actuator 는 health 만 엽니다).')
    l.push('  그래서 바뀌는 순간을 봐야 알 수 있고, 보기 시작한 뒤의 배포부터 시각이 찍힙니다.')
  }
  if (k.serveAt) l.push(`지금 서비스되는 파일: ${stamp(k.serveAt)} (이미지 안의 mtime 입니다)`)
  if (d.stale) {
    l.push('')
    l.push('⚠️ 이미지는 더 새것인데 서비스되는 파일은 옛날 것입니다 —')
    l.push('   빌드는 됐지만 컨테이너가 그 이미지로 안 올라갔습니다.')
  }
  if (k.pub) {
    l.push('')
    l.push(`공개: ${k.pub}`)
    l.push('(눌러서 공개 주소를 엽니다 — 로그인해야 보입니다)')
  }
  return l.join('\n')
}

// 분모는 <배포 대상인 것> 만 센다. 주소를 모르는 칸(CX90 처럼 이 방식으로 배포하지 않는 것)까지
// 넣으면 아무 일이 없어도 늘 모자라 보여서, 정작 내려간 것이 눈에 안 띈다.
const depCounts = computed(() => {
  const c = { be: 0, beN: 0, fe: 0, feN: 0 }
  for (const v of Object.values(deploy.value.items ?? {}))
    for (const tier of ['be', 'fe']) {
      const k = v[tier]?.docker
      if (!k || k.state === 'unknown') continue
      c[`${tier}N`] += 1
      if (k.state === 'up') c[tier] += 1
    }
  return c
})

// 접어 둔 작업공간 — 다음에 들어와도 접힌 채로 보이게 브라우저에 기억한다.
const WS_KEY = 'wbs.devui.collapsed'
const collapsed = ref(new Set(JSON.parse(readLs(WS_KEY) || '[]')))
// 거르는 중에는 접어 둔 것도 펼쳐 보여 준다 — 찾으라고 누른 것이 접혀 있어 안 보이면
// 아무것도 없는 것처럼 읽힌다. 접어 둔 기억은 그대로 두고 <보여 주기만> 한다.
const filtering = computed(() => filter.value !== 'all' || q.value.trim() !== '')
const wsOpen = (name) => filtering.value || !collapsed.value.has(name)
function toggleWs(name) {
  const n = new Set(collapsed.value)
  if (n.has(name)) n.delete(name)
  else n.add(name)
  collapsed.value = n
  writeLs(WS_KEY, JSON.stringify([...n]))
}

// 한꺼번에 펼치고 접기 — 작업공간이 열 개를 넘어가면 하나씩 누르는 것이 일이다.
// 접을 때는 <보이는 것> 이 아니라 <있는 것> 을 모두 접는다 (groups 는 걸러지지 않은
// 전체 목록이다). 걸러져 안 보이던 작업공간만 펼친 채 남으면 다음에 들어왔을 때 어긋난다.
const allCollapsed = computed(
  () => groups.value.length > 0 && groups.value.every((n) => collapsed.value.has(n)),
)
const noneCollapsed = computed(() => groups.value.every((n) => !collapsed.value.has(n)))
function setAllWs(collapse) {
  const n = collapse ? new Set(groups.value) : new Set()
  collapsed.value = n
  writeLs(WS_KEY, JSON.stringify([...n]))
}

// 작업공간별로 묶는다 — 서른 개가 넘는 프로젝트가 한 표에 늘어서면
// 지금 보는 줄이 어느 작업공간 것인지 매번 왼쪽 끝을 확인해야 한다.
// 접어 두었을 때도 머리줄만 보고 상태를 알 수 있게 작업공간 단위로 모은다.
// 접은 채로 두는 작업공간이 대부분이라, 머리줄이 곧 그 작업공간의 전부다.
function rollUp(list) {
  let imgOk = 0
  let imgBad = 0
  let imgBusy = 0
  let imgN = 0
  let dkUp = 0
  let dkN = 0
  let dkDown = 0
  let stale = 0
  for (const p of list)
    for (const tier of ['be', 'fe']) {
      const d = deploy.value.items?.[p.id]?.[tier]
      if (!d) continue
      if (d.img?.state) {
        imgN += 1
        if (d.img.state === 'up') imgOk += 1
        else if (d.img.state === 'busy') imgBusy += 1
        else if (d.img.state !== 'none') imgBad += 1
      }
      // 주소를 모르는 칸은 분모에서도 뺀다 — 배포 대상이 아닌 것까지 세면 늘 모자라 보인다.
      if (d.docker && d.docker.state !== 'unknown') {
        dkN += 1
        if (d.docker.state === 'up') dkUp += 1
        else if (d.docker.state === 'down') dkDown += 1
      }
      if (d.stale) stale += 1
    }
  return { imgOk, imgBad, imgBusy, imgN, dkUp, dkN, dkDown, stale }
}

const grouped = computed(() => {
  const m = new Map()
  for (const p of rows.value) {
    if (!m.has(p.group)) m.set(p.group, [])
    m.get(p.group).push(p)
  }
  // 사람이 정한 차례대로 세운다 (groups). 거기 없는 것은 뒤로 — 그래야 새로 들어온
  // 작업공간이 맨 앞에 끼어들어 기억해 둔 차례를 흐트러뜨리지 않는다.
  const rank = (n) => (groups.value.indexOf(n) + 1 || Number.MAX_SAFE_INTEGER) - 1
  return [...m.entries()]
    .sort((a, b) => rank(a[0]) - rank(b[0]))
    .map(([name, list]) => ({
      name,
      list,
      dir: list[0]?.groupDir ?? '',
      beTotal: list.filter((p) => p.be).length,
      feTotal: list.filter((p) => p.fe).length,
      be: list.filter((p) => p.be && ['running', 'external'].includes(p.be.status)).length,
      fe: list.filter((p) => p.fe && ['running', 'external'].includes(p.fe.status)).length,
      ...rollUp(list),
    }))
})

/** 카드에 테를 둘러 <지금 뭔가 돌고 있다> 를 멀리서도 알아보게 한다 */
const rowLive = (p) =>
  [p.be, p.fe].some((s) => s && ['running', 'external', 'compiling', 'starting'].includes(s.status))

// 살아 있는 것 — 전체 중지의 대상이자 버튼에 붙일 숫자. FE 를 먼저 내린다.
const liveTargets = computed(() => {
  const be = []
  const fe = []
  for (const p of data.value.projects ?? []) {
    if (p.be && STOPPABLE(p.be)) be.push({ id: p.id, tier: 'be' })
    if (p.fe && STOPPABLE(p.fe)) fe.push({ id: p.id, tier: 'fe' })
  }
  return [...fe, ...be]
})

async function act(action, body, mark) {
  if (mark) busy.value = new Set([...busy.value, mark])
  try {
    const r = await api.devAction(action, body)
    // 서버가 막았을 때는 403 이 아니라 ok:false 로 사유를 준다 — api.js 가 403 을
    // <IP 권한이 사라졌다> 로 보고 페이지를 통째로 새로 부르기 때문이다.
    if (r.ok === false && r.message) toast(r.message, 'ng')
    const bad = (r.results ?? []).map((x) => x.result).find((x) => x && x.ok === false)
    if (bad?.message) toast(bad.message, 'ng')
  } catch (e) {
    toast(e.message, 'ng')
  } finally {
    if (mark) {
      const n = new Set(busy.value)
      n.delete(mark)
      busy.value = n
    }
    await load()
  }
}

const one = (action, s) => act(action, { id: s.id, tier: s.tier }, `${s.id}:${s.tier}`)

// 그 폴더에서 명령창·편집기 열기 — 경로를 복사해 붙이지 않게 한다.
// 둘 다 <대시보드 서버 PC> 화면에 뜬다 (기동·중지와 같다).
async function openIn(s, action, fallback) {
  const mark = `${s.id}:${s.tier}`
  busy.value = new Set([...busy.value, mark])
  try {
    const r = await api.devAction(action, { id: s.id, tier: s.tier })
    const one2 = (r.results ?? [])[0]?.result ?? r
    if (one2.ok === false) toast(one2.message ?? fallback, 'ng')
    else toast(one2.message ?? fallback)
  } catch (e) {
    toast(e.message, 'ng')
  } finally {
    const n = new Set(busy.value)
    n.delete(mark)
    busy.value = n
  }
}

const openCmd = (s) => openIn(s, 'cmd', '명령창을 열었습니다.')

// 프로젝트·작업공간 단위 git pull — 폴더가 아니라 그 아래 be/fe 저장소마다 돌린다.
// 받아 온 내용은 각 서비스의 ≡ 로그에 그대로 남는다.
async function pullMany(action, payload, mark) {
  busy.value = new Set([...busy.value, mark])
  try {
    const r = await api.devAction(action, payload)
    if (r.ok === false) toast(r.message ?? 'git pull 에 실패했습니다.', 'ng')
    else toast(r.message ?? '받아왔습니다.')
  } catch (e) {
    toast(e.message, 'ng')
  } finally {
    const n = new Set(busy.value)
    n.delete(mark)
    busy.value = n
    await load()
  }
}
const pullProject = (p) => pullMany('pull-project', { id: p.id }, `${p.id}:pair`)
const pullGroup = (g) => pullMany('pull-group', { group: g.name }, `ws:${g.name}`)

// 작업공간 폴더를 통째로 연다 — 그 아래 프로젝트를 한 창에서 오가며 볼 때.
async function openGroupCode(g) {
  const mark = `ws:${g.name}`
  busy.value = new Set([...busy.value, mark])
  try {
    const r = await api.devAction('code-group', { group: g.name })
    if (r.ok === false) toast(r.message ?? 'VS Code 를 띄우지 못했습니다.', 'ng')
    else toast(r.message ?? 'VS Code 로 열었습니다.')
  } catch (e) {
    toast(e.message, 'ng')
  } finally {
    const n = new Set(busy.value)
    n.delete(mark)
    busy.value = n
  }
}

// 프로젝트 폴더를 통째로 연다 — be·fe 를 한 창에서 같이 보려는 것이다.
// 대상이 tier 가 아니라 프로젝트 id 하나라 openIn 을 쓰지 않는다.
async function openProjectCode(p) {
  const mark = `${p.id}:pair`
  busy.value = new Set([...busy.value, mark])
  try {
    const r = await api.devAction('code-project', { id: p.id })
    if (r.ok === false) toast(r.message ?? 'VS Code 를 띄우지 못했습니다.', 'ng')
    else toast(r.message ?? 'VS Code 로 열었습니다.')
  } catch (e) {
    toast(e.message, 'ng')
  } finally {
    const n = new Set(busy.value)
    n.delete(mark)
    busy.value = n
  }
}
const openCode = (s) => openIn(s, 'code', 'VS Code 로 열었습니다.')

// ---------- git pull ----------
// 결론 한 줄만 화면에 띄운다. 받아 온 내용 전부는 그 서비스의 로그(≡)에 그대로 들어간다.

async function pull(s) {
  const mark = `${s.id}:${s.tier}`
  busy.value = new Set([...busy.value, mark])
  try {
    const r = await api.devAction('pull', { id: s.id, tier: s.tier })
    const one2 = (r.results ?? [])[0]?.result ?? r
    const head = `${s.id.toUpperCase()} ${s.tier.toUpperCase()} · ${one2.message ?? ''}`
    if (one2.ok === false) {
      toast(head, 'ng')
    } else {
      // 실제로 받아 온 것이 있으면 BE 는 다시 컴파일해야 반영된다 (FE 는 vite 가 알아서 집는다)
      const changed = !/up to date/i.test(one2.message ?? '')
      toast(head + (changed && s.tier === 'be' ? '  — 반영하려면 ▶ 로 재기동하세요.' : ''))
    }
  } catch (e) {
    toast(e.message, 'ng')
  } finally {
    const n = new Set(busy.value)
    n.delete(mark)
    busy.value = n
    await load()
  }
}

// ---------- BE·FE 묶음 ----------
// ▶▶ 는 줄마다 있는 ▶ 와 같은 일을 둘에 한꺼번에 한다 — <restart> 다.
// 멈춰 있으면 기동, 떠 있으면 재기동이고, 한쪽만 떠 있어도 한 번에 맞춰진다.
//
// 예전에는 start 를 보내면서 <이미 그 상태인 칸> 을 빼고 보냈다. 서버가 "이미 기동 중이다" 를
// 돌려주면 화면에 경고가 떴기 때문인데, 그 탓에 둘 다 떠 있으면 단추가 아예 눌리지 않아
// 재기동하려면 줄마다 따로 눌러야 했다. restart 는 그 상태를 가리지 않으므로 거를 것이 없다.
//
// ⚠️ 보내는 차례가 곧 도는 차례다 — 서버가 받은 순서대로 하나씩 처리한다(DevRun 의 targets 루프).
//    올릴 때는 BE 먼저(FE 가 뜨자마자 BE 를 찾는다), 내릴 때는 FE 먼저다.
const pairAll = (p) => [p.be, p.fe].filter(Boolean) // BE → FE
const pairStoppable = (p) => [p.fe, p.be].filter((s) => s && STOPPABLE(s)) // 내릴 때는 FE 부터

const restartPair = (p) =>
  act('restart', { targets: pairAll(p).map((s) => ({ id: s.id, tier: s.tier })) }, `${p.id}:pair`)

const stopPair = (p) =>
  act('stop', { targets: pairStoppable(p).map((s) => ({ id: s.id, tier: s.tier })) }, `${p.id}:pair`)

// 줄마다 있는 ▶ 와 같은 결 — 누르기 전에 지금 상태에서 무엇이 벌어질지 밝힌다.
function pairHint(p) {
  const n = pairAll(p).length
  if (!n) return '기동할 수 있는 칸이 없습니다.'
  const live = pairAll(p).filter((s) => STOPPABLE(s))
  const ext = pairAll(p).filter((s) => s.status === 'external')
  const head = live.length ? 'BE·FE 함께 재기동' : 'BE·FE 함께 기동'
  const l = [`${head} (BE → FE 순)`]
  if (live.length) l.push('떠 있는 것은 내렸다가 다시 띄웁니다.')
  if (ext.length) l.push(`외부 ${ext.length}개 — 그 포트를 잡고 있는 남의 프로세스를 내리고 다시 띄웁니다.`)
  return l.join('\n')
}

async function stopAll() {
  const targets = liveTargets.value
  if (!targets.length) return
  if (!confirm(`실행 중인 ${targets.length}개를 모두 내립니다. (FE → BE 순)`)) return
  await act('stop', { targets }, 'all')
}

async function killPort(s) {
  if (!confirm(`포트 ${s.port} 를 잡고 있는 프로세스를 강제 종료합니다.`)) return
  await act('kill-port', { port: s.port }, `${s.id}:${s.tier}`)
}

// 서비스가 도는 곳은 <대시보드 서버 PC> 다. 보는 사람 PC 가 아니라 지금 접속한 그 호스트로 연다.
// 다만 루프백으로 보고 있을 때는 localhost 로 적는다 — vite 가 [::1] 에만 붙는 일이 있어
// 127.0.0.1 로는 연결이 거절된다(BE 는 어느 쪽이든 붙는다).
function urlOf(s) {
  const h = location.hostname
  const host = h === '127.0.0.1' || h === '::1' || h === 'localhost' ? 'localhost' : h
  return `http://${host}:${s.port}`
}

// ---------- 로그인 사번 (서버 모드) ----------
// PMM001 BE 의 .env.properties 의 USER_ID 를 바꾼다 (api/DevRun.cs 의 WriteUserId).
//
// ⚠️ 여기서 바꾸는 것은 <대시보드 API 가 도는 장비>의 파일이다 — 누르는 사람 PC 가 아니다.
//    기동·중지와 똑같은 성질이라 같은 권한(canControl)으로 막는다. 제 PC 를 바꾸려면
//    [내 PC] 탭의 콘솔에 같은 단추가 한 벌 더 있다. 그래서 띠에 장비 이름과 경로를 적어 둔다 —
//    어느 파일을 고치는지 모르고 누르게 두면 안 된다.
// ⚠️ select 가 아니라 input + datalist 다. 개발자 명부(public.dev_user)에 없는 사번도
//    그대로 쳐 넣어 반영할 수 있어야 한다. 모양을 다듬겠다고 select 로 바꾸지 말 것.
const EMPTY_UID = { ok: false, file: '', userId: null, line: null, message: '' }
const uid = ref({ ...EMPTY_UID })
const uidDevs = ref([])
const uidInput = ref('')
const uidBusy = ref(false)

// 철자 맞추기는 서버가 한다 — 명부에 있으면 명부 철자, 없으면 대문자 (DevRun 의 WriteUserId).
// 여기서는 대소문자만 무시하고 견준다. 화면이 따로 올려 버리면 sunakim87 같은 소문자 사번이
// 명부에 있는데도 <다르다> 로 보인다.
const sameId = (a, b) => (a ?? '').toLowerCase() === (b ?? '').toLowerCase()
const uidName = computed(() => uidDevs.value.find((d) => sameId(d.bpId, uid.value.userId))?.name ?? '')
// 쳐 놓고 아직 안 누른 상태 — 눈에 띄게 해 둔다. 안 그러면 바꾼 줄 알고 넘어간다.
const uidDirty = computed(() => {
  const v = uidInput.value.trim()
  return v.length > 0 && !sameId(v, uid.value.userId)
})

async function loadUserId() {
  try {
    const r = await api.devUserId()
    uid.value = r.current ?? { ...EMPTY_UID }
    uidDevs.value = r.developers ?? []
    if (!uidInput.value) uidInput.value = uid.value.userId ?? ''
  } catch {
    /* 대시보드에 못 닿는 것은 위의 상태 띠(err)가 이미 말해 준다 */
  }
}

async function applyUserId() {
  const v = uidInput.value.trim()
  if (!v) return toast('사번을 고르거나 입력하세요.', 'ng')
  uidBusy.value = true
  try {
    // 서버가 막았을 때는 403 이 아니라 ok:false 로 사유를 준다 (act 와 같은 이유).
    const r = await api.devAction('userid', { userId: v })
    if (r.ok === false) return toast(r.message || '반영하지 못했습니다.', 'ng')
    uidInput.value = r.userId // 서버가 맞춘 철자로 되돌려 받는다
    const nm = uidDevs.value.find((d) => sameId(d.bpId, r.userId))?.name
    toast(r.message + (nm ? ` (${nm})` : ''))
    await loadUserId()
  } catch (e) {
    toast(e.message, 'ng')
  } finally {
    uidBusy.value = false
  }
}

// ---------- 로그 (서버 모드) ----------
// 머리글을 잡아 창을 옮긴다 — 로그를 띄워 둔 채로 뒤의 카드(포트·상태)를 봐야 할 때가 많다.
// 다른 팝업(TaskDialog 등)과 같은 장치를 쓴다(web/src/dragmove.js).
const logDrag = useDragMove()

const log = ref(null) // { id, tier, port, dir, lines, since }
const logBox = ref(null)
let logTimer = null

async function openLog(s) {
  log.value = { id: s.id, tier: s.tier, port: s.port, dir: '', lines: [], since: 0 }
  await pullLog()
  if (logTimer) clearInterval(logTimer)
  logTimer = setInterval(pullLog, 1500)
}

async function pullLog() {
  if (!log.value) return
  try {
    const r = await api.devLog(log.value.id, log.value.tier, log.value.since)
    if (!log.value) return
    log.value.dir = r.dir
    log.value.since = r.last
    if (r.lines.length) {
      log.value.lines.push(...r.lines)
      if (log.value.lines.length > 2000) log.value.lines.splice(0, log.value.lines.length - 2000)
      // 바닥을 보고 있을 때만 따라 내린다 — 위로 올려 읽는 중이면 건드리지 않는다
      const el = logBox.value
      if (el && el.scrollHeight - el.scrollTop - el.clientHeight < 80) {
        requestAnimationFrame(() => {
          el.scrollTop = el.scrollHeight
        })
      }
    }
  } catch (e) {
    toast(e.message, 'ng')
  }
}

function closeLog() {
  if (logTimer) clearInterval(logTimer)
  logTimer = null
  log.value = null
}

async function clearLog() {
  if (!log.value) return
  await act('clear-log', { id: log.value.id, tier: log.value.tier })
  log.value.lines = []
  log.value.since = 0
}

// ============================================================================
// 내 PC 모드
// ============================================================================
function readPort() {
  const v = Number(readLs(PORT_KEY))
  return v > 0 && v < 65536 ? v : DEFAULT_PORT
}
const port = ref(readPort())
const portInput = ref(String(port.value))
const probeState = ref('idle') // idle | checking | up | down
const forced = ref(false) // 확인에 실패했어도 사용자가 그래도 띄워 본 상태
const frameKey = ref(0) // 값을 바꿔 iframe 을 다시 만든다

// 콘솔은 127.0.0.1 에만 붙는다(server.mjs 의 HOST). localhost 로 적으면 ::1 로 푸는 PC 에서
// 연결이 거절되므로 여기는 반드시 127.0.0.1 이다. (콘솔이 FE 를 여는 링크가 localhost 인 것은
// 방향이 반대인 이유 — vite 가 ::1 에만 붙는 일이 있어서다. 둘을 <통일>하지 말 것.)
const consoleUrl = () => `http://127.0.0.1:${port.value}`

// 콘솔이 떠 있는지 두드려 본다.
//
// `no-cors` 로 보내는 까닭 — 콘솔은 CORS 를 열지 않는다(머리말 참고). 응답 내용은 못 읽지만
// <연결이 되는가> 만 알면 되고, 그것은 거절 시 fetch 가 던지는 것으로 갈린다.
// 두드리는 곳은 콘솔이 그 용도로 열어 둔 읽기전용 `/api/ping` 이다.
async function probe() {
  probeState.value = 'checking'
  const ac = new AbortController()
  const t = setTimeout(() => ac.abort(), 2500)
  try {
    await fetch(`${consoleUrl()}/api/ping?t=${Date.now()}`, {
      mode: 'no-cors',
      cache: 'no-store',
      signal: ac.signal,
    })
    probeState.value = 'up'
    forced.value = false
  } catch {
    probeState.value = 'down'
  } finally {
    clearTimeout(t)
    fitLater()
  }
}

function applyPort() {
  const v = Number(portInput.value)
  if (!(v > 0 && v < 65536)) {
    portInput.value = String(port.value)
    return
  }
  port.value = v
  writeLs(PORT_KEY, String(v))
  frameKey.value += 1
  probe()
}

const CMD = 'dev-ui.bat'
const copied = ref(false)
async function copyCmd() {
  try {
    await navigator.clipboard.writeText(CMD)
    copied.value = true
    setTimeout(() => (copied.value = false), 1500)
  } catch {
    /* 클립보드를 못 쓰면 화면의 글자를 긁어 가면 된다 */
  }
}

// ---------- 세로 맞춤 ----------
// iframe 에만 스크롤이 생기게 한다. 바깥 페이지까지 스크롤되면 콘솔 안을 보려고
// 두 번 스크롤해야 한다.
//
// 높이를 calc(100vh - 상수) 로 박지 않는 까닭 — 위에 무엇이 오는지(탭 줄·머리말·경고)가
// 상황마다 다르다. 제 자리에서 화면 바닥까지 재는 편이 언제나 맞는다.
const paneEl = ref(null)
const paneH = ref(0)

function fitPane() {
  const el = paneEl.value
  if (!el) return
  const top = el.getBoundingClientRect().top
  paneH.value = Math.max(320, Math.round(window.innerHeight - top - 8))
}
function fitLater() {
  nextTick(fitPane)
}

// ============================================================================
onActivated(() => {
  // [내 PC] 라도 한 번은 부른다 — 서버 장비 이름을 버튼에 적기 위해서다.
  load()
  if (mode.value === 'mine') probe()
  else {
    startPoll()
    loadUserId() // 상태 주기에 얹지 않는다 — 파일을 읽는 일이라 2초마다 두드릴 까닭이 없다
  }
  window.addEventListener('resize', fitPane)
  fitLater()
})

onDeactivated(() => {
  stopPoll()
  window.removeEventListener('resize', fitPane)
})

watch(mode, (m) => {
  if (m === 'mine') {
    stopPoll()
    probe()
  } else {
    load()
    startPoll()
    loadUserId()
  }
  fitLater()
})

onUnmounted(() => {
  stopPoll()
  closeLog()
  window.removeEventListener('resize', fitPane)
})
</script>

<template>
  <div class="topbar">
    <!-- 대상 고르기 — 한 덩어리로 붙인 탭. 두 개가 <따로 노는 단추> 로 보이면
         지금 어느 쪽을 보고 있는지가 안 읽힌다. 고른 쪽만 밑줄로 못을 박는다. -->
    <span class="modetabs" role="tablist">
      <button
        role="tab"
        :aria-selected="mode === 'mine'"
        :class="{ on: mode === 'mine' }"
        title="보고 있는 이 PC 의 개발서버 콘솔"
        @click="setMode('mine')"
      >
        내 PC
      </button>
      <button
        role="tab"
        :aria-selected="mode === 'server'"
        :class="{ on: mode === 'server' }"
        :title="`대시보드 API 가 도는 장비(${data.host || '서버'})`"
        @click="setMode('server')"
      >
        서버<span v-if="data.host" class="sub">{{ data.host }}</span>
      </button>
    </span>

    <template v-if="mode === 'server'">
      <span class="hint">
        BE {{ counts.be }}/{{ counts.beTotal }} · FE {{ counts.fe }}/{{ counts.feTotal }}
        <template v-if="data.roots?.length">
          · <code>{{ data.roots.join(' · ') }}</code>
        </template>
      </span>
      <span
        v-if="deploy.enabled"
        class="hint dephint"
        :title="`개발 서버(Docker) ${deploy.host} 의 컨테이너를 직접 두드려 본 결과입니다.\n확인 시각: ${deploy.at ? stamp(deploy.at) : '아직 없음'}\n이미지 생성 시각은 GitLab 에서 따로 읽어 옵니다 — ${deploy.imgAt ? stamp(deploy.imgAt) : '아직 없음'} 기준`"
      >
        도커 BE {{ depCounts.be }}/{{ depCounts.beN }} · FE {{ depCounts.fe }}/{{ depCounts.feN }}
      </span>
      <span class="spacer"></span>
      <!-- 갱신 — 주기와 <지금 보기> 를 한 덩어리로 묶는다.
           ⚠️ 새로고침 성격의 단추는 화면에 <이것 하나만> 둔다. 예전에는 도커 숫자 옆에도
              ⟳ 가 있었는데, 오른쪽의 [다시 훑기] 와 생김새가 같아 같은 기능으로 읽혔다.
              [다시 훑기] 는 <폴더를 다시 찾는> 전혀 다른 일이다(아래 그 단추 참고). -->
      <label
        class="pollbox"
        :title="`화면이 서버에 상태를 묻는 주기입니다 (로컬 기동 상태).\n\n도커는 ${deploy.ttl ?? 60}초, 이미지는 ${Math.round((deploy.imgTtl ?? 300) / 60)}분마다 서버가 따로 확인합니다 —\n여기를 더 짧게 해도 그보다 빨라지지 않습니다. 지금 보려면 옆의 ⟳ 를 누르세요.\n\n<멈춤> 은 저절로 묻지 않습니다. 하루 종일 켜 둘 때 쓰세요.`"
      >
        갱신
        <select :value="pollMs" @change="setPoll($event.target.value)">
          <option v-for="c in POLL_CHOICES" :key="c.ms" :value="c.ms">{{ c.label }}</option>
        </select>
      </label>
      <!-- 새로고침은 이것 하나다. 예전에는 [다시 훑기] 가 따로 있었는데 하는 일이 달라도
           생김새가 같아 같은 기능으로 읽혔다 — 그래서 <둘을 합쳐> 버렸다.
           한 번 누르면 폴더 다시 찾기 → 도커·이미지 다시 읽기 → 화면 갱신까지 한다. -->
      <button
        class="ico"
        :title="refreshHint"
        :disabled="depBusy || deploy.busy || busy.has('scan')"
        @click="refreshAll"
      >
        {{ depBusy || deploy.busy || busy.has('scan') ? '⋯' : '⟳' }}
      </button>
      <select v-model="group" title="작업공간">
        <option value="all">작업공간 전체</option>
        <option v-for="g in groups" :key="g" :value="g">{{ g }}</option>
      </select>
      <input v-model="q" type="text" placeholder="프로젝트 검색 (001, ppd002)" size="16" />
      <!-- 거르개는 <누르는 것> 이 아니라 <지금 무엇을 보고 있는가> 다. 그래서 아이콘으로
           바꾸지 않고 한 덩어리로 붙여 고른 칸만 드러낸다 — 대상 탭과 같은 결이다. -->
      <span class="seg">
        <button :class="{ on: filter === 'all' }" title="모두 보기" @click="filter = 'all'">
          전체
        </button>
        <button
          :class="{ on: filter === 'running' }"
          title="BE·FE 중 하나라도 떠 있는 것"
          @click="filter = 'running'"
        >
          실행
        </button>
        <button
          :class="{ on: filter === 'stopped' }"
          title="BE·FE 둘 다 내려가 있는 것"
          @click="filter = 'stopped'"
        >
          중지
        </button>
        <button
          :class="{ on: filter === 'problem' }"
          title="실패했거나 혼자 종료된 것"
          @click="filter = 'problem'"
        >
          문제
        </button>
      </span>
      <button
        class="ico"
        :title="
          filtering ? '거르는 중에는 접어 둔 것도 펼쳐 보여 줍니다' : '작업공간을 모두 펼칩니다'
        "
        :disabled="filtering || noneCollapsed"
        @click="setAllWs(false)"
      >
        ⊞
      </button>
      <button
        class="ico"
        :title="
          filtering ? '거르는 중에는 접어 둔 것도 펼쳐 보여 줍니다' : '작업공간을 모두 접습니다'
        "
        :disabled="filtering || allCollapsed"
        @click="setAllWs(true)"
      >
        ⊟
      </button>
      <!-- 숫자는 남긴다 — <몇 개를 내리는지> 를 모르고 누르면 안 되는 단추다 -->
      <button
        class="ico danger"
        :title="`실행 중인 것을 모두 내립니다 (FE → BE 순)${liveTargets.length ? ` — 지금 ${liveTargets.length}개` : ''}`"
        :disabled="!data.canControl || !liveTargets.length || busy.has('all')"
        @click="stopAll"
      >
        ■<span v-if="liveTargets.length" class="cnt">{{ liveTargets.length }}</span>
      </button>
    </template>

    <template v-else-if="mode === 'mine'">
      <span class="badge" :class="probeState">
        {{
          probeState === 'up'
            ? '콘솔 연결됨'
            : probeState === 'checking'
              ? '확인 중…'
              : probeState === 'down'
                ? '콘솔 꺼짐'
                : '확인 전'
        }}
      </span>
      <span class="spacer"></span>
      <a
        class="btnlink"
        href="/api/dev/console.zip"
        title="이 PC 에 깔 콘솔 한 벌 (dev-ui.bat + tools/devserver)"
        download
      >
        ⤓ 콘솔 내려받기
      </a>
      <label class="portbox">
        포트
        <input v-model="portInput" type="text" size="5" @keyup.enter="applyPort" @blur="applyPort" />
      </label>
      <!-- 여기도 아이콘으로 — 다만 [콘솔 내려받기] 만은 글자를 남긴다.
           콘솔을 아직 안 깐 사람이 처음 만나는 단추라, 기호만 두면 어디서 받는지 알 수 없다. -->
      <button class="ico" title="콘솔이 떠 있는지 다시 확인한다" @click="probe">⟲</button>
      <button
        v-if="probeState === 'up' || forced"
        class="ico"
        title="콘솔 화면을 다시 읽는다"
        @click="frameKey += 1"
      >
        ⟳
      </button>
      <a
        class="btnlink ico"
        :href="consoleUrl()"
        target="_blank"
        rel="noopener"
        title="새 탭에서 전체 화면으로"
      >
        ↗
      </a>
    </template>
  </div>

  <!-- 이 띠는 <대시보드에 닿지 않는다> 는 상태다. 동작의 결과는 토스트로 간다(아래). -->
  <p v-if="err && mode === 'server'" class="panel warnbox">
    {{ err }} <button class="mini" @click="err = ''">닫기</button>
  </p>

  <!-- 누른 것의 결과 — 오른쪽 아래에 잠깐 떴다 사라진다. 누르면 바로 치운다. -->
  <div v-if="toasts.length" class="toasts">
    <div
      v-for="t in toasts"
      :key="t.id"
      class="toast"
      :class="t.kind"
      :title="t.text"
      @click="dropToast(t.id)"
    >
      {{ t.text }}
    </div>
  </div>

  <!-- ================= 내 PC ================= -->
  <!-- 바깥은 안 넘치고 iframe 안에서만 스크롤되도록 제 자리에서 바닥까지 재어 높이를 준다 -->
  <div v-if="mode === 'mine'" ref="paneEl" class="pane" :style="paneH ? { height: paneH + 'px' } : null">
    <!-- ⚠️ sandbox 를 걸지 말 것 — 콘솔이 상태·로그를 EventSource(SSE)로 받고 [전체 중지]에서
         confirm() 을 쓴다. 걸어야 한다면 allow-scripts allow-same-origin allow-modals 가 함께 필요하다. -->
    <iframe
      v-if="probeState === 'up' || forced"
      :key="frameKey"
      class="frame"
      :src="consoleUrl()"
      title="로컬 개발서버 콘솔"
    ></iframe>

    <div v-else-if="probeState === 'checking' || probeState === 'idle'" class="panel guide muted">
      이 PC 의 콘솔을 찾는 중…
    </div>

    <div v-else class="panel guide">
      <p class="lead">
        이 PC 의 <code>{{ consoleUrl() }}</code> 에 개발서버 콘솔이 떠 있지 않습니다.
      </p>
      <ol>
        <li>
          <a class="dl" href="/api/dev/console.zip" download>⤓ 콘솔 내려받기</a>
          <span class="sub muted">
            (<code>mm-dev-ui.zip</code> — <code>dev-ui.bat</code> 과
            <code>tools\devserver</code> 가 들어 있습니다. 서버의 원본을 그때그때 담아 주므로 낡지
            않습니다.)
          </span>
        </li>
        <li>
          소스를 받아 둔 폴더(<code>PMM001</code>, <code>PMM002</code> … 가 있는 폴더)에 통째로
          풉니다
          <div class="sub muted">
            경로는 PC 마다 달라도 됩니다 — <code>{{ CMD }}</code> 이 자기 위치에서 소스 루트를
            찾습니다. 자세한 것은 zip 안의 <code>INSTALL.txt</code> 에 있습니다.
          </div>
        </li>
        <li>
          <code>{{ CMD }}</code> 실행
          <button class="mini" @click="copyCmd">복사</button>
          <span v-if="copied" class="ok">복사함</span>
          <div class="sub muted">
            창은 켜 둡니다 — 닫으면 그 콘솔이 띄운 개발서버도 같이 내려갑니다. 포트를 바꾸려면
            <code>dev-ui.bat 4700</code> 처럼 붙이고 위 <b>포트</b> 칸도 같이 바꿉니다.
          </div>
        </li>
        <li><button class="mini" @click="probe">다시 확인</button> 을 누릅니다</li>
      </ol>
      <p class="muted">
        이 칸은 <b>보고 있는 PC</b> 의 콘솔에 붙습니다. 대시보드 서버가 대신 띄워 주는 것이 아니라
        각자 제 PC 에서 한 번 켜 두어야 합니다.
      </p>
      <p class="muted">
        분명히 켰는데도 꺼짐으로 나오면 — 브라우저가 회사 서버 페이지에서 내 PC 로 나가는 확인
        요청을 막은 것일 수 있습니다.
        <button class="mini" @click="forced = true">그래도 화면 띄우기</button>
        로 직접 열어 보고, 그래도 비면 <b>↗ 새 탭</b> 으로 엽니다.
      </p>
    </div>

  </div>

  <!-- ================= 서버 ================= -->
  <template v-else-if="mode === 'server'">
    <p v-if="!data.rootOk" class="panel warnbox">
      소스 폴더 <code>{{ data.root }}</code> 가 없습니다. 서버의
      <code>api/appsettings.json</code> 에 <code>"Dev": { "Root": "…" }</code> 를 적고 API 를
      재시작하세요.
    </p>
    <p v-else-if="!data.canControl && data.why" class="panel warnbox">
      {{ data.why }}
      <br />
      <b>내 PC</b> 를 누르면 이 PC 에서 직접 띄울 수 있습니다.
    </p>

    <!-- 로그인 사번 — PMM001 BE 의 .env.properties 의 USER_ID 한 줄을 바꾼다.
         머리줄에 넣지 않고 제 띠를 쓴다. 머리줄은 이미 꽉 찼고, 무엇보다 <어느 장비의 어느 파일>
         인지를 같이 보여 줘야 하는 단추다 — 기호 하나로 줄여 둘 수 없다. -->
    <div class="panel userbar">
      <span class="ub-l">로그인 사번</span>
      <!-- ⚠️ select 가 아니라 input + datalist 다 — 명부에 없는 사번도 쳐 넣을 수 있어야 한다 -->
      <input
        v-model="uidInput"
        class="ub-in"
        type="text"
        list="uid-list"
        size="12"
        autocomplete="off"
        spellcheck="false"
        placeholder="선택 또는 입력"
        :disabled="!data.canControl"
        title="개발자를 고르거나 사번을 직접 입력합니다"
        @keyup.enter="applyUserId"
      />
      <datalist id="uid-list">
        <option v-for="d in uidDevs" :key="d.bpId" :value="d.bpId" :label="d.name"></option>
      </datalist>
      <button
        class="mini"
        :class="{ on: uidDirty }"
        :disabled="!data.canControl || uidBusy || !uidInput.trim()"
        :title="
          data.canControl
            ? `${uid.file} 의 USER_ID 를 바꿉니다.\n떠 있는 BE 에는 바로 먹지 않습니다 — ↻ 로 재기동해야 합니다.`
            : data.why
        "
        @click="applyUserId"
      >
        {{ uidBusy ? '반영 중…' : '사용자 반영' }}
      </button>
      <!-- 이름 앞의 빈칸은 보간으로 넣는다 — 글자 사이에 두면 템플릿 컴파일에서 눌려 없어진다 -->
      <span v-if="uid.ok" class="ub-cur" :class="{ dirty: uidDirty }">
        현재 <b>{{ uid.userId }}</b>{{ uidName ? ` ${uidName}` : '' }}
      </span>
      <span v-else class="ub-cur ng">{{ uid.message || '읽지 못했습니다' }}</span>
      <span class="ub-sp"></span>
      <!-- 어느 장비의 어느 파일인지 — 이 띠에서 가장 중요한 글자다. 내 PC 가 아니다. -->
      <span class="ub-path" :title="`${uid.file}${uid.line ? ` (${uid.line}줄)` : ''}`">
        <b>{{ data.host || '서버' }}</b> · <code>{{ uid.file }}</code>
      </span>
    </div>

    <!-- 작업공간별 묶음 · 프로젝트 카드 -->
    <!-- 받는 곳은 칸 전체다 — 칸이 길어 머리줄만 받으면 겨누기가 어렵다.
         손잡이(draggable)는 머리줄에만 둔다. -->
    <section
      v-for="g in grouped"
      :key="g.name"
      class="panel ws"
      :class="{ wsdrag: wsDragFrom === g.name, wsover: wsDragOver === g.name && wsDragFrom !== g.name }"
      @dragover.prevent="wsDragOver = g.name"
      @drop.prevent="wsDrop(g.name)"
    >
      <h3
        class="wsh"
        draggable="true"
        title="끌어서 작업공간 차례를 바꿉니다 (▲▼ 로도 됩니다 · 이 브라우저에 기억합니다)"
        @dragstart="wsDragStart(g.name, $event)"
        @dragend="wsDragEnd"
      >
        <!-- 접고 펴는 것은 이 삼각형만 한다. 머리줄 전체가 받으면 이름을 긁어 복사하거나
             옆 단추를 겨누다 빗맞았을 때도 접혀 버린다. -->
        <button
          class="caret"
          type="button"
          :title="wsOpen(g.name) ? '접기' : '펼치기'"
          @click="toggleWs(g.name)"
        >
          {{ wsOpen(g.name) ? '▾' : '▸' }}
        </button>
        {{ g.name }}
        <!-- 접힌 채로도 읽히도록 — 머리줄 하나로 그 작업공간의 상태가 끝나야 한다 -->
        <span class="hint">
          {{ g.list.length }}개
          <template v-if="deploy.enabled && g.imgN">
            · 이미지 {{ g.imgOk }}/{{ g.imgN }}
          </template>
          <template v-if="deploy.enabled && g.dkN"> · 도커 {{ g.dkUp }}/{{ g.dkN }} </template>
          · 로컬 B {{ g.be }}/{{ g.beTotal }} F {{ g.fe }}/{{ g.feTotal }}
        </span>
        <span
          v-if="g.imgBusy"
          class="gwarn busy"
          :title="`지금 빌드가 도는 칸 ${g.imgBusy}개 — 잘못된 것이 아닙니다.`"
          >빌드중 {{ g.imgBusy }}</span
        >
        <span
          v-if="g.imgBad"
          class="gwarn"
          :title="`마지막 빌드가 실패·취소된 칸 ${g.imgBad}개 — 펼쳐서 이미지 알약을 보세요.`"
          >빌드 실패 {{ g.imgBad }}</span
        >
        <span
          v-if="g.stale"
          class="gwarn"
          :title="`이미지는 더 새것인데 컨테이너가 안 올라간 칸 ${g.stale}개.`"
          >안 올라감 {{ g.stale }}</span
        >
        <span
          v-if="g.dkDown"
          class="gwarn"
          :title="`도커에 안 떠 있는 칸 ${g.dkDown}개 (주소를 아는 것 중).`"
          >안 뜸 {{ g.dkDown }}</span
        >
        <button
          :title="`이 작업공간의 be·fe 저장소를 모두 git pull (${g.list.length}개 프로젝트)`"
          :disabled="!data.canControl || busy.has(`ws:${g.name}`)"
          @click.stop="pullGroup(g)"
        >
          ⤓
        </button>
        <button
          class="cmdbtn"
          :title="`작업공간 폴더를 VS Code 로 열기 — ${g.dir || g.name}`"
          :disabled="!data.canControl || busy.has(`ws:${g.name}`)"
          @click.stop="openGroupCode(g)"
        >
          {}
        </button>
        <span class="sp"></span>
        <button class="mv" title="위로" :disabled="wsFirst(g.name)" @click.stop="moveWs(g.name, -1)">
          ▲
        </button>
        <button class="mv" title="아래로" :disabled="wsLast(g.name)" @click.stop="moveWs(g.name, 1)">
          ▼
        </button>
      </h3>

      <div v-show="wsOpen(g.name)" class="cards">
        <div v-for="p in g.list" :key="p.id" class="card" :class="{ live: rowLive(p) }">
          <div class="ch">
            <!-- 번호만 있으면 외운 사람만 읽는다 — FE 의 VITE_APP_TITLE 을 붙여 둔다 (api/DevRun.cs).
                 쓸 만한 이름이 없는 프로젝트(본보기 값·빈 값)는 예전처럼 번호만 보인다. -->
            <b class="nm">{{ p.label }}</b>
            <span v-if="p.title" class="ttl" :title="p.title">{{ p.title }}</span>
            <span class="sp"></span>
            <button
              :title="`이 프로젝트의 be·fe 를 모두 git pull`"
              :disabled="!data.canControl || busy.has(`${p.id}:pair`)"
              @click="pullProject(p)"
            >
              ⤓
            </button>
            <button
              class="cmdbtn"
              :title="`프로젝트 폴더를 VS Code 로 열기 — ${p.dir || p.label}`"
              :disabled="!data.canControl || busy.has(`${p.id}:pair`)"
              @click="openProjectCode(p)"
            >
              {}
            </button>
            <button
              class="pair"
              :title="pairHint(p)"
              :disabled="!data.canControl || busy.has(`${p.id}:pair`) || !pairAll(p).length"
              @click="restartPair(p)"
            >
              ▶▶
            </button>
            <button
              class="pair"
              title="BE·FE 함께 중지 (FE → BE 순)"
              :disabled="!data.canControl || busy.has(`${p.id}:pair`) || !pairStoppable(p).length"
              @click="stopPair(p)"
            >
              ■■
            </button>
          </div>

          <div v-for="tier in ['be', 'fe']" :key="tier" class="tier" :class="tier">
            <!-- B / F — 줄 위 모서리에 걸쳐 놓아 가로 자리를 거의 쓰지 않는다.
                 글자는 줄었어도 풍선말로 뜻은 남긴다. -->
            <span class="tg" :title="tier === 'be' ? 'BE (백엔드)' : 'FE (프런트엔드)'">{{
              tier === 'be' ? 'B' : 'F'
            }}</span>

            <!-- ① 이미지 · ② 도커 · ③ 로컬 순. 흐름이 그 순서다 —
                 GitLab 이 굽고, 개발 서버가 올리고, 그 다음이 내 손에서 도는 것이다.
                 이 세 칸은 p[tier] 가 없어도(= 여기서 못 돌리는 폴더) 그대로 보여 준다. -->
            <!-- ⚠️ 그 tier 자체가 없는 프로젝트(짝이 없는 저장소)는 <칸만 비워> 둔다.
                 알약을 그리면 없는 것이 <이상> 으로 읽힌다. 폭은 남겨야 줄이 안 어긋난다. -->
            <!-- 알약 세 칸 — 이미지 · 도커 · 로컬. 모두 같은 짜임이다:
                 위에 알약, 아래 한 줄. 아래 줄은 <비어 있어도 자리를 지킨다>(&nbsp;) —
                 그래야 세 알약의 가로줄이 어느 줄에서나 같은 높이로 선다. -->
            <span v-if="deploy.enabled" class="depcell" :title="imgTitle(p, tier, dep(p, tier))">
              <template v-if="dep(p, tier)">
                <a
                  v-if="imgOf(p, tier)?.url"
                  class="dep"
                  :class="clsOf(imgOf(p, tier))"
                  :href="imgOf(p, tier).url"
                  target="_blank"
                  rel="noopener"
                  >{{ imgShort(imgOf(p, tier)) }}</a
                >
                <span v-else class="dep" :class="clsOf(imgOf(p, tier))">{{
                  deploy.imgAt ? imgShort(imgOf(p, tier)) : '…'
                }}</span>
              </template>
              <span v-else class="dep hollow"></span>
              <span class="depwhen">{{
                (dep(p, tier) && imgOf(p, tier)?.at && shortStamp(imgOf(p, tier).at)) || ' '
              }}</span>
            </span>

            <span v-if="deploy.enabled" class="depcell" :title="dkTitle(p, tier, dep(p, tier))">
              <template v-if="dep(p, tier)">
                <a
                  v-if="dkOf(p, tier)?.pub"
                  class="dep"
                  :class="clsOf(dkOf(p, tier))"
                  :href="dkOf(p, tier).pub"
                  target="_blank"
                  rel="noopener"
                  >{{ dkShort(dkOf(p, tier)) }}</a
                >
                <span v-else class="dep" :class="clsOf(dkOf(p, tier))">{{
                  deploy.at ? dkShort(dkOf(p, tier)) : '…'
                }}</span>
              </template>
              <span v-else class="dep hollow"></span>
              <!-- 시각은 <바뀌는 것을 본> 때만 적는다. 못 봤으면 비워 두고 풍선말이 까닭을 말한다 —
                   이미지 시각을 대신 끌어다 쓰면 안 올린 것이 올린 것처럼 보인다. -->
              <span
                v-if="dep(p, tier)?.stale"
                class="depwhen drift"
                >안 올라감<b class="driftmk">!</b></span
              >
              <span v-else-if="dkWhen(dkOf(p, tier))" class="depwhen">{{
                shortStamp(dkWhen(dkOf(p, tier)))
              }}</span>
              <span v-else-if="dkOf(p, tier)?.portGuessed" class="depwhen dim"
                >추정 {{ dkOf(p, tier).port }}</span
              >
              <span v-else class="depwhen">&nbsp;</span>
            </span>

            <template v-if="p[tier]">
              <!-- 로컬도 같은 짜임 — 알약 아래에 포트. 실행 중이면 알약 자체가 <브라우저로 열기> 다
                   (곁에 ↗ 를 따로 두지 않는다). PID 는 칸 밖 오른쪽에 둔다. -->
              <span class="depcell">
                <a
                  v-if="['running', 'external'].includes(p[tier].status)"
                  class="dep open"
                  :class="st(p[tier]).cls"
                  :href="urlOf(p[tier])"
                  target="_blank"
                  rel="noopener"
                  :title="`브라우저로 열기 — ${urlOf(p[tier])}`"
                  >{{ st(p[tier]).label }}</a
                >
                <span v-else class="dep" :class="st(p[tier]).cls">{{ st(p[tier]).label }}</span>
                <span class="depwhen">
                  <template v-if="p[tier].port">
                    {{ p[tier].port
                    }}<b
                      v-if="p[tier].dup"
                      class="driftmk"
                      title="다른 프로젝트도 같은 포트를 적어 두었습니다 — 한 번에 하나만 뜰 수 있고, 떠 있어도 어느 쪽인지 가릴 수 없습니다."
                      >!</b
                    >
                  </template>
                  <template v-else>—</template>
                </span>
              </span>
              <span class="pid">{{ p[tier].pid ? `#${p[tier].pid}` : '' }}</span>


              <span class="sp"></span>

              <span class="act">
                <!-- ▶ 하나로 기동과 재기동을 겸한다.
                     서버의 restart 는 <중지 → 800ms → 기동> 인데(DevRun.RestartAsync),
                     멈춰 있을 때의 중지는 자식도 포트 주인도 없어 그냥 지나간다. 그래서
                     <멈춰 있으면 기동, 떠 있으면 재기동> 이 한 동작으로 성립한다.
                     예전의 ▶(기동)은 떠 있으면 눌리지 않아 늘 ↻ 를 눌러야 했다 — 둘을 합쳤다. -->
                <button
                  :title="restartHint(p[tier])"
                  :disabled="
                    !data.canControl || busy.has(`${p.id}:${tier}`) || busy.has(`${p.id}:pair`)
                  "
                  @click="one('restart', p[tier])"
                >
                  ▶
                </button>
                <button
                  :title="p[tier].status === 'external' ? '포트 주인 강제 종료' : '중지'"
                  :disabled="
                    !data.canControl ||
                    busy.has(`${p.id}:${tier}`) ||
                    busy.has(`${p.id}:pair`) ||
                    !STOPPABLE(p[tier])
                  "
                  @click="p[tier].status === 'external' ? killPort(p[tier]) : one('stop', p[tier])"
                >
                  ■
                </button>
                <button
                  title="git pull — 이 폴더에서 받아 옵니다 (받아 온 내용은 ≡ 로그에)"
                  :disabled="
                    !data.canControl || busy.has(`${p.id}:${tier}`) || busy.has(`${p.id}:pair`)
                  "
                  @click="pull(p[tier])"
                >
                  ⤓
                </button>
                <button
                  class="cmdbtn"
                  title="이 폴더에서 명령창 열기 (창은 서버 장비 화면에 뜹니다)"
                  :disabled="!data.canControl || busy.has(`${p.id}:${tier}`)"
                  @click="openCmd(p[tier])"
                >
                  &gt;_
                </button>
                <button
                  class="cmdbtn"
                  title="이 폴더를 VS Code 로 열기 (code . — 편집기는 서버 장비 화면에 뜹니다)"
                  :disabled="!data.canControl || busy.has(`${p.id}:${tier}`)"
                  @click="openCode(p[tier])"
                >
                  {}
                </button>
                <button title="로그" @click="openLog(p[tier])">≡</button>
                <!-- 브라우저로 여는 ↗ 는 없앴다 — 왼쪽 <실행중> 알약이 곧 그 링크다. -->
              </span>
            </template>

            <template v-else>
              <span class="none">
                없음<template v-if="p[tier + 'Why']"> — {{ p[tier + 'Why'] }}</template>
              </span>
              <!-- 이미지·도커 칸은 이 분기 <바깥> 에 있다 — 여기서 못 돌린다고 배포까지
                   없는 것은 아니기 때문이다(받아 두지 않은 폴더도 개발 서버에는 떠 있다). -->
              <span class="sp"></span>
              <!-- 못 돌려도 폴더는 있다 — 받아오면 돌릴 수 있게 되는 경우가 대부분이라
                   git pull 과 편집기는 그대로 준다 -->
              <span v-if="p[tier + 'Dir']" class="act">
                <button
                  :title="`git pull — ${p[tier + 'Dir']}`"
                  :disabled="!data.canControl || busy.has(`${p.id}:${tier}`)"
                  @click="pull({ id: p.id, tier })"
                >
                  ⤓
                </button>
                <button
                  class="cmdbtn"
                  :title="`이 폴더를 VS Code 로 열기 — ${p[tier + 'Dir']}`"
                  :disabled="!data.canControl || busy.has(`${p.id}:${tier}`)"
                  @click="openCode({ id: p.id, tier })"
                >
                  {}
                </button>
              </span>
            </template>
          </div>

          <!-- 사유는 문제일 때만 — 정상 중지의 "중지됨" 은 옆의 <중지> 표시와 겹친다 -->
          <div
            v-for="tier in ['be', 'fe']"
            :key="`m-${tier}`"
            v-if="p[tier]?.message && ['failed', 'exited'].includes(p[tier].status)"
            class="cmsg"
            :title="p[tier]?.message"
          >
            {{ tier === 'be' ? 'BE' : 'FE' }} · {{ p[tier]?.message }}
          </div>
        </div>
      </div>
    </section>

    <p v-if="!rows.length" class="panel empty">조건에 맞는 프로젝트가 없습니다.</p>

  </template>

  <!-- 로그 (서버 모드)
       끌어 옮기는 중에 손을 떼면 그것이 배경 클릭으로 읽혀 창이 닫혔다 — moving 일 때는 닫지 않는다. -->
  <div v-if="log" class="mask" @click.self="logDrag.moving.value || closeLog()">
    <div class="dlg" :class="{ moving: logDrag.moving.value }" :style="logDrag.style.value">
      <!-- 머리글을 잡으면 창이 따라온다. 단추를 누른 것은 끌기로 보지 않는다(dragmove.js). -->
      <h3 class="grab" @pointerdown="logDrag.start($event)">
        <span class="hgrip" title="여기를 잡아 창을 옮깁니다">⠿</span>
        {{ log.id.toUpperCase() }} · {{ log.tier.toUpperCase() }} · 포트 {{ log.port }}
        <span class="path">{{ log.dir }}</span>
        <span class="spacer"></span>
        <button v-if="logDrag.moved()" class="mini" title="창을 원래 자리로" @click="logDrag.reset()">⌖</button>
        <button class="mini" @click="clearLog">비우기</button>
        <button class="mini" @click="closeLog">닫기</button>
      </h3>
      <pre ref="logBox" class="log"><template v-for="l in log.lines" :key="l[0]"><span :class="l[2]">{{ l[3] }}</span>
</template><span v-if="!log.lines.length" class="dim">아직 로그가 없습니다.</span></pre>
    </div>
  </div>
</template>

<style scoped>
.topbar { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
.topbar .spacer { flex: 1; }
.hint code { font-size: 11px; }
button.danger:hover { border-color: var(--warn); color: var(--warn); }
button:disabled { opacity: 0.4; cursor: default; }
button:disabled:hover { border-color: var(--line); color: inherit; }

/* 대상 탭 — 두 칸을 한 덩어리로 붙이고, 고른 쪽만 밑줄로 못을 박는다.
   전역 button.on(파란 배경)을 쓰지 않는 까닭 — 머리줄에 이미 [전체]·[실행중] 같은
   파란 단추가 여럿이라, 같은 모양이면 <거르개> 와 <대상 전환> 이 한 줄에 섞여 읽힌다. */
.modetabs {
  display: inline-flex; align-items: stretch; margin-right: 8px;
  border-bottom: 1px solid var(--line);
}
.modetabs button {
  display: flex; align-items: baseline; gap: 5px;
  border: 0; border-bottom: 2px solid transparent; border-radius: 0;
  background: transparent; padding: 3px 12px 4px; margin-bottom: -1px;
  color: var(--muted); font-size: 12.5px; white-space: nowrap;
}
.modetabs button:hover { color: var(--accent); border-bottom-color: var(--line); }
.modetabs button.on {
  background: transparent; color: var(--text, inherit); font-weight: 600;
  border-bottom-color: var(--accent);
}
.modetabs .sub { font-size: 10.5px; font-weight: 400; color: var(--muted); }

.btnlink {
  border: 1px solid var(--line); background: var(--panel); border-radius: 6px;
  padding: 4px 10px; text-decoration: none; color: inherit; white-space: nowrap;
}
.btnlink:hover { border-color: var(--accent); color: var(--accent); }

.badge {
  white-space: nowrap; font-size: 11px; border: 1px solid var(--line);
  border-radius: 999px; padding: 1px 8px; color: var(--muted);
}
.badge.up { color: var(--done); border-color: var(--done); background: var(--done-soft); }
.badge.down { color: var(--warn); border-color: var(--warn); }
/* 아이콘 단추 — 글자 없이 기호만. 뜻은 풍선말이 지고, 폭은 정사각에 가깝게 잡아
   머리줄에서 <누르는 것> 끼리 크기가 같아 보이게 한다. */
.topbar button.ico,
.topbar .btnlink.ico {
  min-width: 28px; padding: 3px 7px; font-size: 13px; line-height: 1.25;
  display: inline-flex; align-items: center; justify-content: center; gap: 3px;
}
.topbar button.ico .cnt {
  font-size: 10px; line-height: 1; font-variant-numeric: tabular-nums;
}
.topbar button.ico.danger:not(:disabled) { color: var(--warn); border-color: var(--warn); }

/* 거르개 — 한 덩어리로 붙인 선택기. 낱낱의 단추로 보이면 <누르는 동작> 과 섞여 읽힌다. */
.seg { display: inline-flex; }
.seg button { border-radius: 0; margin-left: -1px; padding: 4px 9px; font-size: 11.5px; }
.seg button:first-child { border-radius: 6px 0 0 6px; margin-left: 0; }
.seg button:last-child { border-radius: 0 6px 6px 0; }
.seg button.on { position: relative; z-index: 1; }

.pollbox { font-size: 11px; color: var(--muted); white-space: nowrap; cursor: help; }
.pollbox select { margin-left: 4px; font-size: 11px; padding: 2px 4px; }
.portbox { font-size: 11px; color: var(--muted); white-space: nowrap; }
.portbox input { width: 56px; margin-left: 4px; }

/* 로그인 사번 띠 — 작업공간 카드 위에 한 줄. 경고 띠(warnbox)와 같은 자리에 오므로
   같은 여백을 쓰되, 경고가 아니므로 왼쪽 색 선은 두지 않는다. */
.userbar {
  display: flex; align-items: center; gap: 7px; flex-wrap: wrap;
  padding: 7px 12px; margin: 0 0 8px; font-size: 12px;
}
.userbar .ub-sp { flex: 1; }
.userbar .ub-l { font-size: 11px; color: var(--muted); white-space: nowrap; }
/* 입력칸을 text-transform 으로 올리지 않는다 — 명부에 소문자 사번(sunakim87)이 섞여 있어
   눈에 보이는 글자와 실제로 들어갈 값이 달라진다. 철자는 서버가 맞춘다. */
.userbar .ub-in {
  width: 118px; font-family: var(--mono, ui-monospace, Consolas, monospace); font-size: 12px;
}
.userbar .ub-cur { font-size: 11px; color: var(--muted); white-space: nowrap; }
.userbar .ub-cur b { font-family: var(--mono, ui-monospace, Consolas, monospace); font-weight: 600; }
/* 쳐 놓고 아직 안 누른 상태 */
.userbar .ub-cur.dirty b { color: var(--warn); }
.userbar .ub-cur.ng { color: var(--warn); white-space: normal; }
.userbar .ub-path {
  font-size: 10.5px; color: var(--muted);
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 46%;
}
.userbar .ub-path code { font-size: 10.5px; }

/* 안에서만 스크롤되게 — 높이는 화면에서 재어 넣는다(fitPane) */
.pane { display: flex; flex-direction: column; min-height: 320px; overflow: hidden; }
.pane .frame {
  flex: 1; min-height: 0; width: 100%; display: block;
  border: 1px solid var(--line); border-radius: var(--radius); background: var(--panel);
}
.pane .guide { flex: 1; min-height: 0; overflow: auto; }

.guide { padding: 14px 16px; }
.guide .lead { margin: 0 0 10px; }
.guide ol { margin: 0 0 12px; padding-left: 20px; }
.guide li { margin: 8px 0; }
.guide .sub { font-size: 11.5px; margin-top: 3px; }
.guide p.muted { margin: 6px 0 0; font-size: 12px; }
.guide .dl { font-weight: 600; }
.ok { color: var(--done); font-size: 11px; margin-left: 4px; }

.warnbox { padding: 8px 12px; margin: 0 0 8px; border-left: 3px solid var(--warn); font-size: 12px; }

/* 토스트 — 오른쪽 아래. 표 위에 떠 있지만 <누르는 것> 을 가리지 않게 폭을 묶어 둔다.
   여러 개가 겹치면 쌓인다(git pull 을 작업공간 단위로 돌리면 한꺼번에 여럿 온다). */
.toasts {
  position: fixed; right: 16px; bottom: 16px; z-index: 60;
  display: flex; flex-direction: column; gap: 6px; align-items: flex-end;
  pointer-events: none;
}
.toast {
  pointer-events: auto; cursor: pointer;
  max-width: min(460px, 46vw); padding: 7px 12px; font-size: 12px; line-height: 1.45;
  background: var(--panel); border: 1px solid var(--line); border-left: 3px solid var(--done);
  border-radius: var(--radius); box-shadow: 0 4px 14px var(--shadow);
  /* 긴 메시지(git pull 결과)도 통째로 보여 준다 — 잘라 두면 ≡ 로그를 열어야 한다 */
  white-space: pre-wrap; word-break: break-all;
  animation: toastin 0.16s ease-out;
}
.toast.ng { border-left-color: var(--warn); color: var(--warn); }
.toast:hover { border-color: var(--accent); }
@keyframes toastin {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: none; }
}
.mini { padding: 1px 7px; font-size: 11px; margin-left: 6px; }

/* ---------- 작업공간 · 카드 ---------- */
.ws { padding: 10px 12px 12px; margin-bottom: 10px; }
/* 접었을 때는 머리줄만 남는다 — 아래 여백까지 남으면 접은 표가 안 난다 */
.ws:has(.cards[style*='display: none']) { padding-bottom: 6px; }
.ws:has(.cards[style*='display: none']) .wsh { margin-bottom: 0; }
.wsh {
  display: flex; align-items: baseline; gap: 8px; margin: 0 0 8px; font-size: 12.5px;
  user-select: none;
}
/* 삼각형만 누르는 곳이다. 평소에는 테두리를 감추고 마우스를 올렸을 때만 드러낸다 —
   어디를 눌러야 접히는지 이것 말고는 알 길이 없다. 테두리 몫으로 좌우 여백을 준다. */
.wsh .caret {
  flex: none; padding: 0 4px; font-size: 10px; line-height: 1.5;
  color: var(--muted); cursor: pointer;
}
.wsh button { border-color: transparent; background: transparent; padding: 0 5px; font-size: 11px; }
.wsh button:hover:not(:disabled) { border-color: var(--accent); color: var(--accent); }
.wsh button:disabled:hover { border-color: transparent; }
.wsh .hint { font-weight: 400; font-size: 11px; color: var(--muted); }
/* 문제가 있을 때만 나오는 표 — 접어 둔 작업공간에서도 눈에 걸리게 테를 두른다 */
.wsh .gwarn {
  flex: none; font-weight: 400; font-size: 10px; line-height: 1.5; cursor: help;
  color: var(--warn); border: 1px solid var(--warn); border-radius: 999px; padding: 0 6px;
}
/* <빌드중> 은 알림이지 경고가 아니다 — 색을 달리해 섞이지 않게 한다 */
.wsh .gwarn.busy { color: var(--accent); border-color: var(--accent); }
.wsh .cmdbtn {
  padding: 0 4px; font-size: 11px; font-family: Consolas, 'Courier New', monospace;
  border-color: transparent; background: transparent;
}
.wsh .cmdbtn:hover:not(:disabled) { border-color: var(--accent); color: var(--accent); }
.wsh .cmdbtn:disabled:hover { border-color: transparent; }
.wsh .sp { flex: 1; }
/* 차례 바꾸기 — 머리줄을 끌어도 되고 이것을 눌러도 된다 ([보이는 컬럼] 과 같은 짜임) */
.wsh { cursor: grab; }
.wsh:active { cursor: grabbing; }
.wsh .mv { flex: none; padding: 0 4px; font-size: 9px; line-height: 1.6; }
.wsh .mv:disabled { opacity: 0.25; }
.ws.wsdrag { opacity: 0.45; }
.ws.wsover { outline: 2px dashed var(--accent); outline-offset: -2px; }
/* 창 너비에 맞춰 칸을 늘린다 — 프로젝트 수가 작업공간마다 크게 다르다 */
/* 줄마다 <배포> 칸이 하나 더 늘어 320 으로는 버튼이 밀린다 */
/* 한 줄에 몇 개가 들어갈지는 <최소 폭>이 정한다.
   452px 이면 1920 화면에서 3개까지라 오른쪽이 한 칸 비었다 → 400px 로 낮춰 4개가 들어간다.
   더 낮추면 1366 같은 화면에서 한 칸이 더 생기면서 카드가 좁아져 단추 줄이 접힌다. */
.cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(400px, 1fr)); gap: 8px; }
.card {
  border: 1px solid var(--line); border-radius: var(--radius);
  padding: 7px 9px 8px; background: var(--panel);
}
/* 뭔가 돌고 있는 카드는 멀리서도 눈에 띄어야 한다 */
.card.live { border-color: var(--done); box-shadow: inset 3px 0 0 var(--done); }
.card .ch { display: flex; align-items: center; gap: 3px; margin-bottom: 5px; }
.card .ch .nm { font-size: 12.5px; flex: none; }
/* 이름은 번호보다 눈에 덜 띄게 둔다 — 카드를 찾을 때 먼저 보는 것은 번호다.
   카드 폭이 좁아 긴 이름은 잘라낸다(툴팁에 전체가 있다). min-width:0 이 없으면
   flex 항목이 글자 길이만큼 버텨 오른쪽 단추들을 카드 밖으로 밀어낸다. */
.card .ch .ttl {
  font-size: 11.5px; color: var(--muted); min-width: 0;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.card .ch .ttl::before { content: '-'; margin-right: 4px; color: var(--muted-3); }
.card .ch .sp { flex: 1; }
.card .ch .pair { padding: 0 5px; font-size: 11px; letter-spacing: -1px; }
.card .ch .cmdbtn { padding: 0 3px; font-size: 11px; font-family: Consolas, 'Courier New', monospace; }

/* 왼쪽 10px 은 B/F 글자가 걸터앉을 자리다 — 흐름에서 빼 두어 칸을 차지하지 않는다 */
.tier { display: flex; align-items: center; gap: 5px; padding: 2px 0 2px 10px; font-size: 11.5px; position: relative; }
.tier + .tier { border-top: 1px dashed var(--line); }
/* 줄 위 모서리에 걸친다. 아래 줄(F)은 점선 위에 올라앉으므로 바탕색으로 선을 끊어
   일부러 그 자리에 둔 것처럼 보이게 한다 — 안 그러면 선에 글자가 찍힌 것처럼 읽힌다. */
.tier .tg {
  position: absolute; left: 0; top: -1px; z-index: 1;
  font-size: 8.5px; line-height: 1; font-weight: 700; color: var(--muted);
  background: var(--panel); padding: 0 1px 1px 0; cursor: help;
}
.tier.fe .tg { color: var(--violet); }
.tier .sp { flex: 1; }
.tier .none { color: var(--muted); font-size: 10.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tier .act { flex: none; white-space: nowrap; }
.tier .act button { padding: 0 5px; margin-right: 1px; font-size: 11px; }
.tier .act button.cmdbtn { padding: 0 3px; font-family: Consolas, 'Courier New', monospace; }

/* 카드 안의 동작 버튼은 평소에 테를 감춘다 — 한 카드에 열네 개가 늘어서면
   테두리가 격자처럼 보여 정작 봐야 할 포트·상태가 묻힌다.
   테 <너비> 는 남기고 <색> 만 지운다. 그래야 가리킬 때 칸이 밀리지 않는다. */
.card .ch button,
.tier .act button {
  border-color: transparent;
  background: transparent;
}
.card .ch button:hover:not(:disabled),
.tier .act button:hover:not(:disabled) {
  border-color: var(--accent);
  color: var(--accent);
}
/* 전역 규칙이 <못 누르는 버튼> 에도 테를 돌려주므로 여기서 다시 지운다 */
.card .ch button:disabled:hover,
.tier .act button:disabled:hover { border-color: transparent; }
.cmsg {
  margin-top: 4px; font-size: 10.5px; color: var(--warn);
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

/* 개발 서버(Docker) 배포 — 테를 점선으로 둬서 왼쪽의 <실행중> 과 한눈에 갈리게 한다.
   둘은 대상이 다르다(여기/서버 PC vs 10.100.45.110 컨테이너). 같은 알약 모양이면
   반드시 같은 것으로 읽힌다. 폭은 못 박는다 — 글자 수가 달라도 버튼 자리가 안 밀린다. */
/* 알약 아래에 시각 — 상태 칸(.stat)이 뱃지 아래 PID 를 두는 것과 같은 짜임이다.
   폭을 못 박아 어느 줄에서나 버튼 자리가 같다. */
/* 이미지 · 도커 · 로컬 세 칸이 똑같은 짜임이다 — 위에 알약, 아래 한 줄.
   폭을 못 박고 아래 줄은 비어도 자리를 지키므로(&nbsp;) 세 알약이 어느 줄에서나
   같은 높이에 나란히 선다. 이것이 없으면 시각이 있는 줄만 알약이 위로 밀려 들쭉날쭉해진다. */
.tier .depcell {
  flex: none; width: 62px; display: flex; flex-direction: column; align-items: center; gap: 1px;
}
.tier .dep {
  width: 100%; text-align: center; white-space: nowrap; overflow: hidden;
  font-size: 10.5px; line-height: 1.6; padding: 0 3px;
  border: 1px dashed var(--line); border-radius: 999px;
  color: var(--muted); text-decoration: none; cursor: help;
}
/* 그 tier 자체가 없는 프로젝트 — 알약 자리만 비워 둔다(줄이 어긋나지 않게) */
.tier .dep.hollow { border-color: transparent; }
/* 로컬 알약은 <여기서 띄우고 내리는 것> 이라 이미지·도커(점선)와 테를 달리한다 */
.tier .depcell:last-of-type .dep { border-style: solid; }
.tier .dep.wait { color: var(--accent); border-color: var(--accent); background: var(--accent-soft); }
.tier .dep.ext { color: var(--violet); border-color: var(--violet); }
.tier a.dep.open:hover { text-decoration: underline; }
/* 알약 아래 한 줄 — 이미지 칸은 구운 시각, 도커 칸은 <반영된 것을 본> 시각이다.
   도커 칸이 비어 있는 것은 아직 바뀌는 것을 못 봤다는 뜻이다(풍선말이 까닭을 말한다). */
.tier .depwhen {
  font-size: 9.5px; line-height: 1.1; color: var(--muted);
  font-variant-numeric: tabular-nums; white-space: nowrap; cursor: help;
}
.tier .depwhen.drift { color: var(--warn); }
.tier .depwhen .driftmk { color: var(--warn); }
.tier a.dep { cursor: pointer; }
.tier a.dep:hover { border-style: solid; }
.tier .dep.ok { color: var(--done); border-color: var(--done); }
.tier .dep.ng { color: var(--warn); border-color: var(--warn); }
.tier .dep.off { color: var(--muted); }
/* <주소 모름 · 포트 겹침> — 장애가 아니라 <우리가 모른다> 는 것이다. 테까지 지워
   눈에 안 띄게 둔다. 이것이 빨갛거나 회색 알약으로 보이면 멀쩡한 것을 장애로 읽는다. */
.tier .dep.dimpill { color: var(--muted); border-color: transparent; opacity: 0.55; }
.tier .dep.none { border-color: transparent; }
.dephint { white-space: nowrap; }
.dephint .mini { margin-left: 3px; }

.dim { color: var(--muted); }
.empty { text-align: center; color: var(--muted); padding: 18px; }

/* 상태 칸 — 뱃지 아래 PID. 폭을 못 박아 어느 줄이나 버튼 자리가 같다 */
/* 실행 프로세스 번호 — 로컬 칸 바로 오른쪽. 폭을 못 박아 비어 있어도 버튼 자리가 안 밀린다 */
.tier .pid {
  flex: none; width: 36px; font-size: 9.5px; color: var(--muted);
  font-variant-numeric: tabular-nums; white-space: nowrap; overflow: hidden;
}
.msg {
  display: inline-block; max-width: 100px; margin-left: 6px; vertical-align: bottom;
  font-size: 11px; color: var(--warn); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
/* 떠 있는 것의 알약은 그 자체가 <브라우저로 열기> 다 (예전의 ↗ 를 없앴다).
   테 색은 상태(.ok/.ext)가 정하므로 여기서는 손대지 않는다 — 가리킬 때만 밑줄로 알린다. */


.mask {
  position: fixed; inset: 0; background: var(--shadow-2);
  display: flex; align-items: center; justify-content: center; z-index: 50;
}
.dlg {
  background: var(--panel); border-radius: var(--radius); width: min(1000px, 94vw);
  height: min(680px, 88vh); display: flex; flex-direction: column; padding: 12px 14px;
}
.dlg h3 { display: flex; align-items: center; gap: 6px; margin: 0 0 8px; font-size: 13px; }
/* 머리글을 잡아 옮긴다. touch-action: none 이 없으면 터치·펜에서 브라우저가 스크롤로 가로챈다. */
.dlg h3.grab { cursor: move; user-select: none; touch-action: none; }
.dlg h3 .hgrip { color: var(--muted); font-size: 12px; letter-spacing: -1px; }
/* 옮기는 중에는 그림자를 키워 <떠 있는 창> 으로 읽히게 한다 */
.dlg.moving { box-shadow: 0 14px 40px var(--shadow-2); }
.dlg .path { font-weight: 400; font-size: 11px; color: var(--muted); }
.dlg .spacer { flex: 1; }
.log {
  flex: 1; margin: 0; overflow: auto; background: #1c2024; color: #d7dde3;
  border-radius: var(--radius); padding: 10px 12px; font-size: 11.5px; line-height: 1.45;
  white-space: pre-wrap; word-break: break-all;
}
.log .err { color: #ff9a8a; }
.log .sys { color: #7fd1a8; }
</style>
