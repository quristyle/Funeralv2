<script setup>
import { computed } from 'vue'
import HeatMatrix from '../components/HeatMatrix.vue'
import RefreshBtn from '../components/RefreshBtn.vue'
import { state, pickCell, pickWeekCell, pickRealCell, pickRealWeekCell, loadStats } from '../store'

const emit = defineEmits(['drill'])

function onMonth(p) {
  pickCell({ user: p.user, month: p.bucket })
  emit('drill')
}
function onWeek(p) {
  pickWeekCell({ user: p.user, week: p.bucket })
  emit('drill')
}
function onRealMonth(p) {
  pickRealCell({ user: p.user, month: p.bucket })
  emit('drill')
}
function onRealWeek(p) {
  pickRealWeekCell({ user: p.user, week: p.bucket })
  emit('drill')
}

// 주 열 머리글: 'W33' + 해당 주 마지막 날(월.일). 전체 날짜 범위는 툴팁으로.
function weekLabelsOf(rows) {
  const m = {}
  for (const r of rows) {
    if (m[r.bucket]) continue
    m[r.bucket] = {
      text: r.bucket.replace(/^\d+-/, ''),
      sub: r.week_end.slice(5).replace('-', '.'), // MM.DD
      title: `${r.bucket} (${r.week_start} ~ ${r.week_end})`,
    }
  }
  return m
}
const weekLabels = computed(() => weekLabelsOf(state.byUserWeek))
const realWeekLabels = computed(() => weekLabelsOf(state.byRealWeek))

const basisLabel = computed(() => (state.basis === 'edt' ? '계획종료일' : '계획시작일'))
</script>

<template>
  <!-- 담당자 기준: user_bp_id + complate_yn -->
  <section class="panel">
    <h2>
      월단위 담당자별 건수
      <span class="hint">
        {{ basisLabel }} 기준 · <code>user_bp_id</code> / 완료 <code>complate_yn</code> ·
        셀 클릭 시 상세 목록으로 이동
      </span>
      <span class="spacer"></span>
      <RefreshBtn :fn="loadStats" />
    </h2>
    <HeatMatrix :rows="state.byUser" col-head="월" @pick="onMonth" />
  </section>

  <section class="panel">
    <h2>
      주단위 담당자별 건수
      <span class="hint">{{ basisLabel }} 기준 · ISO 주(월요일 시작) · 머리글 아래는 해당 주 마지막 날</span>
      <span class="spacer"></span>
      <RefreshBtn :fn="loadStats" />
    </h2>
    <HeatMatrix :rows="state.byUserWeek" :labels="weekLabels" col-head="주" @pick="onWeek" />
  </section>

  <!-- 개발자 기준: user_real_id + complate_real_yn -->
  <section class="panel real">
    <h2>
      월단위 개발자별 건수
      <span class="hint">
        {{ basisLabel }} 기준 · <code>user_real_id</code> / 완료 <code>complate_real_yn</code>
      </span>
      <span class="spacer"></span>
      <RefreshBtn :fn="loadStats" />
    </h2>
    <HeatMatrix :rows="state.byReal" col-head="월" @pick="onRealMonth" />
  </section>

  <section class="panel real">
    <h2>
      주단위 개발자별 건수
      <span class="hint">{{ basisLabel }} 기준 · ISO 주(월요일 시작)</span>
      <span class="spacer"></span>
      <RefreshBtn :fn="loadStats" />
    </h2>
    <HeatMatrix :rows="state.byRealWeek" :labels="realWeekLabels" col-head="주" @pick="onRealWeek" />
  </section>
</template>

<style scoped>
h2 .spacer { flex: 1; }
/* 개발자 기준 표는 좌측 띠로 담당자 기준과 구분 */
.panel.real { border-left: 3px solid var(--done); }
</style>
