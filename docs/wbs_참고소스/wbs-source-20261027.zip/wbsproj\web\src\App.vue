<script setup>
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import { state, refreshAll, donePct, loadMenuTree } from './store'
import { api } from './api'
import { copyText } from './pvScript'
import { MENU as ALL_MENU } from './menu'
import RefreshBtn from './components/RefreshBtn.vue'

// 접속자 표시 문구 — 등록 사용자면 성명, 서버 로컬/미등록 상태는 그 사유를 밝힌다
const meLabel = computed(() => {
  const m = state.me
  if (!m.ip) return '접속 확인 중…'
  if (m.name && m.bpId) return `${m.name} (${m.bpId})`
  if (m.reason === 'self') return '서버 로컬 접속'
  if (m.reason === 'bootstrap') return 'IP 미등록 상태 (전체 허용)'
  return '미등록 IP'
})

// 사이드바 접기 — 표가 넓은 화면에서 가로 폭을 벌기 위한 것. 선택은 브라우저에 기억한다.
function readLs(k) {
  try {
    return localStorage.getItem(k)
  } catch {
    return null
  }
}
const sideOpen = ref(readLs('wbs.side') !== 'off')
function toggleSide() {
  sideOpen.value = !sideOpen.value
  try {
    localStorage.setItem('wbs.side', sideOpen.value ? 'on' : 'off')
  } catch {
    /* 저장 못 해도 동작에는 지장 없다 */
  }
}

// ---------- 밝게 / 어둡게 ----------
//
// 처음 칠하는 것은 index.html 의 짧은 스크립트다 — 여기서 붙이면 번들이 뜨기 전까지
// 흰 화면이 한 번 번쩍인다. 여기서는 <바꾸는 것> 과 <서버에 적어 두는 것> 만 한다.
// 저장해 둔 값이 없으면 OS 설정을 따른다 (index.html 과 같은 규칙).
const THEME = { key: 'wbs.theme', pref: 'theme' }
const theme = ref(
  document.documentElement.getAttribute('data-theme')
    ?? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
)
const dark = computed(() => theme.value === 'dark')

function applyTheme(v, save = true) {
  theme.value = v === 'dark' ? 'dark' : 'light'
  document.documentElement.setAttribute('data-theme', theme.value)
  if (!save) return
  try {
    localStorage.setItem(THEME.key, theme.value)
  } catch { /* 저장 못 해도 이번 화면에서는 바뀐 채로 쓴다 */ }
  api.prefSet(THEME.pref, theme.value).catch(() => {})
}
const toggleTheme = () => applyTheme(dark.value ? 'light' : 'dark')

// ---------- 사이드바 너비 (가운데 경계선을 끌어 조절) ----------
//
// 두 군데에 적어 둔다. 쓰임새가 다르다.
//   · localStorage — 열자마자 쓴다. 서버를 기다리면 기본 너비로 한 번 그려졌다가 줄어든다.
//   · 서버(`/api/prefs/side.width`) — 다른 PC·브라우저에서 들어와도 제 너비로 열린다.
// 상세 목록의 <보이는 컬럼>(rows.cols)과 같은 방식이다. 서버에 못 적어도 조용히 낮아질 뿐이다.
const SIDE_W = { key: 'wbs.sidew', pref: 'side.width', def: 208, min: 150, max: 520 }
const clampW = (n) => Math.min(SIDE_W.max, Math.max(SIDE_W.min, Math.round(n)))

const sideW = ref((() => {
  const v = Number(readLs(SIDE_W.key))
  return Number.isFinite(v) && v > 0 ? clampW(v) : SIDE_W.def
})())
const sizing = ref(false)

/** 접었을 때는 폭이 고정이라(아이콘만) 인라인 폭을 주지 않는다 — CSS 가 정한다. */
const sideStyle = computed(() => (sideOpen.value ? { width: sideW.value + 'px' } : null))

function saveWidth() {
  try {
    localStorage.setItem(SIDE_W.key, String(sideW.value))
  } catch {
    /* 못 적어도 이번 화면에서는 그대로 쓴다 */
  }
  // 서버 저장은 끌기가 <끝났을 때> 한 번만 — 움직이는 내내 보내면 수십 번 왕복한다
  api.prefSet(SIDE_W.pref, sideW.value).catch(() => {})
}

// pointer 이벤트로 잡는다 — setPointerCapture 를 쓰면 커서가 iframe(로컬 개발서버 콘솔) 위로
// 지나가도 끌기가 끊기지 않는다. mousemove 로는 그 자리에서 놓친다.
function startResize(e) {
  if (!sideOpen.value) return
  e.preventDefault()
  sizing.value = true
  const x0 = e.clientX
  const w0 = sideW.value
  const el = e.currentTarget
  el.setPointerCapture?.(e.pointerId)

  const move = (ev) => (sideW.value = clampW(w0 + (ev.clientX - x0)))
  const up = () => {
    sizing.value = false
    el.removeEventListener('pointermove', move)
    el.removeEventListener('pointerup', up)
    el.removeEventListener('pointercancel', up)
    saveWidth()
  }
  el.addEventListener('pointermove', move)
  el.addEventListener('pointerup', up)
  el.addEventListener('pointercancel', up)
}

/** 경계선을 두 번 누르면 기본 너비로 — 너무 좁혀 놓고 되돌릴 길을 찾는 일이 없도록. */
function resetWidth() {
  sideW.value = SIDE_W.def
  saveWidth()
}

async function loadWidthFromServer() {
  try {
    const r = await api.prefGet(SIDE_W.pref)
    if (!r.stored || r.value == null) return
    const v = clampW(Number(JSON.parse(r.value)))
    if (Number.isFinite(v) && v !== sideW.value) {
      sideW.value = v
      try {
        localStorage.setItem(SIDE_W.key, String(v))
      } catch { /* 다음에 또 서버에서 읽으면 된다 */ }
    }
  } catch {
    /* 서버에 없으면 localStorage 값을 그대로 쓴다 */
  }
}
loadWidthFromServer()

// 밝게/어둡게도 다른 PC 에서 들어와도 따라오게 서버에 둔 값을 본다.
// 이 브라우저에서 <직접 고른 적이 있으면> 그쪽이 우선이다 — 지금 보는 화면이 제멋대로
// 뒤집히면 안 된다. 서버 값은 <아직 고른 적 없는 브라우저> 를 위한 것이다.
async function loadThemeFromServer() {
  if (readLs(THEME.key)) return
  try {
    const r = await api.prefGet(THEME.pref)
    if (!r.stored || r.value == null) return
    const v = JSON.parse(r.value)
    if (v === 'dark' || v === 'light') applyTheme(v, false)
  } catch {
    /* 서버에 없으면 OS 설정을 그대로 쓴다 */
  }
}
loadThemeFromServer()

// 쓸 수 있는 메뉴만 남긴다.
//  - admin: true 인 메뉴는 최고 관리자에게만
//  - state.me.denied 에 든 키는 [메뉴 권한] 화면에서 막아 둔 것
// 판정은 서버(whoami)가 내린다 — 화면은 받은 대로 가릴 뿐이다.
const MENU = computed(() => {
  const denied = new Set(state.me.denied ?? [])
  return ALL_MENU.filter((m) => (m.admin ? state.me.admin === true : true)).filter(
    (m) => !denied.has(m.key)
  )
})

// ---------- 사이드바 짜임새 (폴더 · 순서) ----------
//
// 폴더와 순서는 DB 에 있고(`dev_menu_folder` · `dev_menu.folder_id/sort_order`)
// <모두에게 같다>. 개인 설정이 아니다 — 고치는 것은 Super 뿐이고, 화면이 버튼을 감추는
// 것과 별개로 서버도 막는다 (api/Menus.cs). 접었다 편 상태만 사람마다 따로 기억한다.
//
// 코드가 가진 목록(menuList.js)이 <무엇이 있나>, DB 가 <어디에 있나> 를 말한다.
// 둘을 겹쳐 본다 — DB 에 아직 없는 메뉴(새로 만들고 sync 전)는 코드 순서 그대로 맨 뒤에 붙는다.
// 그래서 메뉴를 새로 만들어도 사이드바에서 사라지지 않는다.
const NEW_AT_END = 1_000_000

/** 편집 가능한가 — Super 이고, 사이드바가 펼쳐져 있을 때만(접힌 상태는 아이콘뿐이라 끌 수 없다). */
const canEdit = computed(() => state.me.super === true && sideOpen.value)

/** 코드의 메뉴 전부를 DB 의 자리에 앉힌 트리. 권한으로 거르기 <전> 이다. */
const fullTree = computed(() => {
  const place = state.menuTree?.place ?? {}
  const folders = state.menuTree?.folders ?? []
  const at = (key, i) => place[key] ?? { f: null, so: NEW_AT_END + i }

  const byFolder = new Map(folders.map((f) => [f.id, []]))
  const top = []
  ALL_MENU.forEach((m, i) => {
    const p = at(m.key, i)
    const row = { type: 'menu', key: m.key, so: p.so, i }
    // 지워진 폴더를 가리키고 있으면 최상위로 본다 (외래키가 막아 주지만 방어해 둔다)
    if (p.f != null && byFolder.has(p.f)) byFolder.get(p.f).push(row)
    else top.push(row)
  })

  for (const f of folders)
    top.push({ type: 'folder', id: f.id, nm: f.nm, so: f.so, i: NEW_AT_END, children: byFolder.get(f.id) })

  // 최상위는 폴더와 메뉴가 한 줄에 섞인다 — 같은 번호 공간을 나눠 쓴다.
  // 번호가 같으면 코드 순서로 가른다(새로 들어온 것끼리 흔들리지 않게).
  const bySort = (a, b) => a.so - b.so || a.i - b.i
  top.sort(bySort)
  for (const n of top) if (n.type === 'folder') n.children.sort(bySort)
  return top
})

/** 화면에 그릴 것 — 권한으로 거른다. 빈 폴더는 고칠 수 있는 사람에게만 보인다. */
const viewTree = computed(() => {
  const ok = new Set(MENU.value.map((m) => m.key))
  const look = (k) => ALL_MENU.find((m) => m.key === k)
  const out = []
  for (const n of fullTree.value) {
    if (n.type === 'menu') {
      if (ok.has(n.key)) out.push({ ...n, m: look(n.key) })
      continue
    }
    const kids = n.children.filter((c) => ok.has(c.key)).map((c) => ({ ...c, m: look(c.key) }))
    // 담긴 것이 하나도 안 보이는 폴더는 남에게는 빈 상자일 뿐이다.
    // 고칠 수 있는 사람에게는 보여야 한다 — 그래야 거기에 끌어다 넣는다.
    if (kids.length || canEdit.value) out.push({ ...n, children: kids })
  }
  return out
})

// 접힌 폴더 — 사람마다 다르므로 브라우저에 둔다 (서버에 보낼 값이 아니다)
const FOLD_KEY = 'wbs.menufold'
const folded = ref(
  (() => {
    try {
      const v = JSON.parse(readLs(FOLD_KEY) ?? '[]')
      return new Set(Array.isArray(v) ? v : [])
    } catch {
      return new Set()
    }
  })()
)
function toggleFold(id) {
  const s = new Set(folded.value)
  s.has(id) ? s.delete(id) : s.add(id)
  folded.value = s
  try {
    localStorage.setItem(FOLD_KEY, JSON.stringify([...s]))
  } catch {
    /* 못 저장해도 이번 화면에서는 동작한다 */
  }
}
/** 지금 보고 있는 화면이 든 폴더는 접혀 있어도 펼쳐 보여 준다 — 어디에 있는지 알 수 없으면 곤란하다. */
const openFolds = computed(() => {
  const here = fullTree.value.find((n) => n.type === 'folder' && n.children.some((c) => c.key === route.value))
  return (id) => !folded.value.has(id) || here?.id === id
})

// ---------- 끌어놓기로 자리 바꾸기 ----------
// 라이브러리 없이 브라우저의 끌어놓기(HTML5 drag and drop)만 쓴다 — [개발자 정보] 목차와 같은 방식.
//
// 다루는 것은 <코드의 메뉴 전부>(fullTree) 다. 화면에 보이는 것만 보내면,
// 권한으로 가려진 메뉴가 저장할 때마다 트리에서 **조용히 빠진다**.
const drag = ref(null) // { kind:'menu'|'folder', key?, id? }
const over = ref(null) // { kind, key?, id?, pos:'before'|'after'|'in' }

const isOver = (kind, idOrKey, pos) =>
  over.value?.kind === kind && over.value.pos === pos
  && (kind === 'folder' ? over.value.id === idOrKey : over.value.key === idOrKey)

function clearDrag() {
  drag.value = null
  over.value = null
}

function onDragStart(e, d) {
  if (!canEdit.value) {
    e.preventDefault()
    return
  }
  drag.value = d
  e.dataTransfer.effectAllowed = 'move'
  // 데이터가 비면 끌기를 시작조차 하지 않는 브라우저가 있다
  e.dataTransfer.setData('text/plain', d.key ?? String(d.id))
}

/** 메뉴 위 — 위/아래 절반으로 <앞/뒤> 를 가른다. */
function onOverMenu(e, key) {
  if (!drag.value || (drag.value.kind === 'menu' && drag.value.key === key)) return
  e.preventDefault()
  e.stopPropagation()
  e.dataTransfer.dropEffect = 'move'
  const r = e.currentTarget.getBoundingClientRect()
  over.value = { kind: 'menu', key, pos: e.clientY < r.top + r.height / 2 ? 'before' : 'after' }
}

/**
 * 폴더 머리 위 — 띠를 셋으로 가른다. 위 1/4 <앞>, 아래 1/4 <뒤>, 가운데 1/2 <안에 넣기>.
 * 가운데를 넓게 둔 까닭은 <안에 넣기> 가 폴더에 대고 하는 가장 흔한 동작이기 때문이다.
 * 폴더를 끌 때는 안에 넣을 수 없으므로(폴더 안의 폴더는 두지 않는다) 절반으로만 가른다.
 */
function onOverFolder(e, id) {
  if (!drag.value || (drag.value.kind === 'folder' && drag.value.id === id)) return
  e.preventDefault()
  e.stopPropagation()
  e.dataTransfer.dropEffect = 'move'
  const r = e.currentTarget.getBoundingClientRect()
  const y = (e.clientY - r.top) / r.height
  const pos =
    drag.value.kind === 'folder' ? (y < 0.5 ? 'before' : 'after')
    : y < 0.25 ? 'before'
    : y > 0.75 ? 'after'
    : 'in'
  over.value = { kind: 'folder', id, pos }
}

/** 펼쳐 둔 폴더의 빈 속 — 여기에 떨구면 그 폴더에 들어간다 (첫 메뉴를 넣을 길). */
function onOverInside(e, id) {
  if (!drag.value || drag.value.kind === 'folder') return
  e.preventDefault()
  e.stopPropagation()
  e.dataTransfer.dropEffect = 'move'
  over.value = { kind: 'folder', id, pos: 'in' }
}

function pluck(tree, d) {
  if (d.kind === 'folder') {
    const i = tree.findIndex((n) => n.type === 'folder' && n.id === d.id)
    return i < 0 ? null : tree.splice(i, 1)[0]
  }
  const i = tree.findIndex((n) => n.type === 'menu' && n.key === d.key)
  if (i >= 0) return tree.splice(i, 1)[0]
  for (const n of tree) {
    if (n.type !== 'folder') continue
    const j = n.children.findIndex((c) => c.key === d.key)
    if (j >= 0) return n.children.splice(j, 1)[0]
  }
  return null
}

function put(tree, node, t) {
  if (t.kind === 'folder') {
    const i = tree.findIndex((n) => n.type === 'folder' && n.id === t.id)
    if (i < 0) return false
    if (t.pos === 'in') {
      if (node.type === 'folder') return false // 폴더 안에 폴더는 두지 않는다
      tree[i].children.push(node)
      return true
    }
    tree.splice(t.pos === 'after' ? i + 1 : i, 0, node)
    return true
  }

  const ti = tree.findIndex((n) => n.type === 'menu' && n.key === t.key)
  if (ti >= 0) {
    tree.splice(t.pos === 'after' ? ti + 1 : ti, 0, node)
    return true
  }
  // 폴더 안의 메뉴를 가리킨 것이다
  for (const n of tree) {
    if (n.type !== 'folder') continue
    const j = n.children.findIndex((c) => c.key === t.key)
    if (j < 0) continue
    if (node.type === 'folder') {
      // 폴더를 폴더 속 메뉴 위에 떨궜다 — 그 폴더의 앞/뒤(최상위)로 받는다
      const fi = tree.indexOf(n)
      tree.splice(t.pos === 'after' ? fi + 1 : fi, 0, node)
    } else {
      n.children.splice(t.pos === 'after' ? j + 1 : j, 0, node)
    }
    return true
  }
  return false
}

async function onDrop(e) {
  e.preventDefault()
  e.stopPropagation()
  const d = drag.value
  const t = over.value
  clearDrag()
  if (!d || !t || !canEdit.value) return

  // 통째로 베껴 놓고 옮긴다 — 실패하면 손대기 전으로 그냥 돌아간다
  const tree = fullTree.value.map((n) =>
    n.type === 'folder' ? { ...n, children: [...n.children] } : { ...n }
  )
  const node = pluck(tree, d)
  if (!node) return
  if (!put(tree, node, t)) return

  await saveTree(tree)
}

/** 트리 → 화면이 쓰는 자리표. 서버가 매기는 것과 같은 규칙(10, 20, 30 …)으로 미리 맞춰 둔다. */
function asPlace(tree) {
  const folders = []
  const place = {}
  tree.forEach((n, i) => {
    const so = (i + 1) * 10
    if (n.type === 'folder') {
      folders.push({ id: n.id, nm: n.nm, so })
      n.children.forEach((c, j) => (place[c.key] = { f: n.id, so: (j + 1) * 10 }))
    } else {
      place[n.key] = { f: null, so }
    }
  })
  return { folders, place }
}

/**
 * 화면을 먼저 옮기고 서버에 보낸다 — 기다리면 놓은 것이 제자리로 돌아갔다가 다시 가는 것처럼 보인다.
 * 실패하면 서버가 가진 값으로 되돌린다. <화면만 바뀌고 저장은 안 된> 상태로 두지 않는다.
 */
async function saveTree(tree) {
  const prev = state.menuTree
  state.menuTree = asPlace(tree)
  try {
    await api.menuTreeSave(
      tree.map((n) =>
        n.type === 'folder'
          ? { type: 'folder', id: n.id, children: n.children.map((c) => c.key) }
          : { type: 'menu', key: n.key }
      )
    )
  } catch (err) {
    state.menuTree = prev
    state.error = `사이드바 저장 실패: ${err.message}`
    await loadMenuTree()
  }
}

// ---------- 폴더 ----------
async function addFolder() {
  const name = prompt('새 폴더 이름을 입력하세요')?.trim()
  if (!name) return
  try {
    await api.menuFolderAdd(name)
    await loadMenuTree()
  } catch (err) {
    state.error = `폴더 추가 실패: ${err.message}`
  }
}

async function renameFolder(f) {
  const name = prompt('폴더 이름', f.nm)?.trim()
  if (!name || name === f.nm) return
  try {
    await api.menuFolderRename(f.id, name)
    await loadMenuTree()
  } catch (err) {
    state.error = `폴더 이름 변경 실패: ${err.message}`
  }
}

async function removeFolder(f) {
  const n = f.children.length
  if (!confirm(`폴더 "${f.nm}" 을(를) 지웁니다.${n ? `\n안에 있는 메뉴 ${n}개는 바깥으로 나옵니다.` : ''}`))
    return
  try {
    await api.menuFolderDelete(f.id)
    await loadMenuTree()
  } catch (err) {
    state.error = `폴더 삭제 실패: ${err.message}`
  }
}

const route = ref(location.hash.replace(/^#\/?/, '') || 'summary')
const current = computed(
  () => MENU.value.find((m) => m.key === route.value) ?? MENU.value[0] ?? ALL_MENU[0]
)

// 막힌 화면의 주소로 바로 들어온 경우 — 사이드바에 없으니 첫 화면으로 돌린다.
// whoami 가 늦게 오므로, 권한을 알게 된 뒤에도 한 번 더 본다.
watch([MENU, route], () => {
  if (!state.me.ip) return // 아직 누구인지 모른다
  if (MENU.value.length && !MENU.value.some((m) => m.key === route.value)) {
    const drop = tabs.value.filter((k) => !MENU.value.some((m) => m.key === k))
    if (drop.length) {
      tabs.value = tabs.value.filter((k) => !drop.includes(k))
      saveTabs()
    }
    go(MENU.value[0].key)
  }
})

// ---------- 열람한 화면 탭 ----------
// 사이드바에서 고른 화면을 위쪽 탭에 쌓아 두고 탭으로 오간다.
// 화면은 <KeepAlive> 안에 있어 탭을 바꿔도 <보고 있던 그대로> 남는다
// (필터·정렬·스크롤·열어 둔 입력까지). 그래서 오갈 때 다시 조회하지 않는다.
const TAB_KEY = 'wbs.tabs'

function loadTabs() {
  try {
    const saved = JSON.parse(localStorage.getItem(TAB_KEY) || 'null')
    // 그동안 메뉴가 바뀌었을 수 있으니 아는 키만 남긴다
    if (Array.isArray(saved)) return saved.filter((k) => ALL_MENU.some((m) => m.key === k))
  } catch {
    /* 없거나 깨졌으면 지금 화면만 */
  }
  return []
}

// 새로고침해도 열어 둔 탭이 유지된다 (지금 주소의 화면은 반드시 포함)
const tabs = ref([...new Set([...loadTabs(), route.value])])

function saveTabs() {
  try {
    localStorage.setItem(TAB_KEY, JSON.stringify(tabs.value))
  } catch {
    /* 막히면 이번 세션에만 적용된다 */
  }
}

const tabMenus = computed(() => tabs.value.map((k) => MENU.value.find((m) => m.key === k)).filter(Boolean))

function onHash() {
  const key = location.hash.replace(/^#\/?/, '') || 'summary'
  route.value = key
  // 사이드바·드릴다운·북마크 어느 쪽으로 들어와도 탭에 올린다
  if (ALL_MENU.some((m) => m.key === key) && !tabs.value.includes(key)) {
    tabs.value = [...tabs.value, key]
    saveTabs()
  }
}
function go(key) {
  location.hash = `#/${key}`
}

/** 탭을 닫는다. 마지막 하나는 남긴다 — 다 닫으면 갈 곳이 없다. */
function closeTab(key) {
  if (tabs.value.length <= 1) return
  const at = tabs.value.indexOf(key)
  tabs.value = tabs.value.filter((k) => k !== key)
  saveTabs()
  // 보고 있던 탭을 닫았으면 옆 탭으로 옮긴다
  if (route.value === key) go(tabs.value[Math.min(at, tabs.value.length - 1)])
}

/** 고른 탭만 남기고 정리 */
function closeOthers(key = route.value) {
  tabs.value = [key]
  saveTabs()
  if (route.value !== key) go(key)
}

/** 오른쪽 탭 정리 — 이 탭까지만 남긴다 */
function closeRight(key) {
  const at = tabs.value.indexOf(key)
  if (at < 0) return
  const cut = tabs.value.slice(at + 1)
  if (!cut.length) return
  tabs.value = tabs.value.slice(0, at + 1)
  saveTabs()
  // 닫힌 것 중에 보고 있던 탭이 있으면 이 탭으로 옮긴다
  if (cut.includes(route.value)) go(key)
}

/** 탭 순서 바꾸기 (-1 왼쪽 / +1 오른쪽) */
function moveTab(key, dir) {
  const at = tabs.value.indexOf(key)
  const to = at + dir
  if (at < 0 || to < 0 || to >= tabs.value.length) return
  const next = [...tabs.value]
  ;[next[at], next[to]] = [next[to], next[at]]
  tabs.value = next
  saveTabs()
}

// ---------- 탭 오른쪽 버튼 메뉴 ----------
// 탭과 사이드바 메뉴에서 같은 메뉴를 띄운다. 주소 복사·새 창·순서·닫기를 한곳에 모았다.

/** 지금 주소창과 같은 모양의 절대 주소 — 쪽지·메일로 그대로 붙일 수 있게 */
const tabUrl = (key) => `${location.origin}${location.pathname}#/${key}`

const flash = ref('')
let flashTimer = 0
function say(msg) {
  flash.value = msg
  clearTimeout(flashTimer)
  flashTimer = setTimeout(() => (flash.value = ''), 2200)
}

async function copyUrl(key) {
  const url = tabUrl(key)
  const ok = await copyText(url)
  // HTTP(비보안 컨텍스트)에서는 클립보드가 막힐 수 있어 실패도 알린다
  say(ok ? `주소 복사 · ${url}` : `복사가 막혔습니다 — ${url}`)
}

/** 그 화면으로 옮긴 뒤 새로고침 — 새로고침은 <지금 보이는 화면>을 향한다 */
async function refreshTab(key) {
  if (route.value !== key) {
    go(key)
    // hashchange 는 비동기다. 라우트가 실제로 바뀌고 KeepAlive 가
    // 그 화면을 되살린 뒤에야 그 화면의 새로고침 함수가 잡힌다.
    await new Promise((r) => setTimeout(r, 0))
    await nextTick()
  }
  await refreshAll()
}

const menu = ref(null) // { key, x, y }
const menuBox = ref(null)

function openMenu(e, key) {
  menu.value = { key, x: e.clientX, y: e.clientY }
  // 그려진 뒤 실제 크기를 재서 화면 밖으로 나가지 않게 당긴다
  nextTick(() => {
    const el = menuBox.value
    const m = menu.value
    if (!el || !m) return
    const r = el.getBoundingClientRect()
    const W = window.innerWidth
    const H = window.innerHeight
    if (W > 200 && H > 200) {
      menu.value = {
        ...m,
        x: Math.max(6, Math.min(m.x, W - r.width - 6)),
        y: Math.max(6, Math.min(m.y, H - r.height - 6)),
      }
    }
  })
}
const closeMenu = () => (menu.value = null)

function runMenu(it) {
  if (it.off) return
  closeMenu()
  it.fn()
}

const menuItems = computed(() => {
  const key = menu.value?.key
  if (!key) return []
  const m = MENU.value.find((x) => x.key === key)
  const at = tabs.value.indexOf(key)
  const open = at >= 0
  const last = at >= 0 && at === tabs.value.length - 1
  const many = tabs.value.length > 1
  return [
    // 실제로는 origin 까지 붙은 절대 주소를 복사한다 (복사 후 알림에 전체를 보여 준다)
    { ic: '⧉', lb: 'URL 복사', hint: `#/${key}`, fn: () => copyUrl(key) },
    // window.open 은 팝업 차단에 걸릴 수 있어 진짜 링크로 둔다
    { ic: '↗', lb: '새 창으로 열기', hint: '브라우저 새 탭', href: tabUrl(key) },
    { sep: true },
    {
      ic: '▸',
      lb: open ? '이 탭 보기' : '탭으로 열기',
      hint: m?.desc,
      off: route.value === key,
      fn: () => go(key),
    },
    { ic: '⟳', lb: '새로고침', hint: '공통 데이터 + 이 화면', fn: () => refreshTab(key) },
    { sep: true },
    { ic: '‹', lb: '왼쪽으로 이동', off: !open || at <= 0, fn: () => moveTab(key, -1) },
    { ic: '›', lb: '오른쪽으로 이동', off: !open || last, fn: () => moveTab(key, 1) },
    { sep: true },
    { ic: '✕', lb: '탭 닫기', off: !open || !many, fn: () => closeTab(key) },
    { ic: '⊟', lb: '오른쪽 탭 모두 닫기', off: !open || last, fn: () => closeRight(key) },
    { ic: '⊘', lb: '다른 탭 모두 닫기', off: !open || !many, fn: () => closeOthers(key) },
  ]
})

// ---------- 열린 탭 목록 (▾) ----------
//
// 탭 줄은 넘쳐도 <스크롤바를 내놓지 않는다>. 가로 스크롤바가 생기면 안 그래도 아쉬운
// 세로 공간을 줄 하나가 통째로 먹는다. 대신 둘을 둔다.
//   · 지금 보는 탭은 항상 보이게 밀어 준다 (아래 keepActiveVisible)
//   · 가려진 탭은 오른쪽 ▾ 목록에서 바로 간다
const tablistEl = ref(null)
const tabsBox = ref(null)
const tabMenuBtn = ref(null)
const tabsOpen = ref(false)
const hiddenTabs = ref([])
const tabEls = new Map()

const setTabEl = (key, el) => (el ? tabEls.set(key, el) : tabEls.delete(key))
const isHidden = (key) => hiddenTabs.value.includes(key)

/** 지금 폭에서 <통째로 보이지> 않는 탭을 추린다. 반쯤 잘린 것도 가려진 것으로 센다. */
function measureTabs() {
  const box = tablistEl.value
  if (!box) return
  const r = box.getBoundingClientRect()
  const out = []
  for (const m of tabMenus.value) {
    const el = tabEls.get(m.key)
    if (!el) continue
    const t = el.getBoundingClientRect()
    if (t.left < r.left - 1 || t.right > r.right + 1) out.push(m.key)
  }
  hiddenTabs.value = out
}

/**
 * 보고 있는 탭이 밀려 나가 있으면 끌어온다 — 어디에 있는지 모르면 탭 줄이 쓸모없다.
 *
 * <b>scrollIntoView 를 쓰지 않는다.</b> 그 쪽은 위아래 조상까지 함께 밀어 본문이 튀고,
 * 부드러운 스크롤(scroll-behavior)로 예약만 해 두고 창이 그려지지 않는 동안에는
 * <b>아예 움직이지 않는다</b>(실측). 여기서 필요한 것은 가로 한 축뿐이라 직접 민다.
 */
function keepActiveVisible() {
  const box = tablistEl.value
  const el = tabEls.get(route.value)
  if (box && el) {
    const pad = 8
    const r = box.getBoundingClientRect()
    const t = el.getBoundingClientRect()
    if (t.left < r.left + pad) box.scrollLeft -= r.left + pad - t.left
    else if (t.right > r.right - pad) box.scrollLeft += t.right - (r.right - pad)
  }
  measureTabs()
}

watch([tabMenus, route, sideW], () => nextTick(keepActiveVisible))

// ⚠️ 한 번 재고 끝내면 안 된다. 처음 그릴 때는 글꼴·사이드바 폭이 아직 자리를 잡기 전이라
// 띠 너비가 0 에 가깝고, 그 순간에 재면 <탭 전부가 가려졌다> 고 나온다. 숫자가 그럴듯해서
// 틀린 줄도 모른다. 띠 크기가 바뀔 때마다 다시 잰다.
let tabRO = null

// 목록은 ctx 메뉴와 같이 <화면 기준(fixed)> 으로 띄운다. 탭 줄은 sticky 라
// 본문을 스크롤해도 제자리에 있는데, 목록을 absolute 로 달면 혼자 따라 올라간다.
const tabsPos = ref({ top: 0, right: 0 })
function toggleTabs() {
  if (tabsOpen.value) { closeTabsList(); return }
  const r = tabMenuBtn.value?.getBoundingClientRect()
  if (r) tabsPos.value = { top: Math.round(r.bottom + 4), right: Math.round(window.innerWidth - r.right) }
  tabsOpen.value = true
  closeMenu()
}
const closeTabsList = () => (tabsOpen.value = false)

function goFromList(key) {
  closeTabsList()
  go(key)
}

const onKey = (e) => {
  if (e.key === 'Escape') {
    closeMenu()
    closeTabsList()
  }
}

// 메뉴 안을 누른 것은 그대로 둔다 — capture 단계에서 닫아 버리면
// 항목이 사라져 click 이 도달하지 못한다.
const onDocDown = (e) => {
  if (!menuBox.value?.contains(e.target)) closeMenu()
  // 목록 자체와 여는 단추는 그대로 둔다 — 여기서 닫아 버리면 항목에 click 이 닿지 못하고,
  // 단추를 다시 눌러 닫는 동작도 <닫고 다시 열기> 가 되어 영영 안 닫힌다.
  if (!tabsBox.value?.contains(e.target) && !tabMenuBtn.value?.contains(e.target)) closeTabsList()
}

const onWinScroll = () => {
  closeMenu()
  closeTabsList()
}

const onWinResize = () => {
  closeMenu()
  closeTabsList()
  measureTabs()
}

onMounted(() => {
  window.addEventListener('hashchange', onHash)
  // 바깥을 누르거나 화면이 움직이면 닫는다 (capture 로 받아 다른 클릭보다 먼저 정리)
  window.addEventListener('pointerdown', onDocDown, true)
  window.addEventListener('scroll', onWinScroll, true)
  window.addEventListener('resize', onWinResize)
  window.addEventListener('blur', closeMenu)
  window.addEventListener('keydown', onKey)
  // 탭 줄을 가로로 밀면 가려진 탭 수가 달라진다
  tablistEl.value?.addEventListener('scroll', measureTabs, { passive: true })
  if (tablistEl.value && 'ResizeObserver' in window) {
    tabRO = new ResizeObserver(() => measureTabs())
    tabRO.observe(tablistEl.value)
  }
  nextTick(keepActiveVisible)
  saveTabs()
  refreshAll()
})
onUnmounted(() => {
  window.removeEventListener('hashchange', onHash)
  window.removeEventListener('pointerdown', onDocDown, true)
  window.removeEventListener('scroll', onWinScroll, true)
  window.removeEventListener('resize', onWinResize)
  window.removeEventListener('blur', closeMenu)
  window.removeEventListener('keydown', onKey)
  tablistEl.value?.removeEventListener('scroll', measureTabs)
  tabRO?.disconnect()
  clearTimeout(flashTimer)
})
</script>

<template>
  <div class="shell">
    <aside class="side" :class="{ collapsed: !sideOpen, sizing }" :style="sideStyle">
      <div class="brand">
        <!-- 이름표는 <여기가 어디인지> 한 번 알려 주면 되는 자리다. 두 줄을 차지할 값이 아니다 —
             자세한 것(자재관리 · 원본 테이블)은 말풍선과 바닥에 이미 있다. -->
        <div v-if="sideOpen" class="txt" title="WBS 대시보드 · 자재관리(MM)">WBS</div>
        <button
          class="toggle"
          :title="sideOpen ? '사이드바 접기 (아이콘만 남김)' : '사이드바 펼치기'"
          @click="toggleSide"
        >{{ sideOpen ? '«' : '»' }}</button>
      </div>

      <!-- 사이드바가 접히면(아이콘만) 폴더를 쓸 자리가 없다 — 그때는 예전처럼 한 줄로 늘어놓는다 -->
      <nav v-if="!sideOpen">
        <a
          v-for="m in MENU"
          :key="m.key"
          class="item"
          :class="{ on: route === m.key }"
          :href="`#/${m.key}`"
          :title="m.label + ' - ' + m.desc"
          @click.prevent="go(m.key)"
          @contextmenu.prevent="openMenu($event, m.key)"
        >
          <span class="ic">{{ m.icon }}</span>
          <span class="lb">{{ m.label }}</span>
          <span v-if="m.key === 'rows'" class="badge">{{ state.rows.length }}</span>
        </a>
      </nav>

      <nav v-else :class="{ edit: canEdit }" @dragend="clearDrag" @drop="onDrop">
        <template v-for="n in viewTree" :key="n.type === 'folder' ? 'f' + n.id : n.key">
          <!-- ── 폴더 ─────────────────────────────────────────── -->
          <template v-if="n.type === 'folder'">
            <div
              class="fold"
              :class="{
                'over-before': isOver('folder', n.id, 'before'),
                'over-after': isOver('folder', n.id, 'after'),
                'over-in': isOver('folder', n.id, 'in'),
                dragging: drag?.kind === 'folder' && drag.id === n.id,
                shut: !openFolds(n.id),
              }"
              :draggable="canEdit"
              :title="`${n.nm} — 메뉴 ${n.children.length}개`"
              @click="toggleFold(n.id)"
              @dragstart="onDragStart($event, { kind: 'folder', id: n.id })"
              @dragover="onOverFolder($event, n.id)"
              @drop="onDrop"
            >
              <span v-if="canEdit" class="grip" aria-hidden="true">⠿</span>
              <span class="caret">{{ openFolds(n.id) ? '▾' : '▸' }}</span>
              <span class="lb">{{ n.nm }}</span>
              <span class="cnt">{{ n.children.length }}</span>
              <template v-if="canEdit">
                <button class="fbtn" title="폴더 이름 바꾸기" @click.stop="renameFolder(n)">✎</button>
                <button class="fbtn" title="폴더 지우기 (안의 메뉴는 바깥으로 나옵니다)" @click.stop="removeFolder(n)">✕</button>
              </template>
            </div>

            <div v-if="openFolds(n.id)" class="kids">
              <a
                v-for="c in n.children"
                :key="c.key"
                class="item in"
                :class="{
                  on: route === c.key,
                  'over-before': isOver('menu', c.key, 'before'),
                  'over-after': isOver('menu', c.key, 'after'),
                  dragging: drag?.kind === 'menu' && drag.key === c.key,
                }"
                :href="`#/${c.key}`"
                :title="c.m.desc"
                :draggable="canEdit"
                @click.prevent="go(c.key)"
                @contextmenu.prevent="openMenu($event, c.key)"
                @dragstart="onDragStart($event, { kind: 'menu', key: c.key })"
                @dragover="onOverMenu($event, c.key)"
                @drop="onDrop"
              >
                <span v-if="canEdit" class="grip" aria-hidden="true">⠿</span>
                <span class="ic">{{ c.m.icon }}</span>
                <span class="lb">{{ c.m.label }}</span>
                <span v-if="c.key === 'rows'" class="badge">{{ state.rows.length }}</span>
              </a>
              <!-- 빈 폴더에 첫 메뉴를 넣을 자리. 떨굴 데가 없으면 폴더를 채울 길이 없다. -->
              <div
                v-if="!n.children.length"
                class="empty"
                :class="{ 'over-in': isOver('folder', n.id, 'in') }"
                @dragover="onOverInside($event, n.id)"
                @drop="onDrop"
              >여기로 메뉴를 끌어 놓으세요</div>
            </div>
          </template>

          <!-- ── 폴더 밖 메뉴 ─────────────────────────────────── -->
          <a
            v-else
            class="item"
            :class="{
              on: route === n.key,
              'over-before': isOver('menu', n.key, 'before'),
              'over-after': isOver('menu', n.key, 'after'),
              dragging: drag?.kind === 'menu' && drag.key === n.key,
            }"
            :href="`#/${n.key}`"
            :title="n.m.desc"
            :draggable="canEdit"
            @click.prevent="go(n.key)"
            @contextmenu.prevent="openMenu($event, n.key)"
            @dragstart="onDragStart($event, { kind: 'menu', key: n.key })"
            @dragover="onOverMenu($event, n.key)"
            @drop="onDrop"
          >
            <span v-if="canEdit" class="grip" aria-hidden="true">⠿</span>
            <span class="ic">{{ n.m.icon }}</span>
            <span class="lb">{{ n.m.label }}</span>
            <span v-if="n.key === 'rows'" class="badge">{{ state.rows.length }}</span>
          </a>
        </template>

        <!-- 폴더 만들기 — Super 에게만. 순서·폴더는 모두가 함께 보는 것이라 아무나 못 고친다. -->
        <button v-if="canEdit" class="addf" title="사이드바에 폴더를 만듭니다 (모두에게 같이 보입니다)" @click="addFolder">
          ＋ 폴더
        </button>
      </nav>

      <!-- 집계 기준 날짜 + 전체 새로고침. 한 줄로 붙여 자리를 아낀다. -->
      <div class="opts">
        <select
          v-model="state.basis"
          title="집계 기준 날짜 — 요약·기간별·개발자별·모듈별 집계와 상세 목록의 월/주 필터가 이 컬럼을 본다"
        >
          <option value="edt">계획종료일</option>
          <option value="sdt">계획시작일</option>
        </select>
        <RefreshBtn :fn="refreshAll" label="" title="전체 새로고침 (공통 데이터 + 지금 보고 있는 화면)" />
      </div>

      <!-- 바닥은 <곁들이는 정보> 다. 세로를 적게 쓰려고 한 줄씩으로 눌러 두었다 —
           접속자·IP·원본 테이블을 저마다 한 줄씩 차지하면 메뉴가 그만큼 밀린다.
           자세한 것은 말풍선(title)에 그대로 들어 있다. -->
      <div class="foot">
        <div class="pg" title="집계 원본: public.hhip_wbs_wrk2">
          <span>완료 {{ state.summary.done ?? '-' }} / {{ state.summary.total ?? '-' }}</span>
          <span class="pct">{{ donePct }}%</span>
        </div>
        <div class="gauge"><div class="bar" :style="{ width: donePct + '%' }"></div></div>

        <div class="whorow">
          <!-- 접속자 — 지금 누가 쓰고 있는지 항상 보이게 (한 줄로 눌러 담는다) -->
          <span
            class="me"
            :class="state.me.reason"
            :title="`${meLabel}\n접속 IP ${state.me.ip || '-'}\n집계 원본 public.hhip_wbs_wrk2`"
          >
            <span class="who">{{ meLabel }}</span>
            <span class="ip">{{ state.me.ip || '-' }}</span>
          </span>
          <button
            class="theme"
            :title="dark ? '밝게 보기로 바꿉니다' : '어둡게 보기로 바꿉니다'"
            :aria-label="dark ? '밝게 보기' : '어둡게 보기'"
            @click="toggleTheme"
          >{{ dark ? '☀' : '☾' }}</button>
        </div>
      </div>
    </aside>

    <!-- 사이드바와 본문 사이의 경계선. 끌면 너비가 바뀌고, 두 번 누르면 기본값으로 돌아간다.
         접은 상태(아이콘만)에서는 폭이 고정이라 내놓지 않는다. -->
    <div
      v-if="sideOpen"
      class="split"
      :class="{ on: sizing }"
      title="끌어서 사이드바 너비 조절 · 두 번 누르면 기본 너비"
      @pointerdown="startResize"
      @dblclick="resetWidth"
    ><span class="bar"></span></div>

    <main class="main">
      <!-- 열람한 화면 탭. 가운데 버튼으로도 닫히고, 오른쪽 버튼으로 메뉴가 열린다. -->
      <nav class="tabs">
        <!-- 탭이 넘치면 가로로 밀리지만 <스크롤바는 내놓지 않는다> — 줄 하나가 통째로
             스크롤바에 먹히면 안 그래도 아쉬운 세로 공간이 더 준다.
             넘쳐서 안 보이는 탭은 오른쪽 ▾ 목록으로 찾아간다. -->
        <div ref="tablistEl" class="tablist" :class="{ more: hiddenTabs.length }">
          <a
            v-for="m in tabMenus"
            :key="m.key"
            :ref="(el) => setTabEl(m.key, el)"
            class="tab"
            :class="{ on: route === m.key, menu: menu?.key === m.key }"
            :href="`#/${m.key}`"
            :title="m.desc + '\n오른쪽 버튼: 주소 복사 · 새 창 · 순서 · 닫기'"
            @click.prevent="go(m.key)"
            @auxclick.middle.prevent="closeTab(m.key)"
            @contextmenu.prevent="openMenu($event, m.key)"
          >
            <span class="ic">{{ m.icon }}</span>
            <span class="lb">{{ m.label }}</span>
            <button
              v-if="tabMenus.length > 1"
              class="x"
              title="탭 닫기 (가운데 버튼으로도 닫힙니다)"
              @click.prevent.stop="closeTab(m.key)"
            >✕</button>
          </a>
        </div>

        <span v-if="flash" class="flash">{{ flash }}</span>
        <button v-if="tabMenus.length > 1" class="others" title="지금 탭만 남기고 닫기" @click="closeOthers()">
          이 탭만
        </button>
        <!-- 열린 탭 전부를 한눈에. 가려진 탭이 있으면 그 수를 함께 적는다 -->
        <button
          ref="tabMenuBtn"
          class="tabsall"
          :class="{ on: tabsOpen }"
          :title="`열린 탭 ${tabMenus.length}개 보기` + (hiddenTabs.length ? ` (가려진 탭 ${hiddenTabs.length}개)` : '')"
          @click="toggleTabs"
        >
          <span class="cv">▾</span>
          <span v-if="hiddenTabs.length" class="n">{{ hiddenTabs.length }}</span>
        </button>
      </nav>

      <!-- 열린 탭 목록 — 넘쳐서 안 보이는 탭도 여기서 바로 간다 -->
      <div
        v-if="tabsOpen"
        ref="tabsBox"
        class="ctx tabsdrop"
        :style="{ top: tabsPos.top + 'px', right: tabsPos.right + 'px' }"
        @contextmenu.prevent
      >
        <div class="ctx-h">열린 탭 {{ tabMenus.length }}개</div>
        <a
          v-for="m in tabMenus"
          :key="m.key"
          class="ctx-i"
          :class="{ cur: route === m.key, off: isHidden(m.key) }"
          :href="`#/${m.key}`"
          :title="m.desc"
          @click.prevent="goFromList(m.key)"
        >
          <span class="ic">{{ m.icon }}</span>
          <span class="lb">{{ m.label }}</span>
          <button
            v-if="tabMenus.length > 1"
            class="rx"
            title="이 탭 닫기"
            @click.prevent.stop="closeTab(m.key)"
          >✕</button>
        </a>
      </div>

      <!-- 탭 / 사이드바 메뉴의 오른쪽 버튼 메뉴 -->
      <div
        v-if="menu"
        ref="menuBox"
        class="ctx"
        :style="{ left: menu.x + 'px', top: menu.y + 'px' }"
        @contextmenu.prevent
      >
        <div class="ctx-h">{{ MENU.find((m) => m.key === menu.key)?.label }}</div>
        <template v-for="(it, i) in menuItems" :key="i">
          <div v-if="it.sep" class="ctx-sep"></div>
          <a
            v-else-if="it.href"
            class="ctx-i"
            :href="it.href"
            target="_blank"
            rel="noopener"
            @click="closeMenu"
          >
            <span class="ic">{{ it.ic }}</span>
            <span class="lb">{{ it.lb }}</span>
            <span v-if="it.hint" class="hint">{{ it.hint }}</span>
          </a>
          <button v-else class="ctx-i" :class="{ off: it.off }" :disabled="it.off" @click="runMenu(it)">
            <span class="ic">{{ it.ic }}</span>
            <span class="lb">{{ it.lb }}</span>
            <span v-if="it.hint" class="hint">{{ it.hint }}</span>
          </button>
        </template>
      </div>



      <!-- 세로 스크롤은 <이 안에서만> 일어난다. 페이지(body)를 통째로 굴리면 탭 줄이
           sticky 로 버티느라 늘 맨 위 한 줄을 차지하고, 표의 sticky 머리줄과 겹쳐
           같은 자리를 두 겹으로 쌓는다. 스크롤 대상이 본문 하나면 그 다툼이 없다. -->
      <div ref="contentEl" class="content" :class="{ tall: current.full }">
     
        <!-- KeepAlive 가 탭마다 화면을 살려 둔다.
           :key 가 필요한 까닭 — 흐름도/계통도는 같은 컴포넌트(HtmlDoc)에 props 만 달라서
           key 가 없으면 한 칸을 나눠 쓰며 서로를 덮어쓴다.

           key 는 주소(route)가 아니라 <실제로 그리는 메뉴>(current.key)여야 한다.
           whoami 가 오기 전에는 권한을 몰라 잠시 첫 화면으로 떨어지는데, 그때 route 로 키를 주면
           <요약 화면이 perms 키로> 캐시된다. 뒤늦게 권한이 와도 그 캐시가 그대로 나와,
             제목만 바뀌고 본문은 요약인 상태가 된다 (KeepAlive 가 deactivate 오류도 함께 낸다). -->
        <KeepAlive :max="12">
          <component :is="current.comp" :key="current.key" v-bind="current.props ?? {}" @drill="go('rows')" />
        </KeepAlive>
      </div>
    </main>
  </div>
</template>

<style scoped>
/* 바깥(페이지)은 굴리지 않는다 — 굴러가는 것은 사이드바의 메뉴와 본문 둘뿐이다 */
.shell { display: flex; height: 100vh; overflow: hidden; }

.side {
  width: 208px;
  flex: none;
  background: var(--panel);
  border-right: 1px solid var(--line);
  display: flex;
  flex-direction: column;
  height: 100%;
}
.side { transition: width 0.15s ease; }
/* 끌고 있는 동안에는 애니메이션을 끈다 — 켜 두면 손가락보다 한 박자 늦게 따라와 미끄러진다 */
.side.sizing { transition: none; }

/* 사이드바 ↔ 본문 경계선. 보이는 선은 1px 이지만 잡는 자리는 7px 로 넓게 둔다 —
   1px 짜리 손잡이는 겨냥하다 지친다. */
.split {
  flex: none;
  width: 7px;
  margin: 0 -4px 0 -3px;   /* 자리를 차지하지 않고 경계선 위에 겹쳐 둔다 */
  cursor: col-resize;
  height: 100%;
  z-index: 30;
  display: flex;
  justify-content: center;
  touch-action: none;      /* 터치로 끌 때 화면이 함께 밀리지 않게 */
}
.split .bar { width: 1px; background: transparent; transition: background 0.12s ease; }
.split:hover .bar,
.split.on .bar { background: var(--accent); width: 2px; }
.brand {
  padding: 8px 10px 7px;
  border-bottom: 1px solid var(--line);
  display: flex;
  align-items: center;
  gap: 6px;
}
/* 글자 하나짜리 이름표 — 또렷하되 조용하게. 자간을 벌려 <로고> 로 읽히게 한다 */
.brand .txt {
  flex: 1;
  min-width: 0;
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: var(--muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.toggle {
  border: 1px solid var(--line);
  background: var(--panel);
  color: var(--muted);
  border-radius: 5px;
  padding: 0 6px;
  line-height: 20px;
  font-size: 12px;
}
.toggle:hover { color: var(--accent); border-color: var(--accent); }

/* 접힌 상태 — 아이콘만 남겨 메뉴 이동은 계속 되게 한다 */
.side.collapsed { width: 52px; }
.side.collapsed .brand { justify-content: center; padding: 8px 6px; }
.side.collapsed .lb,
.side.collapsed .badge,
.side.collapsed .opts { display: none; }
/* 접어도 테마 단추는 남긴다 — 접어 두고 쓰는 사람이 밝게/어둡게를 못 바꾸면 곤란하다 */
.side.collapsed .foot { padding: 6px 4px; }
.side.collapsed .foot .pg,
.side.collapsed .foot .gauge,
.side.collapsed .foot .me { display: none; }
.side.collapsed .foot .whorow { margin-top: 0; justify-content: center; }
.side.collapsed nav { padding: 8px 6px; }
.side.collapsed .item { justify-content: center; padding: 8px 0; }
.side.collapsed .item .ic { width: auto; font-size: 14px; }

/* 메뉴만 세로로 스크롤한다.
   min-height:0 이 없으면 flex 항목이 내용 높이 아래로 줄지 않아,
   메뉴가 길어질 때 아래의 범위/기준일·요약(.opts/.foot)이 화면 밖으로 밀려난다. */
nav {
  padding: 8px;
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
}
/* 굵기·색은 style.css 가 한 곳에서 정한다 (3px) — 여기서 다시 적지 않는다 */

/* 위아래는 항상 제자리에 둔다 */
.brand,
.opts,
.foot { flex: none; }
.item {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 7px 9px;
  border-radius: 6px;
  color: var(--text);
  text-decoration: none;
  font-size: 12.5px;
}
.item:hover { background: var(--hover); }
.item.on { background: var(--accent-soft); color: var(--accent); font-weight: 600; }
.item .ic { width: 14px; text-align: center; opacity: 0.6; }
.item.on .ic { opacity: 1; }
/* 사이드바를 좁히면 긴 메뉴명이 두 줄로 접혀 줄 높이가 들쭉날쭉해진다.
   min-width:0 이 없으면 flex 항목이 글자 길이만큼 버텨 말줄임표가 걸리지 않는다. */
.item .lb {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.badge {
  background: var(--fill);
  color: var(--muted);
  border-radius: 9px;
  padding: 1px 6px;
  font-size: 10.5px;
  font-variant-numeric: tabular-nums;
}
.item.on .badge { background: var(--panel); color: var(--accent); }

/* ---------- 사이드바 폴더 · 끌어놓기 ---------- */
/* 폴더는 <칸막이>지 누르러 가는 곳이 아니다. 메뉴보다 작고 얇게, 세로도 덜 차지하게 둔다 —
   메뉴와 같은 무게로 그리면 누를 것이 두 배로 보인다. */
.fold {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 2px 8px 1px;
  margin-top: 7px;
  border-radius: 5px;
  font-size: 10.5px;
  font-weight: 400;
  letter-spacing: 0.02em;
  color: var(--muted);
  cursor: pointer;
  user-select: none;
  position: relative;
}
.fold:hover { background: var(--hover); }
.fold .caret { font-size: 8px; width: 8px; }
.fold .lb { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.fold .cnt {
  color: var(--muted-3);
  font-size: 9.5px;
  font-variant-numeric: tabular-nums;
}
/* 폴더 단추는 평소 숨긴다 — 줄마다 ✎✕ 가 서 있으면 메뉴가 아니라 설정 화면처럼 보인다 */
.fold .fbtn {
  border: 0;
  background: none;
  color: var(--muted-3);
  font-size: 10px;
  padding: 0 2px;
  line-height: 1;
  cursor: pointer;
  visibility: hidden;
}
.fold:hover .fbtn { visibility: visible; }
.fold .fbtn:hover { color: var(--accent); }
/* 폴더 안쪽 — 한 칸 들여 <딸린 것> 으로 보이게 하고 세로선으로 묶는다 */
.kids { margin: 1px 0 2px 10px; border-left: 1px solid var(--line); padding-left: 5px; }
.kids .empty {
  font-size: 11px;
  color: var(--muted-2);
  padding: 7px 9px;
  border: 1px dashed var(--line);
  border-radius: 6px;
  text-align: center;
}

/* 끌 수 있을 때만 손잡이를 보여 준다 — 못 옮기는 사람에게 옮길 수 있는 것처럼 보이면 안 된다 */
nav.edit .item,
nav.edit .fold { cursor: grab; }
.grip { color: var(--muted-3); font-size: 10px; width: 8px; flex: none; }
.item:hover .grip,
.fold:hover .grip { color: var(--muted-2); }
.dragging { opacity: 0.4; }

/* 놓을 자리 — 줄 하나로 앞/뒤를 보여 준다 (칸이 좁아 그림자보다 선이 분명하다) */
.over-before,
.over-after { position: relative; }
.over-before::before,
.over-after::after {
  content: '';
  position: absolute;
  left: 2px;
  right: 2px;
  height: 2px;
  background: var(--accent);
  border-radius: 2px;
}
.over-before::before { top: -1px; }
.over-after::after { bottom: -1px; }
/* 폴더 <안에 넣기> 는 선이 아니라 상자를 칠한다 — 앞/뒤와 눈으로 갈려야 한다 */
.over-in { background: var(--accent-soft) !important; box-shadow: inset 0 0 0 1px var(--accent); }

.addf {
  width: 100%;
  margin-top: 8px;
  border: 1px dashed var(--line);
  background: none;
  color: var(--muted);
  border-radius: 6px;
  padding: 6px 0;
  font-size: 11.5px;
  cursor: pointer;
}
.addf:hover { border-color: var(--accent); color: var(--accent); }

/* 기준일 + 새로고침 한 줄 — 기준일이 남는 폭을 다 쓰고 새로고침은 아이콘만 남긴다 */
.opts {
  padding: 8px 12px;
  border-top: 1px solid var(--line);
  display: flex;
  align-items: center;
  gap: 5px;
}
.opts select { flex: 1; min-width: 0; }
.opts button { flex: none; padding: 4px 7px; }

.foot { padding: 7px 10px 8px; border-top: 1px solid var(--line); }
.foot .pg { display: flex; justify-content: space-between; font-size: 10.5px; color: var(--muted); }
.foot .pct { color: var(--done); font-weight: 600; }
.foot .gauge { margin-top: 3px; height: 3px; background: var(--done-soft); border-radius: 2px; overflow: hidden; }
.foot .gauge .bar { height: 100%; background: var(--done); transition: width 0.2s; }

/* 접속자 + 테마 단추를 한 줄에 둔다 */
.foot .whorow { display: flex; align-items: center; gap: 4px; margin-top: 6px; }
.foot .me {
  flex: 1;
  min-width: 0;
  display: flex;
  align-items: baseline;
  gap: 5px;
  padding: 2px 6px;
  border-radius: 5px;
  background: var(--accent-soft);
  line-height: 1.5;
}
/* 이름이 길면 이름 쪽만 줄인다 — IP 는 짧고, 끊기면 읽을 수 없는 값이다 */
.foot .me .who {
  font-size: 11px;
  font-weight: 600;
  color: var(--accent);
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.foot .me .ip {
  flex: none;
  font-size: 10px;
  color: var(--muted);
  font-family: Consolas, 'Courier New', monospace;
  font-variant-numeric: tabular-nums;
}
/* 부트스트랩(등록 IP 없음)·서버 로컬은 노란 톤으로 구분 */
.foot .me.bootstrap { background: var(--warn-soft); }
.foot .me.bootstrap .who { color: var(--warn); }
.foot .me.self { background: var(--hover); }
.foot .me.self .who { color: var(--muted); }

.foot .theme {
  flex: none;
  padding: 1px 6px;
  font-size: 12px;
  line-height: 17px;
  color: var(--muted);
}

/* 사이드바를 뺀 나머지 가로 폭을 전부 쓴다 (표가 넓어 상한을 두지 않는다).
   세로는 화면 높이에 맞춰 두고 <본문만> 굴린다 — 탭 줄은 제자리에 남는다. */
.main {
  flex: 1;
  min-width: 0;
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.content {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 16px 20px 48px;
}
/* 표가 화면 세로를 다 쓰는 화면(상세 목록)에서는 아래 여백을 없앤다 —
   여백이 남아 있으면 표를 끝까지 늘려도 그만큼 더 스크롤된다. */
.content.tall { padding-bottom: 0; }
/* 열람한 화면 탭 — 본문 <위에 얹는 것이 아니라 바깥에> 둔다.
   본문만 굴러가므로 sticky 가 필요 없다. 제자리에 그냥 남는다. */
.tabs {
  flex: none;
  display: flex;
  align-items: stretch;
  gap: 3px;
  /* 탭 줄은 <길잡이>지 내용이 아니다. 세로를 아껴 본문에 넘긴다 (36px → 28px). */
  padding: 3px 20px 0;
  border-bottom: 1px solid var(--line);
  background: var(--panel);
  overflow: hidden;
  z-index: 20;
}

/* 탭이 담기는 띠. 넘치면 가로로 밀 수는 있되 <스크롤바는 감춘다>.
   스크롤바를 내놓으면 줄 하나가 통째로 거기에 먹힌다. */
.tablist {
  flex: 1 1 auto;
  min-width: 0;
  display: flex;
  align-items: stretch;
  gap: 3px;
  overflow-x: auto;
  overflow-y: hidden;
  scrollbar-width: none;
  -ms-overflow-style: none;
}
.tablist::-webkit-scrollbar { display: none; }
/* 가려진 탭이 있으면 오른쪽 끝을 흐리게 — <더 있다> 는 것을 알린다 */
.tablist.more {
  -webkit-mask-image: linear-gradient(to right, #000 calc(100% - 22px), transparent);
  mask-image: linear-gradient(to right, #000 calc(100% - 22px), transparent);
}
.tab {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 2px 9px 3px;
  border: 1px solid transparent;
  border-bottom: 0;
  border-radius: 6px 6px 0 0;
  color: var(--muted);
  text-decoration: none;
  font-size: 12px;
  white-space: nowrap;
  flex: none;
}
.tab:hover { background: var(--hover); color: var(--text); }
/* 지금 보고 있는 화면 표시는 사이드바 메뉴(.item.on)와 <같은 색> 이다 —
   같은 뜻을 두 가지 색으로 말하면 한쪽은 선택이 아닌 다른 것으로 읽힌다. */
.tab.on {
  background: var(--accent-soft);
  border-color: var(--accent-soft);
  color: var(--accent);
  font-weight: 600;
  /* 아래 테두리를 덮어 <지금 이 탭> 이라는 것을 보이게 한다 */
  margin-bottom: -1px;
  padding-bottom: 4px;
}
.tab .ic { font-size: 11px; opacity: 0.75; }
.tab.on .ic { opacity: 1; }
.tab.on .x { color: var(--accent); opacity: 0.65; }
.tab.on .x:hover { opacity: 1; }
.tab .x {
  border: 0;
  background: transparent;
  color: var(--muted-3);
  padding: 0 1px;
  font-size: 10px;
  line-height: 14px;
  border-radius: 3px;
}
.tab .x:hover { background: var(--fill); color: var(--warn); }
/* ⚠️ flex: none 이 없으면 탭이 많을 때 이 단추가 눌려 <이 / 탭 / 만> 으로 줄바꿈되고,
   그 세 줄 높이에 맞춰 탭 줄 전체가 70px 까지 부푼다. 탭이 적을 때는 멀쩡해서 모르고 지난다. */
.tabs .others {
  align-self: center;
  flex: none;
  white-space: nowrap;
  font-size: 11px;
  padding: 2px 7px;
  margin-left: 4px;
  color: var(--muted);
}

/* 열린 탭 목록을 여는 단추 — 늘 오른쪽 끝에 붙어 있다(탭과 함께 밀려 나가지 않는다) */
.tabs .tabsall {
  align-self: center;
  flex: none;
  display: flex;
  align-items: center;
  gap: 3px;
  margin-left: 3px;
  padding: 2px 6px;
  font-size: 11px;
  color: var(--muted);
}
.tabs .tabsall .cv { font-size: 9px; line-height: 16px; }
.tabs .tabsall .n {
  background: var(--accent-soft);
  color: var(--accent);
  border-radius: 8px;
  padding: 0 5px;
  font-size: 10px;
  font-variant-numeric: tabular-nums;
}
.tabs .tabsall.on { border-color: var(--accent); color: var(--accent); }

/* 탭 목록 드롭다운 — 오른쪽 위에 붙는다 (ctx 의 모양을 그대로 쓴다) */
.tabsdrop {
  position: fixed;
  z-index: 210;
  max-height: 70vh;
  overflow-y: auto;
}
.tabsdrop .ctx-i { grid-template-columns: 15px 1fr auto; }
.tabsdrop .ctx-i .lb { overflow: hidden; text-overflow: ellipsis; }
/* 지금 보고 있는 탭 */
.tabsdrop .ctx-i.cur { background: var(--accent-soft); color: var(--accent); font-weight: 600; }
/* 탭 줄에서 밀려나 안 보이는 탭 — 이 목록이 있는 까닭이라 눈에 띄게 둔다 */
.tabsdrop .ctx-i.off .lb::after {
  content: '가려짐';
  margin-left: 6px;
  font-size: 10px;
  color: var(--muted-2);
}
.tabsdrop .rx {
  border: 0;
  background: transparent;
  color: var(--muted-3);
  padding: 0 3px;
  font-size: 10px;
  border-radius: 3px;
}
.tabsdrop .rx:hover { background: var(--fill); color: var(--warn); }
/* 메뉴가 열려 있는 탭을 표시해 준다 — 어느 탭에 대한 메뉴인지 헷갈리지 않게.
   선택된 탭이 accent-soft 를 쓰므로 여기는 회색으로 비킨다 — 같은 색이면
   <고른 탭> 인지 <메뉴를 연 탭> 인지 구별되지 않는다. 고른 탭 위에서는 덧칠하지 않는다. */
.tab.menu:not(.on) { background: var(--fill); color: var(--text); }
.tab.on.menu { box-shadow: inset 0 0 0 1px var(--accent); }
/* 주소를 복사했다는 짧은 알림 */
.tabs .flash {
  align-self: center;
  flex: none;           /* 위 .others 와 같은 까닭 — 눌리면 탭 줄이 부푼다 */
  max-width: 46ch;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin-right: 6px;
  padding: 2px 8px;
  border-radius: 10px;
  background: var(--accent-soft);
  color: var(--accent);
  font-size: 11px;
}

/* ---------- 오른쪽 버튼 메뉴 ---------- */
.ctx {
  position: fixed;
  z-index: 200;
  min-width: 208px;
  max-width: 360px;
  padding: 4px;
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 8px;
  box-shadow: 0 8px 24px var(--shadow);
}
.ctx-h {
  padding: 5px 9px 6px;
  font-size: 11px;
  color: var(--muted);
  border-bottom: 1px solid var(--line);
  margin-bottom: 3px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ctx-sep { height: 1px; background: var(--line); margin: 3px 4px; }
.ctx-i {
  display: grid;
  grid-template-columns: 15px 1fr auto;
  align-items: center;
  gap: 8px;
  width: 100%;
  border: 0;
  background: transparent;
  border-radius: 5px;
  padding: 5px 8px;
  font-size: 12px;
  color: var(--text);
  text-align: left;
}
.ctx-i:hover { background: var(--hover); }
a.ctx-i { text-decoration: none; }
.ctx-i .ic { text-align: center; opacity: 0.6; }
.ctx-i .lb { white-space: nowrap; }
.ctx-i .hint {
  font-size: 10.5px;
  color: var(--muted);
  max-width: 20ch;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ctx-i.off { color: var(--muted-3); }
.ctx-i.off:hover { background: transparent; }
.ctx-i.off .ic { opacity: 0.3; }

.top { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; margin-bottom: 14px; }
.top h1 { font-size: 17px; margin: 0; font-weight: 600; }
.top .sub { color: var(--muted); font-size: 12px; }

@media (max-width: 900px) {
  .shell { flex-direction: column; }
  .side { width: auto; height: auto; position: static; border-right: 0; border-bottom: 1px solid var(--line); }
  /* 가로로 눕는 배치라 세로 스크롤이 필요 없다 — 전부 펼쳐 보여 준다 */
  nav { display: flex; flex-wrap: wrap; overflow-y: visible; min-height: auto; }
  /* 이미 한 줄이라 좁은 화면에서도 그대로 쓴다 — 기준일만 너무 늘어나지 않게 상한을 둔다 */
  .opts select { flex: 0 1 160px; }
  /* 좁은 화면에서도 접속자는 계속 보이게 하고 진행률만 숨긴다 */
  .foot { padding: 6px 12px; }
  .foot .pg, .foot .gauge, .foot .src { display: none; }
  .foot .me { margin-top: 0; flex-direction: row; align-items: center; gap: 8px; }
  /* 이미 가로로 눕는 배치라 접기는 의미가 없다 — 접혀 있어도 펼쳐 보여 주고 버튼도 감춘다 */
  .toggle { display: none; }
  .side.collapsed { width: auto; }
  .side.collapsed .lb { display: inline; }
  .side.collapsed .badge { display: inline; }
  .side.collapsed .opts { display: flex; }
  .side.collapsed .foot { display: block; }
  .side.collapsed .item { justify-content: flex-start; padding: 7px 9px; }
}
</style>
