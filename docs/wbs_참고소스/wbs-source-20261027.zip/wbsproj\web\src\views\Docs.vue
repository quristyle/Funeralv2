<script setup>
import { computed, nextTick, onMounted, ref, watch } from 'vue'
import { api } from '../api'
import { state, useViewRefresh, scrollContentTop } from '../store'
import RichEditor from '../components/RichEditor.vue'
import RefreshBtn from '../components/RefreshBtn.vue'

const docs = ref([])
const loading = ref(false)
const selId = ref(null) // 좌측 목차에서 선택된 섹션 (오른쪽에는 이것만 표시)
const editingId = ref(null)
const draft = ref({ title: '', content: '' })
const saving = ref(false)

async function load() {
  loading.value = true
  try {
    const [list, files] = await Promise.all([api.docs(), api.docIframeAll()])
    docs.value = list
    putFiles(files)
    // 선택이 없거나 삭제되어 사라졌으면 첫 섹션을 선택
    if (!docs.value.some((d) => d.id === selId.value)) selId.value = docs.value[0]?.id ?? null
  } catch (e) {
    state.error = e.message
  } finally {
    loading.value = false
  }
}

// ---------- 목차 순서 바꾸기 ----------
// 라이브러리 없이 브라우저의 끌어놓기(HTML5 drag and drop)만 쓴다.
//
// 놓을 때까지는 화면의 목록만 바꾸고, 놓은 순간 한 번만 서버에 보낸다.
// 순서는 내용이 아니므로 전용 경로(/api/docs/order)로 보낸다 —
// 보통 저장 경로를 쓰면 옮긴 섹션이 모두에게 <변경됨> 으로 뜬다.
const dragId = ref(null)
const overId = ref(null)
const overPos = ref('') // 'before' | 'after' — 놓을 자리를 줄로 보여 준다

function clearDrag() {
  dragId.value = null
  overId.value = null
  overPos.value = ''
}

function onDragStart(e, id) {
  // 편집 중에 목록이 흔들리면 쓰던 글을 잃는다
  if (editingId.value != null) {
    e.preventDefault()
    return
  }
  dragId.value = id
  e.dataTransfer.effectAllowed = 'move'
  // 데이터가 비면 끌기를 시작조차 하지 않는 브라우저가 있다
  e.dataTransfer.setData('text/plain', String(id))
}

function onDragOver(e, id) {
  if (dragId.value == null || id === dragId.value) return
  e.preventDefault() // 막지 않으면 놓을 수 없는 자리가 된다
  e.dataTransfer.dropEffect = 'move'
  const r = e.currentTarget.getBoundingClientRect()
  overId.value = id
  overPos.value = e.clientY < r.top + r.height / 2 ? 'before' : 'after'
}

function onDragLeave(id) {
  if (overId.value === id) overId.value = null
}

async function onDrop(e, id) {
  e.preventDefault()
  const from = dragId.value
  const pos = overPos.value
  clearDrag()
  if (from == null || from === id) return

  const list = [...docs.value]
  const fi = list.findIndex((d) => d.id === from)
  if (fi < 0) return
  const [moved] = list.splice(fi, 1)
  let ti = list.findIndex((d) => d.id === id)
  if (ti < 0) return
  if (pos === 'after') ti += 1
  list.splice(ti, 0, moved)

  // 화면을 먼저 옮긴다 — 서버를 기다리면 놓은 것이 되돌아갔다가 다시 가는 것처럼 보인다
  const prev = docs.value
  docs.value = list
  try {
    await api.docReorder(list.map((d) => d.id))
  } catch (err) {
    docs.value = prev // 서버가 거절하면 되돌린다
    state.error = `순서 저장 실패: ${err.message}`
  }
}

// ---------- 안 본 변경 표시 ----------
// "내가 마지막으로 본 뒤에 바뀌었나" 를 사람마다 따로 기억한다.
// 서버가 모두에게 같은 <NEW> 를 붙이는 방식이 아니다 — 며칠 전 것이라도 내가 안 봤으면
// 나에게는 새것이고, 방금 것이라도 내가 썼으면 나에게는 새것이 아니다.
//
// 보관은 store.js 의 컬럼 설정과 같은 두 곳 —
//   localStorage : 즉시. 서버가 사람을 못 가려도 동작한다.
//   dev_user_pref: 접속 IP 로 사람이 가려질 때. 다른 PC 에서 본 것도 따라온다.
//
// 표시에 쓰는 것은 <화면을 열 때의 기록(base)> 이다. 고른 즉시 seen 을 갱신하면
// 지금 보고 있는 섹션의 표시가 눈앞에서 사라져 무엇이 바뀌었는지 확인할 수가 없다.
// 그래서 굳히는 것은 seen, 보여 주는 것은 base 로 나눠 둔다. 다음에 열면 없어진다.
const SEEN_LS = 'wbs.docs.seen'
const SEEN_PREF = 'docs.seen'
const seen = ref({}) // 굳혀 두는 값  { [id]: updated_at }
const base = ref(null) // 화면에 쓰는 값. null = 아직 판정 전 (아무 표시도 하지 않는다)
// ⚠️ 기록을 읽기 전에는 <봤다> 를 굳히지 않는다.
//    load() 가 selId 를 정하면 watch 가 곧바로 markSeen 을 부르는데, 그때 굳혀 버리면
//    그 한 줄이 <기록이 있다> 로 읽혀 처음 쓰는 사람에게 기준선을 못 깐다.
//    그러면 나머지 전부가 <새 섹션> 으로 뜬다 — 표시가 쓸모없어지는 지점이다.
const seenReady = ref(false)
let seenTimer = null

function readSeenLocal() {
  try {
    const v = JSON.parse(localStorage.getItem(SEEN_LS) || 'null')
    return v && typeof v === 'object' ? v : null
  } catch {
    return null
  }
}

function persistSeen() {
  try {
    localStorage.setItem(SEEN_LS, JSON.stringify(seen.value))
  } catch {
    /* 사생활 보호 모드 등에서 막히면 이번 세션에만 적용된다 */
  }
  // 서버는 몰아서 한 번만 — 목차를 훑을 때마다 보내면 쓸데없이 잦다
  clearTimeout(seenTimer)
  seenTimer = setTimeout(() => {
    api.prefSet(SEEN_PREF, seen.value).catch(() => {
      /* 사람이 안 가려지면 서버가 stored:false 를 준다 — localStorage 로 계속 간다 */
    })
  }, 1500)
}

/** 두 기록을 합친다 — 어느 쪽에서든 <더 나중에 본 것> 이 이긴다. */
function mergeSeen(a, b) {
  const out = { ...(a ?? {}) }
  for (const [k, v] of Object.entries(b ?? {})) {
    if (!(k in out) || String(v) > String(out[k])) out[k] = v
  }
  return out
}

/** 처음 쓰는 사람 — 지금 있는 것을 전부 <본 것> 으로 깔고 그 뒤의 변경만 표시한다. */
function baseline() {
  const m = {}
  for (const d of docs.value) m[d.id] = d.updated_at ?? ''
  seen.value = m
  base.value = { ...m }
  seenReady.value = true
  persistSeen()
}

async function loadSeen() {
  const local = readSeenLocal()
  let merged = local
  try {
    const r = await api.prefGet(SEEN_PREF)
    if (r.stored && r.value) merged = mergeSeen(local, JSON.parse(r.value))
  } catch {
    /* 못 읽으면 로컬 것만 쓴다 */
  }
  if (!merged) {
    baseline()
    return
  }
  seen.value = merged
  base.value = { ...merged }
  seenReady.value = true
  persistSeen() // 두 곳을 합친 결과를 양쪽에 굳혀 둔다
}

/** 지금 보고 있는 것을 <봤다> 로 굳힌다. 화면 표시(base)는 건드리지 않는다. */
function markSeen(id) {
  if (!seenReady.value) return
  const d = docs.value.find((x) => x.id === id)
  if (!d) return
  const at = d.updated_at ?? ''
  if (seen.value[d.id] === at) return
  seen.value = { ...seen.value, [d.id]: at }
  persistSeen()
}

/** 표시 상태 — '' | 'new'(처음 보는 섹션) | 'upd'(본 뒤에 바뀜) */
function markOf(d) {
  if (!base.value) return ''
  if (!(d.id in base.value)) return 'new'
  return base.value[d.id] === (d.updated_at ?? '') ? '' : 'upd'
}

const unseen = computed(() => docs.value.filter((d) => markOf(d)).length)

function markAllSeen() {
  const m = {}
  for (const d of docs.value) m[d.id] = d.updated_at ?? ''
  seen.value = m
  base.value = { ...m } // 이것만은 화면에서도 바로 지운다 — 누른 뜻이 그것이다
  persistSeen()
}

// 목차에는 <무엇이 붙어 있는지> 를 배지로 적는다. 섹션을 눌러 보기 전에는
// 글만 있는 것인지 문서가 붙어 있는 것인지 알 길이 없던 자리다.
//   ⧉ 올려 둔 HTML (우리 서버 안)   ↗ 걸어 둔 주소 (바깥)
// 둘 다 있으면 둘 다 단다.
const toc = computed(() =>
  docs.value.map((d) => {
    const fs = ifFiles.value[d.id] || []
    return {
      id: d.id,
      title: d.title,
      mark: markOf(d),
      inner: fs.filter((f) => !f.url).length,
      outer: fs.filter((f) => f.url).length,
    }
  })
)
const current = computed(() => docs.value.find((d) => d.id === selId.value) ?? null)

// 편집 중 다른 섹션으로 이동하면 변경분이 사라지므로 먼저 확인한다
function isDirty() {
  if (editingId.value == null) return false
  const d = docs.value.find((x) => x.id === editingId.value)
  return !d || d.title !== draft.value.title || (d.content ?? '') !== (draft.value.content ?? '')
}
function select(id) {
  if (id === selId.value) return
  if (isDirty() && !confirm('편집 중인 내용이 저장되지 않았습니다. 이동할까요?')) return
  editingId.value = null
  selId.value = id
}

function startEdit(d) {
  editingId.value = d.id
  draft.value = { title: d.title, content: d.content }
}
function cancel() {
  editingId.value = null
}

// ---------- HTML 로 내려받기 ----------
// 본문은 RichEditor 가 만든 HTML 이 그대로 들어 있다. 그래서 변환할 것이 없고,
// 혼자서도 열리는 파일이 되도록 <문서 껍데기 + 화면과 같은 모양의 style> 만 둘러 준다.
//
// 스타일을 파일 안에 적어 넣는 까닭 — 내려받은 파일은 메일로 돌거나 혼자 열린다.
// style.css 의 var(--line) 같은 것을 그대로 두면 색이 전부 빠진 채로 보인다.
// ⚠️ .view 의 모양을 고치면 여기도 같이 고쳐야 한다. 한쪽만 고치지 말 것.
const DL_CSS = `
  body { margin: 0; padding: 28px 32px; background: #fff; color: #1c2024;
         font: 13px/1.65 -apple-system, "Segoe UI", "맑은 고딕", Malgun Gothic, sans-serif; }
  .doc { max-width: 920px; margin: 0 auto; }
  h1 { font-size: 18px; margin: 0 0 4px; }
  .meta { font-size: 11.5px; color: #6b7480; margin: 0 0 18px;
          border-bottom: 1px solid #e3e6ea; padding-bottom: 10px; }
  .meta span + span::before { content: " | "; color: #c9cdd3; }
  h3 { font-size: 13.5px; margin: 14px 0 6px; padding-bottom: 3px; border-bottom: 1px solid #e3e6ea; }
  h3:first-child { margin-top: 0; }
  p { margin: 5px 0; }
  ul, ol { margin: 5px 0; padding-left: 22px; }
  li { margin: 2px 0; }
  a { color: #2f6fd0; }
  table { border-collapse: collapse; width: 100%; table-layout: fixed; margin: 8px 0; font-size: 12.5px; }
  th, td { border: 1px solid #e3e6ea; padding: 4px 7px; vertical-align: top; word-break: break-word; }
  th { background: #f6f7f9; font-weight: 600; text-align: left; }
  code { background: #eef1f4; border-radius: 3px; padding: 1px 5px;
         font-family: Consolas, "Courier New", monospace; font-size: 12px; }
  pre { background: #f5f6f8; border: 1px solid #e3e6ea; border-radius: 4px; padding: 8px 10px;
        overflow-x: auto; font-family: Consolas, "Courier New", monospace; font-size: 12px; }
  @media print { body { padding: 0; } }
`

/** 제목을 파일 이름으로 쓸 수 있게 다듬는다 (윈도에서 막히는 글자만 바꾼다). */
function safeName(s) {
  const t = String(s ?? '').replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, ' ').trim()
  return (t || '문서').slice(0, 80)
}

const esc = (s) =>
  String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')

function downloadHtml(d) {
  const meta = []
  meta.push(d.created_at ? `작성 ${d.created_at}${d.created_by ? ` · ${d.created_by}` : ''}` : '작성 기록 없음')
  if (d.updated_at) meta.push(`수정 ${d.updated_at}${d.updated_by ? ` · ${d.updated_by}` : ''}`)

  const html =
    `<!doctype html>\n<html lang="ko">\n<head>\n<meta charset="utf-8">\n` +
    `<meta name="viewport" content="width=device-width, initial-scale=1">\n` +
    `<title>${esc(d.title)}</title>\n<style>${DL_CSS}</style>\n</head>\n<body>\n` +
    `<div class="doc">\n<h1>${esc(d.title)}</h1>\n` +
    `<p class="meta">${meta.map((m) => `<span>${esc(m)}</span>`).join('')}</p>\n` +
    `${d.content || '<p>내용 없음</p>'}\n</div>\n</body>\n</html>\n`

  const p = (n) => String(n).padStart(2, '0')
  const t = new Date()
  const stamp = `${t.getFullYear()}${p(t.getMonth() + 1)}${p(t.getDate())}_${p(t.getHours())}${p(t.getMinutes())}`

  // xlsx.js 의 내려받기와 같은 방식이다 — 서버를 거치지 않고 브라우저가 바로 저장한다.
  const a = document.createElement('a')
  a.href = URL.createObjectURL(new Blob(['﻿' + html], { type: 'text/html;charset=utf-8' }))
  a.download = `${safeName(d.title)}_${stamp}.html`
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(a.href), 5000)
}

async function save(d) {
  if (!draft.value.title.trim()) {
    state.error = '제목은 필수입니다.'
    return
  }
  saving.value = true
  try {
    // 누가 고쳤는지 같이 남긴다 — <바뀌었다> 만 알려 주고 누가 바꿨는지 모르면 반쪽이다.
    // 서버가 사람을 못 가리면(서버 로컬·미등록 IP) 보내지 않는다 — 빈 값으로 덮으면 안 된다.
    const who = state.me.name || state.me.bpId || null
    await api.docUpdate(d.id, {
      title: draft.value.title,
      content: draft.value.content,
      ...(who ? { updated_by: who } : {}),
    })
    editingId.value = null
    await load()
    // 내가 방금 쓴 것이 나에게 <변경됨> 으로 보이면 안 된다
    markSeen(d.id)
    if (base.value) base.value = { ...base.value, [d.id]: seen.value[d.id] }
  } catch (e) {
    state.error = `저장 실패: ${e.message}`
  } finally {
    saving.value = false
  }
}

async function addSection() {
  const title = prompt('새 섹션 제목을 입력하세요')
  if (!title?.trim()) return
  try {
    const last = docs.value.at(-1)?.sort_order ?? 0
    const { id } = await api.docCreate({ title: title.trim(), content: '', sort_order: last + 10 })
    selId.value = id // 새 섹션을 바로 선택하고 편집 시작
    await load()
    // 내가 만든 섹션이 나에게 <새 섹션> 으로 보이면 안 된다
    markSeen(id)
    if (base.value) base.value = { ...base.value, [id]: seen.value[id] }
    const created = docs.value.find((d) => d.id === id)
    if (created) startEdit(created)
  } catch (e) {
    state.error = `추가 실패: ${e.message}`
  }
}

// ---------- 섹션을 HTML 문서로 보여 주기 (한 섹션에 여러 장) ----------
//
// 올린 파일은 iframe 으로 띄운다. 본문(content)에 풀어 넣지 않는 까닭은 서버 쪽
// (api/DocFiles.cs)에 적어 두었다 — 한 줄로 줄이면 <올린 쪽 CSS 가 대시보드를 칠한다>.
//
// 여러 장이면 탭으로 갈라 보여 준다. 세로로 쌓지 않는 까닭은, 한 장이 화면 하나만 한
// 문서라서 두 장만 쌓여도 <아래 것이 있는지> 를 스크롤해 봐야 알기 때문이다.
//
// 글과 파일은 함께 있을 수 있고, 그때는 파일이 이긴다. 글은 지우지 않는다 —
// 올린 것을 모두 내리면 쓰던 글로 돌아온다.
const ifInput = ref(null)
const ifBusy = ref(false)
const ifFiles = ref({})   // { [섹션 id]: [ {id, name, uploaded_by, uploaded_at, bytes}, ... ] }
const ifTab = ref({})     // { [섹션 id]: 보고 있는 파일 id } — 섹션을 오갈 때 보던 탭을 기억한다

/** 서버에서 받은 평평한 목록을 섹션별로 가른다 */
function putFiles(rows) {
  const m = {}
  for (const r of rows || []) (m[r.doc_id] ??= []).push(r)
  ifFiles.value = m
}

/** 지금 섹션에 올라와 있는 문서들 */
const curFiles = computed(() => (current.value ? ifFiles.value[current.value.id] || [] : []))

/** 지금 보고 있는 문서. 기억해 둔 탭이 사라졌으면 첫 장으로 되돌린다 */
const curFile = computed(() => {
  const list = curFiles.value
  if (!list.length) return null
  const want = ifTab.value[current.value.id]
  return list.find((f) => f.id === want) || list[0]
})

/**
 * 탭에 적을 이름.
 *
 * 평소에는 올릴 때의 이름을 그대로 쓴다. 다만 <같은 이름이 둘 이상이면> 저장된 이름
 * (꼬리번호가 붙은 쪽 — doc1-2.html)을 적는다. 고친 파일을 같은 이름으로 다시 올리는 일이
 * 흔한데, 그때 탭 둘이 글자까지 같으면 어느 쪽이 어느 것인지 고를 수가 없다.
 */
const ifLabels = computed(() => {
  const seen = {}
  for (const f of curFiles.value) seen[f.name] = (seen[f.name] || 0) + 1
  const m = {}
  for (const f of curFiles.value) m[f.id] = seen[f.name] > 1 ? f.file : f.name
  return m
})

/** 파일 고르기 창을 연다 — 숨겨 둔 input 을 대신 누른다 */
function pickIframe() {
  ifInput.value?.click()
}

async function uploadIframe(ev) {
  const files = [...(ev.target.files || [])]
  ev.target.value = ''            // 같은 파일을 다시 골라도 change 가 오도록
  if (!files.length || !current.value) return

  // 되묻지 않는다 — 올린 것은 한 장씩 내릴 수 있고, 글(content)은 어느 쪽이든 그대로다.
  const d = current.value
  ifBusy.value = true
  try {
    const r = await api.docIframeUpload(d.id, files)
    // 목록을 다시 받지 않고 그 자리에 붙인다 — 다시 받으면 보던 섹션이 흔들린다
    const list = (ifFiles.value[d.id] ??= [])
    list.push(...r.added)
    ifFiles.value = { ...ifFiles.value }
    // 방금 올린 것을 보여 준다. 올려 놓고 탭을 찾아 누르게 하지 않는다.
    if (r.added.length) ifTab.value[d.id] = r.added[r.added.length - 1].id
    bust.value++
    // 섞여 들어온 것(HTML 이 아니거나 너무 큰 것)은 서버가 걸러 돌려준다.
    // 나머지는 올라갔으므로 실패로 치지 않고, 무엇이 빠졌는지만 알린다.
    state.error = r.skipped?.length
      ? `올리지 못한 파일: ${r.skipped.map((s) => `${s.name} (${s.why})`).join(' · ')}`
      : ''
  } catch (e) {
    state.error = `iframe 올리기 실패: ${e.message}`
  } finally {
    ifBusy.value = false
  }
}

// ---- 붙인 문서 위의 글이 너무 길 때 ----
//
// 글은 iframe 위에 <쓴 만큼> 둔다. 다만 iframe 이 생기기 전에 쓰던 버릇으로 문서 한 벌을
// 통째로 붙여 넣은 섹션이 있다 (1.7MB · 46,000px). 그대로 두면 붙인 문서에 닿기까지
// 화면을 46,000px 내려야 하고, 더구나 그 글과 붙인 문서가 같은 문서다.
//
// 그래서 <길면> 접어 둔다. 한 번 누르면 펼쳐지고, 보통 길이의 글은 손대지 않는다.
// 붙인 문서가 없으면 접지 않는다 — 그때는 글이 화면의 전부다.
const viewEl = ref(null)
const tooLong = ref(false)
const expanded = ref(false)
const LONG = 1200   // px. 이보다 길면 아래에 있는 것을 눈으로 찾을 수 없다

async function measureView() {
  expanded.value = false
  tooLong.value = false
  await nextTick()
  if (!curFiles.value.length || !viewEl.value) return
  tooLong.value = viewEl.value.scrollHeight > LONG
}
watch([selId, curFiles], measureView, { immediate: true })

// ---- 주소(URL) 걸기 ----
const urlOpen = ref(false)
const urlBox = ref(null)
const urlForm = ref({ url: '', name: '' })

function openUrlDlg() {
  urlForm.value = { url: '', name: '' }
  urlOpen.value = true
  nextTick(() => urlBox.value?.focus())
}

async function addUrl() {
  const d = current.value
  const u = urlForm.value.url.trim()
  if (!d || !u) return
  ifBusy.value = true
  try {
    const r = await api.docIframeLink(d.id, u, urlForm.value.name.trim())
    const list = (ifFiles.value[d.id] ??= [])
    list.push(...r.added)
    ifFiles.value = { ...ifFiles.value }
    if (r.added.length) ifTab.value[d.id] = r.added[r.added.length - 1].id
    bust.value++
    state.error = ''
    urlOpen.value = false
  } catch (e) {
    state.error = `URL 연결 실패: ${e.message}`
  } finally {
    ifBusy.value = false
  }
}

/** 한 장만 내린다. 나머지는 그대로 둔다 */
async function removeIframe(f) {
  const d = current.value
  if (!d || !f) return
  // 되묻지 않는다 — 글(content)도 다른 장도 그대로 남아서, 잘못 눌렀으면 다시 올리면 된다.
  ifBusy.value = true
  try {
    await api.docIframeRemove(d.id, f.id)
    ifFiles.value[d.id] = (ifFiles.value[d.id] || []).filter((x) => x.id !== f.id)
    ifFiles.value = { ...ifFiles.value }
    if (ifTab.value[d.id] === f.id) delete ifTab.value[d.id]   // 첫 장으로 돌아간다
    state.error = ''
  } catch (e) {
    state.error = `iframe 내리기 실패: ${e.message}`
  } finally {
    ifBusy.value = false
  }
}

/** 보고 있는 탭을 왼쪽·오른쪽으로 한 칸 옮긴다 */
async function moveIframe(step) {
  const d = current.value
  const list = ifFiles.value[d?.id] || []
  const i = list.findIndex((f) => f.id === curFile.value?.id)
  const j = i + step
  if (i < 0 || j < 0 || j >= list.length) return

  const next = [...list]
  ;[next[i], next[j]] = [next[j], next[i]]
  ifFiles.value[d.id] = next
  ifFiles.value = { ...ifFiles.value }
  try {
    await api.docIframeOrder(d.id, next.map((f) => f.id))
  } catch (e) {
    state.error = `차례 바꾸기 실패: ${e.message}`
  }
}

/**
 * iframe 주소. 올릴 때마다 꼬리를 바꿔 준다 —
 * 같은 주소면 브라우저가 <먼젓번 문서> 를 캐시에서 꺼내 보여 준다.
 */
const bust = ref(0)
const iframeSrc = computed(() => {
  const f = curFile.value
  if (!f) return ''
  // 주소로 건 것은 그 주소를 그대로 연다 — 우리 서버를 거치면 그쪽 로그인이 끊긴다.
  // 꼬리(?v=)도 붙이지 않는다. 남의 주소에 모르는 값을 덧붙이는 셈이다.
  if (f.url) return f.url
  return `${api.docIframeUrl(current.value.id, f.id)}?v=${bust.value}`
})

// ---------- 휴지통 ----------
// 섹션 하나에 팀이 한참 쌓아 둔 글이 들어 있다. 지우는 것은 휴지통으로 보내는 것이고,
// 되돌릴 수 없는 삭제는 휴지통에서 한 번 더 물어보고 한다.
const trash = ref([])
const showTrash = ref(false)
const undo = ref(null) // { id, title } — 방금 지운 것. 잠깐 띠를 띄운다.
let undoTimer = null

async function loadTrash() {
  try {
    trash.value = await api.docTrash()
  } catch {
    /* 휴지통을 못 읽어도 본 화면은 그대로 쓴다 */
  }
}

function showUndo(d) {
  undo.value = { id: d.id, title: d.title }
  clearTimeout(undoTimer)
  // 띠는 잠깐만 — 놓쳐도 휴지통에 그대로 있다
  undoTimer = setTimeout(() => (undo.value = null), 12000)
}

async function restore(id) {
  try {
    await api.docRestore(id)
    undo.value = null
    selId.value = id
    await load()
    await loadTrash()
  } catch (e) {
    state.error = `되돌리기 실패: ${e.message}`
  }
}

async function purge(d) {
  if (!confirm(`"${d.title}" 을 완전히 지웁니다. 이것은 되돌릴 수 없습니다.`)) return
  try {
    await api.docPurge(d.id)
    if (undo.value?.id === d.id) undo.value = null
    await loadTrash()
  } catch (e) {
    state.error = `완전 삭제 실패: ${e.message}`
  }
}

async function remove(d) {
  if (!confirm(`"${d.title}" 섹션을 휴지통으로 보낼까요? 되돌릴 수 있습니다.`)) return
  try {
    // 삭제 후에는 이웃 섹션을 선택
    const i = docs.value.findIndex((x) => x.id === d.id)
    const next = docs.value[i + 1]?.id ?? docs.value[i - 1]?.id ?? null
    await api.docDelete(d.id)
    editingId.value = null
    selId.value = next
    showUndo(d)
    await load()
    await loadTrash()
  } catch (e) {
    state.error = `삭제 실패: ${e.message}`
  }
}

// 선택이 바뀌면 본문 위로. 고른 것은 <봤다> 로 굳힌다 (표시는 이번 방문 동안 남는다).
watch(selId, (id) => {
  scrollContentTop(true)
  if (id != null) markSeen(id)
})

useViewRefresh(load)
onMounted(async () => {
  await load()
  await loadSeen()
  loadTrash()
  // 처음 열릴 때 고른 섹션도 본 것이다
  if (selId.value != null) markSeen(selId.value)
})
</script>

<template>
  <div class="wrap">
    <aside class="toc panel">
      <h2>
        목차 <span class="hint">{{ toc.length }}</span>
        <span v-if="unseen" class="cnt" :title="`마지막으로 본 뒤에 바뀐 섹션 ${unseen}개`">
          {{ unseen }}
        </span>
        <span class="spacer"></span>
        <button v-if="unseen" class="seenall" title="모두 읽은 것으로 표시" @click="markAllSeen">
          ✓
        </button>
        <button
          v-if="trash.length"
          class="trashbtn"
          :class="{ on: showTrash }"
          :title="`휴지통 ${trash.length}건 — 되돌릴 수 있습니다`"
          @click="showTrash = !showTrash"
        >
          🗑 {{ trash.length }}
        </button>
        <RefreshBtn :fn="load" label="" />
      </h2>
      <a
        v-for="t in toc"
        :key="t.id"
        class="item"
        :class="{
          on: t.id === selId,
          dragging: t.id === dragId,
          [`over-${overPos}`]: t.id === overId,
        }"
        href="#"
        :title="t.title"
        :draggable="editingId === null"
        @click.prevent="select(t.id)"
        @dragstart="onDragStart($event, t.id)"
        @dragover="onDragOver($event, t.id)"
        @dragleave="onDragLeave(t.id)"
        @drop="onDrop($event, t.id)"
        @dragend="clearDrag"
      >
        <span class="grip" aria-hidden="true">⠿</span>
        <span class="tt">{{ t.title }}</span>
        <span
          v-if="t.inner"
          class="bdg in"
          :title="`올려 둔 HTML 문서 ${t.inner}장이 붙어 있습니다`"
        >⧉<template v-if="t.inner > 1">{{ t.inner }}</template></span>
        <span
          v-if="t.outer"
          class="bdg out"
          :title="`주소(URL)로 건 화면 ${t.outer}개가 붙어 있습니다`"
        >↗<template v-if="t.outer > 1">{{ t.outer }}</template></span>
        <span
          v-if="t.mark"
          class="mk"
          :class="t.mark"
          :title="t.mark === 'new' ? '처음 보는 섹션입니다' : '마지막으로 본 뒤에 내용이 바뀌었습니다'"
        >{{ t.mark === 'new' ? 'N' : '●' }}</span>
      </a>

      <p v-if="!toc.length && !loading" class="muted empty">섹션이 없습니다.</p>
      <p v-else class="muted drophint">끌어서 순서를 바꿀 수 있습니다.</p>
      <button class="add" @click="addSection">+ 섹션 추가</button>

      <div v-if="showTrash && trash.length" class="trash">
        <div class="th">휴지통</div>
        <div v-for="d in trash" :key="d.id" class="row">
          <div class="nm" :title="d.title">{{ d.title }}</div>
          <div class="mt">
            {{ d.deleted_at }}
            <template v-if="d.deleted_by"> · {{ d.deleted_by }}</template>
          </div>
          <div class="bt">
            <button title="되돌린다 (지운 자리로 돌아갑니다)" @click="restore(d.id)">되돌리기</button>
            <button class="del" title="완전히 지운다 — 되돌릴 수 없습니다" @click="purge(d)">완전 삭제</button>
          </div>
        </div>
      </div>
    </aside>

    <div class="doc">
      <p v-if="undo" class="panel undobar">
        <b>{{ undo.title }}</b> 을(를) 휴지통으로 보냈습니다.
        <button @click="restore(undo.id)">되돌리기</button>
        <span class="spacer"></span>
        <button class="x" title="닫기" @click="undo = null">✕</button>
      </p>
      <section v-if="current" class="panel sec">
        <h2>
          <template v-if="editingId === current.id">
            <input v-model="draft.title" class="ttl" type="text" placeholder="제목" />
          </template>
          <template v-else>{{ current.title }}</template>

          <span class="spacer"></span>
          <span v-if="markOf(current)" class="badge" :class="markOf(current)">
            {{ markOf(current) === 'new' ? '새 섹션' : '변경됨' }}
          </span>
          <span class="hint meta">
            <span
              v-if="current.created_at"
              :title="current.created_by ? `${current.created_by} 님이 처음 작성` : '최초 작성 시각'"
            >
              작성 {{ current.created_at }}
              <template v-if="current.created_by"> · {{ current.created_by }}</template>
            </span>
            <span v-else class="none" title="작성 기록을 남기기 전에 만들어진 섹션입니다">작성 —</span>
            <span v-if="current.updated_at" :title="current.updated_by ? `${current.updated_by} 님이 마지막 수정` : '최종 수정 시각'">
              수정 {{ current.updated_at }}
              <template v-if="current.updated_by"> · {{ current.updated_by }}</template>
              <template v-else> · 수정자 미상</template>
            </span>
          </span>

          <template v-if="editingId === current.id">
            <button :disabled="saving" @click="save(current)">{{ saving ? '저장 중…' : '저장' }}</button>
            <button :disabled="saving" @click="cancel">취소</button>
          </template>
          <template v-else>
            <button title="이 섹션을 HTML 파일로 내려받습니다" @click="downloadHtml(current)">⤓ 다운로드</button>
            <!-- HTML 을 여러 장 올려 iframe 으로 보여 준다. 올려 둔 장수를 단추에 적는다 -->
            <button
              :class="{ ifon: curFiles.length }"
              :disabled="ifBusy"
              title="HTML 파일을 올려 이 섹션을 그 문서로 보여 줍니다 (여러 장 고를 수 있고, 글은 그대로 남습니다)"
              @click="pickIframe"
            >
              {{ ifBusy ? '올리는 중…' : curFiles.length ? `⧉ iframe 추가 (${curFiles.length})` : '⧉ iframe 삽입' }}
            </button>
            <button
              :disabled="ifBusy"
              title="파일을 올리는 대신 주소(URL)를 걸어 그 화면을 띄웁니다"
              @click="openUrlDlg"
            >↗ URL 연결</button>
            <button @click="startEdit(current)">편집</button>
            <button class="del" @click="remove(current)">삭제</button>
          </template>
        </h2>

        <RichEditor v-if="editingId === current.id" v-model="draft.content" />

        <!-- 편집으로 쓴 글은 iframe 이 있어도 <맨 위에> 그대로 둔다.
             높이를 매기지 않는다 — 쓴 만큼만 차지하고, 남는 자리는 아래 iframe 이 쓴다.
             글이 없을 때만 iframe 이 자리를 다 쓴다. -->
        <template v-else>
          <div
            v-if="current.content || !curFiles.length"
            ref="viewEl"
            class="view"
            :class="{ above: curFiles.length, clip: tooLong && !expanded }"
            v-html="current.content || '<p class=\'muted\'>내용 없음 — 편집을 눌러 작성하세요.</p>'"
          ></div>
          <button v-if="tooLong" class="more" @click="expanded = !expanded">
            {{ expanded ? '▲ 글 접기' : '▼ 글 펼치기 — 붙인 문서가 아래에 있습니다' }}
          </button>

          <!-- 올려 둔 문서 · 걸어 둔 주소. 여러 장이면 탭으로 가른다. -->
          <template v-if="curFiles.length">
            <div v-if="curFiles.length > 1" class="iftabs">
              <button
                v-for="f in curFiles"
                :key="f.id"
                class="iftab"
                :class="{ on: f.id === curFile.id, ext: f.url }"
                :title="f.url || f.name"
                @click="ifTab[current.id] = f.id"
              >
                {{ f.url ? '↗' : '⧉' }} {{ ifLabels[f.id] }}
              </button>
            </div>

            <p class="ifbar" :class="{ ext: curFile.url }">
              <b>{{ curFile.url ? '↗' : '⧉' }} {{ ifLabels[curFile.id] }}</b>
              <span class="hint">
                {{ curFile.url ? '주소로 연결' : '올린 사람' }}
                {{ curFile.url ? '' : curFile.uploaded_by || '—'
                }}<template v-if="curFile.uploaded_at"> · {{ curFile.uploaded_at }}</template>
              </span>
              <span class="spacer"></span>
              <template v-if="curFiles.length > 1">
                <button class="ifmv" title="이 탭을 왼쪽으로" :disabled="curFiles[0].id === curFile.id" @click="moveIframe(-1)">◀</button>
                <button class="ifmv" title="이 탭을 오른쪽으로" :disabled="curFiles[curFiles.length - 1].id === curFile.id" @click="moveIframe(1)">▶</button>
              </template>
              <a :href="iframeSrc" target="_blank" rel="noopener noreferrer" class="lk">새 탭으로 열기 ↗</a>
              <button class="ifmv del" :disabled="ifBusy" :title="`${curFile.name} 내리기`" @click="removeIframe(curFile)">
                {{ curFile.url ? '이 연결 내리기' : '이 문서 내리기' }}
              </button>
            </p>
            <!-- 남의 사이트는 X-Frame-Options 로 iframe 을 막아 두기도 한다. 그때는 빈 칸으로
                 보이는데, 브라우저가 그 사정을 자바스크립트로 알려 주지 않는다(cross-origin).
                 그래서 막혔는지 따지는 대신, 걸어 둔 주소에는 늘 한 줄을 적어 둔다. -->
            <p v-if="curFile.url" class="ifnote">
              빈 칸으로 보이면 그 사이트가 iframe 을 막아 둔 것입니다 — 위의 [새 탭으로 열기] 로 여세요.
            </p>
            <iframe
              :key="curFile.id"
              :src="iframeSrc"
              class="ifdoc"
              :class="{ short: current.content }"
              :title="curFile.name"
              sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
              loading="lazy"
            ></iframe>
          </template>
        </template>

        <!-- 주소 걸기. 브라우저의 prompt 를 쓰지 않는다 — 창 모양도 제각각이고,
             이름을 함께 받을 칸을 둘 수 없다. 바깥을 눌러도 닫히지 않고 ✕ 로만 닫는다. -->
        <div v-if="urlOpen" class="dlgwrap" @click.self.stop>
          <div class="dlg">
            <h3>
              ↗ URL 연결
              <button class="x" title="닫기" @click="urlOpen = false">✕</button>
            </h3>
            <label>
              주소
              <input
                ref="urlBox"
                v-model="urlForm.url"
                type="url"
                placeholder="https://dev-wbs.hd.com/… (https:// 는 생략해도 됩니다)"
                @keydown.enter.prevent="addUrl"
              />
            </label>
            <label>
              이름 <span class="muted">(비우면 주소에서 땁니다)</span>
              <input v-model="urlForm.name" placeholder="탭에 적을 이름" @keydown.enter.prevent="addUrl" />
            </label>
            <p class="muted note">
              사이트가 iframe 을 막아 두었으면(X-Frame-Options) 빈 칸으로 보입니다.
              그때는 띠의 [새 탭으로 열기] 로 엽니다.
            </p>
            <div class="btns">
              <button class="go" :disabled="ifBusy || !urlForm.url.trim()" @click="addUrl">
                {{ ifBusy ? '거는 중…' : '연결' }}
              </button>
              <button @click="urlOpen = false">취소</button>
            </div>
          </div>
        </div>

        <!-- 고르기 창은 숨겨 둔다. 단추가 대신 누른다. -->
        <input
          ref="ifInput"
          type="file"
          accept=".html,.htm,text/html"
          multiple
          style="display: none"
          @change="uploadIframe"
        />
      </section>

      <p v-else-if="!loading" class="muted" style="padding: 24px; text-align: center">
        {{ toc.length ? '좌측 목차에서 섹션을 선택하세요.' : '등록된 문서가 없습니다. + 섹션 추가 로 시작하세요.' }}
      </p>
    </div>
  </div>
</template>

<style scoped>
.wrap { display: flex; gap: 14px; align-items: flex-start; }

/* 올려 둔 문서 — 섹션 자리를 꽉 채운다. 높이를 작게 잡으면 그 안에서 또 구르게 되어
   문서 하나를 두 겹으로 스크롤하게 된다. */
.ifdoc {
  width: 100%;
  height: calc(100vh - 250px);
  min-height: 420px;
  border: 1px solid var(--line);
  background: #fff;
  display: block;
}
.ifbar {
  display: flex; align-items: baseline; gap: 8px; flex-wrap: wrap;
  margin: 0 0 8px; padding: 5px 9px; font-size: 11.5px;
  background: var(--accent-soft); border: 1px solid var(--accent); color: var(--accent);
}
.ifbar .spacer { flex: 1; }
.ifbar .hint { color: var(--muted); font-weight: 400; }
.ifbar .lk { color: var(--accent); font-size: 11px; }
button.ifon { color: var(--accent); border-color: var(--accent); background: var(--accent-soft); }

/* 여러 장일 때의 탭. 세로로 쌓지 않는 까닭은 script 쪽에 적어 두었다 —
   한 장이 화면 하나만 한 문서라 쌓으면 아래 것이 있는지를 스크롤해 봐야 안다. */
.iftabs {
  display: flex; flex-wrap: wrap; gap: 3px;
  margin: 0 0 6px; padding: 0 0 1px;
  border-bottom: 1px solid var(--line);
}
.iftab {
  max-width: 230px; padding: 5px 10px;
  font-size: 11.5px; border-radius: 0;          /* 각지게 — 선만 곡선이다 */
  border: 1px solid var(--line); border-bottom: none;
  background: var(--panel-2, #f3f3f3); color: var(--muted);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.iftab:hover { color: var(--text); }
.iftab.on {
  background: var(--accent-soft); border-color: var(--accent); color: var(--accent);
  font-weight: 600;
}
.ifbar .ifmv {
  padding: 1px 7px; font-size: 11px; line-height: 1.5; border-radius: 0;
  border: 1px solid var(--accent); background: transparent; color: var(--accent);
}
.ifbar .ifmv:disabled { opacity: 0.35; }
.ifbar .ifmv.del { border-color: var(--line); color: var(--muted); }
.ifbar .ifmv.del:hover:not(:disabled) { border-color: var(--danger, #b4232a); color: var(--danger, #b4232a); }

/* 글이 위에 있을 때의 iframe — 글이 쓰는 만큼을 뺀 나머지를 쓴다.
   글 길이를 미리 알 수 없으므로 높이를 못 박지 않고 최소 높이만 준다. */
.view.above { margin-bottom: 10px; }
/* 너무 긴 글은 접어 둔다 — 까닭은 script 쪽 measureView 에 적어 두었다.
   끝을 흐리게 지워 <더 있다> 는 것을 보여 준다. */
.view.clip {
  max-height: 1200px; overflow: hidden; margin-bottom: 0;
  mask-image: linear-gradient(to bottom, #000 calc(100% - 90px), transparent 100%);
  -webkit-mask-image: linear-gradient(to bottom, #000 calc(100% - 90px), transparent 100%);
}
button.more {
  display: block; width: 100%; margin: 0 0 10px; padding: 5px;
  font-size: 11.5px; border-radius: 0;
  border: 1px solid var(--line); background: var(--panel-2, #f3f3f3); color: var(--muted);
}
button.more:hover { color: var(--text); border-color: var(--muted); }
.ifdoc.short { height: auto; min-height: 60vh; flex: 1; }
.ifnote {
  margin: -4px 0 8px; padding: 4px 9px; font-size: 11px;
  color: var(--muted); background: var(--panel-2, #f3f3f3); border: 1px solid var(--line);
}

/* 바깥 주소로 건 것은 띠와 탭의 빛깔을 달리한다 — 우리 서버의 문서와 섞이지 않게 */
.iftab.ext.on, .ifbar.ext { border-color: var(--muted); background: var(--panel-2, #f3f3f3); color: var(--text); }
.ifbar.ext .lk { color: var(--text); }

/* 목차 배지 — ⧉ 올린 문서 · ↗ 건 주소 */
.toc .bdg {
  flex: none; margin-left: 3px; padding: 0 3px;
  font-size: 10px; line-height: 15px; border-radius: 0;   /* 각지게 */
  border: 1px solid var(--line); color: var(--muted); background: var(--panel-2, #f3f3f3);
}
.toc .bdg.in { border-color: var(--accent); color: var(--accent); background: var(--accent-soft); }
.toc .item.on .bdg { border-color: currentColor; color: inherit; background: transparent; }

/* 주소 걸기 창 — 바깥을 눌러도 닫히지 않는다(✕ 로만) */
.dlgwrap {
  position: fixed; inset: 0; z-index: 60;
  display: flex; align-items: flex-start; justify-content: center; padding-top: 14vh;
  background: rgba(0, 0, 0, 0.35);
}
.dlg {
  width: min(520px, 92vw); padding: 14px 16px 12px;
  background: var(--panel); border: 1px solid var(--line); box-shadow: 0 10px 30px rgba(0, 0, 0, 0.25);
}
.dlg h3 { display: flex; align-items: center; margin: 0 0 10px; font-size: 14px; }
.dlg h3 .x { margin-left: auto; padding: 1px 7px; border-radius: 0; }
.dlg label { display: block; margin-bottom: 9px; font-size: 12px; color: var(--muted); }
.dlg label input {
  display: block; width: 100%; margin-top: 3px; padding: 6px 8px;
  font-size: 12.5px; border-radius: 0; border: 1px solid var(--line);
  background: var(--bg); color: var(--text);
}
.dlg .note { margin: 2px 0 12px; font-size: 11px; line-height: 1.5; }
.dlg .btns { display: flex; gap: 6px; justify-content: flex-end; }
.dlg .btns .go { border-color: var(--accent); color: var(--accent); background: var(--accent-soft); }
.toc { width: 210px; flex: none; position: sticky; top: 14px; }
.toc h2 { display: flex; align-items: center; gap: 6px; }
.toc h2 .spacer { flex: 1; }
.toc .item {
  display: block;
  padding: 6px 8px;
  border-radius: 5px;
  color: var(--text);
  text-decoration: none;
  font-size: 12.5px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.toc .item:hover { background: var(--hover); }
.toc .item.on { background: var(--accent-soft); color: var(--accent); font-weight: 600; }
/* 제목은 줄이되 표식은 늘 보이게 — 표식이 잘리면 표시한 뜻이 없다 */
.toc .item { display: flex; align-items: center; gap: 5px; }
.toc .item .tt { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; }
.toc .item .mk { flex: none; font-size: 9.5px; line-height: 1; font-weight: 700; }
/* 끌기 손잡이 — 평소에는 숨겼다가 가리키면 나온다. 목차가 좁아 늘 두면 제목을 먹는다. */
.toc .item .grip { flex: none; width: 9px; color: var(--muted); opacity: 0; font-size: 9px; cursor: grab; }
.toc .item:hover .grip { opacity: 0.7; }
.toc .item.dragging { opacity: 0.4; }
/* 놓을 자리를 줄로 보여 준다 — 위/아래 어디로 들어가는지가 이것으로만 구별된다 */
.toc .item.over-before { box-shadow: inset 0 2px 0 var(--accent); }
.toc .item.over-after { box-shadow: inset 0 -2px 0 var(--accent); }
.toc .drophint { font-size: 10.5px; padding: 6px 8px 0; }
.toc .item .mk.new { color: var(--on-accent); background: var(--warn); border-radius: 3px; padding: 2px 4px; }
.toc .item .mk.upd { color: var(--warn); font-size: 11px; }
.toc h2 .cnt {
  background: var(--warn); color: var(--on-accent); border-radius: 999px;
  padding: 0 6px; font-size: 10.5px; font-weight: 700;
}
.toc h2 .seenall { padding: 1px 6px; font-size: 11px; }
.sec h2 .badge {
  font-size: 10.5px; font-weight: 700; border-radius: 3px; padding: 1px 6px;
  color: var(--on-accent); background: var(--warn);
}
.toc .empty { font-size: 12px; padding: 4px 8px; }
.toc .add { width: 100%; margin-top: 10px; }
.doc { flex: 1; min-width: 0; }
.undobar {
  display: flex; align-items: center; gap: 8px;
  padding: 8px 12px; margin: 0 0 10px; font-size: 12.5px;
  border-left: 3px solid var(--accent);
}
.undobar .spacer { flex: 1; }
.undobar button { padding: 2px 10px; font-size: 11.5px; }
.undobar .x { padding: 2px 7px; }

.toc h2 .trashbtn { padding: 1px 7px; font-size: 11px; }
.toc .trash { margin-top: 12px; border-top: 1px solid var(--line); padding-top: 8px; }
.toc .trash .th { font-size: 11px; color: var(--muted); font-weight: 600; margin-bottom: 5px; }
.toc .trash .row { padding: 5px 4px; border-bottom: 1px dashed var(--line); }
.toc .trash .nm { font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.toc .trash .mt { font-size: 10.5px; color: var(--muted); margin: 1px 0 4px; }
.toc .trash .bt button { padding: 1px 6px; font-size: 10.5px; margin-right: 3px; }
.toc .trash .bt .del:hover { border-color: var(--danger-2); color: var(--danger-2); }

.sec h2 { display: flex; align-items: center; gap: 6px; }
.sec h2 .spacer { flex: 1; }
.sec h2 .ttl { font-size: 13px; font-weight: 600; width: 260px; }
/* 작성·수정을 한 덩어리로 묶는다 — 머리글이 좁아지면 버튼보다 이쪽이 먼저 줄어야 한다 */
.sec h2 .meta { display: flex; gap: 6px; min-width: 0; white-space: nowrap; overflow: hidden; }
.sec h2 .meta > span + span::before { content: '|'; color: var(--line); margin-right: 6px; }
.sec h2 .meta .none { opacity: 0.6; }
.del:hover { border-color: var(--danger-2); color: var(--danger-2); }

.view { font-size: 13px; line-height: 1.65; }
.view :deep(h3) { font-size: 13.5px; margin: 14px 0 6px; padding-bottom: 3px; border-bottom: 1px solid var(--line); }
.view :deep(h3:first-child) { margin-top: 0; }
.view :deep(p) { margin: 5px 0; }
.view :deep(ul), .view :deep(ol) { margin: 5px 0; padding-left: 22px; }
.view :deep(li) { margin: 2px 0; }
.view :deep(a) { color: var(--accent); }
/* 표 — 편집기(RichEditor.vue .body)와 같은 모양이어야 한다. 한쪽만 고치지 말 것. */
.view :deep(table) {
  border-collapse: collapse;
  width: 100%;
  table-layout: fixed;
  margin: 8px 0;
  font-size: 12.5px;
}
.view :deep(th), .view :deep(td) {
  border: 1px solid var(--line);
  padding: 4px 7px;
  vertical-align: top;
  word-break: break-word;
}
.view :deep(th) { background: var(--bg); font-weight: 600; text-align: left; }
.view :deep(code) {
  background: var(--fill);
  border-radius: 3px;
  padding: 1px 5px;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 12px;
}
.view :deep(pre) {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 4px;
  padding: 8px 10px;
  overflow-x: auto;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 12px;
}

@media (max-width: 900px) {
  .wrap { flex-direction: column; }
  .toc { width: auto; position: static; }
}
</style>
