<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { screenUrls } from '../store'

// 상세 목록의 메뉴명을 누르면 뜨는 작은 메뉴 — 그 화면을 <운영> 과 <개발> 어느 쪽으로든 연다.
//
// 큰 다이얼로그(.dlg)를 쓰지 않은 까닭: 고를 것이 둘뿐이고, 누른 자리에서 바로 골라야
// 212줄을 훑는 흐름이 끊기지 않는다. 그래서 누른 자리에 붙고 아무 데나 누르면 닫힌다.
//
// 주소를 눈에 보이게 적어 둔다. 화면코드가 'TBD2550' 처럼 아직 정해지지 않은 줄도 있어,
// 열기 전에 <어디로 가는지> 를 볼 수 있어야 한다.
const props = defineProps({
  row: { type: Object, required: true },
  x: { type: Number, required: true },
  y: { type: Number, required: true },
})
const emit = defineEmits(['close'])

const urls = computed(() => screenUrls(props.row))

// 화면 밖으로 삐져나가지 않게 — 아래쪽 줄에서 누르면 메뉴가 화면 밑으로 잘린다
const W = 320
const H = 150
const pos = computed(() => ({
  left: Math.min(props.x, window.innerWidth - W - 12) + 'px',
  top: Math.min(props.y, window.innerHeight - H - 12) + 'px',
}))

const box = ref(null)

function open(url) {
  if (!url) return
  window.open(url, '_blank', 'noopener')
  emit('close')
}

function onKey(e) {
  if (e.key === 'Escape') emit('close')
}
onMounted(() => window.addEventListener('keydown', onKey))
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <div class="mask" @click.self="emit('close')" @contextmenu.prevent="emit('close')">
    <div ref="box" class="menu" :style="pos">
      <div class="hd" :title="row.menu_nm">
        <b>{{ urls?.code ?? '화면코드 없음' }}</b>
        <span class="nm">{{ row.menu_nm }}</span>
      </div>

      <template v-if="urls">
        <button class="item" @click="open(urls.ops)">
          <span class="t">운영 화면</span>
          <span class="u">{{ urls.ops }}</span>
        </button>

        <button class="item" :disabled="!urls.dev" @click="open(urls.dev)">
          <span class="t">
            개발 화면
            <em v-if="urls.dev">내 PC 의 개발서버</em>
            <em v-else>모듈번호를 읽지 못했습니다</em>
          </span>
          <span class="u">{{ urls.dev ?? '—' }}</span>
        </button>

        <p class="note">
          개발 화면은 <b>이 PC</b> 에서 {{ urls.module }} 개발서버가 떠 있어야 열립니다
          (<b>로컬 개발서버</b> 화면에서 띄웁니다).
        </p>
      </template>

      <p v-else class="note bad">
        메뉴명이 <code>[코드]</code> 로 시작하지 않거나 모듈이 비어 있어 주소를 만들 수 없습니다.
      </p>
    </div>
  </div>
</template>

<style scoped>
/* 투명한 덮개 — 아무 데나 누르면 닫히게 하려는 것뿐이라 어둡게 하지 않는다 */
.mask { position: fixed; inset: 0; z-index: 120; }
.menu {
  position: fixed;
  width: 320px;
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 8px;
  box-shadow: 0 10px 30px var(--shadow);
  overflow: hidden;
}
.hd {
  padding: 7px 10px;
  border-bottom: 1px solid var(--line);
  background: var(--bg);
  font-size: 11.5px;
  display: flex;
  gap: 6px;
  align-items: baseline;
}
.hd b { font-size: 12.5px; }
.hd .nm { color: var(--muted); min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.item {
  display: block;
  width: 100%;
  text-align: left;
  border: 0;
  border-bottom: 1px solid var(--line);
  border-radius: 0;
  background: none;
  padding: 8px 10px;
  cursor: pointer;
}
.item:hover:not(:disabled) { background: var(--accent-soft); }
.item:disabled { opacity: 0.45; cursor: not-allowed; }
.item .t { display: block; font-size: 12.5px; font-weight: 600; color: var(--text); }
.item .t em { font-style: normal; font-weight: 400; font-size: 11px; color: var(--muted); margin-left: 5px; }
/* 주소를 그대로 보여 준다 — 열기 전에 어디로 가는지 확인할 수 있어야 한다 */
.item .u {
  display: block;
  margin-top: 2px;
  font-size: 10.5px;
  color: var(--accent);
  font-family: Consolas, 'Courier New', monospace;
  word-break: break-all;
}
.note { margin: 0; padding: 7px 10px; font-size: 10.5px; color: var(--muted); line-height: 1.5; }
.note.bad { color: var(--warn); }
.note code { font-family: Consolas, 'Courier New', monospace; }
</style>
