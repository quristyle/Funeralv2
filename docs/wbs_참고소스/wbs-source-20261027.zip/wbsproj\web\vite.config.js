import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'



// 개발 서버는 반드시 localhost 전용으로 둔다.
// 0.0.0.0 으로 열면 IP 접근 제어(IpGate)를 우회하는 경로가 된다 —
// 프록시가 API 를 대신 호출하므로 API 쪽에서는 모든 요청이 127.0.0.1(=항상 허용)로 보인다.
// 다른 사용자에게 공유할 때는 반드시 5080(serve.cmd) 을 사용할 것.
export default defineConfig({
  plugins: [vue()],
  server: {
    host: 'localhost',
    port: 5173,
    strictPort: true,
    open: false,
    proxy: {
      // xfwd: 원래 클라이언트 IP 를 X-Forwarded-For 로 넘겨 API 가 실제 IP 로 판정하게 한다
      '/api': { target: 'http://localhost:5080', changeOrigin: true, xfwd: true },
      // 붙여넣은 이미지도 API 가 서비스한다
      '/uploads': { target: 'http://localhost:5080', changeOrigin: true, xfwd: true },
    },
  },
  build: {
    outDir: '../api/wwwroot',
    emptyOutDir: true,
  },
})
