<script setup>
import { computed, onMounted, ref } from 'vue'
import { api } from '../api'
import { state, useViewRefresh, loadMe } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'
import { ALWAYS_ON, MENU_META } from '../menuList'

// 개발자 × 메뉴 격자. 체크가 켜져 있으면 쓸 수 있다.
//
// 저장하는 것은 <막은 것>뿐이다 — 행이 없으면 허용이라, 아무것도 안 건드린 사람은
// DB 에 한 줄도 생기지 않는다. 메뉴를 새로 만들어도 저절로 숨지 않는 까닭이 이것이다.
const users = ref([])
const menus = ref([])
const denied = ref({}) // bp_id → Set(menu_key)
const origin = ref({}) // bp_id → 저장된 상태 (변경 감지)
const loading = ref(false)
const saving = ref(null)
const saved = ref({})

const keyOf = (set) => [...set].sort().join(',')

/**
 * 열을 사이드바와 같은 묶음(폴더)으로 나눈 머리줄.
 * 메뉴가 스물 몇 개라 이름만 늘어놓으면 찾는 칸이 어디인지 눈으로 못 쫓는다.
 * 폴더가 없는 메뉴는 묶지 않고 빈 칸으로 둔다 — 억지로 이름을 지어 붙이지 않는다.
 */
const groups = computed(() => {
  const out = []
  for (const m of menus.value) {
    const nm = m.folder_nm ?? ''
    const last = out[out.length - 1]
    if (last && last.nm === nm) last.span++
    else out.push({ nm, span: 1 })
  }
  return out
})

async function load() {
  loading.value = true
  try {
    // 화면이 가진 메뉴를 먼저 올려 DB 와 맞춘다 — 새로 만든 메뉴가 여기 빠지지 않도록
    await api
      .menuSync(MENU_META.map((m, i) => ({ menu_key: m.key, menu_nm: m.label, sort_order: i + 1 })))
      .catch(() => {}) // 맞추기에 실패해도 아래 조회는 그대로 한다

    const [us, ms, ps] = await Promise.all([api.devUsers(), api.menus(), api.menuPerms()])
    users.value = us.filter((u) => u.bp_id)
    menus.value = ms
    const d = {}
    for (const u of users.value) d[u.bp_id] = new Set()
    for (const p of ps) (d[p.bp_id] ??= new Set()).add(p.menu_key)
    denied.value = d
    origin.value = Object.fromEntries(Object.entries(d).map(([k, v]) => [k, keyOf(v)]))
  } catch (e) {
    state.error = e.message
  } finally {
    loading.value = false
  }
}

const locked = (k) => ALWAYS_ON.has(k)
const allowed = (bp, k) => !denied.value[bp]?.has(k)
const dirty = (bp) => origin.value[bp] !== keyOf(denied.value[bp] ?? new Set())

function toggle(bp, k) {
  if (locked(k)) return
  const set = (denied.value[bp] ??= new Set())
  if (set.has(k)) set.delete(k)
  else set.add(k)
  denied.value = { ...denied.value } // Set 안의 변화는 추적되지 않는다
  save(bp)
}

/** 한 사람의 모든 메뉴를 켜거나 끈다 */
function setAll(bp, on) {
  const set = new Set()
  if (!on) for (const m of menus.value) if (!locked(m.menu_key)) set.add(m.menu_key)
  denied.value = { ...denied.value, [bp]: set }
  save(bp)
}

const lastSave = new Map()
async function save(bp) {
  const run = async () => {
    if (!dirty(bp)) return
    saving.value = bp
    try {
      const sent = keyOf(denied.value[bp])
      await api.menuPermSave(bp, [...denied.value[bp]])
      origin.value[bp] = sent
      saved.value[bp] = Date.now()
      setTimeout(() => {
        if (Date.now() - (saved.value[bp] ?? 0) >= 1900) delete saved.value[bp]
      }, 2000)
      // 내 권한을 내가 바꿨으면 사이드바가 곧바로 따라야 한다
      if (bp === state.me.bpId) await loadMe()
    } catch (e) {
      state.error = `권한 저장 실패: ${bp} — ${e.message}`
    } finally {
      saving.value = null
    }
  }
  const next = (lastSave.get(bp) ?? Promise.resolve()).then(run).catch(() => {})
  lastSave.set(bp, next)
  return next
}


// 저장 상태 표시 — <미저장 → 저장 중… → ✓ → 없음> 으로 글자가 바뀐다.
// 이 글자의 너비가 바뀌면 개발자 칸이 넓어졌다 좁아지고, 표 전체 열 너비가 다시 잡힌다.
// 가로로 넘치는 표에서는 그때마다 화면이 좌우로 흔들린다. 그래서 세 갈래를 한 칸으로
// 합치고, 아래 CSS 에서 그 칸에 고정 너비를 준다 (빈 상태에도 자리를 남긴다).
// 표식은 한 자로 둔다 — 개발자 칸을 좁히려는 것이고, 글자가 길면 그 칸이 다시 넓어진다.
// 무슨 뜻인지는 마우스를 올리면 나온다.
const stMark = (bp) =>
  saving.value === bp ? '⋯' : saved.value[bp] ? '✓' : dirty(bp) ? '●' : ''
const stCls = (bp) =>
  saving.value === bp ? 'busy' : saved.value[bp] ? 'ok' : dirty(bp) ? 'warn' : ''
const stTitle = (bp) =>
  saving.value === bp
    ? '저장 중…'
    : saved.value[bp]
      ? '저장했습니다'
      : dirty(bp)
        ? '아직 저장되지 않았습니다'
        : ''

const deniedCount = (bp) => denied.value[bp]?.size ?? 0
const totalDenied = computed(() =>
  Object.values(denied.value).reduce((a, s) => a + (s?.size ?? 0), 0)
)

useViewRefresh(load)
onMounted(load)
</script>

<template>
  <section class="panel">
    <h2>
      메뉴 권한
      <span class="hint">
        개발자 {{ users.length }}명 × 메뉴 {{ menus.length }}개{{
          totalDenied ? ` · 막은 칸 ${totalDenied}` : ' · 제한 없음'
        }}{{ loading ? ' · 불러오는 중…' : '' }}
      </span>
      <span class="spacer"></span>
      <RefreshBtn :fn="load" label="새로고침" />
    </h2>

    <div class="wrap">
      <table>
        <thead>
          <tr class="grp">
            <th class="who"></th>
            <th v-for="(g, i) in groups" :key="i" :colspan="g.span" class="gh">{{ g.nm }}</th>
            <th class="act"></th>
          </tr>
          <tr>
            <th class="who">개발자</th>
            <th v-for="m in menus" :key="m.menu_key" class="mn" :title="m.menu_key">
              <span>{{ m.menu_nm || m.menu_key }}</span>
            </th>
            <th class="act">전체</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="u in users" :key="u.bp_id" :class="{ some: deniedCount(u.bp_id) }">
            <td class="who">
              <b>{{ u.name || u.bp_id }}</b>
              <span class="bp">{{ u.bp_id }}</span>
              <span class="st" :class="stCls(u.bp_id)" :title="stTitle(u.bp_id)">
                {{ stMark(u.bp_id) }}
              </span>
            </td>
            <td v-for="m in menus" :key="m.menu_key" class="cell">
              <input
                type="checkbox"
                :checked="allowed(u.bp_id, m.menu_key)"
                :disabled="locked(m.menu_key)"
                :title="
                  locked(m.menu_key)
                    ? '이 메뉴는 막을 수 없습니다 (막으면 갈 곳이 없어집니다)'
                    : `${u.name || u.bp_id} · ${m.menu_nm || m.menu_key}`
                "
                @change="toggle(u.bp_id, m.menu_key)"
              />
            </td>
            <td class="act">
              <button class="ico" title="이 사람의 메뉴를 모두 켭니다" @click="setAll(u.bp_id, true)">
                ☑
              </button>
              <button
                class="ico"
                title="이 사람의 메뉴를 모두 끕니다 (요약은 막을 수 없습니다)"
                @click="setAll(u.bp_id, false)"
              >
                ☐
              </button>
            </td>
          </tr>
          <tr v-if="!users.length && !loading">
            <td :colspan="menus.length + 2" class="muted empty">개발자가 없습니다.</td>
          </tr>
        </tbody>
      </table>
    </div>

    <p class="muted note">
      체크가 <strong>켜져 있으면 쓸 수 있습니다</strong>. 끄면 그 사람의 사이드바에서 사라지고,
      주소로 직접 들어가도 열리지 않습니다. <strong>고치는 즉시 저장</strong>됩니다.
      <br />
      아무것도 끄지 않은 사람은 DB 에 한 줄도 남지 않습니다 — 그래서
      <strong>메뉴를 새로 만들어도 저절로 숨지 않습니다</strong>.
      <code>요약</code> 은 막을 수 없습니다 (막으면 갈 곳이 없어집니다).
      최고 관리자는 이 설정과 무관하게 전체를 씁니다.
    </p>
    <p class="muted note warn">
      이것은 <strong>화면을 가리는</strong> 장치입니다. API 자체는 여전히 열려 있어,
      주소를 아는 사람이 직접 부르면 데이터를 받을 수 있습니다.
      진짜로 막아야 할 사람은 <code>개발자 관리</code> 의 <strong>차단</strong> 을 쓰십시오.
    </p>
    <p class="muted note">
      예외가 하나 있습니다 — <code>로컬 개발서버</code> 는 여기서 끄면 화면뿐 아니라
      <strong>기동·중지 동작까지</strong> 막힙니다. 그 API 는 데이터를 읽어 주는 것이 아니라
      대시보드 서버 장비에서 프로세스를 띄우고 내리기 때문입니다 (<code>api/DevRun.cs</code>).
    </p>
  </section>
</template>

<style scoped>
h2 .spacer { flex: 1; }
.wrap { overflow: auto; max-height: calc(100vh - 260px); border: 1px solid var(--line); border-radius: 8px; }
table { border-collapse: separate; border-spacing: 0; font-size: 12px; }
th, td { border-bottom: 1px solid var(--line); padding: 5px 6px; white-space: nowrap; }

/* 머리글은 위에, 개발자 칸은 왼쪽에 붙여 둔다 — 메뉴가 많아 가로로 넘친다 */
thead th { position: sticky; top: 0; z-index: 3; background: var(--panel); color: var(--muted); font-weight: 600; }
th.who, td.who {
  position: sticky; left: 0; z-index: 2; background: var(--panel);
  border-right: 1px solid var(--line);
  /* 폭을 못 박아 둔다 — 안의 글자가 바뀌어도 뒤쪽 열이 밀리지 않는다 */
  width: 120px; min-width: 120px; max-width: 120px;
}
thead th.who { z-index: 4; }
/* 폴더 띠 — 사이드바와 같은 묶음. 머리줄이 두 줄이 되므로 아래 줄은 그만큼 내려 붙인다 */
thead tr.grp th { top: 0; z-index: 3; }
thead tr:not(.grp) th { top: 21px; }
th.gh {
  font-size: 10.5px; font-weight: 400; color: var(--muted-2);
  border-bottom: 1px solid var(--line); border-left: 1px solid var(--line);
  padding: 1px 6px; white-space: nowrap; text-align: left;
}
th.mn { max-width: 92px; overflow: hidden; text-overflow: ellipsis; font-weight: 600; }
th.mn span { display: block; max-width: 92px; overflow: hidden; text-overflow: ellipsis; }

td.who b { margin-right: 5px; }
td.who .bp { color: var(--muted); font-size: 10.5px; font-variant-numeric: tabular-nums; }
td.who b {
  display: inline-block; max-width: 46px; vertical-align: bottom;
  overflow: hidden; text-overflow: ellipsis;
}
/* 표식이 바뀌어도 너비가 그대로여야 한다 — 비어 있을 때도 자리를 차지한다 */
td.who .st {
  display: inline-block; width: 12px; margin-left: 4px; font-size: 11px;
  text-align: center; overflow: hidden; white-space: nowrap; vertical-align: bottom;
}
td.who .st.ok { color: var(--done); }
td.who .st.busy { color: var(--accent); }
td.who .st.warn { color: var(--warn); }

td.cell { text-align: center; width: 92px; }
td.cell input { width: 15px; height: 15px; cursor: pointer; }
td.cell input:disabled { cursor: default; opacity: 0.4; }

tr.some td.who { box-shadow: inset 3px 0 0 var(--warn); }
/* 개발자 칸이 왼쪽에 붙어 있듯 전체 칸은 오른쪽에 붙여 둔다 —
   메뉴가 많아 가로로 넘칠 때 이 두 칸은 늘 보여야 쓸 수 있다. */
th.act, td.act {
  position: sticky; right: 0; z-index: 2; background: var(--panel);
  border-left: 1px solid var(--line); text-align: center;
  width: 62px; min-width: 62px; max-width: 62px;
}
thead th.act { z-index: 4; }
td.act button.ico { padding: 0 4px; margin: 0 1px; font-size: 13px; line-height: 17px; }

.empty { text-align: center; padding: 20px; }
.note { margin-top: 10px; font-size: 11.5px; line-height: 1.7; }
.note.warn { color: var(--warn); }
</style>
