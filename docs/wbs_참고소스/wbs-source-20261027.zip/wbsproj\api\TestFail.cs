using System.Text.Json;

namespace WbsApi;

/// <summary>
/// 단위테스트 <b>FAIL 목록</b> — [단위테스트 FAIL] 화면(#/testfail)이 읽고 쓰는 표.
///
/// 원본은 <c>D:\수빅자재\HHIP 단위테스트_FAIL목록_20261013.xlsx</c> 였다.
/// 그 파일은 <b>DRM 이 감싸고 있어</b>(머리글이 <c>HHIDRMC</c>) 보통의 zip 리더로는 열리지 않고,
/// 엑셀 COM 으로만 열린다. 서버가 요청마다 열 수 있는 물건이 아니다 —
/// 그래서 <b>한 번 떠서</b> <c>public.hhip_test_fail</c> 에 넣어 두고(<c>db/hhip_test_fail.sql</c>),
/// 화면은 그 표만 본다.
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>고칠 수 있는 것은 H 열 하나뿐이다.</b> 나머지 일곱 칸(A~G)은 테스트한 사람이 적어 둔
/// 사실이라 화면에서 손대지 않는다. 그래서 수정 경로도 <c>verdict</c> 만 받는다 —
/// 화이트리스트를 넓혀 두면 <언젠가> 화면이 다른 칸을 보내게 되고, 그때 원본이 조용히 바뀐다.
///
/// <b>왜 Super 를 요구하지 않는가.</b> 이 칸은 개발자가 자기 건에 답을 다는 자리다.
/// 지우는 것도 아니고 남의 기록을 덮는 것도 아니다. 대신 <b>누가 언제</b> 적었는지는 남긴다
/// (<c>updated_by</c> · <c>updated_at</c>) — 답에는 주인이 있어야 한다.
///
/// <b>엑셀을 다시 적재해도 답은 남는다.</b> <c>db/hhip_test_fail.sql</c> 의 upsert 가
/// <c>verdict</c> 를 일부러 빼 두었다. 사람이 적어 넣은 것을 재적재가 지워서는 안 된다.
/// </summary>
public static class TestFail
{
    /// <summary>H 열의 머리글. 고를 수 있는 값이 여기서 나온다.</summary>
    private const string VerdictHead = "접수/개선/먼소리/어쩌라구/ASIS랑같은데ASIS봤냐?";

    /// <summary>컬럼 머리에 쓰는 짧은 이름. 위의 머리글은 컬럼 이름으로 쓰기에 너무 길다.</summary>
    private const string VerdictLabel = "판단";

    /// <summary>
    /// 머리글을 <c>/</c> 로 가른 것이 곧 고를 수 있는 값이다.
    ///
    /// 화면에 단추로 깔아 주되 <b>이것만 쓰라고 막지는 않는다</b> — 적다 보면 여기 없는 말을
    /// 쓰게 되고, 그때 막혀 있으면 아예 안 적게 된다. 자유 입력이 본 경로고 단추는 지름길이다.
    /// </summary>
    private static readonly string[] Choices = VerdictHead.Split('/', StringSplitOptions.RemoveEmptyEntries);

    /// <summary>
    /// 고를 값마다 <b>무슨 뜻인지</b>. 고를 값 목록(<see cref="Choices"/>) 바로 옆에 둔다 —
    /// 화면에 적어 두면 값은 서버가, 뜻은 화면이 들고 있게 되어 둘이 조용히 어긋난다.
    /// </summary>
    private static readonly Dictionary<string, string> Legend = new()
    {
        ["접수"] = "개선할꺼에요.. 접수할께요..",
        ["개선"] = "바로 개선함... 금주중 처리함.",
        ["먼소리"] = "무슨소리를 하지는 알수가 없군요..",
        ["어쩌라구"] = "그래서 어떻게 하라는 건가",
        ["ASIS랑같은데ASIS봤냐?"] = "asis 가 그렇게 되어 있다.",
    };

    public static void Map(WebApplication app)
    {
        // 목록 — 62건짜리 표라 통째로 준다. 페이지를 나눌 이유가 없다.
        //
        // 상세 목록(hhip_wbs_wrk2)에 붙여 <화면 주소>와 <개발자>를 함께 준다.
        // 잇는 열쇠는 메뉴명 앞머리의 <화면 코드>다 — 엑셀의 '[1120] 자재 코드 관리' 와
        // 원장의 '[1120]자재 코드 관리' 는 띄어쓰기가 달라 글자로는 맞출 수 없지만,
        // 대괄호 안의 코드는 같다. 실측에서 26종 전부 1:1 로 맞았다(겹치는 코드 없음).
        //
        // left join 인 까닭: 원장에 없는 화면이 FAIL 목록에만 있을 수 있다. 그때는
        // 주소도 개발자도 비워서 주고 화면이 <그냥 글자>로 보여 준다 — 줄이 사라지면 안 된다.
        app.MapGet("/api/testfail", async (PgPool db) =>
        {
            var rows = await db.QueryAsync("""
                select f.fail_id, f.seq, f.program, f.category, f.step, f.input_data
                     , f.expect, f.result, f.note
                     , f.verdict, f.updated_by
                     , to_char(f.updated_at, 'YYYY-MM-DD HH24:MI') as updated_at
                     , upper(substring(f.program from '^\s*\[\s*([0-9A-Za-z_-]+)\s*\]')) as screen_code
                     , w.systemcode, w.menu_nm, w.activity_id
                     , w.user_real_id, ru.name as user_real_nm
                  from public.hhip_test_fail f
                  left join lateral (
                       select w.systemcode, w.menu_nm, w.activity_id, w.user_real_id
                         from public.hhip_wbs_wrk2 w
                        where upper(substring(w.menu_nm from '^\s*\[\s*([0-9A-Za-z_-]+)\s*\]'))
                            = upper(substring(f.program from '^\s*\[\s*([0-9A-Za-z_-]+)\s*\]'))
                        order by w.row_uid
                        limit 1
                  ) w on true
                  left join public.dev_user ru on upper(ru.bp_id) = upper(w.user_real_id)
                 order by f.seq
                """);
            return Results.Ok(new
            {
                rows,
                verdict_head = VerdictHead,
                // 컬럼 머리에 쓰는 짧은 이름. 원래 머리글은 고르는 값을 '/' 로 늘어놓은 것이라
                // 컬럼 이름으로는 너무 길다 — 긴 쪽은 안내문과 title 에 남겨 둔다.
                verdict_label = VerdictLabel,
                choices = Choices,
                // 범례 — 고를 값과 <같은 차례>로 준다. 화면이 둘을 맞춰 보지 않아도 되도록.
                legend = Choices.Select(c => new { key = c, desc = Legend.GetValueOrDefault(c, "") }),
                // 화면 머리의 숫자. 세는 일을 화면에 미루면 필터가 걸릴 때마다 뜻이 흔들린다.
                total = rows.Count,
                answered = rows.Count(r => !string.IsNullOrWhiteSpace(r["verdict"] as string)),
            });
        });

        // H 열 한 칸 저장. 받는 것은 verdict 하나뿐이다 (위 주석 참고).
        app.MapPut("/api/testfail/{failId:long}", async (PgPool db, IpGate g, HttpContext ctx, long failId, JsonElement body) =>
        {
            var me = await g.CheckAsync(ctx);
            var who = me.Name ?? me.BpId ?? "미상";

            // 빈 문자열은 <지웠다> 는 뜻이다 — null 로 넣어야 "아직 안 적음" 과 같은 상태가 된다.
            // 빈 문자열로 두면 목록의 <적힌 건> 숫자가 1 늘어난 채 화면만 비어 보인다.
            var v = body.TryGetProperty("verdict", out var e) && e.ValueKind == JsonValueKind.String
                ? e.GetString()!.Trim()
                : "";
            var val = v.Length == 0 ? null : v;

            var n = await db.ExecuteAsync("""
                update public.hhip_test_fail
                   set verdict    = $1::text
                     , updated_by = case when $1::text is null then null else $2::text end
                     , updated_at = case when $1::text is null then null else now()   end
                 where fail_id = $3::bigint
                """, [val, who, failId]);

            if (n == 0) return Results.NotFound(new { error = "그 줄을 찾지 못했습니다.", fail_id = failId });

            // 방금 쓴 값을 그대로 돌려준다 — 화면이 제 손으로 꾸며 내면 서버가 다듬은 것
            // (앞뒤 공백 · 빈 문자열 → 비움)이 화면에만 다르게 남는다.
            var got = await db.QueryAsync("""
                select verdict, updated_by, to_char(updated_at, 'YYYY-MM-DD HH24:MI') as updated_at
                  from public.hhip_test_fail where fail_id = $1::bigint
                """, [failId]);
            return Results.Ok(new
            {
                fail_id = failId,
                verdict = got[0]["verdict"],
                updated_by = got[0]["updated_by"],
                updated_at = got[0]["updated_at"],
            });
        });
    }
}
