import { onUnmounted, ref } from 'vue'

/**
 * 창(팝업)을 머리글을 잡아 옮길 수 있게 한다.
 *
 * 팝업 자체는 그대로 가운데(또는 위쪽)에 놓이고, 옮긴 만큼만 transform 으로 밀어 준다.
 * 그래서 창 크기가 바뀌어도 기준 위치는 흐트러지지 않는다.
 *
 * 쓰는 쪽:
 *   const drag = useDragMove()
 *   <div class="dlg" :style="drag.style.value">
 *     <header @pointerdown="drag.start($event)"> ... </header>
 *
 * @param opts.margin 화면 밖으로 나가지 않게 남길 여백(px)
 */
export function useDragMove({ margin = 24 } = {}) {
  const dx = ref(0)
  const dy = ref(0)
  const moving = ref(false)

  let el = null          // 옮기는 대상(.dlg)
  let startX = 0
  let startY = 0
  let baseX = 0
  let baseY = 0
  // 옮기지 않았을 때의 위치·크기. 끌기를 시작할 때 한 번만 잰다.
  // 끌는 중에 다시 재면 안 된다 — style 은 Vue 가 다음 tick 에 반영하므로
  // 그때의 getBoundingClientRect() 는 <한 발 늦은> 값이고, 그걸로 자르면 창이 튀어 나간다.
  let base = null

  const style = ref({})

  function apply() {
    style.value = dx.value || dy.value || moving.value
      ? { transform: `translate(${dx.value}px, ${dy.value}px)`, transition: 'none' }
      : {}
  }

  /** 지금 dx·dy 를 기준으로 원래 위치를 다시 계산해 둔다 (DOM 이 갇혀 있을 때만 부른다) */
  function measure() {
    if (!el) return
    const r = el.getBoundingClientRect()
    base = { left: r.left - dx.value, top: r.top - dy.value, width: r.width, height: r.height }
  }

  /** 창이 화면 밖으로 사라지지 않게 이동량을 자른다 */
  function clamp() {
    if (!base) return
    const KEEP = 140   // 가로로 최소 이만큼은 화면에 남긴다
    const HEAD = 40    // 머리글 한 줄은 항상 보이게

    const W = window.innerWidth
    const H = window.innerHeight
    // 화면 크기를 못 읽는 상황(숨은 탭·임베드 등)에서는 자르지 않는다.
    // 그대로 계산하면 하한이 상한보다 커져 창이 엉뚱한 자리로 튄다.
    if (!(W > 200) || !(H > 200)) return

    // 창이 화면보다 큰 경우에도 범위가 뒤집힐 수 있으므로 각각 확인한다
    const minX = KEEP - base.left - base.width
    const maxX = W - KEEP - base.left
    if (minX <= maxX) dx.value = Math.min(Math.max(dx.value, minX), maxX)

    const minY = margin - base.top
    const maxY = H - HEAD - base.top
    if (minY <= maxY) dy.value = Math.min(Math.max(dy.value, minY), maxY)
  }

  function start(e) {
    // 입력칸·버튼을 누른 것이면 옮기지 않는다 (검색·닫기가 그대로 동작해야 한다)
    if (e.target.closest('input, button, select, textarea, a')) return
    if (e.button !== undefined && e.button !== 0) return   // 왼쪽 버튼만

    el = e.currentTarget.closest('.dlg') || e.currentTarget.parentElement
    if (!el) return

    moving.value = true
    startX = e.clientX
    startY = e.clientY
    baseX = dx.value
    baseY = dy.value
    measure()   // 이 시점의 DOM 은 화면과 일치한다

    // 커서가 창 밖으로 나가도 계속 따라오게 한다
    try { e.currentTarget.setPointerCapture?.(e.pointerId) } catch { /* 무시 */ }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', stop)
    window.addEventListener('pointercancel', stop)
    apply()
    e.preventDefault()   // 글자 선택으로 끌리지 않게
  }

  function onMove(e) {
    if (!moving.value) return
    dx.value = baseX + (e.clientX - startX)
    dy.value = baseY + (e.clientY - startY)
    clamp()
    apply()
  }

  function stop() {
    moving.value = false
    window.removeEventListener('pointermove', onMove)
    window.removeEventListener('pointerup', stop)
    window.removeEventListener('pointercancel', stop)
    apply()
  }

  /** 창을 원래 자리로 되돌린다 */
  function reset() {
    dx.value = 0
    dy.value = 0
    apply()
  }

  // 창이 작아졌을 때 팝업이 화면 밖에 남아 있지 않게 다시 잘라 준다
  function onResize() {
    if (!dx.value && !dy.value) return
    measure()   // 크기가 바뀌었으니 기준을 다시 잡는다
    clamp()
    apply()
  }
  window.addEventListener('resize', onResize)

  onUnmounted(() => {
    stop()
    window.removeEventListener('resize', onResize)
  })

  return { style, moving, start, reset, moved: () => !!(dx.value || dy.value) }
}
