using System.Collections.Concurrent;

namespace WbsApi;

/// <summary>
/// 동기화 파이프라인의 진행 상황. 화면이 폴링해서 단계별 상태를 보여 준다.
/// (SSE 대신 폴링 — 이 대시보드는 프록시·리버스프록시가 없고 단계가 5개뿐이라 충분하다)
/// </summary>
public sealed class SyncJob
{
    public sealed class Step(string name)
    {
        public string Name { get; } = name;
        public string State { get; set; } = "wait";   // wait | run | ok | skip | fail
        public string? Detail { get; set; }
        public int? Ms { get; set; }
    }

    private readonly object _lock = new();
    private readonly List<Step> _steps = [];

    public string Id { get; } = Guid.NewGuid().ToString("N")[..12];
    public DateTime StartedAt { get; } = DateTime.Now;
    public bool Done { get; private set; }
    public string? Error { get; private set; }
    public object? Result { get; private set; }

    public SyncJob(params string[] names)
    {
        foreach (var n in names) _steps.Add(new Step(n));
    }

    /// <summary>한 단계를 실행하고 상태·소요시간을 남긴다.</summary>
    public async Task<T> RunAsync<T>(string name, Func<Task<T>> body)
    {
        var step = Find(name);
        lock (_lock) step.State = "run";
        var t0 = DateTime.Now;
        try
        {
            var r = await body();
            lock (_lock)
            {
                step.State = "ok";
                step.Ms = (int)(DateTime.Now - t0).TotalMilliseconds;
            }
            return r;
        }
        catch (Exception ex)
        {
            lock (_lock)
            {
                step.State = "fail";
                step.Detail = ex.Message;
                step.Ms = (int)(DateTime.Now - t0).TotalMilliseconds;
            }
            throw;
        }
    }

    public void Detail(string name, string text)
    {
        lock (_lock) Find(name).Detail = text;
    }

    public void Skip(string name, string why)
    {
        lock (_lock)
        {
            var s = Find(name);
            s.State = "skip";
            s.Detail = why;
        }
    }

    public void Finish(object? result, string? error = null)
    {
        lock (_lock)
        {
            Result = result;
            Error = error;
            Done = true;
            // 아직 시작도 못 한 단계는 실패 뒤에 남지 않게 정리한다
            if (error is not null)
                foreach (var s in _steps.Where(s => s.State == "wait")) s.State = "skip";
        }
    }

    private Step Find(string name) =>
        _steps.FirstOrDefault(s => s.Name == name) ?? throw new ArgumentException($"단계 없음: {name}");

    /// <summary>폴링 응답용 스냅샷.</summary>
    public object Snapshot()
    {
        lock (_lock)
        {
            return new
            {
                id = Id,
                started = StartedAt.ToString("HH:mm:ss"),
                done = Done,
                error = Error,
                elapsed = (int)(DateTime.Now - StartedAt).TotalMilliseconds,
                steps = _steps.Select(s => new { name = s.Name, state = s.State, detail = s.Detail, ms = s.Ms }).ToList(),
                result = Result,
            };
        }
    }

    // ---------------------------------------------------------------- 보관소

    private static readonly ConcurrentDictionary<string, SyncJob> Jobs = new();

    public static SyncJob Create(params string[] names)
    {
        var job = new SyncJob(names);
        Jobs[job.Id] = job;

        // 오래된 작업은 정리 (최근 10개만 유지)
        foreach (var old in Jobs.Values.OrderByDescending(j => j.StartedAt).Skip(10))
            Jobs.TryRemove(old.Id, out _);

        return job;
    }

    public static SyncJob? Get(string id) => Jobs.TryGetValue(id, out var j) ? j : null;

    /// <summary>지금 돌고 있는 작업 (중복 실행 방지용).</summary>
    public static SyncJob? Running() => Jobs.Values.FirstOrDefault(j => !j.Done);
}
