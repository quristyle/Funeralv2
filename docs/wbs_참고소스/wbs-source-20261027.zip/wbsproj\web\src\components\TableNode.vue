<script setup>
import { computed, inject, ref } from 'vue'
import { Handle, Position, useVueFlow } from '@vue-flow/core'

// 계통도의 테이블 한 칸.
//
// 손잡이(Handle)를 네 면에 둔다. 한 면에만 두면 왼쪽 테이블을 오른쪽 테이블에 이을 때
// 선이 칸을 가로질러 지나간다 — 48칸짜리 도면에서는 그것만으로 못 읽는 그림이 된다.
// 네 면이 모두 <받기도 하고 내보내기도> 해야 해서 type 을 source·target 둘 다 깔아 둔다.
const props = defineProps({
  id: { type: String, required: true },
  data: { type: Object, required: true },
  selected: { type: Boolean, default: false },
})

const SIDES = [
  { pos: Position.Top, id: 't', name: '위' },
  { pos: Position.Right, id: 'r', name: '오른쪽' },
  { pos: Position.Bottom, id: 'b', name: '아래' },
  { pos: Position.Left, id: 'l', name: '왼쪽' },
]

/**
 * 잇기 모드에서 <어느 지점에 붙일지> 를 고르는 길.
 *
 * 평소에는 손잡이를 끌어 잇는다(끄는 쪽이 출발, 놓는 쪽이 도착 지점이다).
 * 잇기 모드에서는 끌지 않고 <누르는> 것이 본 동작이라, 손잡이도 눌러서 고르게 한다.
 * 그때는 손잡이의 끌기를 꺼 둔다 — 켜 두면 누르려다 끌기가 시작되어 선이 허공에 따라붙는다.
 *
 * provide/inject 로 받는 까닭: data 에 함수를 넣으면 저장할 때 함께 딸려 간다.
 */
const link = inject('tablesLink', null)
const linking = computed(() => !!link?.on?.value)
const picked = computed(() => link?.from?.value?.id === props.id ? link.from.value.handle : null)
// ⚠️ 손잡이 클릭은 칸까지 번지면 안 된다. 칸 클릭이 <지점 없이> 다시 잡아
//    방금 고른 지점을 null 로 덮고, 이은 직후에는 도착 칸에서 새 연결이 시작된다.
//    (둘 다 실제로 밟았다 — @click.stop 과 @mousedown.stop 둘 다 있어야 한다.)
function pickPort(sideId) {
  link?.pick?.(props.id, sideId)
}

const KIND_LABEL = {
  master: '기준', ledger: '원장', derived: '파생',
  snap: '스냅샷', ext: '외부', batch: '배치',
  proc: '프로시저', iface: '인터페이스', eai: 'EAI',
}

/**
 * 머리에 붙는 표시. 글자(종류 칩)만으로는 48칸 사이에서 눈에 안 띄어,
 * <주고받는 자리> 들에만 기호를 하나 더 붙인다.
 *   ⇄ 인터페이스 — 두 시스템이 마주 보고 주고받는다
 *   ⇶ EAI       — 중계가 여러 갈래로 실어 나른다
 */
const MARK = { iface: '⇄', eai: '⇶' }

/**
 * 프로시저는 <표> 가 아니다 — 자료를 담는 것이 아니라 도는 것이다.
 * 그래서 한 줄짜리 알약으로 둔다. 이 화면에서 <둥근 것은 이것뿐>이라, 멀리서 봐도
 * 표 사이에 섞인 프로시저가 바로 가려진다. (객체는 각지게 두는 것이 이 화면의 규칙인데,
 *  여기서만 일부러 어긴다 — 어기는 것 자체가 표시다.)
 */
const isProc = computed(() => props.data.kind === 'proc')

// ---------- 칸 크기 ----------
//
// 기본은 196×44 다. 설명이 길거나 눈에 띄게 두고 싶은 칸은 오른쪽 아래 모서리를 끌어 키운다.
// 크기는 data.w · data.h 에 담겨 도면과 함께 저장된다(사람이 정한 것이라 남아야 한다).
//
// ⚠️ 화면 좌표를 그대로 더하면 안 된다 — 캔버스가 확대·축소되어 있으면 손은 10px 움직였는데
//    칸은 40px 커진다. 지금 배율(zoom)로 나눠 <도면 좌표> 로 바꿔 더한다.
const { viewport } = useVueFlow()
const size = inject('tablesSize', null)
const sizing = ref(false)

const MINW = 120
const MINH = 36
const GRID = 20

const box = computed(() => {
  const w = Number(props.data.w)
  const h = Number(props.data.h)
  return {
    ...(w > 0 ? { width: w + 'px' } : {}),
    ...(h > 0 ? { height: h + 'px' } : {}),
  }
})

function grabSize(e) {
  if (!size) return
  e.preventDefault()
  e.stopPropagation()        // 칸을 고르거나 끄는 것이 아니다 — 모서리를 잡은 것이다
  const el = e.currentTarget.closest('.tnode')
  const z = viewport.value?.zoom || 1
  const w0 = el.offsetWidth, h0 = el.offsetHeight
  const x0 = e.clientX, y0 = e.clientY
  sizing.value = true

  const snap = (v) => Math.round(v / GRID) * GRID
  const move = (ev) => {
    size.set(props.id,
      Math.max(MINW, snap(w0 + (ev.clientX - x0) / z)),
      Math.max(MINH, snap(h0 + (ev.clientY - y0) / z)))
  }
  const up = () => {
    sizing.value = false
    window.removeEventListener('pointermove', move)
    window.removeEventListener('pointerup', up)
    window.removeEventListener('pointercancel', up)
    size.done()
  }
  // ⚠️ window 에 단다 — 모서리는 12px 이라 손이 금방 벗어난다. 요소에 달면 끌다가 끊긴다.
  window.addEventListener('pointermove', move)
  window.addEventListener('pointerup', up)
  window.addEventListener('pointercancel', up)
}

/** 두 번 누르면 기본 크기로 — 키워 놓고 되돌릴 길이 있어야 한다 */
function resetSize(e) {
  if (!size) return
  e.preventDefault()
  e.stopPropagation()
  size.set(props.id, 0, 0)
  size.done()
}

const rowsText = computed(() =>
  props.data.rows == null ? '' : Number(props.data.rows).toLocaleString('ko-KR') + '행')

// 올려놓았을 때 보여 줄 것 — 기존 화면이 칸을 눌러야 보여 주던 것들이다.
const tip = computed(() => [
  `${props.data.id} · ${props.data.kr}`,
  props.data.owner ? `스키마  ${props.data.owner}` : '',
  props.data.pk ? `PK  ${props.data.pk}` : '',
  rowsText.value,
  props.data.trg ? `트리거  ${props.data.trg}` : '',
  props.data.writers?.length ? `쓰는 곳  ${props.data.writers.join(' / ')}` : '',
  props.data.note ? `— ${props.data.note}` : '',
  props.data.warn ? `⚠ ${props.data.warn}` : '',
].filter(Boolean).join('\n'))
</script>

<template>
  <div
    class="tnode"
    :class="[`k-${data.kind}`, { sel: selected, star: data.star, dim: data.dim, hot: data.hot, near: data.near, found: data.found, flash: data.flash, sized: data.w > 0 || data.h > 0, sizing }]"
    :style="box"
    :title="tip"
  >
    <Handle
      v-for="s in SIDES" :key="'s' + s.id" :id="s.id" type="source" :position="s.pos"
      class="hdl" :class="{ show: linking, pick: picked === s.id }"
      :connectable="!linking"
      :title="linking ? `${s.name} 지점에서 잇기` : `끌어서 잇기 (${s.name})`"
      @click.stop="linking && pickPort(s.id)"
      @mousedown.stop
    />
    <Handle
      v-for="s in SIDES" :key="'t' + s.id" :id="s.id" type="target" :position="s.pos"
      class="hdl hdl-t" :connectable="!linking"
    />

    <!-- 고른 스키마에 <없는> 표라면 어디 것인지 머리에 적는다.
         (M10 을 보는 중의 MTB_POR_OHD → NEW05) -->
    <div v-if="data.owner" class="own" :title="`${data.id} 는 ${data.owner} 스키마의 표입니다`">
      {{ data.owner }}
    </div>
    <!-- 업무항목 편집 중에만 뜬다 — 지금 고른 업무항목에 담긴 표라는 표시.
         평소에도 달면 48칸에 체크가 깔려 정작 보던 것이 묻힌다. -->
    <div v-if="data.inItem" class="init" title="이 업무항목에 담겨 있습니다 — 누르면 빠집니다">✔</div>
    <!-- 프로시저는 한 줄이다 — 이름만 적는다. 설명·종류 칩까지 넣으면 알약이 아니라
         그냥 작은 표가 되어, 한눈에 갈라 보이던 것이 사라진다. -->
    <template v-if="isProc">
      <b class="id proc" :title="data.kr || data.id">⚙ {{ data.id }}</b>
    </template>
    <template v-else>
      <div class="hd">
        <!-- 인터페이스는 <바깥과 주고받는 자리> 다. 머리에 오가는 표시를 둔다. -->
        <span v-if="MARK[data.kind]" class="ifmark" aria-hidden="true">{{ MARK[data.kind] }}</span>
        <b class="id">{{ data.id }}</b>
        <span class="kind">{{ KIND_LABEL[data.kind] ?? data.kind }}</span>
      </div>
      <div class="kr">{{ data.kr }}</div>
    </template>
    <!-- 행수·PK 는 칸에 적지 않는다. 48칸이 나란히 선 그림에서 그 두 줄은
         <읽히지 않으면서 자리만> 먹는다 — 올려놓으면 툴팁에, 누르면 오른쪽 상세에 있다. -->
    <span v-if="data.warn" class="warn" title="주의">⚠</span>

    <!-- 크기 조절 — 평소에는 숨기고 칸에 손을 올릴 때만 드러낸다.
         늘 보이면 칸마다 모서리 표가 붙어 102칸이 어지러워진다. -->
    <span
      class="nrsz"
      title="끌어서 칸 크기를 바꿉니다 · 두 번 누르면 기본 크기로"
      @pointerdown="grabSize"
      @dblclick="resetSize"
      @click.stop
    ></span>
  </div>
</template>

<style scoped>
.tnode {
  /* 컴팩트하게 — 이름과 설명 두 줄이면 <무슨 표인지> 는 다 전해진다.
     나머지(행수·PK·트리거·쓰는 곳)는 툴팁과 오른쪽 상세가 맡는다. */
  width: 196px;
  min-height: 44px;
  box-sizing: border-box;
  padding: 5px 8px;
  border: 1px solid var(--line-2, #BAC5CD);
  border-left-width: 4px;
  /* 모서리를 세운다 — 네모는 네모로. 둥글리면 격자가 흐물거려 <줄이 맞는지> 가 안 보인다.
     (선은 곡선이 낫지만 객체는 아니라는 판단이다 — 선 쪽은 그대로 휘어 둔다.) */
  border-radius: 0;
  background: var(--panel, #fff);
  font-size: 11px;
  line-height: 1.45;
  position: relative;
  box-shadow: 0 1px 2px rgba(18, 24, 30, 0.06);
}
/* 고른 칸 · 뜻이 다른 칸 — 종류별 색은 기존 화면(flow.html)의 팔레트를 그대로 옮겼다 */
.k-master  { border-left-color: #BAC5CD; }
.k-ledger  { border-left-color: #D64A16; }
.k-derived { border-left-color: #B07407; background: var(--warn-soft, #FAEED6); }
.k-snap    { border-left-color: #00707D; background: var(--teal-soft, #DDEFF0); }
.k-ext     { border-left-color: #6A4FBF; background: var(--violet-soft, #EDE8FA); border-style: dashed; border-left-style: solid; }
.k-batch   { border-left-color: #2E7D4F; background: var(--done-soft, #E1F0E7); }

/* 인터페이스 — 바깥과 주고받는 자리. 경계를 넘는다는 뜻으로 위아래를 빗금 테두리로 끊고,
   머리에 ⇄ 를 둔다. 외부(k-ext)와 색을 갈라 둔다 — 저쪽은 <남의 시스템>, 이쪽은 <주고받는 길>이다. */
.k-iface {
  border-color: #0E7C86;
  border-style: dashed;
  border-left-style: solid;
  border-left-color: #0E7C86;
  border-top-width: 2px;
  background: var(--teal-soft, #DDEFF0);
}
.k-iface .ifmark { flex: none; margin-right: 3px; font-size: 10px; color: #0E7C86; font-weight: 700; }

/* EAI — 중계(미들웨어)를 거쳐 오가는 자리. 인터페이스와 헷갈리지 않게 색과 테두리를 가른다:
   인터페이스는 빗금(dashed) · 청록, EAI 는 점선(dotted) · 자홍. 둘 다 <경계> 지만
   한쪽은 마주 본 둘 사이고, 다른 한쪽은 가운데에 실어 나르는 것이 하나 더 있다. */
.k-eai {
  border-color: #A8327D;
  border-style: dotted;
  border-left-style: solid;
  border-left-color: #A8327D;
  border-top-width: 2px;
  background: var(--magenta-soft, #F8E9F3);
}
.k-eai .ifmark { flex: none; margin-right: 3px; font-size: 10px; color: #A8327D; font-weight: 700; }

/* 프로시저 — 한 줄 알약. 까닭은 script 의 isProc 주석에 적어 두었다.
   폭을 글자에 맞춰 줄인다(표처럼 196px 로 두면 알약으로 안 보인다). */
.tnode.k-proc {
  width: auto;
  min-width: 110px;
  max-width: 260px;
  min-height: 0;
  padding: 4px 13px;
  border-radius: 999px;
  border-width: 1px;
  border-left-width: 1px;
  border-color: #2E6FBF;
  background: var(--blue-soft, #E8F0FB);
  box-shadow: 0 1px 3px rgba(18, 24, 30, 0.1);
}
.tnode.k-proc .id.proc {
  display: block;
  font-size: 10.5px;
  line-height: 1.35;
  color: #1F4F8F;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.tnode.star { box-shadow: 0 0 0 1px var(--accent, #D64A16), 0 1px 2px rgba(18, 24, 30, 0.06); }
.tnode.sel { outline: 2px solid var(--accent, #D64A16); outline-offset: 1px; }

/* 고른 칸(hot)과 거기에 닿는 칸(near) — 기존 화면이 하던 것을 그대로 옮겼다.
   닿는 칸을 함께 세워 두지 않으면 <무엇과 무엇이 이어져 있는지> 를 선만 보고 좇아야 한다. */
.tnode.hot {
  outline: 2px solid var(--accent, #D64A16);
  outline-offset: 1px;
  box-shadow: 0 0 0 4px rgba(214, 74, 22, 0.14), 0 4px 14px rgba(18, 24, 30, 0.14);
  z-index: 3;
}
.tnode.near { box-shadow: 0 0 0 2px rgba(214, 74, 22, 0.28); }
/* 적고 있는 글자에 걸린 칸 — 흐리지 않은 것만으로는 48칸 사이에서 눈에 안 띈다 */
.tnode.found { outline: 2px solid var(--accent, #D64A16); outline-offset: 1px; }

/* 방금 놓은 칸 — 48칸 사이에 끼어 들어가면 어디 떨어졌는지 눈으로 못 찾는다.
   잠깐 깜빡여 자리를 알려 준다. 움직이지는 않는다(테두리만) — 칸이 흔들리면
   그 옆 칸까지 같이 읽기 어려워진다. */
.tnode.flash { animation: tnode-flash 0.6s ease-in-out 4; }
@keyframes tnode-flash {
  0%, 100% { outline: 2px solid transparent; outline-offset: 1px; box-shadow: none; }
  50% {
    outline: 3px solid var(--accent, #D64A16);
    outline-offset: 2px;
    box-shadow: 0 0 0 6px rgba(214, 74, 22, 0.22);
  }
}

/* 흐림 — 지우지 않는다. 지우면 <어디에 있었는지> 가 사라져 도면을 처음부터 다시 읽어야 한다.
   흐린 칸 위의 글자는 더 흐리게 두되, 테두리는 남겨 자리를 알 수 있게 한다. */
.tnode.dim { opacity: 0.16; }

.hd { display: flex; align-items: baseline; gap: 5px; }
.id {
  font-size: 11px; font-weight: 700; letter-spacing: 0.1px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.kind { font-size: 8.5px; color: var(--muted, #68757F); margin-left: auto; white-space: nowrap; flex: none; }
/* 설명은 두 줄까지만. 긴 것 하나 때문에 그 줄의 칸이 모두 키가 커지면 격자가 흐트러진다 */
/* 설명은 <한 줄> 이다. 넘치면 말줄임(…) 으로 자른다.
   두 줄까지 늘려 두었더니 긴 설명이 들어간 칸만 키가 커져, 나란히 선 칸들의 줄이 어긋났다.
   잘린 설명 전체는 올려놓으면 툴팁에, 누르면 오른쪽 상세에 그대로 있다. */
.kr {
  font-size: 10.5px; line-height: 1.35; color: var(--text, #12181E); margin-top: 1px;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.warn { position: absolute; top: 3px; right: 4px; font-size: 9px; color: #B33636; }

/* 크기 조절 모서리 — 레이어의 것과 같은 모양으로 둔다(같은 일은 같게 보여야 한다) */
.nrsz {
  position: absolute; right: -1px; bottom: -1px; z-index: 3;
  width: 12px; height: 12px; cursor: nwse-resize;
  opacity: 0; transition: opacity 0.12s;
  background:
    linear-gradient(135deg, transparent 0 46%, var(--line-2, #BAC5CD) 46% 60%, transparent 60%),
    linear-gradient(135deg, transparent 0 70%, var(--line-2, #BAC5CD) 70% 84%, transparent 84%);
}
.tnode:hover .nrsz, .tnode.sel .nrsz, .tnode.sizing .nrsz { opacity: 1; }
.tnode.sizing { user-select: none; }

/* 크기를 정해 준 칸은 설명이 여러 줄로 퍼진다 — 키운 까닭이 대개 그것이다.
   기본 크기일 때는 한 줄로 자른다(줄이 어긋나지 않게). */
.tnode.sized { overflow: hidden; }
.tnode.sized .kr { white-space: normal; text-overflow: clip; }
/* 다른 스키마의 표 — 머리 위에 띠로. 칸 안쪽에 섞어 두면 설명 글과 구별되지 않는다. */
/* 업무항목에 담긴 표 — 오른쪽 위에 작게. 각지게 둔다(이 화면의 규칙). */
.init {
  position: absolute; top: -1px; right: -1px; z-index: 2;
  padding: 0 4px; font-size: 9px; font-weight: 700; line-height: 13px;
  color: var(--on-accent, #fff); background: var(--accent);
}
/* 다른 스키마의 표라는 꼬리표 — <상자 밖> 바로 위에 글자만 둔다.
   예전에는 상자 안 맨 위에 띠로 깔았는데, 그러면 머리글이 둘(스키마 띠 + 표 이름)이라
   48칸이 늘어선 그림에서 <표 이름이 어느 줄인지> 가 한눈에 안 들어왔다.
   상자 밖으로 빼면 상자는 이름·설명 두 줄 그대로고, 꼬리표는 주석처럼 읽힌다.

   ⚠️ 자리만 차지하지 않게 absolute 로 띄운다 — 흐름에 두면 칸 높이가 늘어
      격자(ROWH)가 어긋난다. pointer-events 도 끈다(글자가 칸 누르기를 가로채지 않게). */
.own {
  position: absolute;
  left: -1px; bottom: 100%;
  margin-bottom: 1px;
  padding: 0;
  font-size: 9px;
  font-weight: 700;
  letter-spacing: 0.3px;
  line-height: 1.2;
  white-space: nowrap;
  color: #6A4FBF;
  background: none;
  border: 0;
  pointer-events: none;
}

/* 손잡이 — 평소에는 거의 안 보이다가 칸에 손이 가면 드러난다.
   늘 또렷하면 48칸 × 8개 = 384개의 점이 도면을 덮는다. */
.hdl {
  width: 10px; height: 10px;
  background: var(--panel, #fff);
  border: 1.5px solid var(--accent, #D64A16);
  opacity: 0;
  transition: opacity 0.12s;
}
.tnode:hover .hdl, .tnode.sel .hdl { opacity: 1; }
/* 잇기 모드 — 네 지점을 늘 드러낸다. 숨어 있으면 <어디에 붙일지> 를 고를 수가 없다. */
.hdl.show { opacity: 1; width: 13px; height: 13px; cursor: crosshair; }
.hdl.show:hover { background: var(--accent); }
.hdl.pick { background: var(--accent); box-shadow: 0 0 0 3px rgba(214, 74, 22, 0.3); }
/* 받는 쪽 손잡이는 내보내는 쪽과 같은 자리에 겹쳐 둔다 — 어느 면에서든 양방향으로 이어야 한다 */
.hdl-t { pointer-events: none; }
.tnode:hover .hdl-t { pointer-events: auto; }
</style>
