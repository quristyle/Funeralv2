<script setup>
import { computed, ref } from 'vue'
import BarChart from '../components/BarChart.vue'
import RefreshBtn from '../components/RefreshBtn.vue'
import { state, pickModule, loadStats } from '../store'

const emit = defineEmits(['drill'])

// 막대 위에 겹쳐 보일 기준 — 완료(complate_yn) / 개발완료(complate_real_yn) / 실적종료 입력
const overlay = ref('done_real')
const OVERLAY = {
  done: { label: '완료', key: 'done' },
  done_real: { label: '개발완료', key: 'done_real' },
  act_edt: { label: '실적종료 입력', key: 'act_edt' },
}

const items = computed(() =>
  state.byModule.map((r) => ({
    key: r.systemcode,
    label: r.systemcode,
    value: r.cnt,
    done: r[OVERLAY[overlay.value].key] ?? 0,
    sub: `${r.system_nm} · 완료 ${r.done} · 개발완료 ${r.done_real ?? 0} · 실적종료 ${r.act_edt ?? 0}`,
  }))
)

function onPick(b) {
  pickModule(b)
  if (state.sel.module) emit('drill')
}

const pct = (a, b) => (b ? Math.round((a / b) * 1000) / 10 : 0)

// 합계 행
const tot = computed(() =>
  state.byModule.reduce(
    (s, r) => ({
      cnt: s.cnt + r.cnt,
      done: s.done + (r.done ?? 0),
      done_real: s.done_real + (r.done_real ?? 0),
      act_sdt: s.act_sdt + (r.act_sdt ?? 0),
      act_edt: s.act_edt + (r.act_edt ?? 0),
    }),
    { cnt: 0, done: 0, done_real: 0, act_sdt: 0, act_edt: 0 }
  )
)
</script>

<template>
  <section class="panel">
    <h2>
      모듈별 건수
      <span class="hint">막대 클릭 시 상세 목록으로 이동 · 진한 부분 = {{ OVERLAY[overlay].label }}</span>
      <span class="spacer"></span>
      <select v-model="overlay" title="막대에 겹쳐 볼 기준">
        <option v-for="(o, k) in OVERLAY" :key="k" :value="k">{{ o.label }} 기준</option>
      </select>
      <RefreshBtn :fn="loadStats" />
    </h2>
    <BarChart :items="items" :active="state.sel.module" @pick="onPick" />
  </section>

  <section class="panel">
    <h2>모듈 상세 <span class="hint">계획 · 완료 · 개발완료 · 실적일 기준 건수</span></h2>
    <div class="scroll">
      <table>
        <thead>
          <tr>
            <th rowspan="2">모듈</th>
            <th rowspan="2">이름</th>
            <th rowspan="2" class="num">건수</th>
            <th colspan="2" class="grp a">완료</th>
            <th colspan="2" class="grp b">개발완료</th>
            <th colspan="2" class="grp c">실적일 입력</th>
            <th colspan="2" class="grp">계획 기간</th>
            <th colspan="2" class="grp c">실적 기간</th>
          </tr>
          <tr>
            <th class="num">건</th><th class="num">율</th>
            <th class="num">건</th><th class="num">율</th>
            <th class="num">시작</th><th class="num">종료</th>
            <th>시작</th><th>종료</th>
            <th>시작</th><th>종료</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="m in state.byModule" :key="m.systemcode" class="clk" @click="onPick(m.systemcode)">
            <td class="nowrap"><strong>{{ m.systemcode }}</strong></td>
            <td class="nowrap">{{ m.system_nm }}</td>
            <td class="num">{{ m.cnt }}</td>

            <td class="num" :class="{ dim: !m.done }">{{ m.done || '' }}</td>
            <td class="num sm" :class="{ dim: !m.done }">{{ m.done ? pct(m.done, m.cnt) + '%' : '' }}</td>

            <td class="num dev" :class="{ dim: !m.done_real }">{{ m.done_real || '' }}</td>
            <td class="num sm dev" :class="{ dim: !m.done_real }">
              {{ m.done_real ? pct(m.done_real, m.cnt) + '%' : '' }}
            </td>

            <td class="num act" :class="{ dim: !m.act_sdt }">{{ m.act_sdt || '' }}</td>
            <td class="num act" :class="{ dim: !m.act_edt }">{{ m.act_edt || '' }}</td>

            <td class="nowrap muted sm">{{ m.min_dt || '—' }}</td>
            <td class="nowrap muted sm">{{ m.max_dt || '—' }}</td>
            <td class="nowrap muted sm act">{{ m.min_act || '—' }}</td>
            <td class="nowrap muted sm act">{{ m.max_act || '—' }}</td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="2">합계</td>
            <td class="num">{{ tot.cnt }}</td>
            <td class="num">{{ tot.done }}</td>
            <td class="num sm">{{ pct(tot.done, tot.cnt) }}%</td>
            <td class="num dev">{{ tot.done_real }}</td>
            <td class="num sm dev">{{ pct(tot.done_real, tot.cnt) }}%</td>
            <td class="num act">{{ tot.act_sdt }}</td>
            <td class="num act">{{ tot.act_edt }}</td>
            <td colspan="4"></td>
          </tr>
        </tfoot>
      </table>
    </div>
    <p class="muted note">
      <strong>완료</strong> = <code>complate_yn</code> · <strong>개발완료</strong> = <code>complate_real_yn</code> ·
      <strong>실적일 입력</strong> = <code>plan_sdt_c</code> / <code>plan_edt_c</code> 가 채워진 건수 ·
      <strong>실적 기간</strong> = 입력된 실적일자의 최소·최대. 행을 클릭하면 상세 목록으로 이동합니다.
    </p>
  </section>
</template>

<style scoped>
h2 .spacer { flex: 1; }
.nowrap { white-space: nowrap; }
.sm { font-size: 11px; }
.note { margin: 8px 0 0; }
.dim { color: var(--line-strong); }

th.grp { text-align: center; font-size: 11px; }
th.grp.a { background: var(--done-soft); color: var(--done); }
th.grp.b { background: var(--accent-soft); color: var(--accent); }
th.grp.c { background: var(--warn-soft); color: var(--warn); }
thead tr:nth-child(2) th { font-weight: 400; font-size: 11px; }

td.dev { color: var(--accent); font-weight: 600; }
td.act { color: var(--warn); }
td.dev.dim, td.act.dim { color: var(--line-strong); font-weight: 400; }
tfoot td { font-weight: 600; background: var(--surface); }
tr.clk { cursor: pointer; }
tr.clk:hover { background: var(--surface); }
</style>
