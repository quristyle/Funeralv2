-- 개발자 관리의 <Super 권한>.
-- 'o' 면 최고 관리자 — 관리자 전용 메뉴·도구(⛁ 수집, ✔ 테스트 상태변경, 메뉴 권한)가 보이고
-- 메뉴 권한 설정과 무관하게 전체 메뉴를 쓴다.
--
-- appsettings 의 Admin:BpIds 는 <바닥> 으로 남는다 — 이 값을 전부 꺼도 거기 적힌 사람은
-- 계속 관리자다. 실수로 아무도 관리자가 아닌 상태를 만들지 못하게 하려는 것이다.

alter table public.dev_user
    add column if not exists super_yn varchar(1);

comment on column public.dev_user.super_yn is
    'Super 권한 — o 면 최고 관리자 (appsettings 의 Admin:BpIds 와 합집합)';
