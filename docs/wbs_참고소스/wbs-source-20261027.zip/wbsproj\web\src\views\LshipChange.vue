<script setup>
import { computed, nextTick, onMounted, ref } from 'vue'
import { api } from '../api'
import { state, useViewRefresh, isSuper } from '../store'
import { useColResize } from '../colresize'
import { downloadXlsx } from '../xlsx'
import RefreshBtn from '../components/RefreshBtn.vue'

// 대형선 업무설계 변경이력 — <엑셀처럼> 쓰는 표.
//
// 처음에는 칸을 눌러 고치는 보통 표였다. 그런데 이 화면은 <여러 줄을 한자리에서 적어
// 넣는> 일이 본 일이라 그것으로는 모자랐다. 그래서 세 가지를 붙였다.
//
//   1. 방향키로 칸을 옮긴다. 글자를 치면 바로 그 칸이 열린다 (엑셀과 같다).
//   2. 새 줄을 여러 개 깔아 둘 수 있다. 맨 아래에서 Enter·Tab 을 치면 한 줄이 더 생긴다.
//   3. 엑셀에서 긁어 온 것을 붙여넣으면 줄·칸이 통째로 들어온다 (TSV).
//
// 표 컴포넌트를 들여오지 않은 까닭: 이 저장소는 바깥 꾸러미를 쓰지 않는다(닫힌 망).
// 필요한 것은 <칸 사이 이동 · 붙여넣기 · 칸 저장> 셋뿐이라 그 셋만 만들었다.

// ---------- 컬럼 ----------
// 차례가 곧 엑셀에서 붙여넣을 때의 차례이고, colgroup 의 차례이기도 하다.
const COLS = [
  { k: 'screen_nm', label: '화면명', w: 220, min: 120, req: true },
  { k: 'screen_desc', label: '화면설명', w: 300, area: true },
  { k: 'req_sdt', label: '요청시작일', w: 112, min: 96, date: true },
  { k: 'drop_yn', label: '폐기', w: 62, min: 52, yn: true },
  { k: 'owner_nm', label: '담당자', w: 110, list: true },
  { k: 'note', label: '비고', w: 280, area: true },
]
const NC = COLS.length

const cw = useColResize('lshipchg.cols', [
  ...COLS.map((c) => ({ k: c.k, w: c.w, min: c.min })),
  { k: 'who', w: 132, min: 90 },
  { k: 'act', w: 44, min: 36 },
])

const rows = ref([])
const owners = ref([])
const loading = ref(false)
const saving = ref(null)
const savedAt = ref({})
let savedTimer = null

// ---------- 집계 · 필터 ----------
const q = ref('')
const only = ref('live')
const total = computed(() => rows.value.length)
const dropped = computed(() => rows.value.filter((r) => r.drop_yn === 'Y').length)
const live = computed(() => total.value - dropped.value)

const view = computed(() => {
  const kw = q.value.trim().toLowerCase()
  return rows.value.filter((r) => {
    if (only.value === 'live' && r.drop_yn === 'Y') return false
    if (only.value === 'dropped' && r.drop_yn !== 'Y') return false
    if (!kw) return true
    return [r.screen_nm, r.screen_desc, r.owner_nm, r.note, r.req_sdt]
      .some((v) => String(v ?? '').toLowerCase().includes(kw))
  })
})

// ---------- 새 줄 (여러 개) ----------
//
// 한 줄만 깔 수 있었던 것이 모자랐다. 이제 몇 줄이든 깔아 두고 다 적은 뒤 한 번에 보낸다.
// 저장 전까지는 화면에만 있다 — 반쯤 적은 줄이 남들에게 보이지 않는다.
function today() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}
const blank = () => ({ screen_nm: '', screen_desc: '', req_sdt: today(), drop_yn: 'N', owner_nm: '', note: '' })
const drafts = ref([])
const filledDrafts = computed(() => drafts.value.filter((d) => String(d.screen_nm ?? '').trim()))

function addDraft(n = 1) {
  for (let i = 0; i < n; i++) drafts.value.push(blank())
}
function addAndFocus() {
  addDraft()
  nextTick(() => focusCell('d', drafts.value.length - 1, 0))
}
function dropDraft(i) {
  drafts.value.splice(i, 1)
  if (sel.value?.kind === 'd') sel.value = null
}

async function saveDrafts() {
  const list = filledDrafts.value
  if (!list.length) {
    state.error = '화면명이 적힌 줄이 없습니다 — 화면명은 필수입니다.'
    return
  }
  saving.value = 'new'
  const fail = []
  try {
    // 한 줄씩 보낸다. 한 줄이 틀렸다고 다 못 넣는 것보다, 들어간 것은 들어가고
    // 안 들어간 줄만 남아 있는 편이 다시 하기 쉽다.
    for (const d of list) {
      try { await api.lshipChgNew(d) } catch (e) { fail.push(`${d.screen_nm}: ${e.message}`) }
    }
    // 빈 줄과 실패한 줄만 남긴다 — 성공한 줄을 그대로 두면 두 번 넣게 된다
    const bad = new Set(fail.map((f) => f.split(':')[0]))
    drafts.value = drafts.value.filter(
      (d) => !String(d.screen_nm ?? '').trim() || bad.has(String(d.screen_nm).trim()))
    await load()
    state.error = fail.length ? `${fail.length}줄을 넣지 못했습니다 — ${fail[0]}` : ''
  } finally {
    saving.value = null
  }
}

// ---------- 읽기 ----------
async function load() {
  loading.value = true
  try {
    const d = await api.lshipChg()
    rows.value = d.rows
    owners.value = d.owners ?? []
    state.error = ''
  } catch (e) {
    state.error = `변경이력을 읽지 못했습니다: ${e.message}`
  } finally {
    loading.value = false
  }
}
onMounted(load)
useViewRefresh(load)

// ---------- 칸 고르기 · 옮기기 (엑셀처럼) ----------
//
// sel 은 <지금 고른 칸> 이고 editing 은 <그 칸이 열려 있는가> 다. 둘을 가른 까닭:
// 엑셀도 고르기와 적기가 다른 상태다 — 고른 채로 방향키를 치면 옮겨 가고,
// 글자를 치면 그제서야 열린다. 하나로 합치면 방향키가 글자 사이를 오가게 된다.
const sel = ref(null)        // { kind:'r'|'d', i, c }
const editing = ref(false)
const draftText = ref('')

const at = (kind, i) => (kind === 'd' ? drafts.value[i] : view.value[i])
const isSel = (kind, i, c) => sel.value && sel.value.kind === kind && sel.value.i === i && sel.value.c === c
const cellId = (kind, i, c) => `${kind}:${i}:${c}`

function focusCell(kind, i, c) {
  sel.value = { kind, i, c }
  editing.value = false
  nextTick(() => document.querySelector(`[data-cell="${cellId(kind, i, c)}"]`)?.focus())
}

/** 열린 여러 줄 칸을 내용만큼 늘린다 — 적는 동안 쓴 것이 안 보이면 줄을 더 못 넣는다. */
function grow(e) {
  const el = e.target
  if (el.tagName !== 'TEXTAREA') return
  el.style.height = 'auto'
  el.style.height = Math.min(260, Math.max(52, el.scrollHeight + 2)) + 'px'
}

/** 칸을 연다. seed 를 주면 그 글자로 시작한다 (엑셀에서 바로 치기 시작하는 것과 같다). */
function openCell(seed) {
  const s = sel.value
  if (!s) return
  const r = at(s.kind, s.i)
  if (!r) return
  const col = COLS[s.c]
  if (col.yn) { toggleYn(s.kind, r); return }    // 폐기는 열 것이 없다 — 바로 뒤집는다
  draftText.value = seed != null ? seed : String(r[col.k] ?? '')
  editing.value = true
  nextTick(() => {
    const el = document.querySelector('.cell-in')
    el?.focus()
    if (seed != null) el?.setSelectionRange?.(seed.length, seed.length)
    else el?.select?.()
    if (el?.tagName === 'TEXTAREA') grow({ target: el })
  })
}

/** 열려 있으면 적은 것을 넣고 닫는다. */
async function commit() {
  const s = sel.value
  if (!s || !editing.value) return
  const r = at(s.kind, s.i)
  editing.value = false
  if (!r) return
  await setCell(s.kind, s.i, s.c, draftText.value)
}

/** 칸 하나에 값을 넣는다. 새 줄은 화면에만, 저장된 줄은 서버까지. */
async function setCell(kind, i, c, text) {
  const r = at(kind, i)
  if (!r) return
  const col = COLS[c]
  // 여러 줄 칸은 가운데 줄바꿈을 지킨다 — trim 은 앞뒤만 깎는다(줄바꿈 자체는 안 건드린다).
  let v = String(text ?? '').replace(/[ \t]+$/gm, '').trim()
  if (col.yn) v = /^(y|예|폐기|1|true)$/i.test(v) ? 'Y' : 'N'
  if (String(r[col.k] ?? '') === v) return

  if (kind === 'd') { r[col.k] = v; return }      // 새 줄은 보낼 것이 없다
  if (col.req && !v) { state.error = `${col.label}은(는) 비울 수 없습니다.`; return }
  await put(r, { [col.k]: v })
}

const MOVE = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] }

/**
 * 칸 사이를 옮긴다. 저장된 줄과 새 줄은 <위아래로 이어진 한 장>처럼 다닌다 —
 * 보기에 한 표인데 경계에서 멈추면 사람은 고장으로 읽는다.
 */
function move(dr, dc) {
  const s = sel.value
  if (!s) return
  let { kind, i, c } = s
  c += dc
  if (c < 0) { c = NC - 1; dr = dr || -1 }
  if (c >= NC) { c = 0; dr = dr || 1 }

  i += dr
  if (kind === 'r') {
    if (i >= view.value.length) { kind = 'd'; i = 0 }     // 저장된 줄 끝 → 새 줄로
    else if (i < 0) i = 0
  } else {
    if (i < 0) {                                          // 새 줄 위 → 저장된 줄 끝으로
      if (view.value.length) { kind = 'r'; i = view.value.length - 1 }
      else i = 0
    } else if (i >= drafts.value.length) {
      // 맨 아래에서 더 내려가면 한 줄이 생긴다 — 엑셀에서 아래로 계속 적어 나가듯이
      addDraft()
      i = drafts.value.length - 1
    }
  }
  focusCell(kind, i, c)
}

/** 고른 상태(칸이 열려 있지 않을 때)의 키. */
function onGridKey(e) {
  if (!sel.value) return
  const k = e.key

  if (MOVE[k]) { e.preventDefault(); move(...MOVE[k]); return }
  if (k === 'Tab') { e.preventDefault(); move(0, e.shiftKey ? -1 : 1); return }
  if (k === 'Enter' || k === 'F2') { e.preventDefault(); openCell(); return }
  if (k === 'Delete' || k === 'Backspace') {
    e.preventDefault()
    setCell(sel.value.kind, sel.value.i, sel.value.c, '')
    return
  }
  if (k === 'Escape') { sel.value = null; return }
  // 글자를 치면 그 글자로 칸이 열린다 (엑셀과 같다). 조합키는 지나보낸다.
  if (k.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) { e.preventDefault(); openCell(k) }
}

/** 열린 칸 안에서의 키. */
function onEditKey(e) {
  // ⚠️ 위로 올려보내지 않는다. 칸이 열려 있을 때 친 키는 <그 칸의 것>이다.
  //    올려보내면 td 의 onGridKey 가 한 번 더 집는다 — editing 을 방금 끈 참이라
  //    그쪽에서는 <열려 있지 않은 상태의 키>로 읽혀, Esc 는 고른 칸까지 풀고
  //    Tab·Enter 는 두 칸씩 건너뛴다. (실제로 밟았다.)
  e.stopPropagation()
  const k = e.key
  if (k === 'Escape') { e.preventDefault(); editing.value = false; nextTick(() => focusCell(sel.value.kind, sel.value.i, sel.value.c)); return }
  if (k === 'Tab') { e.preventDefault(); commit().then(() => move(0, e.shiftKey ? -1 : 1)); return }
  if (k === 'Enter' && !e.isComposing) {
    // 여러 줄 칸(설명·비고)은 Alt+Enter 로 줄을 바꾼다 — 엑셀과 같다
    if (COLS[sel.value.c].area && e.altKey) return
    e.preventDefault()
    commit().then(() => move(1, 0))
  }
}

// ---------- 붙여넣기 (엑셀에서 긁어 온 것) ----------
//
// 탭으로 칸, 줄바꿈으로 줄. 고른 칸을 왼쪽 위 모서리로 삼아 깔린다.
// 모자라면 새 줄을 더 만든다 — 20줄을 긁어 와도 미리 20줄을 깔아 둘 필요가 없다.
const pasteMsg = ref('')

/**
 * 엑셀이 준 TSV 를 격자로 푼다.
 *
 * ⚠️ 그냥 줄바꿈으로 자르면 안 된다. <b>칸 안에 줄바꿈이 있는 값</b>(비고·화면설명이 그렇다)을
 * 엑셀은 따옴표로 감싸 보낸다 — 그것을 모르고 자르면 <b>한 칸이 여러 줄로 쪼개져</b>
 * 엉뚱한 자리에 깔린다. 따옴표 안의 탭·줄바꿈은 글자로 보고, "" 는 따옴표 한 글자다.
 */
function parseTsv(text) {
  const grid = []
  let row = []
  let cell = ''
  let quoted = false
  const t = text.replace(/\r\n?/g, '\n')

  for (let i = 0; i < t.length; i++) {
    const ch = t[i]
    if (quoted) {
      if (ch === '"') {
        if (t[i + 1] === '"') { cell += '"'; i++ }   // "" → 따옴표 한 글자
        else quoted = false
      } else cell += ch
      continue
    }
    if (ch === '"' && cell === '') { quoted = true; continue }
    if (ch === '\t') { row.push(cell); cell = ''; continue }
    if (ch === '\n') { row.push(cell); grid.push(row); row = []; cell = ''; continue }
    cell += ch
  }
  row.push(cell)
  grid.push(row)
  // 끝의 빈 줄 하나는 버린다 (엑셀이 마지막에 줄바꿈을 붙인다)
  if (grid.length > 1 && grid.at(-1).length === 1 && grid.at(-1)[0] === '') grid.pop()
  return grid
}
async function onPaste(e) {
  if (editing.value || !sel.value) return          // 칸이 열려 있으면 그 칸에 붙는 것이 맞다
  const text = e.clipboardData?.getData('text/plain')
  if (!text) return
  e.preventDefault()

  const grid = parseTsv(text)
  const { kind, i: i0, c: c0 } = sel.value
  let made = 0
  let saved = 0

  // 저장된 줄에 붙는 것은 <한 줄에 한 번> 보낸다. 칸마다 보내면 왕복이 수십 번이다.
  for (let ri = 0; ri < grid.length; ri++) {
    const cells = grid[ri]
    let k = kind
    let i = i0 + ri
    if (k === 'r' && i >= view.value.length) { k = 'd'; i -= view.value.length }
    if (k === 'd') {
      while (i >= drafts.value.length) { addDraft(); made++ }
      const row = drafts.value[i]
      cells.forEach((v, ci) => {
        const col = COLS[c0 + ci]
        if (!col) return
        row[col.k] = col.yn ? (/^(y|예|폐기|1|true)$/i.test(v.trim()) ? 'Y' : 'N') : v.trim()
      })
    } else {
      const row = view.value[i]
      if (!row) continue
      const patch = {}
      cells.forEach((v, ci) => {
        const col = COLS[c0 + ci]
        if (!col) return
        const val = col.yn ? (/^(y|예|폐기|1|true)$/i.test(v.trim()) ? 'Y' : 'N') : v.trim()
        if (col.req && !val) return                // 화면명을 빈칸으로 덮지 않는다
        if (String(row[col.k] ?? '') !== val) patch[col.k] = val
      })
      if (Object.keys(patch).length) { await put(row, patch); saved++ }
    }
  }

  pasteMsg.value =
    `붙여넣었습니다 — ${grid.length}줄` +
    (made ? ` · 새 줄 ${made}개 생김` : '') +
    (saved ? ` · 이미 있던 줄 ${saved}개 저장` : '') +
    (made ? ' (아직 저장 전입니다 — [모두 저장])' : '')
  setTimeout(() => (pasteMsg.value = ''), 6000)
}

// ---------- 저장 ----------
async function put(r, patch) {
  saving.value = r.chg_id
  try {
    const got = await api.lshipChgSet(r.chg_id, patch)
    Object.assign(r, got)
    savedAt.value = { ...savedAt.value, [r.chg_id]: true }
    clearTimeout(savedTimer)
    savedTimer = setTimeout(() => (savedAt.value = {}), 2500)
    state.error = ''
  } catch (e) {
    state.error = `저장 실패 (${r.screen_nm}): ${e.message}`
  } finally {
    saving.value = null
  }
}

function toggleYn(kind, r) {
  const next = r.drop_yn === 'Y' ? 'N' : 'Y'
  if (kind === 'd') { r.drop_yn = next; return }
  put(r, { drop_yn: next })
}

// ---------- 삭제 (Super) ----------
const armed = ref(null)
let armTimer = null
function armDel(r) {
  if (armed.value === r.chg_id) { del(r); return }
  armed.value = r.chg_id
  clearTimeout(armTimer)
  armTimer = setTimeout(() => (armed.value = null), 4000)
}
async function del(r) {
  clearTimeout(armTimer)
  armed.value = null
  saving.value = r.chg_id
  try {
    await api.lshipChgDel(r.chg_id)
    rows.value = rows.value.filter((x) => x.chg_id !== r.chg_id)
    state.error = ''
  } catch (e) {
    state.error = `삭제 실패: ${e.message}`
  } finally {
    saving.value = null
  }
}

// ---------- 엑셀 ----------
/** 지금 화면에 보이는 것만 담는다 — 필터를 걸어 놓고 받으면 그 결과를 기대한다. */
function exportXlsx() {
  const headers = [
    ...COLS.map((c) => ({ label: c.label, width: cw.colStyle(c.k).width.replace('px', '') | 0 })),
    { label: '남긴 사람', width: 110 },
    { label: '남긴 때', width: 120 },
  ]
  const body = view.value.map((r) => [
    r.screen_nm ?? '',
    r.screen_desc ?? '',
    r.req_sdt ?? '',
    r.drop_yn === 'Y' ? '폐기' : '진행',
    r.owner_nm ?? '',
    r.note ?? '',
    r.updated_by || r.created_by || '',
    r.updated_at || r.created_at || '',
  ])
  downloadXlsx('대형선_설계변경이력', '변경이력', headers, body)
}
</script>

<template>
  <section class="panel">
    <h2>
      대형선 설계 변경이력
      <span class="hint">{{ total }}건 · 진행 {{ live }}건 · 폐기 {{ dropped }}건</span>
      <span class="spacer"></span>
      <RefreshBtn :busy="loading" @click="load" />
    </h2>

    <p class="muted note">
      대형선 업무설계가 바뀔 때마다 한 줄씩 남깁니다. <b>화면명만 필수</b>입니다.
      <b>엑셀처럼 씁니다</b> — 칸을 누르고 <code>방향키</code>로 옮기고, 글자를 치면 바로 적힙니다
      (<code>Enter</code>/<code>F2</code> 로 열기, <code>Tab</code> 다음 칸, <code>Esc</code> 되돌리기,
      <b>화면설명·비고는 여러 줄</b>로 적을 수 있습니다 — <code>Alt+Enter</code> 로 줄을 바꾸고
      <code>Enter</code> 로 저장합니다).
      <b>엑셀에서 긁어 와 붙여넣으면</b> 줄·칸이 통째로 들어오고 모자란 줄은 저절로 생깁니다.
      지우는 대신 <b>폐기</b>로 남깁니다.
    </p>

    <div class="topbar">
      <button class="go" @click="addAndFocus">＋ 줄 추가</button>
      <button :disabled="!drafts.length" @click="addDraft(5)">＋5줄</button>
      <button
        v-if="drafts.length"
        class="go"
        :disabled="saving === 'new' || !filledDrafts.length"
        :title="`화면명이 적힌 ${filledDrafts.length}줄을 저장합니다`"
        @click="saveDrafts"
      >{{ saving === 'new' ? '저장 중…' : `모두 저장 (${filledDrafts.length})` }}</button>
      <button v-if="drafts.length" @click="drafts = []">새 줄 비우기</button>

      <input v-model="q" type="search" placeholder="화면명 · 설명 · 담당자 · 비고 검색" />
      <div class="btns">
        <button :class="{ on: only === 'live' }" @click="only = 'live'">진행 {{ live }}</button>
        <button :class="{ on: only === 'dropped' }" @click="only = 'dropped'">폐기 {{ dropped }}</button>
        <button :class="{ on: only === 'all' }" @click="only = 'all'">전체 {{ total }}</button>
      </div>
      <button :disabled="!view.length" title="지금 보이는 줄만 담습니다" @click="exportXlsx">⤓ 엑셀</button>
      <button v-if="cw.touched.value" class="clr" @click="cw.resetAll()">너비 되돌리기</button>
      <span class="spacer"></span>
      <span class="hint">{{ view.length }}건 표시</span>
    </div>

    <p v-if="pasteMsg" class="pmsg">{{ pasteMsg }}</p>

    <div class="scroll" :class="{ sizing: cw.sizing.value }" @paste="onPaste">
      <table :style="cw.tableStyle.value">
        <colgroup><col v-for="c in cw.cols" :key="c.k" :style="cw.colStyle(c.k)" /></colgroup>
        <thead>
          <tr>
            <th v-for="c in COLS" :key="c.k">
              {{ c.label }}<b v-if="c.req" class="req">*</b>
              <span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값"
                    @pointerdown="cw.start($event, c.k)" @dblclick="cw.reset(c.k)"></span>
            </th>
            <th>남긴 사람<span class="cgrip" @pointerdown="cw.start($event, 'who')" @dblclick="cw.reset('who')"></span></th>
            <th class="ctr">
              <span v-if="isSuper" title="진짜 삭제 — 평소에는 폐기를 쓰세요">삭제</span>
              <span class="cgrip" @pointerdown="cw.start($event, 'act')" @dblclick="cw.reset('act')"></span>
            </th>
          </tr>
        </thead>

        <tbody>
          <!-- 저장된 줄 -->
          <tr v-for="(r, i) in view" :key="r.chg_id" :class="{ dropped: r.drop_yn === 'Y' }">
            <td
              v-for="(c, ci) in COLS"
              :key="c.k"
              :class="{ ctr: c.yn, sel: isSel('r', i, ci) }"
              :data-cell="cellId('r', i, ci)"
              tabindex="0"
              @focus="sel = { kind: 'r', i, c: ci }"
              @click="focusCell('r', i, ci)"
              @dblclick="openCell()"
              @keydown="editing ? null : onGridKey($event)"
            >
              <template v-if="c.yn">
                <button class="yn" :class="{ on: r.drop_yn === 'Y' }" :disabled="saving === r.chg_id"
                        :title="r.drop_yn === 'Y' ? '폐기됨 — 누르면 진행으로' : '누르면 폐기로'"
                        @click.stop="toggleYn('r', r)">{{ r.drop_yn === 'Y' ? '폐기' : '진행' }}</button>
              </template>
              <template v-else-if="isSel('r', i, ci) && editing">
                <input v-if="c.date" v-model="draftText" class="cell-in" type="date"
                       @blur="commit" @keydown="onEditKey" />
                <textarea v-else-if="c.area" v-model="draftText" class="cell-in ml" rows="3"
                          spellcheck="false" :title="'Alt+Enter 줄바꿈 · Enter 저장'"
                          @input="grow" @blur="commit" @keydown="onEditKey"></textarea>
                <input v-else v-model="draftText" class="cell-in" type="text"
                       :list="c.list ? 'dl_owners' : undefined" @blur="commit" @keydown="onEditKey" />
              </template>
              <span v-else class="txt" :class="{ empty: !String(r[c.k] ?? '').trim(), nm: c.req }">{{
                String(r[c.k] ?? '').trim() || '—'
              }}</span>
            </td>

            <td class="who">
              <span v-if="saving === r.chg_id" class="st">저장 중…</span>
              <span v-else-if="savedAt[r.chg_id]" class="st ok">저장됨</span>
              <template v-else>
                <span class="nm2">{{ r.updated_by || r.created_by || '—' }}</span>
                <span class="at">{{ r.updated_at || r.created_at }}</span>
              </template>
            </td>
            <td class="ctr">
              <button v-if="isSuper" class="del" :class="{ arm: armed === r.chg_id }"
                      :disabled="saving === r.chg_id"
                      :title="armed === r.chg_id ? '한 번 더 누르면 정말 지웁니다' : '진짜 삭제 — 평소에는 폐기를 쓰세요'"
                      @click="armDel(r)">{{ armed === r.chg_id ? '한 번 더' : '✕' }}</button>
            </td>
          </tr>

          <!-- 새 줄 — 저장 전까지 화면에만 있다 -->
          <tr v-for="(d, i) in drafts" :key="'d' + i" class="addrow">
            <td
              v-for="(c, ci) in COLS"
              :key="c.k"
              :class="{ ctr: c.yn, sel: isSel('d', i, ci) }"
              :data-cell="cellId('d', i, ci)"
              tabindex="0"
              @focus="sel = { kind: 'd', i, c: ci }"
              @click="focusCell('d', i, ci)"
              @dblclick="openCell()"
              @keydown="editing ? null : onGridKey($event)"
            >
              <template v-if="c.yn">
                <button class="yn" :class="{ on: d.drop_yn === 'Y' }"
                        @click.stop="toggleYn('d', d)">{{ d.drop_yn === 'Y' ? '폐기' : '진행' }}</button>
              </template>
              <template v-else-if="isSel('d', i, ci) && editing">
                <input v-if="c.date" v-model="draftText" class="cell-in" type="date"
                       @blur="commit" @keydown="onEditKey" />
                <textarea v-else-if="c.area" v-model="draftText" class="cell-in ml" rows="3"
                          spellcheck="false" :title="'Alt+Enter 줄바꿈 · Enter 저장'"
                          @input="grow" @blur="commit" @keydown="onEditKey"></textarea>
                <input v-else v-model="draftText" class="cell-in" type="text"
                       :list="c.list ? 'dl_owners' : undefined" @blur="commit" @keydown="onEditKey" />
              </template>
              <span v-else class="txt" :class="{ empty: !String(d[c.k] ?? '').trim(), nm: c.req }">{{
                String(d[c.k] ?? '').trim() || (c.req ? '화면명 (필수)' : '—')
              }}</span>
            </td>
            <td class="who"><span class="st new">새 줄</span></td>
            <td class="ctr">
              <button class="del" title="이 새 줄을 치웁니다 (저장 전이라 서버에는 없습니다)"
                      @click="dropDraft(i)">✕</button>
            </td>
          </tr>

          <tr v-if="!view.length && !drafts.length && !loading">
            <td colspan="8" class="empty">
              {{ total ? '걸러진 것이 없습니다.' : '아직 적은 이력이 없습니다 — [＋ 줄 추가] 로 시작하거나 엑셀에서 붙여넣으세요.' }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <datalist id="dl_owners"><option v-for="o in owners" :key="o" :value="o"></option></datalist>
  </section>
</template>

<style scoped>
h2 { display: flex; align-items: center; gap: 8px; }
.spacer { flex: 1; }
.hint { font-size: 12px; font-weight: 400; color: var(--muted); }
.note { margin: 0 0 10px; font-size: 11.5px; line-height: 1.8; }
.req { color: var(--danger); margin-left: 2px; }

.topbar { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; flex-wrap: wrap; }
.topbar input[type='search'] { min-width: 200px; }
.topbar button { font-size: 11.5px; padding: 3px 9px; }
.btns { display: flex; gap: 4px; }
.btns button.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
button.go { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
button.go:disabled { opacity: 0.5; cursor: default; }
.pmsg {
  margin: 0 0 8px; padding: 5px 10px; font-size: 11.5px; border-radius: 6px;
  background: var(--accent-soft); border: 1px solid var(--accent); color: var(--accent);
}

.scroll { overflow: auto; max-height: calc(100vh - 300px); }
.scroll.sizing { user-select: none; cursor: col-resize; }
table { border-collapse: collapse; font-size: 12px; }
th, td { border: 1px solid var(--line); padding: 3px 7px; text-align: left; vertical-align: top; }
td { overflow-wrap: anywhere; outline: none; }
/* sticky 는 position 을 겸하므로 손잡이(.cgrip)의 기준 칸도 된다 */
th {
  position: sticky; top: 0; z-index: 2;
  background: var(--panel); color: var(--muted); font-weight: 600; font-size: 11.5px;
}
.ctr { text-align: center; }
tbody tr:hover { background: var(--hover); }
tbody tr.dropped { color: var(--muted-3); }
tbody tr.dropped .txt.nm { text-decoration: line-through; }
.empty { text-align: center; color: var(--muted); padding: 24px; }

/* 고른 칸 — 엑셀의 굵은 테두리. 어느 칸에 있는지가 한눈에 보여야 방향키를 믿고 친다 */
td.sel { outline: 2px solid var(--accent); outline-offset: -2px; background: var(--accent-soft); }

.cgrip {
  position: absolute; top: 0; right: -3px; width: 7px; height: 100%;
  cursor: col-resize; user-select: none; touch-action: none; z-index: 3;
}
.cgrip:hover { background: var(--accent); opacity: 0.35; }

/* 적어 둔 줄바꿈이 그대로 보인다(pre-wrap). 다만 긴 글 하나가 줄을 통째로 늘리지 않도록
   높이를 막고 그 안에서 구르게 둔다 — 잘라 숨기면 적어 둔 것을 볼 길이 없어진다. */
.txt {
  display: block; font-size: 11.5px; line-height: 1.6; min-height: 19px;
  white-space: pre-wrap; max-height: 112px; overflow: auto;
}
.txt.empty { color: var(--muted-3); }
.txt.nm { font-weight: 600; }
.cell-in { width: 100%; font-size: 11.5px; line-height: 1.5; resize: vertical; padding: 1px 4px; }
/* 여러 줄 칸 — 적는 동안 내용만큼 늘어난다(grow). 높이는 js 가 정하므로 rows 는 밑바닥일 뿐이다 */
.cell-in.ml { min-height: 52px; max-height: 260px; }

.yn { font-size: 10.5px; padding: 1px 8px; border-radius: 9px; color: var(--done); border-color: var(--done-line); background: var(--done-soft); }
.yn.on { color: var(--muted); border-color: var(--line); background: var(--bg); }

tbody tr.addrow { background: var(--accent-soft); }
tbody tr.addrow:hover { background: var(--accent-soft); }

.who { font-size: 10.5px; color: var(--muted); }
.who .at { display: block; color: var(--muted-3); font-variant-numeric: tabular-nums; }
.st { font-size: 10.5px; color: var(--muted); }
.st.ok { color: var(--done); }
.st.new { color: var(--accent); }

.del { font-size: 11px; padding: 1px 6px; color: var(--muted-3); border-color: transparent; background: none; }
tbody tr:hover .del { color: var(--danger-text); border-color: var(--line); }
.del:hover:not(:disabled) { border-color: var(--danger); background: var(--danger-soft); }
.del.arm { background: var(--danger); border-color: var(--danger); color: #fff; font-size: 10px; }
</style>
