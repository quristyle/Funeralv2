<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { api } from '../api'
import { state, useViewRefresh, pvWorkUrl } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'
import PvDialog from '../components/PvDialog.vue'
import { buildPvDateScript } from '../pvScript'

// 착수지연 = 계획시작일 도래 & 실적시작일 없음 / 종료지연 = 계획종료일 도래 & 실적종료일 없음
const sum = ref({})
const byPlan = ref([]) // 담당자별
const byReal = ref([]) // 개발자별
const rows = ref([])
const loading = ref(false)

// 상세 목록 필터
const kind = ref('all') // all | start | finish
const selUser = ref('')
const selReal = ref('')

const lastAt = ref('')

async function loadAll() {
  loading.value = true
  try {
    const [s, p, r] = await Promise.all([
      api.delaySummary(state.scope),
      api.delayByUser(state.scope, 'plan'),
      api.delayByUser(state.scope, 'real'),
      loadPvCache(),
    ])
    sum.value = s
    byPlan.value = p
    byReal.value = r
    await loadRows()
    lastAt.value = new Date().toLocaleTimeString('ko-KR')
  } catch (e) {
    state.error = e.message
  } finally {
    loading.value = false
  }
}

async function loadRows() {
  try {
    rows.value = await api.delayRows(state.scope, kind.value, selUser.value, selReal.value)
  } catch (e) {
    state.error = e.message
  }
}

function pickUser(u) {
  selUser.value = selUser.value === u ? '' : u
  selReal.value = ''
}
function pickReal(u) {
  selReal.value = selReal.value === u ? '' : u
  selUser.value = ''
}
function clearSel() {
  selUser.value = ''
  selReal.value = ''
  kind.value = 'all'
}

const latePct = computed(() =>
  sum.value.total ? Math.round((sum.value.any_late / sum.value.total) * 1000) / 10 : 0
)
// 지연이 있는 인원만 (지연 0명은 표에서 감춤)
const planLate = computed(() => byPlan.value.filter((r) => r.any_late > 0))
const realLate = computed(() => byReal.value.filter((r) => r.any_late > 0))

const hasSel = computed(() => !!selUser.value || !!selReal.value || kind.value !== 'all')

// ---------- ProjectView 실적시작일 전송 ----------
// 계획시작일은 지났는데 실적시작일이 비어 있는(착수지연) 항목만 대상으로 한다.
// 종료지연만 걸린 행은 채울 값이 없으므로 제외한다.
const pvRows = computed(() =>
  rows.value.filter((r) => r.activity_id && r.plan_sdt && !r.plan_sdt_c)
)
const pvScript = ref('')

// ProjectView 캐시 — workId 가 다 있으면 목록 조회를 건너뛴다. 없어도 동작한다.
const pvCache = ref({ ids: {}, done: {}, projectId: '', n: 0 })
const pvSkipped = ref(0)

async function loadPvCache() {
  try {
    const rs = await api.pvCacheRows(state.scope)
    const ids = {}
    const done = {}
    let projectId = ''
    for (const r of rs) {
      if (r.pv_work_id) ids[r.activity_id] = r.pv_work_id
      if (r.pv_actual_sdt) done[r.activity_id] = r.pv_actual_sdt   // 이미 실적시작일이 있는 건
      if (!projectId && r.pv_project_id) projectId = r.pv_project_id
    }
    pvCache.value = { ids, done, projectId, n: Object.keys(ids).length }
  } catch {
    // 캐시는 없어도 되는 것이라 조용히 넘어간다
  }
}

function openPvScript() {
  const all = pvRows.value.map((r) => ({ activity_id: r.activity_id, date: r.plan_sdt }))

  // ProjectView 에 이미 실적시작일이 있는 건은 스크립트가 어차피 건너뛴다.
  // 캐시로 미리 알 수 있으면 조회조차 하지 않는다.
  const done = pvCache.value.done
  const items = all.filter((i) => !done[i.activity_id])
  pvSkipped.value = all.length - items.length

  pvScript.value = buildPvDateScript(
    items,
    '계획시작일 → 실적시작일(actualStartDate)',
    new Date().toLocaleString('ko-KR'),
    { ids: pvCache.value.ids, projectId: pvCache.value.projectId }
  )
}

watch([kind, selUser, selReal], loadRows)
watch(() => state.scope, loadAll)
useViewRefresh(loadAll)
onMounted(loadAll)
</script>

<template>
  <!-- 화면 전체(요약·담당자별·개발자별·상세) 를 한 번에 다시 읽는다 -->
  <div class="topbar">
    <span class="hint">
      기준일 {{ sum.asof ?? '-' }}
      <template v-if="lastAt"> · 마지막 갱신 {{ lastAt }}</template>
      <template v-if="loading"> · 불러오는 중…</template>
    </span>
    <span class="spacer"></span>
    <RefreshBtn :fn="loadAll" label="전체 새로고침" />
  </div>

  <div class="cards">
    <div class="card"><div class="k">개발 대상</div><div class="v">{{ sum.total ?? '-' }}</div></div>
    <div class="card late">
      <div class="k">착수지연</div>
      <div class="v">
        {{ sum.start_late ?? '-' }}
        <small v-if="sum.max_start_days">최대 {{ sum.max_start_days }}일</small>
      </div>
    </div>
    <div class="card late">
      <div class="k">종료지연</div>
      <div class="v">
        {{ sum.finish_late ?? '-' }}
        <small v-if="sum.max_finish_days">최대 {{ sum.max_finish_days }}일</small>
      </div>
    </div>
    <div class="card">
      <div class="k">착수·종료 모두 지연</div>
      <div class="v">{{ sum.both_late ?? '-' }}</div>
    </div>
    <div class="card">
      <div class="k">지연 항목 (중복 제외)</div>
      <div class="v">{{ sum.any_late ?? '-' }} <small>/ {{ sum.total ?? '-' }} · {{ latePct }}%</small></div>
    </div>
    <div class="card">
      <div class="k">기준일 (오늘)</div>
      <div class="v" style="font-size: 14px">{{ sum.asof ?? '-' }}</div>
    </div>
  </div>

  <div class="grid2" style="margin-top: 14px">
    <section class="panel">
      <h2>
        담당자별 지연 <span class="hint">행을 클릭하면 아래 목록이 필터됩니다</span>
        <span class="spacer"></span>
        <RefreshBtn :fn="loadAll" />
      </h2>
      <div class="scroll">
        <table>
          <thead>
            <tr>
              <th>담당자</th><th class="num">담당</th>
              <th class="num">착수지연</th><th class="num">종료지연</th><th class="num">지연 합</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="u in planLate" :key="u.user_bp_id"
              class="clk" :class="{ on: selUser === u.user_bp_id }"
              @click="pickUser(u.user_bp_id)"
            >
              <td class="nowrap"><span class="nm">{{ u.user_nm }}</span><span class="uid">{{ u.user_bp_id }}</span></td>
              <td class="num muted">{{ u.assigned }}</td>
              <td class="num" :class="{ bad: u.start_late }">{{ u.start_late || '' }}</td>
              <td class="num" :class="{ bad: u.finish_late }">{{ u.finish_late || '' }}</td>
              <td class="num tot">{{ u.any_late }}</td>
            </tr>
            <tr v-if="!planLate.length">
              <td colspan="5" class="muted ctr">지연 없음</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <section class="panel real">
      <h2>
        개발자별 지연 <span class="hint">user_real_id 기준</span>
        <span class="spacer"></span>
        <RefreshBtn :fn="loadAll" />
      </h2>
      <div class="scroll">
        <table>
          <thead>
            <tr>
              <th>개발자</th><th class="num">담당</th>
              <th class="num">착수지연</th><th class="num">종료지연</th><th class="num">지연 합</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="u in realLate" :key="u.user_bp_id"
              class="clk" :class="{ on: selReal === u.user_bp_id }"
              @click="pickReal(u.user_bp_id)"
            >
              <td class="nowrap">
                <span class="nm">{{ u.user_nm }}</span>
                <span v-if="u.user_nm !== u.user_bp_id" class="uid">{{ u.user_bp_id }}</span>
              </td>
              <td class="num muted">{{ u.assigned }}</td>
              <td class="num" :class="{ bad: u.start_late }">{{ u.start_late || '' }}</td>
              <td class="num" :class="{ bad: u.finish_late }">{{ u.finish_late || '' }}</td>
              <td class="num tot">{{ u.any_late }}</td>
            </tr>
            <tr v-if="!realLate.length">
              <td colspan="5" class="muted ctr">지연 없음</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </div>

  <section class="panel">
    <h2>
      지연 상세 목록 <span class="hint">{{ rows.length }}건{{ loading ? ' · 조회 중…' : '' }}</span>
      <span class="spacer"></span>
      <select v-model="kind" title="지연 유형">
        <option value="all">착수 + 종료 지연</option>
        <option value="start">착수지연만</option>
        <option value="finish">종료지연만</option>
      </select>
      <button v-if="hasSel" @click="clearSel">필터 해제</button>
      <RefreshBtn :fn="loadRows" />

      <!-- ProjectView 전송: 현재 목록 중 실적시작일이 비어 있는 행만 담는다 -->
      <span class="sep"></span>
      <button
        class="pv"
        :disabled="!pvRows.length"
        :title="pvRows.length
          ? `실적시작일이 비어 있는 ${pvRows.length}건의 계획시작일을 ProjectView 로 보냅니다`
          : '보낼 대상이 없습니다 (실적시작일이 비어 있는 행이 없음)'"
        @click="openPvScript"
      >
        ProjectView 실적시작일 전송 ({{ pvRows.length }})
      </button>
    </h2>

    <p v-if="selUser || selReal" class="muted" style="margin: -4px 0 8px">
      필터:
      <template v-if="selUser">담당자 {{ byPlan.find((u) => u.user_bp_id === selUser)?.user_nm }} ({{ selUser }})</template>
      <template v-if="selReal">개발자 {{ byReal.find((u) => u.user_bp_id === selReal)?.user_nm }} ({{ selReal }})</template>
    </p>

    <div class="scroll tall">
      <table>
        <thead>
          <tr>
            <th>Activity ID</th><th>모듈</th><th>메뉴명</th>
            <th>시작일</th><th>실적시작</th><th class="num">착수지연</th>
            <th>종료일</th><th>실적종료</th><th class="num">종료지연</th>
            <th>담당자</th><th>개발자</th>
            <th class="ctr">완료</th><th class="ctr">개발자완료</th>
            <th class="num">우선순위</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in rows" :key="r.activity_id + r.menu_nm">
            <!-- Activity ID 를 누르면 ProjectView 작업 상세로 간다. 주소는 store 의
                 pvWorkUrl 이 만든다 — 여기서 문자열을 조립하면 ProjectView 가 옮겨 갈 때
                 고칠 곳이 둘이 된다. projectKey 는 코드 앞자리(AAC-A1047 → AAC)에서 뽑는다. -->
            <td class="nowrap">
              <a
                v-if="r.activity_id"
                class="pvlink"
                :href="pvWorkUrl(r)"
                target="_blank"
                rel="noopener noreferrer"
                :title="`ProjectView 작업 상세 열기 (${r.activity_id})`"
              >{{ r.activity_id }}</a>
              <span v-else class="muted">—</span>
            </td>
            <td class="nowrap">{{ r.systemcode }} {{ r.system_nm }}</td>
            <td>{{ r.menu_nm }}</td>
            <td class="nowrap">{{ r.plan_sdt || '—' }}</td>
            <td class="nowrap" :class="{ miss: r.start_late }">{{ r.plan_sdt_c || '미입력' }}</td>
            <td class="num"><span v-if="r.start_days != null" class="days">{{ r.start_days }}일</span></td>
            <td class="nowrap">{{ r.plan_edt || '—' }}</td>
            <td class="nowrap" :class="{ miss: r.finish_late }">{{ r.plan_edt_c || '미입력' }}</td>
            <td class="num"><span v-if="r.finish_days != null" class="days">{{ r.finish_days }}일</span></td>
            <td class="nowrap">
              <template v-if="r.user_nm"><span class="nm">{{ r.user_nm }}</span><span class="uid">{{ r.user_bp_id }}</span></template>
              <span v-else class="muted">—</span>
            </td>
            <td class="nowrap">
              <template v-if="r.user_real_nm"><span class="nm">{{ r.user_real_nm }}</span><span class="uid">{{ r.user_real_id }}</span></template>
              <span v-else class="muted">—</span>
            </td>
            <!-- 완료 / 개발자완료 -->
            <td class="ctr">
              <span v-if="r.complate_yn === 'o'" class="chk">✓</span><span v-else class="muted">·</span>
            </td>
            <td class="ctr">
              <span v-if="r.complate_real_yn === 'o'" class="chk">✓</span><span v-else class="muted">·</span>
            </td>
            <td class="num">{{ r.priority_order || '' }}</td>
          </tr>
          <tr v-if="!rows.length && !loading">
            <td colspan="14" class="muted ctr" style="padding: 20px">지연 항목 없음</td>
          </tr>
        </tbody>
      </table>
    </div>

    <p class="muted note">
      착수지연 = 계획시작일이 <strong>{{ sum.asof }}</strong> 이전인데 실적시작일이 비어 있음 ·
      종료지연 = 계획종료일이 도래했는데 실적종료일이 비어 있음. 지연일수는 기준일과의 일수 차이입니다.
    </p>
    <p class="muted note">
      <strong>ProjectView 실적시작일 전송</strong> — 위 버튼은 <em>현재 목록 중 실적시작일이 비어 있는
      {{ pvRows.length }}건</em>의 <code>시작일</code>을 ProjectView 의 <code>actualStartDate</code> 로
      채우는 콘솔 스크립트를 만듭니다. ProjectView 로그인 탭의 F12 → Console 에 붙여넣으면 먼저
      <code>DRY RUN</code> 으로 대상과 날짜만 출력하고, 콘솔에 <code>pvSend()</code> 를 입력할 때 실제 전송됩니다.
      ProjectView 에 <strong>이미 실적시작일이 있는 항목은 건너뛰며</strong>,
      진척률(<code>finishRate</code>)은 조회한 값을 그대로 되돌려 보내 건드리지 않습니다.
    </p>
  </section>

  <!-- ProjectView 전송 스크립트 창 -->
  <PvDialog
    v-if="pvScript"
    :script="pvScript"
    title="ProjectView 실적시작일 전송 스크립트"
    :meta="`${pvRows.length - pvSkipped}건 · 계획시작일 → 실적시작일` + (pvSkipped ? ` · ProjectView 에 이미 있어 제외 ${pvSkipped}건` : '')"
    sends="바뀌는 값: actualStartDate (실적시작일) — 진척률·실적종료일은 그대로 둡니다."
    @close="pvScript = ''"
  />
</template>

<style scoped>
h2 .spacer { flex: 1; }
.topbar {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
  padding: 7px 12px;
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 8px;
}
.topbar .spacer { flex: 1; }
.topbar .hint { font-size: 12px; color: var(--muted); }
.panel.real { border-left: 3px solid var(--done); }
.nowrap { white-space: nowrap; }
h2 .sep { width: 1px; height: 16px; background: var(--line); margin: 0 2px; }
button.pv { border-color: var(--accent); color: var(--accent); }
button.pv:hover:not(:disabled) { background: var(--accent-soft); }
button.pv:disabled { border-color: var(--line); color: var(--muted); }
.ctr { text-align: center; }
.nm { font-weight: 600; }
.uid { color: var(--muted); font-size: 11px; margin-left: 5px; font-variant-numeric: tabular-nums; }
.scroll.tall { max-height: calc(100vh - 430px); overflow: auto; }
.scroll.tall thead th { position: sticky; top: 0; z-index: 2; background: var(--panel); box-shadow: inset 0 -1px 0 var(--line); }

tr.clk { cursor: pointer; }
tr.clk:hover { background: var(--surface); }
tr.clk.on { background: var(--accent-soft); }
td.bad { color: var(--danger); font-weight: 600; }
td.tot { font-weight: 600; }
td.miss { color: var(--danger); }
.chk { color: var(--done); font-weight: 700; }
.days {
  background: var(--danger-soft);
  color: var(--danger-text);
  border-radius: 9px;
  padding: 1px 6px;
  font-size: 11px;
  font-weight: 600;
}
.card.late .v { color: var(--danger); }
.card .v small { font-size: 11.5px; font-weight: 400; color: var(--muted); margin-left: 4px; }
.note { margin: 8px 0 0; }
/* Rows.vue 와 같은 모양 — 표 안에서는 밑줄 없이 글자색 그대로 두고 올려놓을 때만 티를 낸다 */
a.pvlink { color: inherit; text-decoration: none; }
a.pvlink:hover { color: var(--accent); text-decoration: underline; }
</style>
