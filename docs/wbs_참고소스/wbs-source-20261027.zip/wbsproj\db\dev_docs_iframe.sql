-- 개발자 정보(dev_docs) — 섹션을 <올려 둔 HTML 파일>로도 보여 줄 수 있게 한다.
--
-- 왜 content 에 넣지 않나: 올리는 것은 <문서 한 벌>이다. 스타일·스크립트가 통째로 들어 있고
-- 수백 KB 가 넘기도 한다. 그것을 섹션 본문에 풀어 넣으면
--   · 이 화면의 다른 글과 CSS 가 서로 먹는다 (올린 쪽이 화면 전체를 칠해 버린다)
--   · 편집기가 열 수 없는 크기가 되고, 한 번 열면 태그가 뭉개진다
-- 그래서 파일은 파일대로 두고(api/data/doc_files/{id}/), 섹션은 <그 파일을 가리키는> 표시만
-- 들고 있는다. 보여 줄 때는 iframe 이라 CSS 가 서로 넘어오지 않는다.
--
-- iframe_file 이 비어 있으면 평소처럼 content 를 보여 준다. 글과 파일은 함께 있을 수 있고,
-- 그때는 파일이 이긴다 — 글은 남겨 두되 보여 주지 않는다(되돌릴 수 있게).

alter table public.dev_docs add column if not exists iframe_file text;
alter table public.dev_docs add column if not exists iframe_name text;
alter table public.dev_docs add column if not exists iframe_at   timestamptz;
alter table public.dev_docs add column if not exists iframe_by   text;

comment on column public.dev_docs.iframe_file is
  '올려 둔 HTML 파일 이름 (api/data/doc_files/{id}/ 안). 비어 있으면 content 를 보여 준다';
comment on column public.dev_docs.iframe_name is
  '올릴 때의 원래 파일 이름 — 화면에 그대로 보여 준다';
comment on column public.dev_docs.iframe_at is '올린 시각';
comment on column public.dev_docs.iframe_by is '올린 사람';
