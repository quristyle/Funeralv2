using System.Text;

namespace WbsApi;

/// <summary>
/// 인터페이스 첨부파일.
///
/// 지시서 7항이 if_* 스키마 변경을 금지하므로 <b>테이블을 만들지 않고</b> 파일시스템에만 둔다.
///   api/data/if_files/{if_id}/{파일ID}__{원래 이름}
/// 파일 이름 자체가 메타데이터라 별도 저장소가 필요 없고, 목록은 디렉터리를 읽어 만든다.
/// (업로더·설명까지 남기려면 테이블이 필요하다 — 필요하면 DDL 을 제안하고 승인받아 바꾼다)
///
/// 내려받기는 정적 서비스가 아니라 API 로 처리한다. IP 접근 제어 안쪽에 두고,
/// 무엇이 올라오든 브라우저에서 실행되지 않도록 항상 첨부(attachment)로 내려 준다.
/// </summary>
public static class IfFiles
{
    private const long MaxBytes = 25L * 1024 * 1024;   // 파일 1개 최대 25MB
    private const int MaxCount = 20;                   // 한 번에 올릴 수 있는 개수
    private const string Sep = "__";                   // 파일ID 와 원래 이름 구분자

    private static string Root(IWebHostEnvironment env) =>
        Path.Combine(env.ContentRootPath, "data", "if_files");

    private static string DirOf(IWebHostEnvironment env, int ifId) =>
        Path.Combine(Root(env), ifId.ToString());

    /// <summary>경로 조작·제어문자를 막고 길이를 제한한다. 확장자는 그대로 둔다.</summary>
    private static string SafeName(string? name)
    {
        var n = Path.GetFileName(name ?? "").Trim();
        if (string.IsNullOrWhiteSpace(n)) n = "file";

        var bad = Path.GetInvalidFileNameChars().Concat(['\\', '/', ':', '*', '?', '"', '<', '>', '|']).ToHashSet();
        var sb = new StringBuilder(n.Length);
        foreach (var c in n) sb.Append(bad.Contains(c) || char.IsControl(c) ? '_' : c);

        n = sb.ToString().TrimStart('.');            // 숨김파일·상위경로 흉내 방지
        if (n.Contains(Sep)) n = n.Replace(Sep, "_"); // 구분자와 충돌하지 않게
        if (n.Length > 120) n = n[..60] + "~" + n[^40..];
        return n.Length == 0 ? "file" : n;
    }

    /// <summary>파일ID 는 우리가 만든 것만 받는다 (경로 조작 차단).</summary>
    private static bool ValidId(string id) =>
        id.Length is > 8 and < 40 && id.All(c => char.IsAsciiLetterOrDigit(c) || c == '-');

    private static FileInfo? Find(IWebHostEnvironment env, int ifId, string fileId)
    {
        if (!ValidId(fileId)) return null;
        var dir = new DirectoryInfo(DirOf(env, ifId));
        if (!dir.Exists) return null;
        return dir.GetFiles($"{fileId}{Sep}*").FirstOrDefault();
    }

    private static object Shape(FileInfo f)
    {
        var i = f.Name.IndexOf(Sep, StringComparison.Ordinal);
        return new
        {
            file_id = i > 0 ? f.Name[..i] : f.Name,
            name = i > 0 ? f.Name[(i + Sep.Length)..] : f.Name,
            size = f.Length,
            modified = f.LastWriteTime.ToString("yyyy-MM-dd HH:mm"),
        };
    }

    public static void Map(WebApplication app)
    {
        var env = app.Environment;

        // 인터페이스별 첨부 개수 (목록 화면의 배지용)
        app.MapGet("/api/if/files/counts", () =>
        {
            var root = new DirectoryInfo(Root(env));
            if (!root.Exists) return Results.Ok(Array.Empty<object>());

            var rows = root.GetDirectories()
                .Where(d => int.TryParse(d.Name, out _))
                .Select(d => new { if_id = int.Parse(d.Name), cnt = d.GetFiles().Length })
                .Where(x => x.cnt > 0)
                .ToList();
            return Results.Ok(rows);
        });

        // 목록
        app.MapGet("/api/if/{ifId:int}/files", (int ifId) =>
        {
            var dir = new DirectoryInfo(DirOf(env, ifId));
            if (!dir.Exists) return Results.Ok(Array.Empty<object>());
            return Results.Ok(dir.GetFiles()
                .OrderByDescending(f => f.LastWriteTime)
                .Select(Shape)
                .ToList());
        });

        // 업로드 (여러 개)
        app.MapPost("/api/if/{ifId:int}/files", async (PgPool db, HttpRequest req, int ifId) =>
        {
            if (!req.HasFormContentType)
                return Results.BadRequest(new { error = "파일을 multipart/form-data 로 보내세요." });

            // 없는 인터페이스에 파일이 쌓이지 않도록 확인 (if_* 는 읽기만 한다)
            var exists = await db.QueryAsync("select 1 as ok from public.if_master where if_id = $1::int limit 1", [ifId]);
            if (exists.Count == 0) return Results.BadRequest(new { error = $"존재하지 않는 인터페이스입니다: {ifId}" });

            var form = await req.ReadFormAsync();
            var files = form.Files;
            if (files.Count == 0) return Results.BadRequest(new { error = "첨부할 파일이 없습니다." });
            if (files.Count > MaxCount) return Results.BadRequest(new { error = $"한 번에 {MaxCount}개까지 올릴 수 있습니다." });

            var tooBig = files.FirstOrDefault(f => f.Length > MaxBytes);
            if (tooBig is not null)
                return Results.BadRequest(new { error = $"{tooBig.FileName} 이(가) 너무 큽니다. 파일당 25MB 까지." });

            var dir = DirOf(env, ifId);
            Directory.CreateDirectory(dir);

            var saved = new List<object>();
            foreach (var f in files)
            {
                if (f.Length == 0) continue;
                var id = $"{DateTime.Now:yyyyMMddHHmmss}-{Guid.NewGuid():N}"[..22];
                var path = Path.Combine(dir, $"{id}{Sep}{SafeName(f.FileName)}");
                await using (var fs = File.Create(path)) await f.CopyToAsync(fs);
                saved.Add(Shape(new FileInfo(path)));
            }

            return saved.Count == 0
                ? Results.BadRequest(new { error = "빈 파일만 있습니다." })
                : Results.Ok(saved);
        });

        // 내려받기 — 무엇이든 첨부로만 내려 준다 (브라우저에서 열리지 않게)
        app.MapGet("/api/if/{ifId:int}/files/{fileId}", (int ifId, string fileId) =>
        {
            var f = Find(env, ifId, fileId);
            if (f is null) return Results.NotFound(new { error = "파일 없음" });

            var i = f.Name.IndexOf(Sep, StringComparison.Ordinal);
            var name = i > 0 ? f.Name[(i + Sep.Length)..] : f.Name;
            return Results.File(f.FullName, "application/octet-stream", name);
        });

        // 삭제
        app.MapDelete("/api/if/{ifId:int}/files/{fileId}", (int ifId, string fileId) =>
        {
            var f = Find(env, ifId, fileId);
            if (f is null) return Results.NotFound(new { error = "파일 없음" });
            f.Delete();
            return Results.Ok(new { deleted = 1 });
        });
    }
}
