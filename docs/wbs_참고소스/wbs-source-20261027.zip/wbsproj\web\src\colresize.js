import { computed, onMounted, ref } from 'vue'
import { api } from './api'

/**
 * 표의 <컬럼 너비를 끌어 조절>하게 한다.
 *
 * 쓰는 쪽:
 *   const cw = useColResize('testfail.cols', [
 *     { k: 'seq', w: 38, min: 30 },
 *     { k: 'program', w: 190 },
 *     ...
 *   ])
 *
 *   <table :style="cw.tableStyle.value">
 *     <colgroup><col v-for="c in cw.cols" :key="c.k" :style="cw.colStyle(c.k)" /></colgroup>
 *     <thead><tr>
 *       <th>프로그램<span class="cgrip" @pointerdown="cw.start($event, 'program')"
 *                                      @dblclick="cw.reset('program')"></span></th>
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * <b>왜 colgroup + table-layout: fixed 인가.</b> 기본(auto)에서는 브라우저가 내용 길이를
 * 보고 폭을 다시 나눈다 — 한 칸을 넓히면 <b>옆 칸이 제멋대로 줄어든다.</b> fixed 로 두면
 * 적어 준 폭이 그대로 쓰이고, 합이 화면보다 넓으면 가로로 구른다.
 *
 * <b>왜 두 군데에 적는가.</b> 사이드바 너비(App.vue)와 같은 까닭이다 —
 *   · localStorage  열자마자 쓴다. 서버를 기다리면 기본 폭으로 한 번 그려졌다가 바뀐다.
 *   · 서버 pref     다른 PC·브라우저에서 들어와도 제 폭으로 열린다.
 * 서버에 못 적어도 조용히 낮아질 뿐이다(이번 화면에서는 그대로 쓴다).
 *
 * <b>왜 pointer 이벤트인가.</b> setPointerCapture 를 쓰면 커서가 iframe 이나 표 밖으로
 * 나가도 끌기가 끊기지 않는다. mousemove 로는 그 자리에서 놓친다.
 *
 * @param prefKey  서버 pref 키 (localStorage 키는 'wbs.' + prefKey)
 * @param defs     [{ k, w, min? }] — 차례가 곧 colgroup 의 차례다
 */
export function useColResize(prefKey, defs) {
  const LS = 'wbs.' + prefKey
  const MIN = 34

  const def = Object.fromEntries(defs.map((d) => [d.k, d.w]))
  const minOf = (k) => defs.find((d) => d.k === k)?.min ?? MIN

  const read = () => {
    try {
      const v = JSON.parse(localStorage.getItem(LS) || 'null')
      return v && typeof v === 'object' ? v : {}
    } catch {
      return {}
    }
  }

  // 적어 둔 것만 들고 있는다. 기본값을 통째로 복사해 두면 나중에 기본 폭을 고쳐도
  // 한 번이라도 연 사람에게는 옛 폭이 남는다.
  const saved = ref(read())
  const sizing = ref(false)

  const widthOf = (k) => saved.value[k] ?? def[k] ?? 100
  const colStyle = (k) => ({ width: widthOf(k) + 'px' })

  /** 표 전체 폭. 합이 화면보다 좁으면 100% 로 펴서 오른쪽에 빈 띠가 남지 않게 한다. */
  const total = computed(() => defs.reduce((a, d) => a + widthOf(d.k), 0))
  const tableStyle = computed(() => ({
    tableLayout: 'fixed',
    width: `max(100%, ${total.value}px)`,
  }))

  function persist() {
    try {
      localStorage.setItem(LS, JSON.stringify(saved.value))
    } catch {
      /* 못 적어도 이번 화면에서는 그대로 쓴다 */
    }
    // 서버 저장은 끌기가 <끝났을 때> 한 번만 — 움직이는 내내 보내면 수십 번 왕복한다
    api.prefSet(prefKey, saved.value).catch(() => {})
  }

  function start(e, k) {
    e.preventDefault()
    e.stopPropagation()
    sizing.value = true
    const x0 = e.clientX
    const w0 = widthOf(k)
    const lo = minOf(k)
    const el = e.currentTarget
    el.setPointerCapture?.(e.pointerId)

    const move = (ev) => {
      saved.value = { ...saved.value, [k]: Math.max(lo, Math.round(w0 + (ev.clientX - x0))) }
    }
    const up = () => {
      sizing.value = false
      el.removeEventListener('pointermove', move)
      el.removeEventListener('pointerup', up)
      el.removeEventListener('pointercancel', up)
      persist()
    }
    el.addEventListener('pointermove', move)
    el.addEventListener('pointerup', up)
    el.addEventListener('pointercancel', up)
  }

  /** 손잡이를 두 번 누르면 그 칸만 기본 폭으로 — 너무 좁혀 놓고 되돌릴 길을 찾는 일이 없도록 */
  function reset(k) {
    const next = { ...saved.value }
    delete next[k]
    saved.value = next
    persist()
  }

  /** 전부 기본 폭으로 */
  function resetAll() {
    saved.value = {}
    persist()
  }

  const touched = computed(() => Object.keys(saved.value).length > 0)

  onMounted(async () => {
    try {
      const r = await api.prefGet(prefKey)
      if (!r.stored || r.value == null) return
      const v = JSON.parse(r.value)
      if (!v || typeof v !== 'object') return
      // 이 화면에서 아직 손대지 않았을 때만 서버 값을 받는다 —
      // 읽는 데 시간이 걸려, 그 사이 끌어 놓은 폭을 덮어쓰면 손 밑에서 칸이 튄다.
      if (!sizing.value && !touched.value) {
        saved.value = v
        try { localStorage.setItem(LS, JSON.stringify(v)) } catch { /* 다음에 또 읽으면 된다 */ }
      }
    } catch {
      /* 서버에 없으면 localStorage 값을 그대로 쓴다 */
    }
  })

  return { cols: defs, colStyle, tableStyle, start, reset, resetAll, sizing, touched }
}
