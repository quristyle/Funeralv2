<script setup>
import { ref } from 'vue'

// 화면마다 두는 새로고침 버튼. 진행 중에는 비활성화하고 회전 표시를 준다.
const props = defineProps({
  fn: { type: Function, required: true },
  // label 을 ''로 주면 아이콘만 남는다 (자리를 아낄 때). 그때는 title 로 뜻을 알린다.
  label: { type: String, default: '새로고침' },
  title: { type: String, default: '' },
})

const busy = ref(false)

async function run() {
  if (busy.value) return
  busy.value = true
  try {
    await props.fn()
  } finally {
    busy.value = false
  }
}
</script>

<template>
  <button class="rf" :disabled="busy" :title="title || label || '새로고침'" @click="run">
    <span class="ic" :class="{ spin: busy }">⟳</span>{{ label ? ' ' + label : '' }}
  </button>
</template>

<style scoped>
.rf { white-space: nowrap; }
.ic { display: inline-block; }
.spin { animation: sp 0.7s linear infinite; }
@keyframes sp {
  to { transform: rotate(360deg); }
}
</style>
