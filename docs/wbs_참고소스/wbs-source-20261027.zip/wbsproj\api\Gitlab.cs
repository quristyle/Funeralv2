using System.Net.Http.Headers;
using System.Text.Json;

namespace WbsApi;

/// <summary>
/// GitLab 파이프라인/Job 상태 조회.
/// pmm001~pmm018 의 -be / -fe 프로젝트에서 "가장 최근 Job" 의 상태를 모아 온다.
/// 조회 전용(read_api) Personal Access Token 이 필요하다.
/// </summary>
public sealed class Gitlab(IConfiguration cfg)
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(15) };

    private readonly string _base = (cfg["Gitlab:BaseUrl"] ?? "https://code.hd.com").TrimEnd('/');
    private readonly string _group = (cfg["Gitlab:Group"] ?? "g6x0/xu62/material-management").Trim('/');
    private readonly string _token = cfg["Gitlab:Token"]
                                     ?? Environment.GetEnvironmentVariable("GITLAB_TOKEN") ?? "";
    private readonly int _from = cfg.GetValue("Gitlab:ModuleFrom", 1);
    private readonly int _to = cfg.GetValue("Gitlab:ModuleTo", 18);
    private readonly int _ttl = cfg.GetValue("Gitlab:CacheSeconds", 60);

    private List<Dictionary<string, object?>>? _cache;
    private DateTimeOffset _at = DateTimeOffset.MinValue;
    private readonly SemaphoreSlim _lock = new(1, 1);

    public bool Configured => !string.IsNullOrWhiteSpace(_token);
    public string BaseUrl => _base;
    public string Group => _group;
    public DateTimeOffset LoadedAt => _at;

    /// <summary>대상 프로젝트 목록 (토큰이 없어도 화면에서 링크는 쓸 수 있게 별도 제공)</summary>
    public List<(string Module, string Kind, string Path)> Targets()
    {
        var list = new List<(string, string, string)>();
        for (var i = _from; i <= _to; i++)
        {
            var m = $"pmm{i:D3}";
            foreach (var kind in new[] { "be", "fe" })
                list.Add((m.ToUpperInvariant(), kind, $"{_group}/{m}/{m}-{kind}"));
        }
        return list;
    }

    public string JobsUrl(string path) => $"{_base}/{path}/-/jobs";

    public async Task<List<Dictionary<string, object?>>> StatusAsync(bool force = false)
    {
        if (!force && _cache is not null && DateTimeOffset.UtcNow - _at < TimeSpan.FromSeconds(_ttl))
            return _cache;

        await _lock.WaitAsync();
        try
        {
            if (!force && _cache is not null && DateTimeOffset.UtcNow - _at < TimeSpan.FromSeconds(_ttl))
                return _cache;

            var targets = Targets();
            var results = new Dictionary<string, object?>[targets.Count];

            // 36개 프로젝트를 동시에 조회하되 서버 부담을 고려해 8개로 제한
            using var gate = new SemaphoreSlim(8, 8);
            await Task.WhenAll(targets.Select(async (t, idx) =>
            {
                await gate.WaitAsync();
                try { results[idx] = await OneAsync(t.Module, t.Kind, t.Path); }
                finally { gate.Release(); }
            }));

            _cache = [.. results];
            _at = DateTimeOffset.UtcNow;
            return _cache;
        }
        finally { _lock.Release(); }
    }

    private async Task<Dictionary<string, object?>> OneAsync(string module, string kind, string path)
    {
        var row = new Dictionary<string, object?>
        {
            ["module"] = module,
            ["kind"] = kind,
            ["path"] = path,
            ["jobs_url"] = JobsUrl(path),
            ["status"] = null,
            ["error"] = null,
            ["last_success"] = null,
        };
        if (!Configured) { row["error"] = "토큰 미설정"; return row; }

        try
        {
            var enc = Uri.EscapeDataString(path);
            // 최근 Job 1건 + 최근 성공 Job 1건을 함께 조회
            var latestTask = FetchJobAsync($"{_base}/api/v4/projects/{enc}/jobs?per_page=1");
            var successTask = FetchJobAsync($"{_base}/api/v4/projects/{enc}/jobs?scope%5B%5D=success&per_page=1");
            await Task.WhenAll(latestTask, successTask);

            var (latest, err) = latestTask.Result;
            if (err is not null) { row["error"] = err; return row; }
            if (latest is null) { row["status"] = "none"; return row; }

            foreach (var kv in latest) row[kv.Key] = kv.Value;      // 최근 Job 정보를 그대로 펼침
            row["last_success"] = successTask.Result.Job;           // 최근 성공 Job (없으면 null)
        }
        catch (Exception e)
        {
            row["error"] = e.Message.Length > 120 ? e.Message[..120] : e.Message;
        }
        return row;
    }

    /// <summary>Job 1건 조회 → (Job 정보, 오류 메시지)</summary>
    private async Task<(Dictionary<string, object?>? Job, string? Error)> FetchJobAsync(string url)
    {
        using var req = new HttpRequestMessage(HttpMethod.Get, url);
        req.Headers.Add("PRIVATE-TOKEN", _token);
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        using var res = await Http.SendAsync(req);
        var body = await res.Content.ReadAsStringAsync();
        if (!res.IsSuccessStatusCode)
            return (null, (int)res.StatusCode switch
            {
                401 => "인증 실패 (토큰 확인)",
                403 => "권한 없음 (read_api 필요)",
                404 => "프로젝트 없음",
                _ => $"HTTP {(int)res.StatusCode}"
            });

        using var doc = JsonDocument.Parse(body);
        if (doc.RootElement.ValueKind != JsonValueKind.Array || doc.RootElement.GetArrayLength() == 0)
            return (null, null);

        var j = doc.RootElement[0];
        string? S(string n) => j.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
        double? D(string n) => j.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDouble() : null;

        var o = new Dictionary<string, object?>
        {
            ["status"] = S("status"),
            ["job_id"] = j.TryGetProperty("id", out var id) && id.ValueKind == JsonValueKind.Number ? id.GetInt64() : null,
            ["job_name"] = S("name"),
            ["stage"] = S("stage"),
            ["ref"] = S("ref"),
            ["created_at"] = S("created_at"),
            ["started_at"] = S("started_at"),
            ["finished_at"] = S("finished_at"),
            ["duration"] = D("duration"),
            ["job_url"] = S("web_url"),
        };
        if (j.TryGetProperty("commit", out var c) && c.ValueKind == JsonValueKind.Object)
        {
            o["commit_id"] = c.TryGetProperty("short_id", out var sid) ? sid.GetString() : null;
            o["commit_title"] = c.TryGetProperty("title", out var ct) ? ct.GetString() : null;
            o["commit_author"] = c.TryGetProperty("author_name", out var ca) ? ca.GetString() : null;
        }
        if (j.TryGetProperty("pipeline", out var p) && p.ValueKind == JsonValueKind.Object)
        {
            o["pipeline_id"] = p.TryGetProperty("id", out var pid) && pid.ValueKind == JsonValueKind.Number ? pid.GetInt64() : null;
            o["pipeline_status"] = p.TryGetProperty("status", out var ps) ? ps.GetString() : null;
        }
        if (j.TryGetProperty("user", out var u) && u.ValueKind == JsonValueKind.Object)
            o["user_name"] = u.TryGetProperty("name", out var un) ? un.GetString() : null;

        return (o, null);
    }
}
