<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { api } from '../api'
import { state } from '../store'
import { buildPvTestScript, copyText } from '../pvScript'
import { useDragMove } from '../dragmove'

// ProjectView 단위테스트 절차의 상태를 여러 화면에 걸쳐 바꾼다.
//
// 대시보드가 ProjectView API 를 직접 부를 수 없어(HTTPS↔HTTP mixed content)
// 여기서는 <스크립트를 만들어 주기만> 하고, 실제 호출은 ProjectView 탭 콘솔에서 일어난다.
//
// 화면 ↔ 단위테스트는 <화면명> 으로 잇는다.
// 단위테스트에는 work 를 가리키는 칸이 없고 title 이 화면명 그대로다
//   ProjectView title "[1120]자재코드 관리"  =  대시보드 menu_nm "[1120]자재코드 관리"
// 그래서 { activity_id: 화면명 } 표를 스크립트에 박아 주고, 스크립트가 대괄호 안 코드로 맞춘다.
const props = defineProps({
  /** 지금 목록에 보이는 행들 — [{ activity_id }] */
  rows: { type: Array, default: () => [] },
})
const emit = defineEmits(['close'])

// 머리말을 잡아 창을 옮긴다 (PvCollectDialog 와 함께 빠져 있던 둘 중 하나)
const drag = useDragMove()

// ProjectView 단위테스트 절차가 쓰는 상태값 전부.
// 예전에는 실제 데이터에서 눈으로 확인한 셋(UNPERFORMED · IN_PROGRESS · SUCCESS)만 두고
// 나머지는 손으로 적게 했는데, 그러면 NA·FAIL·NE 를 넣을 때마다 철자를 맞혀야 했다.
//
// 차례는 받은 목록 그대로 둔다. 한글은 눈으로 고르라고 붙인 풀이일 뿐이고,
// 스크립트에 실려 나가는 값은 언제나 왼쪽의 코드다.
// ⚠️ NE 는 ProjectView 가 한글로 뭐라 부르는지 확인하지 못해 코드만 둔다 — 확인되면 채운다.
const KNOWN = [
  ['NA', '해당없음'],
  ['UNPERFORMED', '미수행'],
  ['SUCCESS', '성공'],
  ['FAIL', '실패'],
  ['IN_PROGRESS', '진행중'],
  ['NE', ''],
]
const status = ref('SUCCESS')
const target = ref('view') // view = 목록에 보이는 화면 / all = 전체
const scope = ref('all') // 절차 범위: all | pick
const picked = ref('')
const copied = ref('')
const err = ref('')

// activity_id → 화면명. 이것이 없으면 이어 줄 방법이 없다.
const ids = ref({})
const projectId = ref('')
const loading = ref(true)

onMounted(async () => {
  try {
    const rs = await api.pvCacheRows(state.scope)
    const m = {}
    for (const r of rs) {
      if (r.menu_nm) m[r.activity_id] = r.menu_nm
      if (!projectId.value && r.pv_project_id) projectId.value = r.pv_project_id
    }
    ids.value = m
  } catch (e) {
    err.value = 'ProjectView 캐시를 읽지 못했습니다: ' + e.message
  } finally {
    loading.value = false
  }
})

const viewIds = computed(() => new Set(props.rows.map((r) => r.activity_id).filter(Boolean)))

/** 스크립트에 박을 표 — 고른 범위 안에서 화면명이 있는 것만 */
const sendIds = computed(() => {
  const out = {}
  for (const [act, nm] of Object.entries(ids.value)) {
    if (target.value === 'view' && !viewIds.value.has(act)) continue
    out[act] = nm
  }
  return out
})
const sendCount = computed(() => Object.keys(sendIds.value).length)

/** 보이는 행 중 화면명을 모르는 것 — 이 화면들은 빠진다 */
const missing = computed(() =>
  target.value === 'view' ? [...viewIds.value].filter((a) => !ids.value[a]) : []
)

const onlyList = computed(() =>
  scope.value === 'pick'
    ? [...new Set(picked.value.split(/[^0-9]+/).map(Number).filter((n) => n > 0))].sort((a, b) => a - b)
    : []
)

const script = computed(() =>
  buildPvTestScript(status.value.trim(), {
    ids: sendIds.value,
    only: onlyList.value,
    projectId: projectId.value,
    scopeText: target.value === 'view' ? '목록에 보이는 화면' : '전체',
  }, new Date().toLocaleString('ko-KR'))
)

const area = ref(null)
async function doCopy() {
  area.value?.select()
  copied.value = (await copyText(script.value))
    ? '복사했습니다. ProjectView 탭의 F12 → Console 에 붙여넣으세요.'
    : '자동 복사가 막혔습니다. 내용이 전체 선택된 상태이니 Ctrl+C 로 복사하세요.'
}

// 바깥을 눌러 닫는 길을 막았으므로 Esc 는 살아 있어야 한다 — 닫는 길이 하나뿐이면
// 단추가 가려지거나 창이 화면 밖으로 밀렸을 때 빠져나올 수 없다.
function onKey(e) { if (e.key === 'Escape') emit('close') }
onMounted(() => window.addEventListener('keydown', onKey))
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <div class="mask">
    <div class="dlg" :class="{ moving: drag.moving.value }" :style="drag.style.value">
      <header class="grab" @pointerdown="drag.start($event)">
        <span class="hgrip" title="여기를 잡아 창을 옮깁니다">⠿</span>
        <strong>단위테스트 상태 변경</strong>
        <span class="hint">여러 화면의 테스트 절차 status 를 한 번에</span>
        <span class="spacer"></span>
        <button v-if="drag.moved()" title="창을 원래 자리로" @click="drag.reset()">⌖</button>
        <button class="x" title="닫기 (Esc)" @click="emit('close')">✕</button>
      </header>

      <!-- 머리말·꼬리말은 제자리에 두고 가운데만 구른다 -->
      <div class="body">

      <p v-if="err" class="err">{{ err }}</p>

      <p class="note warn">
        <strong>이것만 ProjectView 를 고칩니다.</strong>
        붙여넣으면 먼저 <strong>조회만</strong> 해서 무엇이 바뀔지 화면별로 보여 주고,
        콘솔에 <code>pvSend()</code> 를 쳐야 실제로 바뀝니다.
      </p>

      <div class="form">
        <label>바꿀 상태</label>
        <div class="fi">
          <input v-model="status" spellcheck="false" placeholder="SUCCESS" />
          <button
            v-for="[k, ko] in KNOWN" :key="k" class="sm" :class="{ on: status === k }"
            :title="ko ? `${k} — ${ko}` : k" @click="status = k"
          >{{ k }}<em v-if="ko">{{ ko }}</em></button>
          <span class="muted">
            ProjectView 가 쓰는 상태값 여섯입니다. 적어 넣을 수도 있고 —
            목록에 없는 값이면 스크립트가 <strong>지금 쓰이는 상태값</strong>을 찍어 주고
            보내기 전에 한 번 더 알려 줍니다.
          </span>
        </div>

        <label>대상 화면</label>
        <div class="fi">
          <label class="rd">
            <input v-model="target" type="radio" value="view" />
            목록에 보이는 화면 <b>{{ rows.length }}</b>건
          </label>
          <label class="rd">
            <input v-model="target" type="radio" value="all" />
            전체 <b>{{ Object.keys(ids).length }}</b>건
          </label>
          <span class="muted">
            <template v-if="loading">캐시 읽는 중…</template>
            <template v-else>스크립트에 담기는 화면 <strong>{{ sendCount }}</strong>건</template>
          </span>
        </div>

        <label>절차 범위</label>
        <div class="fi">
          <label class="rd"><input v-model="scope" type="radio" value="all" /> 절차 전부</label>
          <label class="rd"><input v-model="scope" type="radio" value="pick" /> 번호 지정</label>
          <input
            v-if="scope === 'pick'" v-model="picked" class="nums" spellcheck="false"
            placeholder="예: 1 2 5 (띄어쓰기나 쉼표)"
          />
          <span v-if="scope === 'pick'" class="muted">
            {{ onlyList.length ? `${onlyList.length}개 번호 — ${onlyList.join(', ')}` : '번호를 넣어 주세요' }}
            · 화면마다 그 번호의 절차만 바꿉니다
          </span>
        </div>
      </div>

      <p v-if="missing.length" class="note warn">
        보이는 화면 중 <strong>{{ missing.length }}건</strong>은 화면명을 몰라 빠집니다 —
        <code>⛁</code> 로 한 번 걷으면 채워집니다.
        <span class="muted">{{ missing.slice(0, 8).join(', ') }}{{ missing.length > 8 ? ' …' : '' }}</span>
      </p>
      <p v-else-if="!loading && !sendCount" class="note warn">
        담을 화면이 없습니다. <code>⛁</code> 로 ProjectView 데이터를 한 번 걷어 주세요.
      </p>

      <p class="note">
        이미 같은 상태인 절차는 <strong>건너뜁니다</strong>. 보내는 본문은
        <strong>목록이 준 절차 객체에서 <code>status</code> 만 바꾼 것</strong>이고,
        DRY RUN 이 첫 건의 본문 전체와 <strong>화면별 건수</strong>를 찍어 줍니다.
      </p>

      <div class="row">
        <label>스크립트</label>
        <span class="spacer"></span>
        <button
          class="go"
          :disabled="!status.trim() || !sendCount || (scope === 'pick' && !onlyList.length)"
          @click="doCopy"
        >복사</button>
      </div>
      <p v-if="copied" class="ok">{{ copied }}</p>
      <textarea ref="area" class="code" readonly :value="script" spellcheck="false"></textarea>
      </div>

      <footer>
        <span class="muted">
          화면과 단위테스트는 <strong>화면명</strong>으로 잇습니다 — 단위테스트의 제목이
          <code>[1120]자재코드 관리</code> 처럼 화면명 그대로라, 대괄호 안의 코드를 맞춥니다.
          이어지지 않은 화면은 DRY RUN 이 이름과 함께 알려 주고 <strong>건너뜁니다</strong>.
        </span>
      </footer>
    </div>
  </div>
</template>

<style scoped>
.mask {
  position: fixed; inset: 0; background: var(--overlay);
  display: flex; align-items: flex-start; justify-content: center;
  padding: 40px 20px; z-index: 100;
}
.dlg {
  background: var(--panel); border: 1px solid var(--line); border-radius: 10px;
  width: min(880px, 100%); max-height: calc(100vh - 80px);
  display: flex; flex-direction: column; box-shadow: 0 8px 28px var(--shadow);
  overflow: hidden;
}
.dlg.moving { user-select: none; }
/* min-height:0 이 없으면 flex 자식이 내용만큼 늘어나 max-height 를 그냥 넘긴다 */
.body { flex: 1; min-height: 0; overflow: auto; padding-bottom: 12px; }
.dlg header {
  display: flex; align-items: center; gap: 8px; padding: 11px 14px;
  border-bottom: 1px solid var(--line); flex: none;
}
.dlg header.grab { cursor: move; user-select: none; touch-action: none; }
.dlg header .hint { font-size: 11.5px; color: var(--muted); }
.hgrip { color: var(--muted-3); font-size: 12px; letter-spacing: -2px; }
.spacer { flex: 1; }

.err, .ok, .note { margin: 10px 14px 0; padding: 6px 10px; border-radius: 6px; font-size: 12px; line-height: 1.6; }
.err { background: var(--danger-soft); border: 1px solid var(--danger-line); color: var(--danger-text); }
.ok { background: var(--done-soft); border: 1px solid var(--done); color: var(--done); }
.note { background: var(--accent-soft); border: 1px solid var(--accent); color: var(--accent); }
.note.warn { background: var(--warn-soft); border-color: var(--warn-line); color: var(--warn); }
.note .muted { color: var(--muted); font-size: 11px; }

.form { display: grid; grid-template-columns: 76px 1fr; gap: 8px 10px; margin: 12px 14px 0; align-items: start; }
.form > label { font-size: 12px; font-weight: 600; padding-top: 5px; }
.fi { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.fi input:not([type='radio']) { width: 150px; font-family: Consolas, monospace; }
.fi .nums { width: 220px; }
.fi .muted { font-size: 11px; color: var(--muted); flex: 1 1 240px; }
.rd { font-size: 12px; display: flex; align-items: center; gap: 4px; }
.rd b { font-variant-numeric: tabular-nums; }
/* 코드가 본문이고 한글은 곁들이다 — 보내는 값은 코드이므로 그쪽이 커야 한다.
   여섯 개가 한 줄에 다 안 들어가면 .fi 의 flex-wrap 이 받아 준다. */
button.sm { padding: 2px 8px; font-size: 11px; display: inline-flex; align-items: baseline; gap: 5px; }
button.sm em { font-style: normal; font-size: 10px; color: var(--muted); }
/* 전역에 button.on { background: var(--accent) } 가 이미 있다.
   글자색까지 accent 로 주면 파란 바탕에 파란 글자가 되어 안 보인다. */
button.sm.on { border-color: var(--accent); color: var(--on-accent); }
/* 고른 단추 안의 한글도 파란 바탕 위에서 읽혀야 한다 — muted 그대로면 묻힌다. */
button.sm.on em { color: var(--on-accent); opacity: 0.78; }

.row { display: flex; align-items: center; gap: 8px; margin: 12px 14px 4px; flex: none; }
.row label { font-size: 12px; font-weight: 600; }
button.go { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
button.go:hover { color: var(--on-accent); }
button.go:disabled { opacity: 0.5; cursor: default; }

.code {
  margin: 0 14px; flex: 1 1 auto; min-height: 160px; white-space: pre;
  font-family: Consolas, 'Courier New', monospace; font-size: 11.5px; line-height: 1.5;
  border: 1px solid var(--line); border-radius: 6px; padding: 8px;
  background: var(--surface); resize: vertical; overflow: auto;
}
.dlg footer { padding: 10px 14px; flex: none; }
.dlg footer .muted { font-size: 11px; line-height: 1.5; color: var(--muted); }
header .x { border: 0; background: transparent; font-size: 14px; color: var(--muted); padding: 2px 6px; }
header .x:hover { color: var(--text); }
</style>
