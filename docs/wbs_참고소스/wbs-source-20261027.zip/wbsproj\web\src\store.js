import { computed, onActivated, onDeactivated, onMounted, onUnmounted, reactive, watch } from 'vue'
import { api } from './api'

// 화면이 여러 개로 나뉘어도 필터/조회 상태는 하나만 유지한다.
// (프롭 드릴링 대신 단일 reactive 스토어 — 의존성 없이 가장 단순한 방법)
export const state = reactive({
  basis: 'edt', // 모든 집계·필터의 기준 날짜. 기본은 계획종료일(plan_edt)

  scope: 'dev', // dev = new_dev2 'o' (개발 대상), all = 전체 행
  error: '',
  loading: false,

  summary: {},
  monthly: [],
  weekly: [],
  byUser: [],      // 담당자(user_bp_id / complate_yn) 기준
  byUserWeek: [],
  byReal: [],      // 개발자(user_real_id / complate_real_yn) 기준
  byRealWeek: [],
  byModule: [],
  users: [],
  delay: { sum: {}, byUser: [] }, // 지연 요약 (요약 화면에서도 쓰려고 스토어에 둔다)
  devUsers: [], // dev_user 전체 명단 (담당자/개발자 수정용)
  me: {},       // 접속자 정보 (IP, 등록된 사용자명)
  // 사이드바 짜임새 — 폴더와 메뉴 자리. 모두에게 같은 값이며 Super 만 고친다.
  // whoami 에 함께 실려 온다 (따로 부르면 메뉴가 한 번 그려졌다가 다시 그려진다).
  menuTree: { folders: [], place: {} },
  taskCount: {}, // activity_id → { cnt, done } 일감 건수
  fileCount: {}, // row_uid → 첨부(화면설계 문서) 건수

  rows: [],
  rowsLoading: false,
  // late:   지연 필터   — '' 전체 / start 착수지연 / finish 종료지연 / both 둘 다 / any 하나라도 / none 지연없음
  // status: 진행 상태  — '' 전체 / open 착수도래&미완료 / notyet 미도래 / done 완료
  sel: { month: '', week: '', user: '', realUser: '', module: '', done: '', late: '', status: '' },
  // q: 서버 쪽 통합 검색(메뉴명·Activity ID). 상세 목록의 입력칸은 걷어냈고
  //    이제 컬럼별 필터로 찾는다. API 는 그대로 받으니 필요하면 다시 붙일 수 있다.
  q: '',
  sort: { col: '', dir: 'asc' },
  colFilter: {}, // 상세 목록 컬럼별 검색어 (조회 결과 안에서 클라이언트 필터)
  cols: [],      // 상세 목록에서 보이는 컬럼 (아래에서 localStorage 값으로 채운다)
})

export async function loadStats() {
  state.loading = true
  state.error = ''
  try {
    const [s, m, w, u, uw, r, rw, mod] = await Promise.all([
      api.summary(state.basis, state.scope),
      api.monthly(state.basis, state.scope),
      api.weekly(state.basis, state.scope),
      api.monthlyByUser(state.basis, state.scope, 'plan'),
      api.weeklyByUser(state.basis, state.scope, 'plan'),
      api.monthlyByUser(state.basis, state.scope, 'real'),
      api.weeklyByUser(state.basis, state.scope, 'real'),
      api.byModule(state.basis, state.scope),
    ])
    state.summary = s
    state.monthly = m
    state.weekly = w
    state.byUser = u
    state.byUserWeek = uw
    state.byReal = r
    state.byRealWeek = rw
    state.byModule = mod
    await loadDelay()
  } catch (e) {
    state.error = e.message
  } finally {
    state.loading = false
  }
}

// 지연 요약 (착수/종료 지연) — 요약 화면과 지연 화면이 함께 쓴다
export async function loadDelay() {
  try {
    const [s, u] = await Promise.all([
      api.delaySummary(state.scope),
      api.delayByUser(state.scope, 'plan'),
    ])
    state.delay = { sum: s, byUser: u }
  } catch (e) {
    state.error = e.message
  }
}

// 담당자 드롭다운은 선택된 월/주 범위에 맞춰 다시 읽는다 (건수도 해당 기간 기준)
export async function loadUsers() {
  try {
    state.users = await api.users(state.scope, state.basis, state.sel.month, state.sel.week)
  } catch (e) {
    state.error = e.message
  }
}

export async function loadRows() {
  state.rowsLoading = true
  try {
    state.rows = await api.rows({ basis: state.basis, scope: state.scope, ...state.sel, q: state.q, limit: 1000 })
  } catch (e) {
    state.error = e.message
  } finally {
    state.rowsLoading = false
  }
}

// 개발자 명단은 바뀌지 않으므로 최초 1회만 읽는다
export async function loadDevUsers() {
  try {
    state.devUsers = await api.devUsers()
  } catch (e) {
    state.error = e.message
  }
}

// 접속자(IP) 확인 — dev_user.use_ip 에 등록된 사용자면 성명이 함께 내려온다
export async function loadMe() {
  try {
    const me = await api.whoami()
    state.me = me
    if (me.tree) state.menuTree = me.tree
  } catch (e) {
    state.error = e.message
  }
}

/** 사이드바를 고친 뒤 제자리를 다시 읽는다 (whoami 전체를 다시 부를 까닭이 없다). */
export async function loadMenuTree() {
  try {
    state.menuTree = await api.menuTree()
  } catch (e) {
    state.error = e.message
  }
}

// 화면별 일감 건수 (상세목록 '일감' 컬럼)
export async function loadTaskCounts() {
  try {
    const rows = await api.taskCounts()
    state.taskCount = Object.fromEntries(rows.map((r) => [r.activity_id, { cnt: r.cnt, done: r.done }]))
  } catch (e) {
    state.error = e.message
  }
}

// 행 첨부(화면설계 문서) 건수 — 일감 건수와 같은 방식이다.
// 폴더를 한 번 훑어 전부 받아 온다 (행마다 물으면 한 화면에 211번 왕복한다).
export async function loadFileCounts() {
  try {
    const rows = await api.rowFileCounts()
    state.fileCount = Object.fromEntries(rows.map((r) => [r.row_uid, r.cnt]))
  } catch (e) {
    state.error = e.message
  }
}

export function reloadAll() {
  return Promise.all([loadStats(), loadUsers(), loadRows(), loadDevUsers(), loadMe(), loadTaskCounts(),
                      loadFileCounts(), loadColsFromServer()])
}

// 화면마다 자체 데이터(문서·개발자 마스터 등)가 있어, 현재 화면의 새로고침 함수를 등록해 둔다.
const view = { refresh: null }

export function useViewRefresh(fn) {
  const on = () => { view.refresh = fn }
  const off = () => { if (view.refresh === fn) view.refresh = null }
  onMounted(on)
  onUnmounted(off)
  // 탭 전환은 <KeepAlive> 안에서 일어나므로 unmount 가 되지 않는다.
  // activated/deactivated 를 함께 잡아야 새로고침이 <지금 보이는 화면>을 향한다.
  // (KeepAlive 밖에서는 아무 일도 하지 않는 훅이라 그냥 둬도 안전하다.)
  onActivated(on)
  onDeactivated(off)
}

/**
 * 본문을 맨 위로 올린다.
 *
 * ⚠️ window.scrollTo 가 아니다. 페이지(body)는 굴리지 않고 <본문 칸>만 굴러가도록
 * 바꿨기 때문에, window 를 밀면 아무 일도 일어나지 않는다 — 오류도 안 난다.
 */
export function scrollContentTop(smooth = false) {
  document
    .querySelector('.content')
    ?.scrollTo({ top: 0, behavior: smooth ? 'smooth' : 'auto' })
}

/** 공통 데이터 + 현재 화면 데이터를 함께 다시 읽는다. */
export async function refreshAll() {
  await reloadAll()
  if (view.refresh) await view.refresh()
}

// ---------- 필터 ----------

export const hasFilter = computed(
  () => Object.values(state.sel).some(Boolean) || !!state.q || Object.values(state.colFilter).some(Boolean)
)

export function pickMonth(b) {
  state.sel = { ...state.sel, month: state.sel.month === b ? '' : b, week: '', user: '', realUser: '', module: '' }
}
export function pickWeek(b) {
  state.sel = { ...state.sel, month: '', week: state.sel.week === b ? '' : b, user: '', realUser: '', module: '' }
}
export function pickModule(b) {
  state.sel = { ...state.sel, month: '', week: '', user: '', realUser: '', module: state.sel.module === b ? '' : b }
}
export function pickCell({ user, month }) {
  state.sel = { ...state.sel, month, week: '', user, realUser: '', module: '' }
}
export function pickWeekCell({ user, week }) {
  state.sel = { ...state.sel, month: '', week, user, realUser: '', module: '' }
}
// 개발자(user_real_id) 기준 매트릭스용
export function pickRealCell({ user, month }) {
  state.sel = { ...state.sel, month, week: '', user: '', realUser: user, module: '' }
}
export function pickRealWeekCell({ user, week }) {
  state.sel = { ...state.sel, month: '', week, user: '', realUser: user, module: '' }
}
// 월/주 드롭다운: 담당자·모듈 선택은 유지하고 서로만 해제한다 (둘 다 날짜 기준이라 충돌)
export function onMonthPick(v) {
  state.sel = { ...state.sel, month: v, week: '' }
}
export function onWeekPick(v) {
  state.sel = { ...state.sel, week: v, month: '' }
}
export function clearFilter() {
  state.sel = { month: '', week: '', user: '', realUser: '', module: '', done: '', late: '', status: '' }
  state.q = ''
  state.colFilter = {}
}
export function clearColFilter() {
  state.colFilter = {}
}

/**
 * 최고 관리자인가 — 판정은 서버(/api/whoami)가 한다.
 * 화면에서 도구성 기능을 감추는 용도다. 감추는 것은 <가리는 것>이고
 * 접근을 막는 것이 아니라는 점을 잊지 말 것.
 */
export const isAdmin = computed(() => state.me.admin === true)

/**
 * Super 권한인가 — isAdmin 과 다르다.
 *
 * isAdmin 에는 <서버 장비에서 연 것>(loopback)이 섞여 있다. 그 PC 앞에 앉은 사람은
 * 누구든 isAdmin 이 된다. 원장(hhip_wbs_wrk2)에 줄을 세우거나 키를 채우는 일처럼
 * Super 에게만 열어야 하는 것은 이쪽을 본다 (서버도 같은 기준으로 막는다).
 */
export const isSuper = computed(() => state.me.super === true)

export const userName = (id) =>
  state.users.find((r) => r.user_bp_id === id)?.user_nm ??
  state.byUser.find((r) => r.user_bp_id === id)?.user_nm ??
  ''

// ---------- 정렬 ----------

// ftype: 컬럼 필터 입력 형태 (text = 부분일치 검색, check = 완료/미완료 선택)
export const COLS = [
  { key: 'activity_id', label: 'Activity ID', ftype: 'text', w: 96, g: '기본' },
  { key: 'systemcode', label: '모듈', ftype: 'text', w: 110, g: '기본' },
  { key: 'menu_nm', label: '메뉴명', ftype: 'text', w: 200, g: '기본' },
  { key: 'plan_sdt', label: '시작일', ftype: 'text', w: 84, g: '일정' },
  { key: 'plan_edt', label: '종료일', ftype: 'text', w: 84, g: '일정' },
  { key: 'plan_sdt_c', label: '실적시작', ftype: 'text', w: 84, g: '일정' },
  { key: 'plan_edt_c', label: '실적종료', ftype: 'text', w: 84, g: '일정' },
  { key: 'user_bp_id', label: '담당자', ftype: 'pick', w: 120, g: '담당' },
  { key: 'complate_yn', label: '완료', ftype: 'check', w: 56, g: '담당' },
  { key: 'user_real_id', label: '개발자', ftype: 'pick', w: 120, g: '담당' },
  { key: 'complate_real_yn', label: '개발자완료', ftype: 'check', w: 68, g: '담당' },
  { key: 'recheck_yn', label: '재확인요청', ftype: 'check', w: 74, g: '담당' },
  // 대형 3종 — 기존 완료/개발자완료/재확인요청과 나란히 관리한다
  { key: 'complate_big_yn', label: '대형완료', ftype: 'check', w: 68, g: '대형' },
  { key: 'complate_real_big_yn', label: '대형개발자완료', ftype: 'check', w: 92, g: '대형' },
  { key: 'recheck_big_yn', label: '대형재확인요청', ftype: 'check', w: 92, g: '대형' },
  { key: 'db_ready_big_yn', label: '대형DB준비여부', ftype: 'check', w: 92, g: '대형' },
  { key: 'priority_order', label: '우선순위', ftype: 'text', w: 64, g: '속성' },
  { key: 'prog_type', label: '화면유형', ftype: 'text', w: 120, g: '속성' },
  { key: 'trg_use_chk', label: '트리거 발화', ftype: 'text', w: 160, g: '속성' },
  { key: 'dwg_view_use', label: '도면조회', ftype: 'check', w: 64, g: '속성' },
  { key: 'report_use', label: '리포트', ftype: 'check', w: 56, g: '속성' },
  { key: 'task_cnt', label: '일감', ftype: 'task', w: 66, g: '속성' },
  // 화면설계 문서 첨부 — 일감과 같은 자리에 둔다 (둘 다 <그 줄에 딸린 것> 의 개수다)
  { key: 'file_cnt', label: '첨부', ftype: 'file', w: 62, g: '속성' },
  // 계획진척률 — 착수도래 필터가 무엇을 보고 거르는지 눈으로 확인할 수 있게 둔다
  { key: 'plan_rate', label: '계획진척률', ftype: 'num', w: 84, g: '일정' },
  // ProjectView 캐시 — 상세 목록의 ⛁ 로 수집해야 값이 찬다.
  // 수집 전에는 전부 비어 있고, 목록 자체는 그대로 동작한다.
  // 현재단계 — 워크플로가 지금 어느 칸에 있는지 (task-history 의 마지막 '현재상태')
  { key: 'pv_status', label: 'PV 현재단계', ftype: 'text', w: 130, pv: true, g: 'ProjectView' },
  { key: 'pv_finish_rate', label: 'PV 진척률', ftype: 'num', w: 78, pv: true, g: 'ProjectView' },
  { key: 'pv_actual_sdt', label: 'PV 실적시작', ftype: 'text', w: 88, pv: true, g: 'ProjectView' },
  { key: 'pv_task_cnt', label: 'PV 일감', ftype: 'num', w: 66, pv: true, g: 'ProjectView' },
  { key: 'pv_task_edt', label: 'PV 일감완료일', ftype: 'text', w: 96, pv: true, g: 'ProjectView' },
  { key: 'pv_workers', label: 'PV 일감담당자', ftype: 'text', w: 130, pv: true, g: 'ProjectView' },
  { key: 'pv_node_empty', label: 'PV 빈단계', ftype: 'num', w: 74, pv: true, g: 'ProjectView' },
  { key: 'pv_snapshot_at', label: 'PV 수집', ftype: 'text', w: 112, pv: true, g: 'ProjectView' },
]

// ---------------------------------------------------------------- 보이는 컬럼
// 사람마다 보고 싶은 컬럼이 다르다.
//
// 어디에 남기나 — 두 곳에 남긴다.
//   1) 서버(dev_user_pref)  : 접속 IP 로 사람이 가려질 때. 다른 PC 에서 열어도 따라온다.
//   2) localStorage         : 항상. 서버가 사람을 못 가릴 때의 보루이자, 첫 화면을 즉시 그리는 용도.
// 화면은 localStorage 값으로 곧바로 그린 뒤, 서버 값이 도착하면 그것으로 갈아 끼운다.
// (서버를 기다리느라 컬럼이 깜빡이지 않게 하려는 것이다.)
const COL_KEY = 'wbs.rows.cols'
const PREF_KEY = 'rows.cols'
const ALL_KEYS = COLS.map((c) => c.key)

/** 기본으로 켜 두는 컬럼 (전부 끄고 되돌릴 때 쓰는 최소 구성) */
export const BASE_COLS = ['activity_id', 'systemcode', 'menu_nm', 'plan_edt', 'user_bp_id', 'complate_yn']

/** 컬럼 설정이 지금 어디에 보관되는지 — 화면에서 안내에 쓴다 */
export const colStore = reactive({ server: false, who: '', at: '' })

// 고른 목록과 함께 <그때 존재하던 컬럼 목록>도 남긴다.
// 그래야 나중에 컬럼이 추가됐을 때 "끈 것"과 "그때는 없던 것"을 구별할 수 있다.
// 이것이 없으면 새 컬럼이 기존 사용자에게 영영 보이지 않는다.
/**
 * 저장된 값({cols, known})을 지금의 컬럼 목록에 맞춘다.
 * known 은 <저장할 때 존재하던 컬럼 목록>이다. 그래야 나중에 컬럼이 추가됐을 때
 * "사용자가 끈 것"과 "그때는 없던 것"을 구별할 수 있다 —
 * 이것이 없으면 새 컬럼이 기존 사용자에게 영영 보이지 않는다.
 */
function normalizeCols(saved) {
  // 예전 형식(배열)도 그대로 받아 준다
  const picked = Array.isArray(saved) ? saved : saved?.cols
  const known = Array.isArray(saved) ? picked : saved?.known
  if (!Array.isArray(picked)) return null

  const keep = picked.filter((k) => ALL_KEYS.includes(k))
  const fresh = Array.isArray(known) ? ALL_KEYS.filter((k) => !known.includes(k)) : []
  const out = [...keep, ...fresh.filter((k) => !keep.includes(k))]
  return out.length ? out : [...ALL_KEYS]
}

function loadColsLocal() {
  try {
    const raw = localStorage.getItem(COL_KEY)
    if (!raw) return [...ALL_KEYS]
    return normalizeCols(JSON.parse(raw)) ?? [...ALL_KEYS]
  } catch {
    return [...ALL_KEYS]
  }
}

function saveColsLocal() {
  try {
    localStorage.setItem(COL_KEY, JSON.stringify({ cols: state.cols, known: ALL_KEYS }))
  } catch {
    /* 사생활 보호 모드 등에서 막히면 이번 세션에만 적용된다 */
  }
}

/** 서버에도 남긴다. 사람이 가려지지 않으면 서버가 stored:false 를 주고 조용히 넘어간다. */
async function saveColsServer() {
  try {
    const r = await api.prefSet(PREF_KEY, { cols: state.cols, known: ALL_KEYS })
    colStore.server = !!r.stored
    if (r.who) colStore.who = r.who
    if (r.stored) colStore.at = new Date().toLocaleTimeString('ko-KR')
  } catch {
    colStore.server = false
  }
}

function saveCols() {
  saveColsLocal()
  saveColsServer()
}

state.cols = loadColsLocal()
saveColsLocal()   // 새 컬럼을 켠 결과와 현재 컬럼 목록을 바로 굳혀 둔다

/**
 * 서버에 보관된 내 컬럼 설정을 읽어 온다 (앱이 뜰 때 1회).
 * 서버에 값이 있으면 그것이 이긴다 — 다른 PC 에서 바꾼 것이 따라오게 하려는 것이다.
 */
export async function loadColsFromServer() {
  try {
    const r = await api.prefGet(PREF_KEY)
    colStore.server = !!r.stored
    colStore.who = r.who || ''
    if (!r.stored || !r.value) {
      // 서버가 사람을 가렸는데 아직 저장된 것이 없으면, 지금 값을 올려 둔다
      if (r.stored) await saveColsServer()
      return
    }
    const cols = normalizeCols(JSON.parse(r.value))
    if (cols) {
      state.cols = cols
      saveColsLocal()
    }
  } catch {
    colStore.server = false
  }
}

/**
 * 화면에 그릴 컬럼 — <고른 순서>를 그대로 따른다.
 * state.cols 배열의 순서가 곧 표의 컬럼 순서다 (팝업에서 끌어 바꾼 순서).
 * 머리글·필터줄·본문 셀·엑셀 내려받기가 모두 이 하나를 돈다.
 */
export const visibleCols = computed(() =>
  state.cols.map((k) => COLS.find((c) => c.key === k)).filter(Boolean)
)

export const isColOn = (key) => state.cols.includes(key)

export function toggleCol(key) {
  const on = state.cols.includes(key)
  if (on && state.cols.length <= 1) return // 최소 한 개는 남긴다
  // 새로 켜는 컬럼은 맨 뒤에 붙인다 (순서는 팝업에서 끌어 바꾼다)
  state.cols = on ? state.cols.filter((k) => k !== key) : [...state.cols, key]
  saveCols()
}

/** 여러 개를 한 번에 켜고 끈다 (팝업의 묶음 단위 선택용) */
export function setCols(keys) {
  const keep = [...new Set(keys.filter((k) => ALL_KEYS.includes(k)))]
  if (!keep.length) return // 최소 한 개는 남긴다
  state.cols = keep
  saveCols()
}

/** all = 전체 켜기, 아니면 기본 몇 개만 남긴다 */
export function resetCols(all) {
  state.cols = all ? [...ALL_KEYS] : [...BASE_COLS]
  saveCols()
}

export const taskOf = (r) => state.taskCount[r.activity_id] ?? { cnt: 0, done: 0 }

/** 그 줄에 붙은 화면설계 문서 수. 키가 row_uid 라 Activity ID 가 없는 줄에도 붙는다. */
export const fileOf = (r) => state.fileCount[r.row_uid] ?? 0

/**
 * ProjectView 워크플로의 현재단계 표기.
 * ProjectView 화면이 '(90%) PI검토' 처럼 진척률과 함께 보여 주므로 같은 모양으로 맞춘다.
 */
export const pvStageText = (r) => {
  if (!r.pv_status) return ''
  const rate = r.pv_finish_rate == null ? '' : `(${Number(r.pv_finish_rate)}%) `
  return rate + r.pv_status
}

// ---------------------------------------------------------------- 화면 주소
// 상세 목록의 메뉴명을 누르면 <그 화면> 을 운영/개발 어느 쪽으로든 열 수 있게 한다.
//
// 세 조각으로 만든다 — 전부 목록에 이미 있는 값이라 따로 받아 올 것이 없다.
//   화면코드  메뉴명 앞머리의 대괄호          '[1110]자재 분류코드 관리' → 1110
//   모듈      systemcode                    PMM001
//   모듈번호  systemcode 뒤 숫자             PMM001 → 1
//
//   운영  https://dev-isos-hhip.hd.com/launcher/pmm001/MM1110
//   개발  http://localhost:3201/#/mm1110     (FE 포트 = 3200 + 모듈번호, api/DevRun.cs)
export const OPS_BASE = 'https://dev-isos-hhip.hd.com/launcher'
const FE_PORT_BASE = 3200
// 화면 ID 앞머리. 이 대시보드가 보는 것은 자재관리(MM) 하나다 — 전 행 module = 'MM'.
const SCREEN_PREFIX = 'MM'

/** 메뉴명 앞머리의 화면코드 ('[12C0] 운송비 관리' → '12C0'). 없으면 null. */
export const screenCodeOf = (r) =>
  (String(r?.menu_nm ?? '').match(/^\s*\[\s*([0-9A-Za-z_-]+)\s*\]/) || [])[1] ?? null

/**
 * 그 줄의 화면 주소 둘. 코드나 모듈을 못 읽으면 null 을 돌려준다
 * (메뉴명이 '[코드]' 로 시작하지 않는 줄이 생길 수 있다).
 */
export function screenUrls(r) {
  const code = screenCodeOf(r)
  const sys = String(r?.systemcode ?? '').trim()
  if (!code || !sys) return null

  const no = Number((sys.match(/(\d+)\s*$/) || [])[1])
  return {
    code,
    module: sys,
    // 운영은 모듈 폴더가 소문자다 (.../launcher/pmm001/MM1110)
    ops: `${OPS_BASE}/${sys.toLowerCase()}/${SCREEN_PREFIX}${code}`,
    // 개발은 <보는 사람 PC 의> 개발서버다. 그 PC 에서 그 모듈이 떠 있어야 열린다.
    dev: Number.isFinite(no) && no > 0
      ? `http://localhost:${FE_PORT_BASE + no}/#/${(SCREEN_PREFIX + code).toLowerCase()}`
      : null,
  }
}

// ProjectView 주소. 옮겨 가면 이 한 줄만 고치면 된다.
// (스크립트 쪽은 ProjectView 탭에서 돌기 때문에 상대경로를 쓰고, 여기만 절대주소가 필요하다.)
export const PV_BASE = 'https://dev-wbs.hd.com/projectview'

/** 코드 앞자리가 projectKey 다 (AAC-A189 → AAC). 하드코딩하지 않으려는 것이다. */
const pvKeyOf = (code) => String(code).split('-')[0]

/**
 * 일감 상세 화면 주소.
 *   .../#/PGE_PST_TaskDetailPage?projectKey=AAC&taskId=AAC-T1240
 * taskId 자리에 들어가는 것은 TASK_ uuid 가 아니라 <일감 코드>다.
 */
export const pvTaskUrl = (r) => {
  const code = r?.pv_task_code
  if (!code) return null
  return `${PV_BASE}/#/PGE_PST_TaskDetailPage?projectKey=${encodeURIComponent(pvKeyOf(code))}` +
         `&taskId=${encodeURIComponent(code)}`
}

/**
 * 액티비티(작업) 상세 화면 주소.
 *   .../#/PGE_PSW_WorkDetailPage?projectKey=AAC&activityId=AAC-A189
 * activityId 는 우리 원장의 activity_id 그대로다 — 캐시를 수집하지 않아도 링크가 된다.
 */
export const pvWorkUrl = (r) => {
  const code = r?.activity_id
  if (!code) return null
  return `${PV_BASE}/#/PGE_PSW_WorkDetailPage?projectKey=${encodeURIComponent(pvKeyOf(code))}` +
         `&activityId=${encodeURIComponent(code)}`
}

/**
 * 단위테스트 상세 화면 주소.
 *   .../#/PGE_PSU_TestDetailPage?projectKey=AAC&testCaseId=AAC-TC793
 *
 * testCaseId 는 캐시가 아니라 <원장>에 들어 있다 (hhip_wbs_wrk2.pv_test_case_id).
 * ProjectView 단위테스트 목록의 title 이 우리 menu_nm 과 글자 그대로 같아서 그것으로 이어
 * 넣어 둔 값이다 — 받아 오는 경로는 아직 없고 db/pv_test_case_id.sql 로 채운다.
 * 그래서 테스트가 없는 화면은 null 이고, 메뉴에서 그 줄이 눌리지 않는다.
 */
export const pvTestUrl = (r) => {
  const code = r?.pv_test_case_id
  if (!code) return null
  return `${PV_BASE}/#/PGE_PSU_TestDetailPage?projectKey=${encodeURIComponent(pvKeyOf(code))}` +
         `&testCaseId=${encodeURIComponent(code)}`
}

/** 컬럼 필터·정렬이 보는 값 = 화면에 보이는 텍스트 기준 */
const cellText = (r, col) => {
  switch (col) {
    // 일감: 있음/없음/미완료 세 가지로 필터
    case 'task_cnt': {
      const t = taskOf(r)
      return t.cnt === 0 ? 'none' : t.done < t.cnt ? 'open' : 'done'
    }
    case 'user_bp_id': return r.user_nm ? `${r.user_nm} ${r.user_bp_id ?? ''}` : ''
    case 'user_real_id': return r.user_real_nm ? `${r.user_real_nm} ${r.user_real_id ?? ''}` : ''
    case 'systemcode': return `${r.systemcode ?? ''} ${r.system_nm ?? ''}`
    case 'complate_yn': return r.complate_yn === 'o' ? 'y' : 'n'
    case 'complate_real_yn': return r.complate_real_yn === 'o' ? 'y' : 'n'
    case 'recheck_yn': return r.recheck_yn === 'o' ? 'y' : 'n'
    case 'complate_big_yn': return r.complate_big_yn === 'o' ? 'y' : 'n'
    case 'complate_real_big_yn': return r.complate_real_big_yn === 'o' ? 'y' : 'n'
    case 'recheck_big_yn': return r.recheck_big_yn === 'o' ? 'y' : 'n'
    case 'db_ready_big_yn': return r.db_ready_big_yn === 'o' ? 'y' : 'n'
    case 'dwg_view_use': return r.dwg_view_use === 'o' ? 'y' : 'n'
    case 'report_use': return r.report_use === 'o' ? 'y' : 'n'
    // 첨부: 있음/없음 두 가지로 필터
    case 'file_cnt': return fileOf(r) ? 'y' : 'n'
    // ProjectView 수집 시각은 'YYYY-MM-DD HH:MM' 까지만 보고 거른다
    case 'pv_status': return pvStageText(r)
    case 'pv_snapshot_at': return String(r.pv_snapshot_at ?? '').slice(0, 16)
    default: return String(r[col] ?? '')
  }
}

// 드롭다운으로 고르는 컬럼 (담당자·개발자) — ID 완전일치, 미할당은 '__none__'
const PICK_COLS = { user_bp_id: 'user_nm', user_real_id: 'user_real_nm' }
export const NONE = '__none__'

export const filteredRows = computed(() => {
  const active = Object.entries(state.colFilter).filter(([, v]) => v !== '' && v != null)
  if (!active.length) return state.rows
  return state.rows.filter((r) =>
    active.every(([col, v]) => {
      if (col in PICK_COLS) {
        const assigned = !!r[PICK_COLS[col]] // dev_user 에 매칭되는 성명이 있으면 배정된 것
        return v === NONE ? !assigned : assigned && r[col] === v
      }
      const text = cellText(r, col)
      // 완료·일감·도면조회·리포트·첨부 컬럼은 완전일치, 나머지는 대소문자 무시 부분일치
      return col.startsWith('complate_') || col === 'recheck_yn' || col === 'task_cnt'
        || col === 'dwg_view_use' || col === 'report_use' || col === 'file_cnt'
        ? text === v
        : text.toLowerCase().includes(String(v).toLowerCase())
    })
  )
})

/** 담당자·개발자 컬럼 필터의 선택 목록 (현재 조회 결과에 있는 값 + 건수) */
function pickOptions(idKey, nmKey) {
  const map = new Map()
  let none = 0
  for (const r of state.rows) {
    if (!r[nmKey]) { none++; continue }
    const cur = map.get(r[idKey]) ?? { value: r[idKey], label: r[nmKey], cnt: 0 }
    cur.cnt++
    map.set(r[idKey], cur)
  }
  const list = [...map.values()].sort((a, b) => a.label.localeCompare(b.label, 'ko'))
  if (none) list.push({ value: NONE, label: '미할당', cnt: none })
  return list
}

export const colOptions = computed(() => ({
  user_bp_id: pickOptions('user_bp_id', 'user_nm'),
  user_real_id: pickOptions('user_real_id', 'user_real_nm'),
}))

export function toggleSort(col) {
  if (state.sort.col !== col) state.sort = { col, dir: 'asc' }
  else if (state.sort.dir === 'asc') state.sort = { col, dir: 'desc' }
  else state.sort = { col: '', dir: 'asc' } // 3번째 클릭이면 기본 순서로
}

const sortKey = (r, col) =>
  // 미할당(성명 없음)은 빈 키로 두어 정렬 시 항상 뒤로 밀리게 한다
  col === 'user_bp_id' ? (r.user_nm ? `${r.user_nm}${r.user_bp_id ?? ''}` : '')
  : col === 'user_real_id' ? (r.user_real_nm ? `${r.user_real_nm}${r.user_real_id ?? ''}` : '')
  : col === 'systemcode' ? `${r.systemcode ?? ''}${r.menu_nm ?? ''}`
  : col === 'complate_yn' ? (r.complate_yn === 'o' ? '1' : '0')
  : col === 'complate_real_yn' ? (r.complate_real_yn === 'o' ? '1' : '0')
  : col === 'recheck_yn' ? (r.recheck_yn === 'o' ? '1' : '0')
  : col === 'dwg_view_use' ? (r.dwg_view_use === 'o' ? '1' : '0')
  : col === 'report_use' ? (r.report_use === 'o' ? '1' : '0')
  // 일감·첨부는 건수 내림차순이 자연스러우므로 0 은 빈 키로 두어 뒤로 보낸다
  : col === 'task_cnt' ? (taskOf(r).cnt ? String(taskOf(r).cnt).padStart(4, '0') : '')
  : col === 'file_cnt' ? (fileOf(r) ? String(fileOf(r)).padStart(4, '0') : '')
  : (r[col] ?? '')

export const sortedRows = computed(() => {
  if (!state.sort.col) return filteredRows.value
  const { col, dir } = state.sort
  const sign = dir === 'asc' ? 1 : -1
  return [...filteredRows.value].sort((a, b) => {
    const x = sortKey(a, col)
    const y = sortKey(b, col)
    if (x === y) return 0
    if (x === '') return 1 // 빈 값은 항상 뒤로
    if (y === '') return -1
    return sign * String(x).localeCompare(String(y), 'ko', { numeric: true })
  })
})

// ---------- 파생 ----------

export const donePct = computed(() =>
  state.summary.total ? Math.round((state.summary.done / state.summary.total) * 1000) / 10 : 0
)

export const monthItems = computed(() =>
  state.monthly.map((r) => ({
    key: r.bucket,
    label: r.bucket,
    value: r.cnt,
    done: r.done,
    sub: `${r.cnt}건 · 완료 ${r.done} · 담당자 ${r.users}명`,
  }))
)
export const weekItems = computed(() =>
  state.weekly.map((r) => ({
    key: r.bucket,
    label: `${r.bucket} (${r.week_start.slice(5).replace('-', '/')})`,
    value: r.cnt,
    done: r.done,
    sub: `${r.week_start} ~ ${r.week_end} · 완료 ${r.done}`,
  }))
)
export const moduleItems = computed(() =>
  state.byModule.map((r) => ({
    key: r.systemcode,
    label: `${r.systemcode}`,
    value: r.cnt,
    done: r.done,
    sub: `${r.system_nm} · 완료 ${r.done}`,
  }))
)

// ---------- 감시 ----------

watch(() => [state.sel, state.q, state.basis, state.scope], loadRows, { deep: true })
watch(() => [state.basis, state.scope], loadStats)
watch(() => [state.basis, state.scope, state.sel.month, state.sel.week], loadUsers)
