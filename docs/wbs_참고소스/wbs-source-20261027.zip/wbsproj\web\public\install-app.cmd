@echo off
rem =====================================================================
rem  WBS Dashboard - install as a desktop app (no admin rights needed)
rem
rem  Creates Desktop + Start Menu shortcuts that open the dashboard in a
rem  Chrome/Edge app window (no address bar, own taskbar icon).
rem
rem  Why not a real PWA install?
rem    Chrome only offers "Install" on a secure origin (https or localhost).
rem    We are served over plain http on a LAN IP, so that button never shows.
rem    The chrome://flags workaround caused browser freezes - do not use it.
rem    This app-mode shortcut gives the same day-to-day result.
rem
rem  Usage
rem    install-app.cmd        install (or refresh) the shortcuts
rem    install-app.cmd /u     remove them
rem =====================================================================
setlocal EnableExtensions

rem  pass a URL to override, e.g.  install-app.cmd https://10.13.45.51:5443/
set "APP_URL=http://10.13.45.51:5080/"
if not "%~1"=="" if /i not "%~1"=="/u" if /i not "%~1"=="-u" set "APP_URL=%~1"
set "APP_DIR=%LOCALAPPDATA%\WbsDashboard"
set "ICON=%APP_DIR%\wbs.ico"
set "PROFILE=%APP_DIR%\profile"
set "LNK_NAME=WBS Dashboard.lnk"
set "DESKTOP=%USERPROFILE%\Desktop"
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"

if /i "%~1"=="/u" goto :uninstall
if /i "%~1"=="-u" goto :uninstall

echo.
echo   WBS Dashboard - installing app shortcuts
echo   URL : %APP_URL%
echo.

rem ---- 1) find a browser -------------------------------------------------
set "BROWSER="
call :find "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
call :find "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
call :find "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
call :find "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
call :find "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if not defined BROWSER (
  echo   ERROR: Chrome or Edge was not found.
  echo          Install Chrome, or edit BROWSER in this script.
  goto :end
)
echo   browser : %BROWSER%

rem ---- 2) fetch the icon from the server ---------------------------------
if not exist "%APP_DIR%" mkdir "%APP_DIR%" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { Invoke-WebRequest -Uri '%APP_URL%wbs.ico' -OutFile '%ICON%' -UseBasicParsing -TimeoutSec 15; exit 0 } catch { exit 1 }"
if errorlevel 1 (
  echo   WARNING: could not download the icon - the shortcut will use the browser icon.
  echo            ^(is the server running at %APP_URL% ?^)
  set "ICON="
) else (
  echo   icon    : %ICON%
)

rem ---- 3) create the shortcuts -------------------------------------------
rem  --app            : window without address bar / tabs
rem  --user-data-dir  : its own profile, so the account chooser never appears
rem                     and normal browsing is not affected
set "ARGS=--app=%APP_URL% --user-data-dir=%PROFILE% --no-first-run --no-default-browser-check --window-size=1500,950"

call :shortcut "%DESKTOP%\%LNK_NAME%"
call :shortcut "%STARTMENU%\%LNK_NAME%"

echo.
echo   done. Look for "WBS Dashboard" on the desktop and in the Start menu.
echo   To remove:  install-app.cmd /u
echo.
goto :end

rem ---------------------------------------------------------------- helpers
:find
if defined BROWSER goto :eof
if exist "%~1" set "BROWSER=%~1"
goto :eof

:shortcut
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s = (New-Object -ComObject WScript.Shell).CreateShortcut('%~1');" ^
  "$s.TargetPath = '%BROWSER%';" ^
  "$s.Arguments = '%ARGS%';" ^
  "$s.WorkingDirectory = (Split-Path '%BROWSER%');" ^
  "$s.Description = 'WBS Dashboard (Subic MM)';" ^
  "if ('%ICON%' -ne '') { $s.IconLocation = '%ICON%,0' };" ^
  "$s.Save()"
if errorlevel 1 (echo   FAILED: %~1) else (echo   created : %~1)
goto :eof

:uninstall
echo.
echo   removing WBS Dashboard shortcuts ...
if exist "%DESKTOP%\%LNK_NAME%" del /f /q "%DESKTOP%\%LNK_NAME%" && echo   removed : %DESKTOP%\%LNK_NAME%
if exist "%STARTMENU%\%LNK_NAME%" del /f /q "%STARTMENU%\%LNK_NAME%" && echo   removed : %STARTMENU%\%LNK_NAME%
echo.
echo   The app profile is kept at %APP_DIR%
echo   Delete that folder by hand if you want it gone as well.
echo.

:end
endlocal
