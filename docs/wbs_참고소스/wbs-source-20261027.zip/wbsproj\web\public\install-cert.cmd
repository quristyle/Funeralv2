@echo off
rem =====================================================================
rem  WBS Dashboard - trust the server certificate (run as Administrator)
rem
rem  Chrome only shows the "Install" (+) icon on a secure origin (https).
rem  The server has a self-signed certificate for its LAN IP; this script
rem  puts that certificate into "Trusted Root Certification Authorities"
rem  so https://10.13.45.51:5443 opens without a warning.
rem
rem  What you are trusting: one certificate that is valid ONLY for that IP.
rem  It cannot vouch for any other site.
rem
rem  Usage
rem    right click -> Run as administrator
rem    install-cert.cmd /u     remove the trust again
rem =====================================================================
setlocal EnableExtensions

set "SERVER_HTTP=http://10.13.45.51:5080"
set "CER_URL=%SERVER_HTTP%/wbs.cer"
set "CER=%TEMP%\wbs.cer"
set "SUBJECT=WBS Dashboard"

rem ---- must be admin ----------------------------------------------------
net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo   ERROR: administrator rights are required.
  echo          Right click this file and choose "Run as administrator".
  echo.
  pause
  goto :end
)

if /i "%~1"=="/u" goto :uninstall
if /i "%~1"=="-u" goto :uninstall

echo.
echo   WBS Dashboard - installing the server certificate
echo.

rem ---- download ---------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { Invoke-WebRequest -Uri '%CER_URL%' -OutFile '%CER%' -UseBasicParsing -TimeoutSec 15; exit 0 } catch { exit 1 }"
if errorlevel 1 (
  echo   ERROR: could not download %CER_URL%
  echo          Is the server running? Was tools\make-cert.ps1 run on it?
  echo.
  pause
  goto :end
)

rem ---- import into Trusted Root ----------------------------------------
certutil -addstore -f Root "%CER%" >nul
if errorlevel 1 (
  echo   ERROR: certutil failed to add the certificate.
  pause
  goto :end
)

echo   installed. Certificate details:
powershell -NoProfile -Command ^
  "$c = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2('%CER%');" ^
  "Write-Host ('    subject : ' + $c.Subject);" ^
  "Write-Host ('    valid   : ' + $c.NotBefore.ToString('yyyy-MM-dd') + ' ~ ' + $c.NotAfter.ToString('yyyy-MM-dd'));" ^
  "Write-Host ('    thumb   : ' + $c.Thumbprint)"

del /f /q "%CER%" >nul 2>&1

echo.
echo   Next: close Chrome completely, then open
echo         https://10.13.45.51:5443/
echo   The address bar should show a padlock and an install icon.
echo.
pause
goto :end

:uninstall
echo.
echo   removing the WBS Dashboard certificate from Trusted Root ...
powershell -NoProfile -Command ^
  "Get-ChildItem Cert:\LocalMachine\Root ^| Where-Object { $_.Subject -like '*%SUBJECT%*' } ^| ForEach-Object { Write-Host ('    removing ' + $_.Thumbprint); Remove-Item $_.PSPath -Force }"
echo   done.
echo.
pause

:end
endlocal
