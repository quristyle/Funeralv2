-- 개발자 관리 화면의 <차단여부>.
-- 'o' 면 사용 IP 가 등록돼 있어도 접근을 막는다.
--
-- 루프백(127.0.0.1 · ::1 · localhost)은 이 값을 보지 않는다 —
-- 서버 장비에서 여는 사람은 최고 권한이라, 스스로를 잠그지 못하게 하려는 것이다.
-- (IpGate.CheckAsync 에서 차단 판정보다 루프백 판정이 앞에 온다)

alter table public.dev_user
  add column if not exists block_yn varchar(1);

comment on column public.dev_user.block_yn is
  '차단여부 — o 면 등록 IP 라도 접근 차단 (루프백 제외). 빈 값/x = 허용';
