-- ---------------------------------------------------------------------------
-- ProjectView workflow CURRENT STATUS per task.
--
-- pv_status already exists (db/pv_cache2.sql). This adds when it changed,
-- so the list can show how long a task has been sitting in that stage.
--
-- Where it comes from: task-history (DTS_PST_00040). The current stage is the
-- LAST "현재상태 / Current Status" entry ordered by changeDtm.
-- Note the API does NOT return the history in chronological order - sorting is
-- required, taking the last array element gives a wrong answer.
-- ---------------------------------------------------------------------------

alter table public.hhip_wbs_pv_task add column if not exists pv_status_at date;

comment on column public.hhip_wbs_pv_task.pv_status_at is 'When the task entered pv_status (from task-history).';
