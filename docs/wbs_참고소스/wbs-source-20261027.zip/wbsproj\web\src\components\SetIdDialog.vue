<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { api } from '../api'
import { state } from '../store'
import { useDragMove } from '../dragmove'

// 나중에 확정된 Activity ID 를 채우는 창.
//
// 전에는 브라우저 prompt() 였다. 세 가지가 아쉬웠다 —
//   1) 어느 줄인지 글자로만 알려 줄 수 있었다. 모듈·우선순위 같은 다른 단서를 못 보여 준다.
//   2) 겹치는 ID 인지 <보낸 뒤에야> 알았다. 서버가 409 로 막아 주지만, 그때는 창이 이미 닫혀
//      무엇을 적었는지도 사라진 뒤다.
//   3) 생김새를 손댈 수 없어 다른 창들과 따로 논다.
//
// 그래서 다른 창들과 같은 규칙을 따르는 창으로 바꿨다 —
// 끌어 옮기기 · 머리말의 ✕ · Esc · <바깥을 눌러도 닫히지 않음>.
const props = defineProps({ row: { type: Object, required: true } })
const emit = defineEmits(['close', 'saved'])

const drag = useDragMove()
const box = ref(null)
const val = ref('')
const busy = ref(false)
const err = ref('')

/** 적어 넣은 값. 대소문자는 서버가 upper 로 비교하므로 여기서도 그렇게 본다. */
const clean = computed(() => val.value.trim())

// 서버도 409 로 막지만, 다 적고 나서 거절당하기 전에 미리 알려 준다.
// 목록(state.rows)에 이미 실려 있는 것만 보므로 <조회 범위 밖>의 겹침은 서버가 잡는다.
const dup = computed(() => {
  const v = clean.value.toUpperCase()
  if (!v) return null
  return state.rows.find((r) => String(r.activity_id ?? '').toUpperCase() === v) ?? null
})

// 생김새만 본다. 막지는 않는다 — ProjectView 의 코드 규칙이 바뀔 수 있고,
// 여기서 막아 두면 그때 이 창부터 고쳐야 한다. 다르면 <다르다고 알려만> 준다.
const SHAPE = /^[A-Za-z]{2,5}-[A-Za-z]\d+$/
const odd = computed(() => !!clean.value && !SHAPE.test(clean.value))

const canSave = computed(() => !!clean.value && !dup.value && !busy.value)

async function save() {
  if (!canSave.value) return
  busy.value = true
  err.value = ''
  try {
    emit('saved', await api.rowSetActivityId(props.row.row_uid, clean.value))
  } catch (e) {
    err.value = e.message
  } finally {
    busy.value = false
  }
}

function onKey(e) {
  if (e.key === 'Escape') emit('close')
  // 한 칸짜리 창이라 Enter 로 받는다 (여러 칸짜리 창과 달리 실수로 눌릴 일이 없다).
  // isComposing 을 보는 까닭: 한글 조합 중의 Enter 는 <글자를 확정하는> Enter 다.
  else if (e.key === 'Enter' && !e.isComposing) save()
}
onMounted(() => {
  window.addEventListener('keydown', onKey)
  box.value?.focus()
})
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <div class="mask">
    <div class="dlg" :class="{ moving: drag.moving.value }" :style="drag.style.value">
      <header class="grab" @pointerdown="drag.start($event)">
        <span class="hgrip" title="여기를 잡아 창을 옮깁니다">⠿</span>
        <strong>Activity ID 지정</strong>
        <span class="spacer"></span>
        <button v-if="drag.moved()" title="창을 원래 자리로" @click="drag.reset()">⌖</button>
        <button class="x" title="닫기 (Esc)" @click="emit('close')">✕</button>
      </header>

      <div class="body">
        <!-- 어느 줄인지 — prompt() 로는 못 보여 주던 것 -->
        <p class="who">
          <b>{{ row.systemcode }}</b>
          <span v-if="row.system_nm" class="sys">{{ row.system_nm }}</span>
          <span class="menu">{{ row.menu_nm }}</span>
        </p>

        <label class="fld">
          <span class="lb">Activity ID</span>
          <input
            ref="box"
            v-model="val"
            type="text"
            placeholder="AAC-A376"
            spellcheck="false"
            autocomplete="off"
            :disabled="busy"
          />
        </label>

        <p v-if="dup" class="msg bad">
          이미 있는 Activity ID 입니다 — <b>{{ dup.activity_id }}</b> {{ dup.menu_nm }}
        </p>
        <p v-else-if="err" class="msg bad">{{ err }}</p>
        <p v-else-if="odd" class="msg warn">
          <b>{{ clean }}</b> 는 평소 쓰던 모양(<code>AAC-A376</code>)과 다릅니다 — 막지는 않습니다.
        </p>
        <p v-else class="msg">
          채우면 이 줄에도 <b>ProjectView 캐시 · 일감</b>이 붙습니다.
          한 번 채우면 이 창에서는 <b>다시 바꿀 수 없습니다</b> —
          캐시와 일감이 이 값을 가리키게 되기 때문입니다.
        </p>
      </div>

      <footer>
        <span class="spacer"></span>
        <button :disabled="busy" @click="emit('close')">취소</button>
        <button class="go" :disabled="!canSave" title="Enter" @click="save">
          {{ busy ? '저장 중…' : '저장' }}
        </button>
      </footer>
    </div>
  </div>
</template>

<style scoped>
.mask {
  position: fixed;
  inset: 0;
  background: var(--overlay);
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 80px 16px 16px;
  z-index: 60;
}
.dlg {
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 10px;
  width: min(480px, 100%);
  display: flex;
  flex-direction: column;
  box-shadow: 0 8px 28px var(--shadow);
}
.dlg.moving { user-select: none; }
.dlg header,
.dlg footer { display: flex; align-items: center; gap: 8px; padding: 10px 14px; flex: none; }
.dlg header { border-bottom: 1px solid var(--line); }
.dlg header.grab { cursor: move; user-select: none; touch-action: none; }
.dlg footer { border-top: 1px solid var(--line); }
.hgrip { color: var(--muted-3); font-size: 12px; letter-spacing: -2px; }
.spacer { flex: 1; }
header .x { border: 0; background: transparent; font-size: 14px; color: var(--muted); padding: 2px 6px; }
header .x:hover { color: var(--text); }

.body { padding: 14px; }
.who { margin: 0 0 12px; font-size: 12.5px; display: flex; align-items: baseline; gap: 7px; flex-wrap: wrap; }
.who .sys { color: var(--muted); }
.who .menu { font-weight: 600; }
.fld { display: flex; flex-direction: column; gap: 4px; }
.fld .lb { font-size: 11.5px; color: var(--muted); }
.fld input {
  font-size: 15px;
  padding: 7px 10px;
  font-variant-numeric: tabular-nums;
  letter-spacing: 0.3px;
}
.msg { margin: 10px 0 0; font-size: 11.5px; color: var(--muted); line-height: 1.6; }
.msg.bad { color: var(--danger-text); }
.msg.warn { color: var(--warn); }
.msg code { font-size: 11px; }
</style>
