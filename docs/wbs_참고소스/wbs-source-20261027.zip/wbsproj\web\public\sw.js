// WBS 대시보드 서비스 워커 — 앱 껍데기만 캐시한다.
//
// 이 워커는 <https 로 접속했을 때만> 동작한다. 이유는 두 가지다.
//  1) 크롬은 보안 출처에서만 서비스 워커를 허용한다.
//  2) 예전에 chrome://flags 로 http 출처를 보안 출처인 척 만든 PC 에서 브라우저가
//     멈추는 문제가 있었다. 그 상태로는 절대 동작하지 않도록 아래에서 막는다.
//
// http 출처에 남아 있는 워커는 스스로 캐시를 지우고 등록을 해제한다 (자동 복구).
//
// 캐시 규칙
//   /api, /uploads   : 절대 캐시하지 않는다 (현황 데이터는 항상 최신이어야 하고,
//                      API 는 접속 IP 로 권한을 가리므로 응답을 남겨 두면 안 된다)
//   화면 이동(navigate): 네트워크 우선 → 실패하면 캐시된 index.html
//   그 밖의 GET       : 캐시를 먼저 주고 뒤에서 갱신

const VERSION = 'wbs-v3'
const SHELL = VERSION + '-shell'

// https 가 아니면(=플래그로 흉내낸 http 포함) 아무 일도 하지 않고 스스로 물러난다
const OK = self.location.protocol === 'https:'

const PRECACHE = ['/', '/index.html', '/manifest.webmanifest', '/icon-192.png', '/icon-512.png']

self.addEventListener('install', (e) => {
  if (!OK) return void self.skipWaiting()
  e.waitUntil(
    caches
      .open(SHELL)
      .then((c) => c.addAll(PRECACHE))
      .catch(() => {})   // 하나라도 실패해도 설치는 진행한다
      .then(() => self.skipWaiting())
  )
})

self.addEventListener('activate', (e) => {
  if (!OK) {
    // http 출처 — 캐시를 모두 지우고 등록을 해제한 뒤 열려 있는 탭을 새로 고친다
    e.waitUntil(
      caches
        .keys()
        .then((ks) => Promise.all(ks.map((k) => caches.delete(k))))
        .then(() => self.registration.unregister())
        .then(() => self.clients.matchAll({ type: 'window' }))
        .then((cs) => cs.forEach((c) => c.navigate(c.url)))
        .catch(() => {})
    )
    return
  }
  e.waitUntil(
    caches
      .keys()
      .then((ks) => Promise.all(ks.filter((k) => k !== SHELL).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  )
})

const noStore = (url) => url.pathname.startsWith('/api') || url.pathname.startsWith('/uploads')

self.addEventListener('fetch', (e) => {
  if (!OK) return                                   // http 출처에서는 절대 개입하지 않는다

  const req = e.request
  if (req.method !== 'GET') return

  const url = new URL(req.url)
  if (url.origin !== self.location.origin) return   // 외부 요청은 그대로 둔다
  if (noStore(url)) return                          // 데이터는 항상 네트워크로

  // 화면 이동 — 네트워크 우선, 끊기면 캐시된 껍데기 (설치 조건인 오프라인 동작을 만족시킨다)
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone()
          caches.open(SHELL).then((c) => c.put('/index.html', copy)).catch(() => {})
          return res
        })
        .catch(() => caches.match('/index.html').then((r) => r || caches.match('/')))
    )
    return
  }

  // 그 밖의 정적 파일 — 캐시 우선 + 뒤에서 갱신
  e.respondWith(
    caches.match(req).then((hit) => {
      const net = fetch(req)
        .then((res) => {
          if (res && res.ok && res.type === 'basic') {
            const copy = res.clone()
            caches.open(SHELL).then((c) => c.put(req, copy)).catch(() => {})
          }
          return res
        })
        .catch(() => hit)
      return hit || net
    })
  )
})
