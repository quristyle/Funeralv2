﻿# DRM 으로 잠긴 엑셀을 Excel COM 으로 열어 모든 시트를 텍스트(탭 구분)로 덤프한다.
# 읽기 전용으로만 열고 원본은 건드리지 않는다.
#
# 사용법: powershell -ExecutionPolicy Bypass -File tools\xlsx2txt.ps1 -Path "<xlsx>" -Out "<txt>"

param(
  [Parameter(Mandatory = $true)][string]$Path,
  [Parameter(Mandatory = $true)][string]$Out,
  [int]$MaxRows = 400,
  [int]$MaxCols = 40
)

$ErrorActionPreference = 'Stop'
if (-not (Test-Path $Path)) { Write-Error "파일 없음: $Path"; exit 1 }

$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

try {
  $wb = $excel.Workbooks.Open((Resolve-Path $Path).Path, 0, $true)
  $sb = New-Object System.Text.StringBuilder

  foreach ($ws in $wb.Worksheets) {
    [void]$sb.AppendLine("========== SHEET: $($ws.Name) ==========")
    $used = $ws.UsedRange
    $rows = [Math]::Min($used.Rows.Count, $MaxRows)
    $cols = [Math]::Min($used.Columns.Count, $MaxCols)
    if ($rows -le 0 -or $cols -le 0) { [void]$sb.AppendLine('(빈 시트)'); continue }

    [void]$sb.AppendLine("(범위 $($used.Address($false,$false)) · $($used.Rows.Count)행 x $($used.Columns.Count)열)")
    $vals = $used.Value2

    for ($r = 1; $r -le $rows; $r++) {
      $line = New-Object System.Collections.Generic.List[string]
      $any = $false
      for ($c = 1; $c -le $cols; $c++) {
        $v = if ($used.Rows.Count -eq 1 -and $used.Columns.Count -eq 1) { $vals } else { $vals[$r, $c] }
        if ($null -eq $v) { $line.Add(''); continue }
        $any = $true
        if ($v -is [double]) {
          $fmt = [string]$ws.Cells.Item($r + $used.Row - 1, $c + $used.Column - 1).NumberFormat
          if ($fmt -match 'y+' -and $fmt -match '[md]') { $line.Add([DateTime]::FromOADate($v).ToString('yyyy-MM-dd')); continue }
          $line.Add([string]$v); continue
        }
        $line.Add((([string]$v) -replace "[`r`n]+", ' / '))
      }
      # 빈 줄은 건너뛰어 읽기 좋게
      if ($any) { [void]$sb.AppendLine(("{0,3}| " -f $r) + [string]::Join(" | ", $line).TrimEnd(' |')) }
    }
    [void]$sb.AppendLine('')
  }

  $wb.Close($false)
  [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($wb)

  [System.IO.File]::WriteAllText($Out, $sb.ToString(), (New-Object System.Text.UTF8Encoding $true))
  Write-Host "저장: $Out"
}
finally {
  $excel.Quit()
  [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
  [GC]::Collect()
}
