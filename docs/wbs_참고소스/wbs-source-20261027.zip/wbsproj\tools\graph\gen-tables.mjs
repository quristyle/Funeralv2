// 기존 [테이블 계통도](web/public/p30/flow.html) 의 데이터를 Vue Flow 모양으로 내보낸다.
//
//   node tools/graph/gen-tables.mjs            # M10 도면을 새로 굽는다
//   node tools/graph/gen-tables.mjs --schema m20
//   node tools/graph/gen-tables.mjs --print    # 굽지 않고 숫자만 센다
//
// 도면은 스키마마다 한 장이다(tables-m10.json · tables-m20.json). 한 장에 둘을 섞지 않는
// 까닭: 같은 이름의 표가 두 스키마에 다 있어, 섞으면 <어느 쪽 표인지> 가릴 길이 없다.
//
// ⚠️ flow.html 이 정본이다. 저 화면은 손대지 않기로 했으므로, 거기 데이터가 바뀌면
//    이것을 다시 돌려 <기본 배치>를 갱신한다. 사람이 새 화면에서 옮겨 놓은 자리는
//    api/data/vueflow/tables.json 에 따로 저장되고, [기본 배치로] 를 눌러야 덮인다.

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const here = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(here, '..', '..')
const SRC = path.join(ROOT, 'web', 'public', 'p30', 'flow.html')
const i = process.argv.indexOf('--schema')
const SCHEMA = (i > 0 ? process.argv[i + 1] : 'm10').toLowerCase()
if (!['m10', 'm20'].includes(SCHEMA)) throw new Error('스키마는 m10 · m20 중 하나입니다: ' + SCHEMA)
const DST = path.join(ROOT, 'api', 'data', 'vueflow', `tables-${SCHEMA}.json`)

// ── flow.html 에서 배열 셋을 꺼낸다 ─────────────────────────────────────────
// 줄 단위로 집는다. 통째로 정규식을 걸면 주석 안의 ']' 하나에 끊긴다.
const lines = fs.readFileSync(SRC, 'utf8').split('\n')
function grab(name) {
  const i = lines.findIndex((l) => l.trim().startsWith(`var ${name} = [`))
  if (i < 0) throw new Error(`${name} 을(를) 찾지 못했습니다 — flow.html 이 바뀌었습니다`)
  let j = i
  while (j < lines.length && lines[j].trim() !== '];') j++
  return eval('(' + [lines[i].slice(lines[i].indexOf('[')), ...lines.slice(i + 1, j), ']'].join('\n') + ')')
}
const NODES = grab('NODES')
const EDGES = grab('EDGES')
const FLOWS = grab('FLOWS')
const laneLine = lines.find((l) => l.trim().startsWith('var LANES'))
const LANES = eval('(' + laneLine.slice(laneLine.indexOf('[')).replace(/;\s*$/, '') + ')')

// ── 자리 ────────────────────────────────────────────────────────────────────
// col/row 는 <몇 번째 칸> 이라는 뜻뿐이라 픽셀로 편다. 본류(row 0~7)와
// 하단 밴드(row 8~9) 사이는 띄워 둔다 — 원래 화면도 그렇게 갈라 보여 준다.
// 칸이 컴팩트해진 만큼(84 → 44px) 줄 간격도 조인다 — 상자만 줄이면 빈 공간만 커진다.
// 모든 값이 격자(GRID=20)의 배수다 — 칸을 끌면 자석처럼 격자에 붙으므로,
// 처음 자리도 격자 위에 있어야 첫 드래그에서 칸이 튀지 않는다.
const GRID = 20
const NW = 200, NH = 40, COLW = 240, ROWH = 80, PADX = 40, PADY = 100, BANDGAP = 60
const px = (c) => PADX + c * COLW
const py = (r) => PADY + r * ROWH + (r >= 8 ? BANDGAP : 0)

const nodes = NODES.map((n) => ({
  id: n.id,
  type: 'table',
  position: { x: px(n.col), y: py(n.row) },
  data: {
    id: n.id, kr: n.kr, kind: n.k, col: n.col, row: n.row,
    rows: n.rows ?? null, pk: n.pk ?? '', star: n.star ? 1 : 0,
    note: n.note ?? '', warn: n.warn ?? '', trg: n.trg ?? '',
    writers: n.w ?? [],
  },
}))

const have = new Set(nodes.map((n) => n.id))
const dropped = []
const edges = EDGES.filter((e) => {
  const ok = have.has(e.f) && have.has(e.t)
  if (!ok) dropped.push(`${e.f}→${e.t}`)
  return ok
}).map((e, i) => ({
  id: `e${i + 1}`,
  source: e.f,
  target: e.t,
  label: e.l ?? '',
  type: 'default',   // 베지어 곡선 — 객체는 각지게, 선은 휘게
  data: { ty: e.ty ?? 'proc', key: e.key ? 1 : 0 },
}))

const lanes = LANES.map((nm, i) => ({ i, name: nm, x: px(i) - 24, w: COLW }))

const out = {
  v: 1,
  from: 'web/public/p30/flow.html',
  schema: SCHEMA.toUpperCase(),
  made: new Date().toISOString().slice(0, 19).replace('T', ' '),
  size: { nw: NW, nh: NH },
  lanes,
  flows: FLOWS,
  nodes,
  edges,
}

if (process.argv.includes('--print')) {
  console.log(`[${SCHEMA.toUpperCase()}] 칸 ${nodes.length} · 이음선 ${edges.length} · 레인 ${lanes.length} · 흐름 ${FLOWS.length}`)
} else {
  fs.mkdirSync(path.dirname(DST), { recursive: true })
  fs.writeFileSync(DST, JSON.stringify(out, null, 1), 'utf8')
  console.log(`구웠습니다 → ${path.relative(ROOT, DST)}`)
  console.log(`  칸 ${nodes.length} · 이음선 ${edges.length} · 레인 ${lanes.length} · 흐름 ${FLOWS.length}`)
}
if (dropped.length) console.log('⚠ 한쪽이 없는 이음선은 뺐습니다:', dropped.join(', '))
