-- 개발자 관리의 <비상연락처>.
-- 본인 전화번호(tel_no) 옆에 두고 길이·형식도 같게 맞춘다.

alter table public.dev_user
    add column if not exists emerg_tel_no varchar(40);

comment on column public.dev_user.emerg_tel_no is '비상연락처 (가족·동거인 등 본인 외 연락처)';
