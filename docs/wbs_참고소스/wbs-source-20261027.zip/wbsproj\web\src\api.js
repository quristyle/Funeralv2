const base = '/api'

// IP 접근 권한이 사라진 경우(등록 해제 · 차단) 열려 있던 화면이 계속 쓰이지 않도록
// 첫 거절 응답에서 페이지를 새로 불러 서버가 주는 화면으로 넘긴다.
//
// 차단은 500 으로 오는데, 평범한 서버 오류까지 새로고침하면 무한히 되풀이된다.
// 그래서 서버가 붙인 표시(X-Wbs-Gate)가 있을 때만 다시 부른다.
function guard(res) {
  if (res.status === 403 || res.headers.get('X-Wbs-Gate') === 'blocked') {
    location.reload()
    throw new Error('접근 권한이 없습니다.')
  }
  return res
}

async function get(path, params = {}) {
  const q = new URLSearchParams(
    Object.entries(params).filter(([, v]) => v !== null && v !== undefined && v !== '')
  ).toString()
  const res = guard(await fetch(`${base}${path}${q ? '?' + q : ''}`))
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`)
  return res.json()
}

async function send(method, path, body) {
  const res = guard(await fetch(`${base}${path}`, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  }))
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`)
  return res.json()
}

export const api = {
  summary: (basis, scope) => get('/stats/summary', { basis, scope }),
  monthly: (basis, scope) => get('/stats/monthly', { basis, scope }),
  weekly: (basis, scope) => get('/stats/weekly', { basis, scope }),
  monthlyByUser: (basis, scope, who) => get('/stats/monthly-by-user', { basis, scope, who }),
  weeklyByUser: (basis, scope, who) => get('/stats/weekly-by-user', { basis, scope, who }),
  byModule: (basis, scope) => get('/stats/by-module', { basis, scope }),
  users: (scope, basis, month, week) => get('/users', { scope, basis, month, week }),
  whoami: () => get('/whoami'),
  ciStatus: (refresh) => get('/ci/status', { refresh: refresh ? 'true' : '' }),
  glMonitor: (refresh) => get('/gl/monitor', { refresh: refresh ? 'true' : '' }),
  // 커밋 드릴다운 — 작성자별 목록, 커밋 한 건의 내용과 바뀐 파일
  glCommits: (path, author, days) => get('/gl/commits', { path, author, days }),
  glCommit: (path, sha) => get('/gl/commit', { path, sha }),

  progressSummary: (scope) => get('/progress/summary', { scope }),
  progressByUser: (scope, who) => get('/progress/by-user', { scope, who }),
  progressByModule: (scope) => get('/progress/by-module', { scope }),
  progressRows: (scope, user, realUser, module) => get('/progress/rows', { scope, user, realUser, module }),

  // ---- 로컬 개발서버 관제 (api/DevRun.cs) ----
  devState: () => get('/dev/state'),
  // 개발 서버(Docker) 배포 상태 — devState 에도 직전 결과가 얹혀 온다. 이쪽은 <지금 다시
  // 두드려 보기> 용이다 (api/DevDeploy.cs).
  devDeploy: (force) => get('/dev/deploy', { force: force ? 'true' : '' }),
  devLog: (id, tier, since) => get('/dev/log', { id, tier, since }),
  // 로그인 사번 — 서버 체크아웃의 .env.properties 의 USER_ID. 쓰기는 devAction('userid', …) 다.
  devUserId: () => get('/dev/userid'),
  devAction: (action, body) => send('POST', `/dev/${action}`, body),

  // ---- EAI 인터페이스 카탈로그 ----
  ifList: (p) => get('/if', p ?? {}),
  ifCodes: (grp) => get('/if/codes', { grp }),
  ifSystems: () => get('/if/systems'),
  ifGet: (id) => get(`/if/${id}`),
  ifCreate: (body) => send('POST', '/if', body),
  ifUpdate: (id, body) => send('PUT', `/if/${id}`, body),
  ifDelete: (id) => send('DELETE', `/if/${id}`),
  ifStepAdd: (id, body) => send('POST', `/if/${id}/steps`, body),
  ifStepUpdate: (sid, body) => send('PUT', `/if/steps/${sid}`, body),
  ifStepDelete: (sid) => send('DELETE', `/if/steps/${sid}`),
  ifStepReorder: (id, order) => send('PUT', `/if/${id}/steps/reorder`, { order }),
  ifNoteAdd: (id, body) => send('POST', `/if/${id}/notes`, body),
  ifNoteUpdate: (nid, body) => send('PUT', `/if/notes/${nid}`, body),
  ifNoteDelete: (nid) => send('DELETE', `/if/notes/${nid}`),
  ifAttrSave: (id, values) => send('PUT', `/if/${id}/attrs`, { values }),

  // ---- 인터페이스 첨부파일 ----
  ifFiles: (id) => get(`/if/${id}/files`),
  ifFileCounts: () => get('/if/files/counts'),
  ifFileUrl: (id, fileId) => `${base}/if/${id}/files/${fileId}`,
  ifFileDelete: (id, fileId) => send('DELETE', `/if/${id}/files/${fileId}`),
  /** 여러 파일을 한 번에 올린다 (multipart) */
  ifFileUpload: async (id, fileList) => {
    const fd = new FormData()
    for (const f of fileList) fd.append('files', f, f.name)
    const res = guard(await fetch(`${base}/if/${id}/files`, { method: 'POST', body: fd }))
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`)
    return res.json()
  },


  /** 클립보드 이미지 업로드 — Blob 을 그대로 보내고 { url } 을 받는다 */
  uploadImage: async (blob) => {
    const res = guard(await fetch(`${base}/upload`, {
      method: 'POST',
      headers: { 'Content-Type': blob.type || 'image/png' },
      body: blob,
    }))
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`)
    return res.json()
  },

  // ---- ProjectView 날짜 동기화 (읽기 방향) ----
  pvSyncFiles: () => get('/pv-sync/files'),
  pvSyncConfig: () => get('/pv-sync/config'),
  /** 브라우저가 세션으로 받은 엑셀을 서버 보관 폴더로 올린다 */
  pvSyncUpload: async (blob) => {
    const res = guard(await fetch(`${base}/pv-sync/upload`, { method: 'POST', body: blob }))
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`)
    return res.json()
  },
  pvTokenGet: () => get('/pv-sync/token'),
  pvTokenSet: (token) => send('POST', '/pv-sync/token', { token }),
  pvSyncRun: (body) => send('POST', '/pv-sync/run', body),
  pvSyncJob: (id) => get(`/pv-sync/job/${id}`),
  pvSyncPreview: (body) => send('POST', '/pv-sync/preview', body),
  pvSyncApply: (body) => send('POST', '/pv-sync/apply', body),
  // ---- ProjectView 캐시 (신원 · 현재값 스냅샷) ----
  pvCache: (scope) => get('/pv/cache', { scope }),
  pvCacheRows: (scope) => get('/pv/rows', { scope }),
  pvCacheTasks: (activityId) => get('/pv/tasks', { activityId }),
  pvIngest: (body) => send('POST', '/pv/ingest', body),
  pvCacheClear: (what) => send('DELETE', '/pv/cache' + (what ? '?what=' + what : '')),
  // ---- 사용자별 화면 설정 (접속 IP → dev_user.bp_id) ----
  prefGet: (key) => get(`/prefs/${key}`),
  prefSet: (key, value) => send('PUT', `/prefs/${key}`, value),

  taskCounts: () => get('/tasks/counts'),

  tasks: (activityId) => get('/tasks', { activityId }),
  taskCreate: (body) => send('POST', '/tasks', body),
  taskUpdate: (id, body) => send('PUT', `/tasks/${id}`, body),
  taskDelete: (id) => send('DELETE', `/tasks/${id}`),

  delaySummary: (scope) => get('/delay/summary', { scope }),
  delayByUser: (scope, who) => get('/delay/by-user', { scope, who }),
  delayRows: (scope, kind, user, realUser) => get('/delay/rows', { scope, kind, user, realUser }),
  // 메뉴 권한 — 막힌 것만 오간다 (행이 없으면 허용)
  menus: () => get('/menus'),
  menuSync: (menus) => send('POST', '/menus/sync', { menus }),
  // 사이드바 짜임새 — 폴더와 순서. 고치는 것은 Super 뿐이고 서버가 막는다 (api/Menus.cs).
  // 읽기는 whoami 에 함께 실려 오므로 이 경로는 <고친 뒤 다시 맞출 때> 쓴다.
  menuTree: () => get('/menus/tree'),
  menuTreeSave: (tree) => send('PUT', '/menus/tree', { tree }),
  menuFolderAdd: (name) => send('POST', '/menus/folders', { name }),
  menuFolderRename: (id, name) => send('PUT', `/menus/folders/${id}`, { name }),
  menuFolderDelete: (id) => send('DELETE', `/menus/folders/${id}`),
  menuPerms: () => get('/menu-perms'),
  menuPermSave: (bpId, denied) => send('PUT', `/menu-perms/${encodeURIComponent(bpId)}`, { denied }),

  devUsers: () => get('/dev-users'),
  devUserCreate: (body) => send('POST', '/dev-users', body),
  devUserUpdate: (bpId, body) => send('PUT', `/dev-users/${encodeURIComponent(bpId)}`, body),
  devUserDelete: (bpId) => send('DELETE', `/dev-users/${encodeURIComponent(bpId)}`),
  rows: (params) => get('/rows', params),
  // 신규 대상(화면) 추가 — 상세 목록의 [+ 대상추가] 창. 필수는 systemcode · menu_nm
  rowCreate: (body) => send('POST', '/rows', body),
  // 대상 한 줄의 모든 컬럼 — 수정 창이 값을 채울 때만 쓴다 (목록에는 싣지 않는다)
  rowOne: (rowUid) => get('/rows/one', { rowUid }),
  // 대상 한 줄을 통째로 고친다. values 에 있는 키만 건드린다
  rowUpdate: (rowUid, values) => send('PUT', '/rows', { row_uid: rowUid, values }),
  // 나중에 확정된 Activity ID 를 채운다 — 그 값이 아직 없으므로 row_uid 로 행을 집는다
  rowSetActivityId: (rowUid, activityId) =>
    send('PUT', '/rows/activity-id', { row_uid: rowUid, activity_id: activityId }),
  // 지우면 무엇이 함께 사라지는지 — 삭제 단추를 누르기 전에 보여 주려고 먼저 읽는다
  rowDeps: (rowUid) => get(`/rows/${rowUid}/deps`),

  // ---- 단위테스트 FAIL 목록 (api/TestFail.cs) ----
  // 62건짜리 표라 통째로 받는다. 고치는 것은 H 열(verdict) 하나뿐이다.
  testFail: () => get('/testfail'),
  testFailSet: (failId, verdict) => send('PUT', `/testfail/${failId}`, { verdict }),

  // ---- 대형선 업무설계 변경이력 (api/LshipChange.cs) ----
  // 고치기는 <보낸 칸만> 건드린다 — 통째로 덮으면 두 사람이 다른 칸을 고쳤을 때
  // 나중 사람이 앞사람 것을 지운다. 그래서 화면도 칸 하나씩 보낸다.
  lshipChg: () => get('/lshipchg'),
  lshipChgNew: (body) => send('POST', '/lshipchg', body),
  lshipChgSet: (chgId, patch) => send('PUT', `/lshipchg/${chgId}`, patch),
  // 진짜 삭제는 Super 만. 평소에는 drop_yn 을 'Y' 로 바꾸는 <폐기>를 쓴다
  lshipChgDel: (chgId) => send('DELETE', `/lshipchg/${chgId}`),

  // ---- 도식 (Vue Flow) — api/Graph.cs ----
  // stamp 는 <읽을 때의 수정시각>이다. 저장할 때 그대로 돌려줘야 하고,
  // 그 사이 남이 저장했으면 서버가 409 로 막고 지금 도면을 함께 준다.
  graphGet: (name) => get(`/graph/${name}`),
  graphSet: (name, stamp, graph) => send('PUT', `/graph/${name}`, { stamp, graph }),
  graphReset: (name) => send('POST', `/graph/${name}/reset`),
  // 업무항목 — 도면과 따로 둔다 (기본 배치로 되돌려도 사라지지 않게). api/Graph.cs 참고
  graphItems: (name) => get(`/graph/${name}/items`),
  graphItemsSet: (name, stamp, items) => send('PUT', `/graph/${name}/items`, { stamp, items }),
  // 대상 한 줄을 지운다 (Super 만). 서버가 되돌릴 자료를 먼저 남긴 뒤 지운다
  rowDelete: (rowUid) => send('DELETE', `/rows/${rowUid}`),

  // ---- 행 첨부 (화면설계 문서) — api/RowFiles.cs ----
  // 키가 row_uid 라 Activity ID 가 없는 줄에도 붙는다 (db/wrk2_row_uid.sql)
  // 배지용 건수는 한 번에 다 받아 온다 (행마다 물으면 한 화면에 211번 왕복한다)
  rowFileCounts: () => get('/rows/files/counts'),
  rowFiles: (rowUid) => get(`/rows/${rowUid}/files`),
  rowFileUrl: (rowUid, fileId) => `${base}/rows/${rowUid}/files/${encodeURIComponent(fileId)}`,
  rowFileDelete: (rowUid, fileId) => send('DELETE', `/rows/${rowUid}/files/${encodeURIComponent(fileId)}`),
  // 업로드만 JSON 이 아니다 — multipart 는 Content-Type 을 브라우저가 경계값과 함께 붙여야 한다
  rowFileUpload: async (rowUid, fileList) => {
    const fd = new FormData()
    for (const f of fileList) fd.append('files', f, f.name)
    const res = guard(await fetch(`${base}/rows/${rowUid}/files`, { method: 'POST', body: fd }))
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`)
    return res.json()
  },

  // ---- DB 세션 정리 (api/OraKill.cs) ----
  // SQL 은 서버(Java)에 박혀 있다 — 여기서 문장을 보내지 않는다. 보내는 것은 <간격> 뿐이다.
  oraState: () => get('/ora/state'),
  oraScan: () => send('POST', '/ora/scan'),
  oraSweep: () => send('POST', '/ora/sweep'),
  oraAuto: (seconds) => send('PUT', '/ora/auto', { seconds }),
  // 조건 묶음을 <있는 그대로> 보낸다. 한때 (bponly) 하나만 받아 { bponly } 로 감쌌는데,
  // keepteam 이 생긴 뒤로도 그대로여서 { bponly: { keepteam: false } } 가 날아갔다.
  // 서버는 boolean 이 아닌 값을 말없이 버리고 200 을 주므로 — 화면은 성공한 척, 조건은 그대로였다.
  oraOptions: (patch) => send('PUT', '/ora/options', patch),
  // 한 건만 — 번호만 보낸다. 조건은 서버가 다시 건다 (목록을 본 사이 상태가 바뀔 수 있다)
  oraKillOne: (sid, serial) => send('POST', '/ora/kill', { sid, serial }),
  // 사번별 전체 현황 — 조건을 하나도 걸지 않은 목록
  oraUsers: () => send('POST', '/ora/users'),
  // 한 사번의 세션을 통째로 끊는다 (놀고 있든 일하고 있든)
  oraKillUser: (osuser) => send('POST', '/ora/killuser', { osuser }),
  // 한 스키마의 테이블 목록 — 계통도 화면의 [테이블 찾기] 가 쓴다.
  // 세션 정리와 한 묶음에 있는 까닭: Oracle 에 닿는 길이 그 데몬 하나뿐이다 (api/OraKill.cs).
  oraTables: (owner, q, limit) => get('/ora/tables', { owner, q, limit }),
  // 표 이름들이 어느 스키마에 있는지 — 한 번에 묻는다 (48개를 하나씩 물을 DB 가 아니다).
  // 시노님까지 함께 주므로 <여기 있는 척하는 표> 를 가려낼 수 있다.
  oraTableOwners: (names) => get('/ora/table-owners', { names: names.join(',') }),
  // 패키지·프로시저 — 계통도에 <무엇이 이 표를 쓰는가> 를 함께 그릴 때 쓴다
  oraProcs: (owner, q, limit) => get('/ora/procs', { owner, q, limit }),

  // ---- 현지 POR I/F 후행처리 (api/LocPor.cs) ----
  // 세션 정리와 한 묶음에 있는 까닭: Oracle 에 닿는 길이 그 데몬 하나뿐이다.
  // ⚠️ locporRun 은 돌이킬 수 없다 — 수신분을 업무표로 전개하고 알림 메일까지 만든다.
  //    보내는 것은 IFSEQ 하나뿐이고, 호출문은 서버(Java)에 박혀 있다.
  locporList: (q, limit) => get('/locpor/list', { q, limit }),
  locporLog: (ifseq, limit) => get('/locpor/log', { ifseq, limit }),
  locporRun: (ifseq) => send('POST', '/locpor/run', { ifseq }),
  // [3320] 승인완료 직전까지 흘리기 — 고른 줄 하나를 { ship, por, seq } 로 보낸다.
  // ⚠️ 돌이킬 수 없다. 발주번호를 매기고 PO_STAT 을 '3'(Waiting Approval) 로 민다.
  //    POR 번호는 수신표에 있는 그대로(네 자리) 보낸다 — 원장의 여덟 자리로 붙이는
  //    일은 프로시저가 한다. 여기서 미리 만들면 규칙이 두 군데가 된다.
  locporPo: (p) => send('POST', '/locpor/po', p),
  // 전개분 되돌리기 — 세는 것(scope)과 지우는 것(wipe)은 경로부터 갈라 둔다.
  // ⚠️ locporWipe 는 원장·발주(PO)·자재마스터까지 지운다. 되돌릴 수 없다.
  //    화면은 반드시 scope 로 먼저 세어 보여 주고 두 번 눌러야 부른다.
  // 범위는 둘 — { ifseq } 한 묶음, 또는 { ship, por } 그 POR 통째.
  // ⚠️ ship+por 는 <수신표에 없는 줄>(사람이 손으로 넣은 것)까지 지운다. 세는 쪽이
  //    그 수를 not_if 로 돌려주므로 화면은 반드시 그것을 적는다.
  locporScope: (p) => get('/locpor/scope', p),
  locporWipe: (p) => send('POST', '/locpor/wipe', p),

  // ---- 업무흐름 시나리오 (api/Flow.cs) ----
  // stamp 는 <읽을 때의 수정시각> 이다. 저장할 때 같이 보내 다른 사람이 먼저 저장했는지 가린다.
  flowDoc: () => get('/flow/doc'),
  flowSave: (text, stamp) => send('PUT', '/flow/doc', { text, stamp }),
  flowHistory: () => get('/flow/history'),
  flowHistoryOne: (name) => get(`/flow/history/${name}`),

  // ---- 라이브러리 저장소 (api/Nexus.cs) ----
  // force 는 서버 캐시까지 버린다 — 저장소가 방금 바뀐 것을 확인할 때만 쓴다.
  nexusConfig: () => get('/nexus/config'),
  nexusRepos: (force) => get('/nexus/repos', { force: force ? 'true' : '' }),
  nexusBrowse: (repository, force) => get('/nexus/browse', { repository, force: force ? 'true' : '' }),
  nexusUsed: (force) => get('/nexus/used', { force: force ? 'true' : '' }),

  // ---- 보관 파일 (api/FileStore.cs) ----
  fileStores: () => get('/files/stores'),
  fileList: (store, limit) => get('/files/list', { store, limit }),
  docs: () => get('/docs'),
  docCreate: (body) => send('POST', '/docs', body),
  docUpdate: (id, body) => send('PUT', `/docs/${id}`, body),
  // 삭제는 휴지통으로 간다. purge 는 되돌릴 수 없다 (Program.cs 의 주석 참고)
  docDelete: (id) => send('DELETE', `/docs/${id}`),

  // ---- 섹션을 HTML 문서로 보여 주기 — 한 섹션에 여러 장 (api/DocFiles.cs) ----
  // iframe 주소는 <화면이 쓰는 주소> 라 여기서 만든다 — 화면이 base 를 또 조립하면
  // 배포 경로가 바뀔 때 두 군데를 고치게 된다.
  docIframeUrl: (id, fid) => `${base}/docs/${id}/iframe/${fid}`,
  // 처음 뜰 때 한 번에 받아 섹션별로 갈라 쓴다 — 섹션마다 물으면 스무 번을 묻게 된다
  docIframeAll: () => send('GET', '/docs/iframes'),
  docIframeList: (id) => send('GET', `/docs/${id}/iframe`),
  // 여러 장을 한꺼번에 올린다. 돌려받는 것은 { added, skipped } 다 —
  // 섞여 들어온 비(非)HTML 은 서버가 걸러 skipped 로 돌려주고, 나머지는 올라간다.
  docIframeUpload: async (id, files) => {
    const fd = new FormData()
    for (const f of files) fd.append('files', f, f.name)
    const res = guard(await fetch(`${base}/docs/${id}/iframe`, { method: 'POST', body: fd }))
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`)
    return res.json()
  },
  // 파일 대신 주소를 건다. 돌려받는 꼴은 올리기와 같다 ({ added, skipped })
  docIframeLink: (id, url, name) => send('POST', `/docs/${id}/iframe/url`, { url, name }),
  docIframeRemove: (id, fid) => send('DELETE', `/docs/${id}/iframe/${fid}`),
  docIframeOrder: (id, ids) => send('PUT', `/docs/${id}/iframe/order`, { ids }),
  docTrash: () => get('/docs/trash'),
  docRestore: (id) => send('POST', `/docs/${id}/restore`),
  docPurge: (id) => send('DELETE', `/docs/${id}?purge=true`),
  // 순서만 바꾼다 — updated_at 을 올리지 않는다 (Program.cs 의 /api/docs/order 주석 참고)
  docReorder: (ids) => send('PUT', '/docs/order', { ids }),

  patch: async (activityId, body) => {
    const res = guard(await fetch(`${base}/rows/${encodeURIComponent(activityId)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }))
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`)
    return res.json()
  },
}
