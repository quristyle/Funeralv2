<script setup>
import { computed } from 'vue'
import { state, donePct, loadStats } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'

// 담당자별 진행 현황 — 완료(complate_yn) 와 개발완료(complate_real_yn) 를 나란히 본다
const perUser = computed(() => {
  const m = new Map()
  for (const r of state.byUser) {
    const cur = m.get(r.user_bp_id) ?? { id: r.user_bp_id, nm: r.user_nm, cnt: 0, done: 0, dev: 0, big: 0, bigDev: 0 }
    cur.cnt += r.cnt
    cur.done += r.done_plan ?? r.done ?? 0
    cur.dev += r.done_real ?? 0
    cur.big += r.done_big ?? 0
    cur.bigDev += r.done_real_big ?? 0
    m.set(r.user_bp_id, cur)
  }
  return [...m.values()].sort((a, b) => a.nm.localeCompare(b.nm, 'ko'))
})

const pct = (a, b) => (b ? Math.round((a / b) * 1000) / 10 : 0)

// 지연 — 담당자별 건수를 표에 함께 얹는다
const delaySum = computed(() => state.delay.sum ?? {})
const delayOf = (id) => state.delay.byUser?.find((r) => r.user_bp_id === id) ?? {}
const devPct = computed(() =>
  state.summary.total ? Math.round((state.summary.done_real / state.summary.total) * 1000) / 10 : 0
)
// 대형은 별도 트랙 — 위 완료율과 섞지 않고 따로 보여 준다
const bigPct = computed(() =>
  state.summary.total ? Math.round((state.summary.done_big / state.summary.total) * 1000) / 10 : 0
)
const bigDevPct = computed(() =>
  state.summary.total ? Math.round((state.summary.done_real_big / state.summary.total) * 1000) / 10 : 0
)
</script>

<template>
  <div class="cards">
    <div class="card"><div class="k">전체 항목</div><div class="v">{{ state.summary.total ?? '-' }}</div></div>
    <div class="card done">
      <div class="k">완료</div>
      <div class="v">
        {{ state.summary.done ?? '-' }} <small>/ {{ state.summary.total ?? '-' }} · {{ donePct }}%</small>
      </div>
      <div class="gauge"><div class="bar" :style="{ width: donePct + '%' }"></div></div>
    </div>
    <div class="card dev">
      <div class="k">개발완료</div>
      <div class="v">
        {{ state.summary.done_real ?? '-' }} <small>/ {{ state.summary.total ?? '-' }} · {{ devPct }}%</small>
      </div>
      <div class="gauge"><div class="bar dev" :style="{ width: devPct + '%' }"></div></div>
    </div>
    <div class="card big">
      <div class="k">대형완료</div>
      <div class="v">
        {{ state.summary.done_big ?? '-' }} <small>/ {{ state.summary.total ?? '-' }} · {{ bigPct }}%</small>
      </div>
      <div class="gauge"><div class="bar big" :style="{ width: bigPct + '%' }"></div></div>
    </div>
    <div class="card big">
      <div class="k">대형개발완료</div>
      <div class="v">
        {{ state.summary.done_real_big ?? '-' }} <small>/ {{ state.summary.total ?? '-' }} · {{ bigDevPct }}%</small>
      </div>
      <div class="gauge"><div class="bar big" :style="{ width: bigDevPct + '%' }"></div></div>
    </div>
    <div class="card">
      <div class="k">일정 있음</div>
      <div class="v">{{ state.summary.dated ?? '-' }} <small>/ {{ state.summary.total ?? '-' }}</small></div>
    </div>
    <div class="card"><div class="k">모듈</div><div class="v">{{ state.summary.modules ?? '-' }}</div></div>
    <div class="card"><div class="k">담당자</div><div class="v">{{ state.summary.users ?? '-' }}</div></div>
    <div class="card">
      <div class="k">계획 기간 ({{ state.basis === 'edt' ? '종료일' : '시작일' }} 기준)</div>
      <div class="v" style="font-size: 13px">
        {{ state.summary.min_dt ?? '-' }} ~ {{ state.summary.max_dt ?? '-' }}
      </div>
    </div>
    <div class="card">
      <div class="k">Activity 미지정</div>
      <div class="v">{{ state.summary.no_activity ?? '-' }}</div>
    </div>
  </div>

  <!-- 지연 요약 (오늘 기준) -->
  <section class="panel late">
    <h2>
      지연 요약
      <span class="hint">
        기준일 {{ delaySum.asof ?? '-' }} · 착수지연 = 계획시작일 도래 &amp; 실적시작 없음 ·
        종료지연 = 계획종료일 도래 &amp; 실적종료 없음
      </span>
      <span class="spacer"></span>
      <a class="more" href="#/delay">지연 현황 자세히 →</a>
    </h2>

    <div class="cards">
      <div class="card" :class="{ bad: delaySum.start_late }">
        <div class="k">착수지연</div>
        <div class="v">
          {{ delaySum.start_late ?? '-' }}
          <small v-if="delaySum.max_start_days">최대 {{ delaySum.max_start_days }}일</small>
        </div>
      </div>
      <div class="card" :class="{ bad: delaySum.finish_late }">
        <div class="k">종료지연</div>
        <div class="v">
          {{ delaySum.finish_late ?? '-' }}
          <small v-if="delaySum.max_finish_days">최대 {{ delaySum.max_finish_days }}일</small>
        </div>
      </div>
      <div class="card"><div class="k">착수·종료 모두</div><div class="v">{{ delaySum.both_late ?? '-' }}</div></div>
      <div class="card">
        <div class="k">지연 항목 (중복 제외)</div>
        <div class="v">
          {{ delaySum.any_late ?? '-' }}
          <small>/ {{ delaySum.total ?? '-' }} · {{ pct(delaySum.any_late ?? 0, delaySum.total ?? 0) }}%</small>
        </div>
      </div>
    </div>

    <p v-if="delaySum.any_late === 0" class="muted ok2">현재 지연 항목이 없습니다.</p>
  </section>

  <section class="panel" style="margin-top: 14px">
    <h2>
      담당자별 진행 현황
      <span class="spacer"></span>
      <RefreshBtn :fn="loadStats" />
    </h2>
    <div class="scroll">
      <table>
        <thead>
          <tr>
            <th>담당자</th>
            <th class="num">담당</th>
            <th class="num">완료</th>
            <th style="width: 26%">진행률</th>
            <th class="num">개발완료</th>
            <th style="width: 26%">개발진행률</th>
            <th class="num">착수지연</th>
            <th class="num">종료지연</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="u in perUser" :key="u.id">
            <td class="nowrap"><span class="nm">{{ u.nm }}</span><span class="uid">{{ u.id }}</span></td>
            <td class="num">{{ u.cnt }}</td>
            <td class="num">{{ u.done }}</td>
            <td>
              <div class="row2">
                <div class="gauge"><div class="bar" :style="{ width: pct(u.done, u.cnt) + '%' }"></div></div>
                <span class="pct">{{ pct(u.done, u.cnt) }}%</span>
              </div>
            </td>
            <td class="num">{{ u.dev }}</td>
            <td>
              <div class="row2">
                <div class="gauge"><div class="bar dev" :style="{ width: pct(u.dev, u.cnt) + '%' }"></div></div>
                <span class="pct">{{ pct(u.dev, u.cnt) }}%</span>
              </div>
            </td>
            <td class="num" :class="{ bad2: delayOf(u.id).start_late }">
              {{ delayOf(u.id).start_late || '' }}
            </td>
            <td class="num" :class="{ bad2: delayOf(u.id).finish_late }">
              {{ delayOf(u.id).finish_late || '' }}
            </td>
          </tr>
          <tr v-if="!perUser.length">
            <td colspan="8" class="muted" style="text-align: center; padding: 18px">데이터 없음</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>

<style scoped>
h2 .spacer { flex: 1; }
.nowrap { white-space: nowrap; }
.nm { font-weight: 600; }
.uid { color: var(--muted); font-size: 11px; margin-left: 6px; }
.row2 { display: flex; align-items: center; gap: 7px; }
.row2 .gauge { flex: 1; }
.pct { font-size: 11px; font-variant-numeric: tabular-nums; min-width: 40px; text-align: right; color: var(--muted); }
.gauge { height: 8px; background: var(--fill); border-radius: 4px; overflow: hidden; }
.gauge .bar { height: 100%; background: var(--done); border-radius: 4px; transition: width 0.2s; }
.gauge .bar.big { background: var(--muted); }
.card.big .gauge { margin-top: 6px; height: 4px; }
/* 개발완료(complate_real_yn)는 파란 계열로 구분 */
.gauge .bar.dev { background: var(--accent); }
.card.done .gauge, .card.dev .gauge { margin-top: 6px; height: 4px; }
.card.done .v { color: var(--done); }
.card.dev .v { color: var(--accent); }

/* 지연 요약 */
.panel.late { margin-top: 14px; border-left: 3px solid var(--warn); }
.panel.late .cards { margin-top: 2px; }
.panel.late .card.bad .v { color: var(--danger); }
.panel.late .card .v small { font-size: 11px; font-weight: 400; color: var(--muted); margin-left: 4px; }
h2 .spacer { flex: 1; }
.more { font-size: 12px; color: var(--accent); text-decoration: none; white-space: nowrap; }
.more:hover { text-decoration: underline; }
.ok2 { margin: 8px 0 0; color: var(--done); }
td.bad2 { color: var(--danger); font-weight: 600; }
</style>
