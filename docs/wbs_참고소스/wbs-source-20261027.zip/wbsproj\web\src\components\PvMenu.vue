<script setup>
import { computed, onMounted, onUnmounted } from 'vue'
import { pvTaskUrl, pvTestUrl, pvWorkUrl } from '../store'

// 상세 목록의 Activity ID 를 누르면 뜨는 작은 메뉴 — 그 화면의 ProjectView 쪽 세 군데로 간다.
//
// 예전에는 Activity ID 가 <작업 상세> 로 바로 가는 링크였다. 그런데 한 화면을 두고 볼 곳이
// 셋이고(작업 · 일감 · 단위테스트), 나머지 둘은 다른 칸에 있거나 아예 없어서 ProjectView 에
// 들어가 찾아야 했다. 누르던 자리는 그대로 두고 고를 수 있게만 바꾼 것이다.
//
// 메뉴명의 ScreenMenu.vue 와 같은 짜임이다 — 누른 자리에 붙고, 아무 데나 누르면 닫히고,
// 주소를 그대로 보여 준다(열기 전에 어디로 가는지 눈으로 확인할 수 있어야 한다).
const props = defineProps({
  row: { type: Object, required: true },
  x: { type: Number, required: true },
  y: { type: Number, required: true },
})
const emit = defineEmits(['close'])

// 차례는 <우리가 쥔 것부터>다. 작업은 activity_id 만으로 만들어져 늘 열리고,
// 일감·단위테스트는 각각 수집·입력이 있어야 열린다.
const items = computed(() => [
  {
    key: 'work',
    label: '작업 상세',
    note: 'Activity — 예전에 이 자리를 누르면 가던 곳',
    code: props.row.activity_id,
    url: pvWorkUrl(props.row),
    why: 'Activity ID 가 없는 줄입니다',
  },
  {
    key: 'task',
    label: '일감 상세',
    note: '현재단계 칸의 링크와 같은 곳',
    code: props.row.pv_task_code,
    url: pvTaskUrl(props.row),
    why: '일감 코드가 없습니다 — ⛁ 로 ProjectView 를 한 번 수집하면 채워집니다',
  },
  {
    key: 'test',
    label: '단위테스트 상세',
    note: '이 화면의 테스트 케이스',
    code: props.row.pv_test_case_id,
    url: pvTestUrl(props.row),
    why: '이 화면에 걸린 단위테스트가 없습니다 (db/pv_test_case_id.sql 로 넣습니다)',
  },
])

// 화면 밖으로 삐져나가지 않게 — 아래쪽 줄에서 누르면 메뉴가 화면 밑으로 잘린다
const W = 340
const H = 210
const pos = computed(() => ({
  left: Math.min(props.x, window.innerWidth - W - 12) + 'px',
  top: Math.min(props.y, window.innerHeight - H - 12) + 'px',
}))

function open(url) {
  if (!url) return
  window.open(url, '_blank', 'noopener')
  emit('close')
}

function onKey(e) {
  if (e.key === 'Escape') emit('close')
}
onMounted(() => window.addEventListener('keydown', onKey))
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <div class="mask" @click.self="emit('close')" @contextmenu.prevent="emit('close')">
    <div class="menu" :style="pos">
      <div class="hd" :title="row.menu_nm">
        <b>{{ row.activity_id }}</b>
        <span class="nm">{{ row.menu_nm }}</span>
      </div>

      <button
        v-for="it in items" :key="it.key" class="item" :disabled="!it.url"
        :title="it.url || it.why" @click="open(it.url)"
      >
        <span class="t">
          {{ it.label }}
          <em>{{ it.url ? it.note : it.why }}</em>
        </span>
        <span class="u">{{ it.url ?? '—' }}</span>
      </button>

      <p class="note">ProjectView 는 모두 새 창으로 엽니다.</p>
    </div>
  </div>
</template>

<style scoped>
/* 투명한 덮개 — 아무 데나 누르면 닫히게 하려는 것뿐이라 어둡게 하지 않는다 */
.mask { position: fixed; inset: 0; z-index: 120; }
.menu {
  position: fixed;
  width: 340px;
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 8px;
  box-shadow: 0 10px 30px var(--shadow);
  overflow: hidden;
}
.hd {
  padding: 7px 10px;
  border-bottom: 1px solid var(--line);
  background: var(--bg);
  font-size: 11.5px;
  display: flex;
  gap: 6px;
  align-items: baseline;
}
.hd b { font-size: 12.5px; }
.hd .nm { color: var(--muted); min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.item {
  display: block;
  width: 100%;
  text-align: left;
  border: 0;
  border-bottom: 1px solid var(--line);
  border-radius: 0;
  background: none;
  padding: 8px 10px;
  cursor: pointer;
}
.item:hover:not(:disabled) { background: var(--accent-soft); }
.item:disabled { opacity: 0.45; cursor: not-allowed; }
.item .t { display: block; font-size: 12.5px; font-weight: 600; color: var(--text); }
.item .t em { font-style: normal; font-weight: 400; font-size: 11px; color: var(--muted); margin-left: 5px; }
/* 주소를 그대로 보여 준다 — 열기 전에 어디로 가는지 확인할 수 있어야 한다 */
.item .u {
  display: block;
  margin-top: 2px;
  font-size: 10.5px;
  color: var(--accent);
  font-family: Consolas, 'Courier New', monospace;
  word-break: break-all;
}
.note { margin: 0; padding: 7px 10px; font-size: 10.5px; color: var(--muted); line-height: 1.5; }
</style>
