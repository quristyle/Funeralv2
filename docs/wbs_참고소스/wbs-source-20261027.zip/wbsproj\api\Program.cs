using System.Text.Json;
using WbsApi;

var builder = WebApplication.CreateBuilder(args);

// ---------- HTTPS (인증서가 있을 때만) ----------
// PWA 설치 아이콘은 <보안 출처>에서만 뜬다. 도메인이 없어도 IP 를 SAN 에 넣은
// 자체서명 인증서면 되고, 각 PC 가 그것을 신뢰하면 경고 없이 열린다.
//   인증서 만들기 : toolsmake-cert.ps1   →  api/cert/wbs.pfx
//   PC 에 신뢰등록 : web/public/install-cert.cmd
//
// 한 포트로 http 와 https 를 동시에 받을 수는 없다(프로토콜 자동감지 없음).
// 그래서 기존 http 포트는 그대로 두고 https 포트를 하나 더 연다.
// 인증서 파일이 없으면 아무것도 하지 않는다 — 예전과 똑같이 http 만 열린다.
var pfxPath = Path.Combine(builder.Environment.ContentRootPath, "cert", "wbs.pfx");
if (File.Exists(pfxPath))
{
    var pfxPw = builder.Configuration["Https:Password"] ?? "wbs";
    var httpsPort = int.TryParse(builder.Configuration["Https:Port"], out var hp) ? hp : 5443;

    // 설정의 Urls 에서 http 포트를 읽어 둔다 (Kestrel 에 직접 등록하면 Urls 는 무시되므로)
    var httpPort = 5080;
    var urlCfg = builder.Configuration["Urls"];
    if (!string.IsNullOrWhiteSpace(urlCfg))
    {
        var one = urlCfg.Split(';', StringSplitOptions.RemoveEmptyEntries)[0].Trim()
                        .Replace("0.0.0.0", "localhost").Replace("+", "localhost");
        if (Uri.TryCreate(one, UriKind.Absolute, out var u) && u.Port > 0) httpPort = u.Port;
    }

    builder.WebHost.ConfigureKestrel(k =>
    {
        k.ListenAnyIP(httpPort);
        k.ListenAnyIP(httpsPort, o => o.UseHttps(pfxPath, pfxPw));
    });
    Console.WriteLine($"HTTPS 사용: http {httpPort} · https {httpsPort} ({pfxPath})");
}

var cs = builder.Configuration.GetConnectionString("Wbs")
         ?? throw new InvalidOperationException("ConnectionStrings:Wbs 미설정");

builder.Services.AddSingleton(new PgPool(PgOptions.Parse(cs)));
builder.Services.AddSingleton<IpGate>();
builder.Services.AddSingleton<Gitlab>();
builder.Services.AddSingleton<GitlabMonitor>();
builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.SetIsOriginAllowed(_ => true).AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();
app.UseCors();

// ---------- IP 접근 제어 ----------
// dev_user.use_ip 에 등록된 IP 만 통과. 미등록 IP 는 접속 IP 를 알려주는 안내 화면을 받는다.
var gate = app.Services.GetRequiredService<IpGate>();

app.Use(async (ctx, next) =>
{
    var path = ctx.Request.Path.Value ?? "";
    // 진단용 health 와 본인 확인용 whoami 는 항상 열어 둔다 (차단 화면에서도 IP 확인 가능)
    if (path.StartsWith("/api/health") || path.StartsWith("/api/whoami")) { await next(); return; }

    var r = await gate.CheckAsync(ctx);
    if (r.Allowed) { await next(); return; }

    ctx.Response.Headers.CacheControl = "no-store";

    // 차단(개발자 관리의 <차단여부>)은 미등록과 다르게 다룬다.
    // 미등록은 <IP 를 등록받으세요> 라고 안내하지만, 차단은 흔한 서버 오류처럼 보이게 둔다.
    if (r.Reason == "blocked")
    {
        ctx.Response.StatusCode = 500;
        // 프론트가 <진짜 500> 과 구분해 페이지를 다시 부르게 하는 표시.
        // 이것이 없으면 평범한 서버 오류에도 새로고침이 돌아 무한히 반복된다.
        ctx.Response.Headers["X-Wbs-Gate"] = "blocked";
        // 본문이 Apache 를 흉내 내는데 헤더만 Kestrel 이면 한눈에 티가 난다.
        // 이 응답에만 맞춰 둔다 — 평상시 응답은 그대로다.
        ctx.Response.Headers["Server"] = "Apache/2.4.58";
        ctx.Response.ContentType = "text/html; charset=utf-8";
        await ctx.Response.WriteAsync(IpGate.BlockedHtml(ctx));
        return;
    }

    ctx.Response.StatusCode = 403;
    if (path.StartsWith("/api/"))
    {
        await ctx.Response.WriteAsJsonAsync(new { error = "등록되지 않은 IP 입니다.", ip = r.Ip });
    }
    else
    {
        ctx.Response.ContentType = "text/html; charset=utf-8";
        await ctx.Response.WriteAsync(IpGate.DeniedHtml(r.Ip));
    }
});

// 관리자가 두 가지 거절 화면을 미리 확인할 수 있는 경로.
// 실제와 같은 본문을 주되 상태는 200 으로 둔다 — 미리보기가 모니터링에 오류로 잡히면 곤란하다.
//
// 차단 화면은 서버 장비(루프백)에서는 실제로 볼 수가 없다.
// 루프백은 차단 판정을 건너뛰도록 만들어 두었기 때문이다. 그래서 이 경로가 필요하다.
app.MapGet("/denied-preview", (HttpContext ctx) =>
    Results.Content(IpGate.DeniedHtml(IpGate.ClientIp(ctx)), "text/html; charset=utf-8"));

app.MapGet("/blocked-preview", (HttpContext ctx) =>
    Results.Content(IpGate.BlockedHtml(ctx), "text/html; charset=utf-8"));

// 최고 관리자 — 도구성 기능(ProjectView 수집 등)을 이 사람에게만 보여 준다.
// 판정을 화면마다 흩지 않으려고 서버에서 내려 준다.
//
// 두 곳의 <합집합>이다.
//   ① 개발자 관리의 Super 권한 (dev_user.super_yn) — 화면에서 켜고 끈다
//   ② appsettings 의 "Admin:BpIds" (쉼표 구분) — <바닥>
// ②를 바닥으로 남기는 까닭: ①을 전부 꺼도 거기 적힌 사람은 계속 관리자다.
// 실수로 아무도 관리자가 아닌 상태를 만들면 되돌릴 화면조차 들어갈 수 없다.
var adminBpIds = new HashSet<string>(
    (builder.Configuration["Admin:BpIds"] ?? "BP33772")
        .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries),
    StringComparer.OrdinalIgnoreCase);

// Super 판정은 여기 한 곳에서만 한다.
// whoami 가 <보여 줄지> 정하는 기준과 서버가 <막는> 기준이 어긋나면
// 버튼은 보이는데 눌리지 않는(또는 그 반대의) 고장이 난다.
bool IsSuper(IpGate.Result r) =>
    r.Allowed && (r.Super || (r.BpId is not null && adminBpIds.Contains(r.BpId)));

// 현재 접속자 정보 (화면 상단·하단 표시용)
app.MapGet("/api/whoami", async (HttpContext ctx, IpGate g, PgPool db) =>
{
    var r = await g.CheckAsync(ctx);
    // 규칙은 셋이다.
    //  ① 서버 장비(localhost)에서 연 것이면 메뉴도 기능도 전부 연다.
    //  ② 그 밖의 사용자는 <메뉴 권한> 화면의 설정을 그대로 따른다 — Super 라도 마찬가지다.
    //  ③ 주요 동작(⛁ 수집 · ✔ 테스트 상태변경 · 메뉴 권한 화면)은 Super 에게만 보인다.
    var superUser = IsSuper(r);
    var admin = r.Allowed && (r.Loopback || superUser);   // ①③
    var denied = r.Loopback ? new List<string>() : await Menus.DeniedAsync(db, r.BpId);   // ①②
    // 사이드바 짜임새(폴더·순서)를 여기에 실어 보낸다 — 따로 부르면 메뉴가 <코드 순서로 한 번
    // 그려졌다가> 제자리를 찾아 다시 그려진다. 그 깜빡임이 열 때마다 보인다.
    var tree = await Menus.TreeAsync(db);
    return Results.Ok(new
    {
        ip = r.Ip, allowed = r.Allowed, bpId = r.BpId, name = r.Name,
        reason = r.Reason, registered = r.Registered, denied, tree,
        // 차단된 사람은 신원이 가려져도(BpId 가 있어도) 관리자가 아니다.
        // 막힌 사람에게 admin:true 가 딸려 나가면 진단할 때 헷갈린다.
        admin,
        // admin 과 따로 내려보낸다 — admin 에는 <서버 장비에서 연 것>(Loopback)이 섞여 있다.
        // 원장에 줄을 세우는 [대상추가] 처럼 Super 에게만 열 것은 이쪽을 본다.
        super = superUser,
    });
});

// ---------- 사용자별 화면 설정 (public.dev_user_pref) ----------
// 누구인지는 접속 IP → dev_user.bp_id 로 가린다 (IpGate 와 같은 방식).
// 가려지지 않으면(서버 로컬·미등록 IP) 저장하지 않고 stored:false 를 돌려준다.
// 그때는 화면이 localStorage 를 계속 쓴다 — 기능이 죽지 않고 조용히 낮아진다.
static bool PrefKeyOk(string k) =>
    k.Length is > 0 and <= 60 && k.All(c => char.IsLetterOrDigit(c) || c is '.' or '_' or '-');

app.MapGet("/api/prefs/{key}", async (PgPool db, IpGate g, HttpContext ctx, string key) =>
{
    if (!PrefKeyOk(key)) return Results.BadRequest(new { error = "설정 이름이 올바르지 않습니다." });
    var me = await g.CheckAsync(ctx);
    if (string.IsNullOrWhiteSpace(me.BpId))
        return Results.Ok(new { stored = false, key, value = (string?)null, who = (string?)null });

    var rows = await db.QueryAsync(
        "select pref_val from public.dev_user_pref where bp_id = $1::text and pref_key = $2::text",
        [me.BpId, key]);
    return Results.Ok(new
    {
        stored = true,
        key,
        value = rows.Count > 0 ? rows[0]["pref_val"] : null,
        who = me.Name ?? me.BpId,
    });
});

app.MapPut("/api/prefs/{key}", async (PgPool db, IpGate g, HttpContext ctx, string key, JsonElement body) =>
{
    if (!PrefKeyOk(key)) return Results.BadRequest(new { error = "설정 이름이 올바르지 않습니다." });
    var me = await g.CheckAsync(ctx);
    if (string.IsNullOrWhiteSpace(me.BpId))
        return Results.Ok(new { stored = false, key, reason = me.Reason });

    // 통째로 담되 터무니없이 큰 값은 막는다 (화면 설정은 수백 바이트면 충분하다)
    var val = body.ValueKind == JsonValueKind.Null ? null : body.GetRawText();
    if (val is { Length: > 20000 }) return Results.BadRequest(new { error = "설정 값이 너무 큽니다." });

    if (val is null)
    {
        await db.ExecuteAsync(
            "delete from public.dev_user_pref where bp_id = $1::text and pref_key = $2::text",
            [me.BpId, key]);
        return Results.Ok(new { stored = true, key, cleared = true });
    }

    await db.ExecuteAsync("""
        insert into public.dev_user_pref (bp_id, pref_key, pref_val, updated_at)
             values ($1::text, $2::text, $3::text, now())
        on conflict (bp_id, pref_key) do update set
            pref_val = excluded.pref_val, updated_at = now()
        """, [me.BpId, key, val]);
    return Results.Ok(new { stored = true, key, who = me.Name ?? me.BpId });
});

// 빌드된 프론트(web/dist → api/wwwroot)가 있으면 API 와 같은 포트로 함께 서비스한다.
// 사내망 사용자는 http://<서버IP>:5080 하나만 열면 된다.
app.UseDefaultFiles();

// 기본 목록에 없는 확장자는 정적 서비스가 404 로 막는다. 배포용 파일 몇 개만 열어 준다.
var mime = new Microsoft.AspNetCore.StaticFiles.FileExtensionContentTypeProvider();
mime.Mappings[".cmd"] = "application/octet-stream";   // 설치 스크립트 (내려받기)
mime.Mappings[".cer"] = "application/x-x509-ca-cert"; // https 인증서 (PC 신뢰 등록용)
mime.Mappings[".ps1"] = "text/plain; charset=utf-8";

app.UseStaticFiles(new StaticFileOptions
{
    ContentTypeProvider = mime,
    // 파일명에 해시가 붙는 assets/* 만 영구 캐시한다.
    // 나머지(index.html · sw.js · manifest · 아이콘 · 배포 스크립트)는 매번 재검증한다 —
    // 특히 sw.js 를 오래 캐시하면 잘못된 서비스 워커를 되돌리기 어려워진다.
    OnPrepareResponse = ctx =>
    {
        var path = ctx.Context.Request.Path.Value ?? "";
        ctx.Context.Response.Headers.CacheControl =
            path.StartsWith("/assets/", StringComparison.OrdinalIgnoreCase)
                ? "public, max-age=31536000, immutable"
                : "no-cache";
    }
});

// ---------- 붙여넣은 이미지 보관 ----------
// wwwroot 는 프론트 빌드 때 비워지므로(emptyOutDir) 업로드는 별도 폴더에 둔다.
var uploadDir = Path.Combine(builder.Environment.ContentRootPath, "data", "uploads");
Directory.CreateDirectory(uploadDir);

app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(uploadDir),
    RequestPath = "/uploads",
    OnPrepareResponse = ctx =>
        ctx.Context.Response.Headers.CacheControl = "public, max-age=31536000, immutable",
});

// 클립보드 이미지 업로드 — 본문에 바이트를 그대로 받는다
app.MapPost("/api/upload", async (HttpRequest req) =>
{
    var ext = (req.ContentType ?? "").Split(';')[0].Trim().ToLowerInvariant() switch
    {
        "image/png" => ".png",
        "image/jpeg" or "image/jpg" => ".jpg",
        "image/gif" => ".gif",
        "image/webp" => ".webp",
        "image/bmp" => ".bmp",
        _ => null,
    };
    if (ext is null)
        return Results.BadRequest(new { error = "이미지(png · jpeg · gif · webp · bmp)만 올릴 수 있습니다." });

    using var ms = new MemoryStream();
    await req.Body.CopyToAsync(ms);
    if (ms.Length == 0) return Results.BadRequest(new { error = "빈 파일입니다." });
    if (ms.Length > 10 * 1024 * 1024) return Results.BadRequest(new { error = "10MB 이하만 올릴 수 있습니다." });

    var name = $"{DateTime.Now:yyyyMMdd-HHmmss}-{Guid.NewGuid():N}"[..30] + ext;
    await File.WriteAllBytesAsync(Path.Combine(uploadDir, name), ms.ToArray());
    return Results.Ok(new { url = $"/uploads/{name}", size = ms.Length, name });
});

// SQL 오류를 JSON 으로 그대로 노출 (개발용 도구)
app.Use(async (ctx, next) =>
{
    try { await next(); }
    catch (PgException ex)
    {
        ctx.Response.StatusCode = 400;
        await ctx.Response.WriteAsJsonAsync(new { error = ex.Message });
    }
});

// 조회 기준 날짜 컬럼 화이트리스트 (식별자는 바인딩 불가하므로 반드시 화이트리스트로 처리)
// 기본값은 계획종료일(plan_edt) — 대시보드 기본 기준과 일치시킨다.
static string DateCol(string? basis) => basis?.ToLowerInvariant() switch
{
    "sdt" or "plan_sdt" => "plan_sdt",
    _ => "plan_edt"
};

// 조회 범위. 기본은 개발 대상(new_dev2 = 'o')만, scope=all 이면 전체 행.
static string DevWhere(string? scope) => scope?.ToLowerInvariant() == "all" ? "true" : "new_dev2 = 'o'";

// 집계 기준 인물. plan = 담당자(user_bp_id/complate_yn), real = 개발자(user_real_id/complate_real_yn)
static (string User, string Done) WhoCols(string? who) => who?.ToLowerInvariant() == "real"
    ? ("user_real_id", "complate_real_yn")
    : ("user_bp_id", "complate_yn");

// 수정 허용 컬럼 화이트리스트
// 일정(plan_sdt/plan_edt)과 실적(plan_sdt_c/plan_edt_c)은 엑셀 WBS 가 원본이므로 화면에서 수정 불가.
var editable = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
{
    "systemcode", "system_nm", "menu_nm",
    "user_bp_id", "priority_order", "prog_type", "prog_type_desc",
    "etc_desc", "comment", "new_dev2", "report_use", "complate_yn",
    "user_real_id", "complate_real_yn", "recheck_yn",
    // 대형 3종 — 기존 완료/개발자완료/재확인요청과 나란히 관리한다
    "complate_big_yn", "complate_real_big_yn", "recheck_big_yn",
    // 대형DB준비여부 — 같은 방식의 단일 문자 표시('o' = 준비됨)
    "db_ready_big_yn",
    // 도면조회여부 — 상세 목록에 컬럼으로 나와 있어 거기서 바로 켜고 끈다
    "dwg_view_use"
};
var dateCols = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "plan_sdt", "plan_edt" };

// 신규 대상(화면) 추가에 넣을 수 있는 컬럼 — hhip_wbs_wrk2 의 전부다.
//
// 수정(editable)과 따로 두는 까닭: 일정·실적일자는 엑셀 WBS 가 원본이라 화면에서 <고칠> 수
// 없지만, 엑셀에 아직 없는 <새로 만든 대상> 은 여기서 처음 넣어 줘야 한다. 수정 금지와
// 입력 금지는 다른 이야기다.
var insertable = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
{
    "module", "module_name", "systemcode", "system_nm", "program_id", "menu_nm",
    "comment", "activity_id", "plan_sdt", "plan_edt", "priority_order",
    "plan_sdt_c", "plan_edt_c", "prog_type", "prog_type_desc",
    "trg_exsit_chk", "trg_use_chk", "trg_evt_rel", "etc_desc", "new_dev2",
    "asis_cs", "report_use", "sheet_use", "dwg_view_use", "por_view_use",
    "menu_desc", "mon_req_comp", "user_bp_id", "complate_yn", "comp_desc",
    "user_real_id", "complate_real_yn", "recheck_yn",
    "complate_big_yn", "complate_real_big_yn", "recheck_big_yn", "db_ready_big_yn",
    // ProjectView 단위테스트 코드 — 한꺼번에 넣는 길은 db/pv_test_case_id.sql 이고,
    // 한 줄만 고치거나 새 대상에 달아 줄 때는 [✎ 대상 수정] 창에서 쓴다.
    "pv_test_case_id",
};
var insertDateCols = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    { "plan_sdt", "plan_edt", "plan_sdt_c", "plan_edt_c" };

app.MapGet("/api/health", async (PgPool db) =>
    Results.Ok(new { ok = true, now = (await db.QueryAsync("select now()::text as now"))[0]["now"] }));

// 요약 카드
app.MapGet("/api/stats/summary", async (PgPool db, string? basis, string? scope) =>
{
    var c = DateCol(basis);
    var rows = await db.QueryAsync($"""
        select count(*)                                    as total
             , count({c})                                  as dated
             , count(distinct systemcode)                  as modules
             , count(distinct user_bp_id)                  as users
             , min({c})::text                              as min_dt
             , max({c})::text                              as max_dt
             , count(*) filter (where activity_id is null) as no_activity
             , count(*) filter (where complate_yn = 'o')    as done
             , count(*) filter (where complate_real_yn = 'o') as done_real
             -- 대형 (별도 트랙 — 기존 완료 수치는 그대로 두고 따로 센다)
             , count(*) filter (where complate_big_yn = 'o')      as done_big
             , count(*) filter (where complate_real_big_yn = 'o') as done_real_big
          from public.hhip_wbs_wrk2
         where {DevWhere(scope)}
        """);
    return Results.Ok(rows[0]);
});

// 월단위 건수
app.MapGet("/api/stats/monthly", async (PgPool db, string? basis, string? scope) =>
{
    var c = DateCol(basis);
    return Results.Ok(await db.QueryAsync($"""
        select to_char(date_trunc('month', {c}), 'YYYY-MM') as bucket
             , count(*)                                     as cnt
             , count(*) filter (where complate_yn = 'o')    as done
             , count(distinct systemcode)                   as modules
             , count(distinct user_bp_id)                   as users
          from public.hhip_wbs_wrk2
         where {DevWhere(scope)} and {c} is not null
         group by 1
         order by 1
        """));
});

// 주단위 건수 (ISO 주, 월요일 시작)
app.MapGet("/api/stats/weekly", async (PgPool db, string? basis, string? scope) =>
{
    var c = DateCol(basis);
    return Results.Ok(await db.QueryAsync($"""
        select to_char(date_trunc('week', {c}), 'IYYY-"W"IW')      as bucket
             , date_trunc('week', {c})::date::text                 as week_start
             , (date_trunc('week', {c}) + interval '4 day')::date::text as week_end
             , count(*)                                            as cnt
             , count(*) filter (where complate_yn = 'o')           as done
             , count(distinct user_bp_id)                          as users
          from public.hhip_wbs_wrk2
         where {DevWhere(scope)} and {c} is not null
         group by 1, 2, 3
         order by 2
        """));
});

// 월단위 개발자별 건수 (매트릭스 원본)
app.MapGet("/api/stats/monthly-by-user", async (PgPool db, string? basis, string? scope, string? who) =>
{
    var c = DateCol(basis);
    var (uc, dc) = WhoCols(who);
    // 성명은 dev_user 에서 가져온다 (bp_id 대소문자 무시 매칭).
    // dev_user 에 없는 값('미분류' 등)은 저장된 값 그대로 한 행으로 묶어 보여준다.
    return Results.Ok(await db.QueryAsync($"""
        select coalesce(w.{uc}, '(미지정)')                    as user_bp_id
             , coalesce(u.name, w.{uc}, '(미지정)')            as user_nm
             , to_char(date_trunc('month', w.{c}), 'YYYY-MM')  as bucket
             , count(*)                                        as cnt
             , count(*) filter (where w.{dc} = 'o')            as done
             -- 담당자 완료 / 개발자 완료를 각각 따로도 제공한다 (요약 화면용)
             , count(*) filter (where w.complate_yn = 'o')      as done_plan
             , count(*) filter (where w.complate_real_yn = 'o') as done_real
             , count(*) filter (where w.complate_big_yn = 'o')      as done_big
             , count(*) filter (where w.complate_real_big_yn = 'o') as done_real_big
          from public.hhip_wbs_wrk2 w
          left join public.dev_user u on upper(u.bp_id) = upper(w.{uc})
         where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")} and w.{c} is not null
         group by 1, 2, 3
         order by 2, 1, 3
        """));
});

// 주단위 개발자별 건수 (매트릭스 원본)
app.MapGet("/api/stats/weekly-by-user", async (PgPool db, string? basis, string? scope, string? who) =>
{
    var c = DateCol(basis);
    var (uc, dc) = WhoCols(who);
    return Results.Ok(await db.QueryAsync($"""
        select coalesce(w.{uc}, '(미지정)')                            as user_bp_id
             , coalesce(u.name, w.{uc}, '(미지정)')                    as user_nm
             , to_char(date_trunc('week', w.{c}), 'IYYY-"W"IW')       as bucket
             , date_trunc('week', w.{c})::date::text                  as week_start
             , (date_trunc('week', w.{c}) + interval '4 day')::date::text as week_end
             , count(*)                                               as cnt
             , count(*) filter (where w.{dc} = 'o')                   as done
          from public.hhip_wbs_wrk2 w
          left join public.dev_user u on upper(u.bp_id) = upper(w.{uc})
         where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")} and w.{c} is not null
         group by 1, 2, 3, 4, 5
         order by 4, 2, 1
        """));
});

// 모듈별 건수
app.MapGet("/api/stats/by-module", async (PgPool db, string? basis, string? scope) =>
{
    var c = DateCol(basis);
    return Results.Ok(await db.QueryAsync($"""
        select systemcode
             , min(system_nm)  as system_nm
             , count(*)        as cnt
             , count(*) filter (where complate_yn = 'o')      as done
             , count(*) filter (where complate_real_yn = 'o') as done_real
             , count(*) filter (where complate_big_yn = 'o')      as done_big
             , count(*) filter (where complate_real_big_yn = 'o') as done_real_big
             , count({c})      as dated
             , min({c})::text  as min_dt
             , max({c})::text  as max_dt
             -- 실적일자 기준 (입력된 건수와 실적 기간)
             , count(plan_sdt_c)   as act_sdt
             , count(plan_edt_c)   as act_edt
             , min(plan_sdt_c)::text as min_act
             , max(plan_edt_c)::text as max_act
          from public.hhip_wbs_wrk2
         where {DevWhere(scope)}
         group by systemcode
         order by systemcode
        """));
});

// 담당자 목록 (필터 드롭다운용).
// month/week 를 주면 그 기간에 실제로 배정된 담당자만, 그 기간 건수와 함께 준다.
app.MapGet("/api/users", async (PgPool db, string? scope, string? basis, string? month, string? week) =>
{
    var c = DateCol(basis);
    return Results.Ok(await db.QueryAsync($"""
        select coalesce(w.user_bp_id, '(미지정)')             as user_bp_id
             , coalesce(u.name
                      , case when w.user_bp_id is null then '미지정' else '(미등록)' end) as user_nm
             , count(*)                                       as cnt
          from public.hhip_wbs_wrk2 w
          left join public.dev_user u on upper(u.bp_id) = upper(w.user_bp_id)
         where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")}
           and ($1::text is null or to_char(date_trunc('month', w.{c}), 'YYYY-MM') = $1)
           and ($2::text is null or to_char(date_trunc('week',  w.{c}), 'IYYY-"W"IW') = $2)
         group by 1, 2
         order by 2, 1
        """, [Nz(month), Nz(week)]));
});

// ---------- 계획 진척률 ----------
// 계획시작일 도래 전 = 0%, 계획종료일 경과 = 100%,
// 그 사이는 (오늘 - 계획시작일) / (계획종료일 - 계획시작일) 비율.
// 시작일 = 종료일(1일 작업)이면 도래 시점에 100% 로 본다.
const string PlanRate = """
    case when w.plan_sdt is null or w.plan_edt is null then null
         when current_date < w.plan_sdt  then 0
         when current_date >= w.plan_edt then 100
         else round((current_date - w.plan_sdt)::numeric / (w.plan_edt - w.plan_sdt) * 100, 1)
    end
    """;
// 실적완료율 비교용 (complate_yn = 'o')
const string DoneFlag = "(w.complate_yn = 'o')";
// 대형 완료 — 기존 완료와 별개로 세는 트랙 (완료율 계산에 섞지 않는다)
const string DoneBigFlag = "(w.complate_big_yn = 'o')";

app.MapGet("/api/progress/summary", async (PgPool db, string? scope) =>
{
    var rows = await db.QueryAsync($"""
        with t as (
          select w.*, {PlanRate} as rate, {DoneFlag} as done, {DoneBigFlag} as done_big
            from public.hhip_wbs_wrk2 w
           where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")}
        )
        select current_date::text                                  as asof
             , count(*)                                            as total
             , count(rate)                                         as dated
             , round(avg(rate), 1)                                 as plan_rate
             , count(*) filter (where rate = 0)                     as not_started
             , count(*) filter (where rate > 0 and rate < 100)       as in_progress
             , count(*) filter (where rate = 100)                    as elapsed
             , count(*) filter (where done)                          as done_cnt
             , round(count(*) filter (where done)::numeric
                     / nullif(count(*), 0) * 100, 1)                as done_rate
             -- 대형 완료 (별도 트랙)
             , count(*) filter (where done_big)                      as done_big_cnt
             , round(count(*) filter (where done_big)::numeric
                     / nullif(count(*), 0) * 100, 1)                as done_big_rate
          from t
        """);
    return Results.Ok(rows[0]);
});

// 담당자별(who=plan) / 개발자별(who=real) 계획진척률
app.MapGet("/api/progress/by-user", async (PgPool db, string? scope, string? who) =>
{
    var (uc, dc) = WhoCols(who);
    var bc = dc == "complate_real_yn" ? "complate_real_big_yn" : "complate_big_yn";
    return Results.Ok(await db.QueryAsync($"""
        select coalesce(w.{uc}, '(미지정)')                        as user_bp_id
             , coalesce(u.name, w.{uc}, '(미지정)')                 as user_nm
             , count(*)                                            as cnt
             , round(avg({PlanRate}), 1)                            as plan_rate
             , count(*) filter (where ({PlanRate}) = 0)              as not_started
             , count(*) filter (where ({PlanRate}) > 0 and ({PlanRate}) < 100) as in_progress
             , count(*) filter (where ({PlanRate}) = 100)            as elapsed
             , count(*) filter (where w.{dc} = 'o')                  as done_cnt
             , round(count(*) filter (where w.{dc} = 'o')::numeric
                     / nullif(count(*), 0) * 100, 1)                as done_rate
             -- 대형 (담당자 기준이면 complate_big_yn, 개발자 기준이면 complate_real_big_yn)
             , count(*) filter (where w.{bc} = 'o')                  as done_big_cnt
             , round(count(*) filter (where w.{bc} = 'o')::numeric
                     / nullif(count(*), 0) * 100, 1)                as done_big_rate
          from public.hhip_wbs_wrk2 w
          left join public.dev_user u on upper(u.bp_id) = upper(w.{uc})
         where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")}
         group by 1, 2
         order by 4 desc nulls last, 2
        """));
});

app.MapGet("/api/progress/by-module", async (PgPool db, string? scope) =>
    Results.Ok(await db.QueryAsync($"""
        select w.systemcode
             , min(w.system_nm)                                     as system_nm
             , count(*)                                            as cnt
             , round(avg({PlanRate}), 1)                            as plan_rate
             , count(*) filter (where {DoneFlag})                    as done_cnt
             , round(count(*) filter (where {DoneFlag})::numeric
                     / nullif(count(*), 0) * 100, 1)                as done_rate
             , count(*) filter (where {DoneBigFlag})                 as done_big_cnt
             , round(count(*) filter (where {DoneBigFlag})::numeric
                     / nullif(count(*), 0) * 100, 1)                as done_big_rate
             , min(w.plan_sdt)::text                                as min_dt
             , max(w.plan_edt)::text                                as max_dt
          from public.hhip_wbs_wrk2 w
         where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")}
         group by 1
         order by 1
        """)));

// 항목별 계획진척률 상세
app.MapGet("/api/progress/rows", async (PgPool db, string? scope, string? user, string? realUser, string? module) =>
    Results.Ok(await db.QueryAsync($"""
        select w.activity_id, w.systemcode, w.system_nm, w.menu_nm
             , w.plan_sdt::text as plan_sdt, w.plan_edt::text as plan_edt
             , w.plan_sdt_c::text as plan_sdt_c, w.plan_edt_c::text as plan_edt_c
             -- 진척률과 분모·분자를 일치시킨다 (기간 = 종료-시작, 경과 = 오늘-시작)
             , (w.plan_edt - w.plan_sdt)                             as span_days
             , greatest(0, least(current_date - w.plan_sdt, w.plan_edt - w.plan_sdt)) as passed_days
             , {PlanRate}                                            as plan_rate
             , w.complate_yn, w.user_bp_id, u.name as user_nm
             , w.user_real_id, ru.name as user_real_nm, w.complate_real_yn
             , w.priority_order
          from public.hhip_wbs_wrk2 w
          left join public.dev_user u  on upper(u.bp_id)  = upper(w.user_bp_id)
          left join public.dev_user ru on upper(ru.bp_id) = upper(w.user_real_id)
         where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")}
           and ($1::text is null or coalesce(w.user_bp_id, '(미지정)') = $1)
           and ($2::text is null or coalesce(w.user_real_id, '(미지정)') = $2)
           and ($3::text is null or w.systemcode = $3)
         order by ({PlanRate}) desc nulls last, w.plan_edt, w.systemcode, w.menu_nm
        """, [Nz(user), Nz(realUser), Nz(module)])));

// ---------- 지연 현황 ----------
// 착수지연: 계획시작일이 도래(<= 오늘)했는데 실적시작일이 없음
// 종료지연: 계획종료일이 도래(<= 오늘)했는데 실적종료일이 없음
const string StartLate = "(w.plan_sdt is not null and w.plan_sdt <= current_date and w.plan_sdt_c is null)";
const string FinishLate = "(w.plan_edt is not null and w.plan_edt <= current_date and w.plan_edt_c is null)";

app.MapGet("/api/delay/summary", async (PgPool db, string? scope) =>
{
    var rows = await db.QueryAsync($"""
        select current_date::text                                        as asof
             , count(*)                                                  as total
             , count(*) filter (where {StartLate})                        as start_late
             , count(*) filter (where {FinishLate})                       as finish_late
             , count(*) filter (where {StartLate} and {FinishLate})        as both_late
             , count(*) filter (where {StartLate} or {FinishLate})         as any_late
             , max(current_date - w.plan_sdt) filter (where {StartLate})   as max_start_days
             , max(current_date - w.plan_edt) filter (where {FinishLate})  as max_finish_days
          from public.hhip_wbs_wrk2 w
         where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")}
        """);
    return Results.Ok(rows[0]);
});

// 담당자별(who=plan) / 개발자별(who=real) 지연 건수
app.MapGet("/api/delay/by-user", async (PgPool db, string? scope, string? who) =>
{
    var (uc, _) = WhoCols(who);
    return Results.Ok(await db.QueryAsync($"""
        select coalesce(w.{uc}, '(미지정)')                       as user_bp_id
             , coalesce(u.name, w.{uc}, '(미지정)')                as user_nm
             , count(*)                                           as assigned
             , count(*) filter (where {StartLate})                 as start_late
             , count(*) filter (where {FinishLate})                as finish_late
             , count(*) filter (where {StartLate} or {FinishLate})  as any_late
          from public.hhip_wbs_wrk2 w
          left join public.dev_user u on upper(u.bp_id) = upper(w.{uc})
         where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")}
         group by 1, 2
         order by 6 desc, 2
        """));
});

// 지연 대상 상세 (kind: start | finish | all)
app.MapGet("/api/delay/rows", async (PgPool db, string? scope, string? kind, string? user, string? realUser) =>
{
    var where = kind?.ToLowerInvariant() switch
    {
        "start" => StartLate,
        "finish" => FinishLate,
        _ => $"({StartLate} or {FinishLate})"
    };
    return Results.Ok(await db.QueryAsync($"""
        select w.activity_id, w.systemcode, w.system_nm, w.menu_nm
             , w.plan_sdt::text as plan_sdt, w.plan_edt::text as plan_edt
             , w.plan_sdt_c::text as plan_sdt_c, w.plan_edt_c::text as plan_edt_c
             , w.user_bp_id, u.name  as user_nm
             , w.user_real_id, ru.name as user_real_nm
             , w.complate_yn, w.complate_real_yn
             , {StartLate}  as start_late
             , {FinishLate} as finish_late
             , case when {StartLate}  then current_date - w.plan_sdt end as start_days
             , case when {FinishLate} then current_date - w.plan_edt end as finish_days
             , w.priority_order, w.prog_type
          from public.hhip_wbs_wrk2 w
          left join public.dev_user u  on upper(u.bp_id)  = upper(w.user_bp_id)
          left join public.dev_user ru on upper(ru.bp_id) = upper(w.user_real_id)
         where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")}
           and {where}
           and ($1::text is null or coalesce(w.user_bp_id, '(미지정)') = $1)
           and ($2::text is null or coalesce(w.user_real_id, '(미지정)') = $2)
         order by greatest(coalesce(current_date - w.plan_sdt, 0), coalesce(current_date - w.plan_edt, 0)) desc
                , w.systemcode, w.menu_nm
        """, [Nz(user), Nz(realUser)]));
});

// ---------- GitLab 빌드(Job) 상태 ----------
app.MapGet("/api/ci/status", async (Gitlab gl, bool? refresh) =>
{
    var rows = await gl.StatusAsync(refresh == true);
    return Results.Ok(new
    {
        configured = gl.Configured,
        baseUrl = gl.BaseUrl,
        group = gl.Group,
        loadedAt = gl.LoadedAt == DateTimeOffset.MinValue ? null : gl.LoadedAt.ToLocalTime().ToString("HH:mm:ss"),
        rows,
    });
});

// GitLab 종합 모니터링 (프로젝트 통계 · 브랜치 · MR · 커밋 · 빌드 품질 · 레지스트리)
app.MapGet("/api/gl/monitor", async (GitlabMonitor gm, Gitlab gl, bool? refresh) =>
{
    var rows = await gm.LoadAsync(refresh == true);
    return Results.Ok(new
    {
        configured = gm.Configured,
        baseUrl = gl.BaseUrl,
        group = gl.Group,
        loadedAt = gm.LoadedAt == DateTimeOffset.MinValue ? null : gm.LoadedAt.ToLocalTime().ToString("HH:mm:ss"),
        rows,
    });
});

// 커밋 드릴다운 — <커밋 활동> 탭에서 작성자·커밋을 눌렀을 때.
//
// path 는 화면이 보내 온다. 우리 그룹 밖을 조회하는 통로가 되지 않도록 앞을 확인한다 —
// 토큰이 붙은 요청이라 아무 프로젝트나 대신 읽어 주면 안 된다.
static bool InGroup(Gitlab gl, string? path) =>
    !string.IsNullOrWhiteSpace(path)
    && path.StartsWith(gl.Group + "/", StringComparison.OrdinalIgnoreCase);

app.MapGet("/api/gl/commits", async (GitlabMonitor gm, Gitlab gl, string path, string? author, int? days) =>
    !InGroup(gl, path)
        ? Results.BadRequest(new { error = "이 그룹의 프로젝트가 아닙니다.", path })
        : Results.Ok(new { rows = await gm.CommitsAsync(path, author, days ?? 7) }));

app.MapGet("/api/gl/commit", async (GitlabMonitor gm, Gitlab gl, string path, string sha) =>
    !InGroup(gl, path)
        ? Results.BadRequest(new { error = "이 그룹의 프로젝트가 아닙니다.", path })
        : Results.Ok(await gm.CommitAsync(path, sha)));

// ---------- EAI 인터페이스 카탈로그 (public.if_*) ----------
Interfaces.Map(app);
IfFiles.Map(app);
// 첨부 삭제는 Super 만 — 판정 기준을 통째로 넘겨 whoami 와 어긋나지 않게 한다
RowFiles.Map(app, IsSuper);
FileStore.Map(app, RowFiles.Root(app.Environment), uploadDir);
Menus.Map(app, IsSuper);

// 로컬 개발서버 관제 — 이 API 가 도는 PC 의 PMM BE/FE 를 기동·중지한다 (DevRun.cs 머리말 참고)
DevRun.Init(app.Configuration, app.Environment.ContentRootPath);
DevRun.Map(app);

// 배포 상태 — 개발 서버(Docker)에 떠 있는 것. 위와 대상이 다르다 (DevDeploy.cs 머리말 참고)
DevDeploy.Init(app.Configuration, app.Environment.ContentRootPath);
DevDeploy.Map(app);
PvSync.Map(app);
PvCache.Map(app);
PvSync.MapRun(app);

// 사내 Nexus 저장소 — 어떤 라이브러리가 몇 버전 올라와 있나 (Nexus.cs 머리말 참고)
// DevRun.Init 뒤에 둔다 — [PMM 사용] 탭이 DevRun 이 찾아 둔 프로젝트 폴더를 읽는다.
// 묵은 Oracle 세션 정리 — 끊는 일은 Super 만 (OraKill.cs 머리말 참고)
OraKill.Init(app.Configuration, app.Environment.ContentRootPath);
OraKill.Map(app, IsSuper);

// 현지 POR I/F 후행처리 — EAI 가 적재 뒤에 부르는 프로시저를 사람이 대신 누른다.
// ⚠️ OraKill 뒤에 둔다 — 그쪽이 쥐고 있는 Oracle 연결을 빌려 쓴다 (LocPor.cs 머리말).
LocPor.Map(app);

// 업무흐름 시나리오 — api/data/flow/scenario.md 한 장을 읽고 쓴다 (Flow.cs 머리말 참고)
Flow.Init(app.Configuration, app.Environment.ContentRootPath);
Flow.Map(app);

Nexus.Init(app.Configuration);
Nexus.Map(app);

// 단위테스트 FAIL 목록 — 엑셀에서 한 번 떠 둔 표를 보여 주고 H 열만 받는다
TestFail.Map(app);

// 대형선 업무설계 변경이력 — 적는 것은 누구나, 진짜 삭제만 Super
LshipChange.Map(app, IsSuper);

// 도식(Vue Flow) — 테이블 계통도 편집 화면이 읽고 쓴다
Graph.Init(app.Environment.ContentRootPath);
Graph.Map(app);

// ---------- 일감 (public.hhip_wbs_task) ----------
// hhip_wbs_wrk2(화면) 1 : N 일감. activity_id 로 연결.

// 화면별 일감 건수 (상세목록 '일감' 컬럼용)
app.MapGet("/api/tasks/counts", async (PgPool db) =>
    Results.Ok(await db.QueryAsync("""
        select activity_id
             , count(*)                                as cnt
             , count(*) filter (where done_yn = 'o')    as done
          from public.hhip_wbs_task
         where activity_id is not null
         group by activity_id
        """)));

// 한 화면의 일감 목록
app.MapGet("/api/tasks", async (PgPool db, string? activityId) =>
{
    if (string.IsNullOrWhiteSpace(activityId))
        return Results.BadRequest(new { error = "activityId 는 필수입니다." });
    return Results.Ok(await db.QueryAsync("""
        select task_id, activity_id, task_div, memo, done_yn, sort_order
             , to_char(created_at,'YYYY-MM-DD HH24:MI') as created_at
             , to_char(updated_at,'YYYY-MM-DD HH24:MI') as updated_at
          from public.hhip_wbs_task
         where activity_id = $1::text
         order by coalesce(done_yn,'') , sort_order, task_id
        """, [activityId]));
});

app.MapPost("/api/tasks", async (PgPool db, JsonElement body) =>
{
    var act = body.TryGetProperty("activity_id", out var a) ? a.GetString()?.Trim() : null;
    if (string.IsNullOrWhiteSpace(act)) return Results.BadRequest(new { error = "activity_id 는 필수입니다." });

    // 부모 화면이 실제로 있는지 확인 (DB FK 를 걸 수 없는 상태라 애플리케이션에서 검증)
    var parent = await db.QueryAsync(
        "select 1 as ok from public.hhip_wbs_wrk2 where activity_id = $1::text limit 1", [act]);
    if (parent.Count == 0) return Results.BadRequest(new { error = $"존재하지 않는 activity_id 입니다: {act}" });

    var div = body.TryGetProperty("task_div", out var d) ? d.GetString() : null;
    var memo = body.TryGetProperty("memo", out var m) ? m.GetString() : null;

    var rows = await db.QueryAsync("""
        insert into public.hhip_wbs_task (activity_id, task_div, memo, sort_order)
        values ($1::text, $2::text, $3::text,
                coalesce((select max(sort_order) + 10 from public.hhip_wbs_task where activity_id = $1::text), 10))
        returning task_id
        """, [act, Nz(div), Nz(memo)]);
    return Results.Ok(new { task_id = rows[0]["task_id"] });
});

app.MapPut("/api/tasks/{id:int}", async (PgPool db, int id, JsonElement body) =>
{
    // 본문에 담겨 온 항목만 갱신한다. SQL 의 자리표시자와 넘기는 값의 개수가 어긋나면
    // PostgreSQL 이 타입을 정하지 못해 실패하므로($3 을 쓰지 않는데 값은 4개 →
    // "$3 매개 변수의 자료형을 알 수 없습니다") SQL 과 파라미터를 함께 만든다.
    var sets = new List<string>();
    var args = new List<object?>();

    void Set(string col, string? val)
    {
        args.Add(val);
        sets.Add($"{col} = ${args.Count}::text");
    }

    if (body.TryGetProperty("task_div", out var d)) Set("task_div", Nz(d.GetString()));
    if (body.TryGetProperty("memo", out var m)) Set("memo", Nz(m.GetString()));
    // done_yn: 'o' 또는 빈 문자열(해제)
    if (body.TryGetProperty("done_yn", out var dn))
        Set("done_yn", dn.ValueKind == JsonValueKind.Null ? null : Nz(dn.GetString()));

    if (sets.Count == 0) return Results.BadRequest(new { error = "변경할 항목이 없습니다." });

    sets.Add("updated_at = now()");
    args.Add(id);
    var n = await db.ExecuteAsync(
        $"update public.hhip_wbs_task set {string.Join(", ", sets)} where task_id = ${args.Count}::int",
        args.ToArray());
    return n > 0 ? Results.Ok(new { updated = n }) : Results.NotFound(new { error = "대상 없음", id });
});

app.MapDelete("/api/tasks/{id:int}", async (PgPool db, int id) =>
{
    var n = await db.ExecuteAsync("delete from public.hhip_wbs_task where task_id = $1::int", [id]);
    return n > 0 ? Results.Ok(new { deleted = n }) : Results.NotFound(new { error = "대상 없음", id });
});

// ---------- 개발자 마스터 (public.dev_user) ----------

// 수정 허용 컬럼 (bp_id 는 키라 제외)
var devUserCols = new[]
{
    "name", "position_nm", "birth_dt", "email", "tel_no", "emerg_tel_no", "use_ip",
    "mac_addr", "notebook_no", "notebook_chk_no",
    // 차단여부 · Super 권한 — IpGate 와 whoami 가 본다
    "super_yn",
    // 모니터 3대 — 노트북과 같은 짝(장비번호 · 확인번호)
    "monitor1_no", "monitor1_chk_no",
    "monitor2_no", "monitor2_chk_no",
    "monitor3_no", "monitor3_chk_no",
    "summer_size", "winter_size",
    "git", "startkit", "dxb", "vm_conn", "aipro", "claudecode",
    "dev_db", "wiki", "projectview", "svn", "notebook", "hub_hdmi",
    // ProjectView 사용자 id(USR-...). 워크플로 담당자를 이름 대신 이 값으로 찾는다.
    "pv_user_id",
    // 차단여부 — o 면 사용 IP 가 등록돼 있어도 막는다 (IpGate 가 본다)
    "block_yn"
};
var devUserSet = new HashSet<string>(devUserCols, StringComparer.OrdinalIgnoreCase);
// 날짜형 컬럼은 ::date 로 바인딩한다 (나머지는 ::text)
var devUserDateCols = new HashSet<string>(["birth_dt"], StringComparer.OrdinalIgnoreCase);
string DuCast(string col) => devUserDateCols.Contains(col) ? "::date" : "::text";

app.MapGet("/api/dev-users", async (PgPool db) =>
    Results.Ok(await db.QueryAsync($"""
        select bp_id
             , {string.Join("\n             , ", devUserCols.Select(c =>
                 devUserDateCols.Contains(c) ? $"{c}::text as {c}" : c))}
          from public.dev_user
         where bp_id is not null
         order by name, bp_id
        """)));

app.MapPost("/api/dev-users", async (PgPool db, JsonElement body) =>
{
    var bpId = body.TryGetProperty("bp_id", out var b) ? b.GetString()?.Trim() : null;
    if (string.IsNullOrWhiteSpace(bpId)) return Results.BadRequest(new { error = "bp_id 는 필수입니다." });

    var cols = new List<string> { "bp_id" };
    var args = new List<object?> { bpId };
    foreach (var p in body.EnumerateObject())
    {
        if (!devUserSet.Contains(p.Name)) continue;
        cols.Add(p.Name.ToLowerInvariant());
        var s = p.Value.ValueKind == JsonValueKind.Null ? null : p.Value.ToString();
        args.Add(string.IsNullOrWhiteSpace(s) ? null : s);
    }
    var ph = string.Join(", ", cols.Select((c, i) => $"${i + 1}{DuCast(c)}"));
    var n = await db.ExecuteAsync(
        $"insert into public.dev_user ({string.Join(", ", cols)}) values ({ph})", [.. args]);
    return Results.Ok(new { inserted = n, bp_id = bpId });
});

app.MapPut("/api/dev-users/{bpId}", async (PgPool db, string bpId, JsonElement body) =>
{
    var sets = new List<string>();
    var args = new List<object?>();
    foreach (var p in body.EnumerateObject())
    {
        if (!devUserSet.Contains(p.Name)) continue;
        var s = p.Value.ValueKind == JsonValueKind.Null ? null : p.Value.ToString();
        args.Add(string.IsNullOrWhiteSpace(s) ? null : s);
        sets.Add($"{p.Name.ToLowerInvariant()} = ${args.Count}{DuCast(p.Name)}");
    }
    if (sets.Count == 0) return Results.BadRequest(new { error = "수정 가능한 컬럼이 없습니다." });

    args.Add(bpId);
    var n = await db.ExecuteAsync(
        $"update public.dev_user set {string.Join(", ", sets)} where bp_id = ${args.Count}::text", [.. args]);
    return n > 0 ? Results.Ok(new { updated = n }) : Results.NotFound(new { error = "대상 없음", bpId });
});

app.MapDelete("/api/dev-users/{bpId}", async (PgPool db, string bpId) =>
{
    var n = await db.ExecuteAsync("delete from public.dev_user where bp_id = $1::text", [bpId]);
    return n > 0 ? Results.Ok(new { deleted = n }) : Results.NotFound(new { error = "대상 없음", bpId });
});

// 드릴다운 목록
app.MapGet("/api/rows", async (PgPool db,
    string? basis, string? scope, string? month, string? week, string? user, string? realUser,
    string? module, string? q, string? done, string? late, string? status, int? limit) =>
{
    var c = DateCol(basis);
    // done=y 완료만 / done=n 미완료만 / 그 외 전체
    var doneWhere = done?.ToLowerInvariant() switch
    {
        "y" => " and w.complate_yn = 'o'",
        "n" => " and (w.complate_yn is distinct from 'o')",
        _ => ""
    };
    // 지연 필터 — 지연 현황 화면(/api/delay/rows)과 같은 식을 쓴다.
    // 기준일은 DB 의 current_date 라 브라우저 시각과 어긋나지 않는다.
    var lateWhere = late?.ToLowerInvariant() switch
    {
        "start" => $" and {StartLate}",
        "finish" => $" and {FinishLate}",
        "both" => $" and {StartLate} and {FinishLate}",
        "any" => $" and ({StartLate} or {FinishLate})",
        "none" => $" and not ({StartLate} or {FinishLate})",
        _ => ""
    };
    // 진행 상태 — 진척률 현황 화면의 항목별 목록과 같은 기준.
    // 착수도래 = 계획진척률이 0 보다 크다 (계획시작일이 지났다는 뜻).
    // 일정이 없어 진척률이 null 인 행은 '미도래' 로 본다 (진척률 화면의 (plan_rate ?? 0) 과 같다)
    var started = $"coalesce((({PlanRate}) > 0), false)";
    var statusWhere = status?.ToLowerInvariant() switch
    {
        "open" => $" and {started} and {DoneFlag} is not true",   // 착수도래 & 미완료
        "notyet" => $" and not {started}",                        // 미도래
        "done" => $" and {DoneFlag}",                             // 완료
        _ => ""
    };
    var sql = $"""
        select w.row_uid, w.activity_id, w.systemcode, w.system_nm, w.menu_nm, w.program_id
             , w.plan_sdt::text as plan_sdt, w.plan_edt::text as plan_edt
             , w.plan_sdt_c::text as plan_sdt_c, w.plan_edt_c::text as plan_edt_c
             -- 성명은 dev_user 에 있을 때만 채운다. 매칭되지 않는 값('미분류' 같은 placeholder,
             -- 오타, 퇴사자 등)은 성명 null 로 내려보내 화면에서 '미할당'으로 비워 보여준다.
             , w.user_bp_id
             , u.name  as user_nm
             , w.complate_yn
             , w.user_real_id
             , ru.name as user_real_nm
             , w.complate_real_yn
             , w.recheck_yn
             , w.complate_big_yn, w.complate_real_big_yn, w.recheck_big_yn
             , w.db_ready_big_yn
             , w.priority_order, w.prog_type, w.prog_type_desc, w.trg_use_chk
             -- 도면조회여부 · 리포트사용 — 상세 목록의 체크 컬럼. 'o' 면 쓴다
             , w.dwg_view_use
             , w.report_use
             -- ProjectView 단위테스트 코드(AAC-TC###) — Activity ID 메뉴의 <단위테스트 상세> 주소를
             -- 만드는 값이다. 캐시가 아니라 원장에 있다 (db/pv_test_case_id.sql 참고)
             , w.pv_test_case_id
             -- 계획진척률 (진척률 현황 화면과 같은 식) — 착수도래 필터의 근거이기도 하다
             , {PlanRate} as plan_rate
             -- 지연 여부와 지연일수 (지연 현황 화면과 같은 기준)
             , {StartLate}  as start_late
             , {FinishLate} as finish_late
             , case when {StartLate}  then current_date - w.plan_sdt end as start_days
             , case when {FinishLate} then current_date - w.plan_edt end as finish_days
             -- ProjectView 캐시 (없으면 전부 null — 목록은 그대로 동작한다)
             , p.pv_finish_rate
             , p.pv_actual_sdt::text  as pv_actual_sdt
             , p.pv_actual_edt::text  as pv_actual_edt
             , p.pv_snapshot_at::text as pv_snapshot_at
             , pt.task_cnt   as pv_task_cnt
             , pt.node_cnt   as pv_node_cnt
             , pt.node_empty as pv_node_empty
             , pt.task_edt::text as pv_task_edt
             , pt.workers    as pv_workers
             , pt.status     as pv_status
             , pt.status_at::text as pv_status_at
             , pt.status_cnt as pv_status_cnt
             , pt.task_code  as pv_task_code
          from public.hhip_wbs_wrk2 w
          left join public.dev_user u  on upper(u.bp_id)  = upper(w.user_bp_id)
          left join public.dev_user ru on upper(ru.bp_id) = upper(w.user_real_id)
          left join public.hhip_wbs_pv p on p.activity_id = w.activity_id
          left join {PvCache.TaskRollup} pt on pt.activity_id = w.activity_id
         where {DevWhere(scope).Replace("new_dev2", "w.new_dev2")}
           and ($1::text is null or to_char(date_trunc('month', w.{c}), 'YYYY-MM') = $1)
           and ($2::text is null or to_char(date_trunc('week',  w.{c}), 'IYYY-"W"IW') = $2)
           and ($3::text is null or coalesce(w.user_bp_id, '(미지정)') = $3)
           and ($4::text is null or w.systemcode = $4)
           and ($5::text is null or w.menu_nm ilike '%' || $5 || '%' or w.activity_id ilike '%' || $5 || '%')
           and ($6::text is null or coalesce(w.user_real_id, '(미지정)') = $6)
           {doneWhere}{lateWhere}{statusWhere}
         order by w.{c} nulls last, w.systemcode, w.menu_nm
         limit $7::int
        """;
    return Results.Ok(await db.QueryAsync(sql, [
        Nz(month), Nz(week), Nz(user), Nz(module), Nz(q), Nz(realUser), Math.Clamp(limit ?? 500, 1, 5000)
    ]));
});

// ---------- 개발자 정보 공유 문서 (public.dev_docs) ----------

// created_* 는 db/dev_docs_created.sql 로 뒤에 붙인 컬럼이라, 그 전에 만든 섹션은 null 이다.
// 화면은 그것을 '작성 —' 으로 보여 준다 (모르는 값을 updated_at 으로 메우지 않는다).
app.MapGet("/api/docs", async (PgPool db) =>
    Results.Ok(await db.QueryAsync("""
        select id, title, content, sort_order, updated_by, created_by
             , to_char(updated_at,'YYYY-MM-DD HH24:MI') as updated_at
             , to_char(created_at,'YYYY-MM-DD HH24:MI') as created_at
          from public.dev_docs
         where deleted_at is null
         order by sort_order, id
        """)));

// 누가 만들었는지는 삭제(deleted_by)와 같이 서버가 IpGate 로 가린다 — 화면이 보내 주기를
// 기다리지 않는다. 수정자(updated_by)만 본문으로 받는데, 그쪽은 이미 그렇게 돌고 있어서다.
app.MapPost("/api/docs", async (PgPool db, IpGate g, HttpContext ctx, JsonElement body) =>
{
    var title = body.TryGetProperty("title", out var t) ? t.GetString() : null;
    var content = body.TryGetProperty("content", out var c) ? c.GetString() : "";
    var order = body.TryGetProperty("sort_order", out var o) && o.ValueKind == JsonValueKind.Number
        ? o.GetInt32() : 100;
    if (string.IsNullOrWhiteSpace(title)) return Results.BadRequest(new { error = "제목은 필수입니다." });

    // 사람이 안 가려지면(서버 로컬·미등록 IP) null 로 둔다 — 빈 이름으로 채우지 않는다.
    // 만든 직후의 <수정자> 는 만든 사람이다. 비워 두면 머리글의 수정자만 빈 채로 남는다.
    var me = await g.CheckAsync(ctx);
    var who = string.IsNullOrWhiteSpace(me.Name) ? me.BpId : me.Name;

    var rows = await db.QueryAsync("""
        insert into public.dev_docs (title, content, sort_order, created_by, updated_by)
        values ($1::text, $2::text, $3::int, $4::text, $4::text)
        returning id
        """, [title, content ?? "", order, who]);
    return Results.Ok(new { id = rows[0]["id"] });
});

app.MapPut("/api/docs/{id:int}", async (PgPool db, int id, JsonElement body) =>
{
    var title = body.TryGetProperty("title", out var t) ? t.GetString() : null;
    var content = body.TryGetProperty("content", out var c) ? c.GetString() : null;
    var order = body.TryGetProperty("sort_order", out var o) && o.ValueKind == JsonValueKind.Number
        ? (int?)o.GetInt32() : null;
    var by = body.TryGetProperty("updated_by", out var u) ? u.GetString() : null;

    var n = await db.ExecuteAsync("""
        update public.dev_docs
           set title      = coalesce($1::text, title)
             , content    = coalesce($2::text, content)
             , sort_order = coalesce($3::int, sort_order)
             , updated_by = coalesce($4::text, updated_by)
             , updated_at = now()
         where id = $5::int
        """, [title, content, order, by, id]);
    return n > 0 ? Results.Ok(new { updated = n }) : Results.NotFound(new { error = "대상 없음", id });
});

// 목차 순서만 바꾼다.
//
// ⚠️ 여기서 updated_at 을 건드리면 안 된다. 목차를 끌어 옮긴 것은 <내용이 바뀐 것> 이
//    아닌데, PUT /api/docs/{id} 는 무엇을 보내든 updated_at 을 올린다. 그것을 쓰면
//    화면(Docs.vue)의 <변경됨> 표시가 옮긴 섹션 전부에 대해, 모두에게 잘못 켜진다.
//    그래서 순서 전용 경로를 따로 둔다.
//
// 경로가 {id:int} 와 겹치지 않는 까닭 — "order" 는 int 제약을 통과하지 못한다.
app.MapPut("/api/docs/order", async (PgPool db, JsonElement body) =>
{
    if (!body.TryGetProperty("ids", out var arr) || arr.ValueKind != JsonValueKind.Array)
        return Results.BadRequest(new { error = "ids 배열이 필요합니다." });

    var ids = new List<int>();
    foreach (var x in arr.EnumerateArray())
        if (x.TryGetInt32(out var v)) ids.Add(v);
    if (ids.Count == 0) return Results.BadRequest(new { error = "ids 가 비어 있습니다." });

    // 한 건씩 보내면 중간에 끊겼을 때 순서가 반쯤 뒤섞인 채 남는다.
    return await db.UseAsync<IResult>(async c =>
    {
        await c.QueryAsync("begin");
        try
        {
            for (var i = 0; i < ids.Count; i++)
                await c.QueryAsync(
                    "update public.dev_docs set sort_order = $1::int where id = $2::int",
                    [(i + 1) * 10, ids[i]]);
            await c.QueryAsync("commit");
            return Results.Ok(new { ordered = ids.Count });
        }
        catch
        {
            await c.QueryAsync("rollback");
            throw;
        }
    });
});

// 섹션 삭제 — 진짜로 지우지 않고 휴지통으로 보낸다 (db/dev_docs_trash.sql 참고).
//
// 섹션 하나에 팀이 한참 쌓아 둔 글이 들어 있다. 실수로 지우면 되돌릴 방법이
// 백업 복구뿐이었다. 되돌릴 수 없는 삭제는 휴지통에서 purge=true 로 따로 부른다.
app.MapDelete("/api/docs/{id:int}", async (PgPool db, IpGate g, HttpContext ctx,
                                           IWebHostEnvironment env, int id, bool? purge) =>
{
    if (purge == true)
    {
        var d = await db.ExecuteAsync("delete from public.dev_docs where id = $1::int", [id]);
        // 올려 둔 HTML 도 같이 치운다. 휴지통으로 보낼 때는 두는데, 여기는 되돌릴 데가 없다 —
        // 안 치우면 api/data/doc_files 에 주인 없는 폴더만 쌓인다.
        if (d > 0) DocFiles.Purge(env, id);
        return d > 0 ? Results.Ok(new { purged = d }) : Results.NotFound(new { error = "대상 없음", id });
    }

    var me = await g.CheckAsync(ctx);
    var n = await db.ExecuteAsync("""
        update public.dev_docs
           set deleted_at = now()
             , deleted_by = $1::text
         where id = $2::int and deleted_at is null
        """, [me.Name ?? me.BpId, id]);
    return n > 0 ? Results.Ok(new { deleted = n }) : Results.NotFound(new { error = "대상 없음", id });
});

// 휴지통 — 무엇이 언제 누구 손에 지워졌는지.
// 본문(content)은 주지 않는다. 목록에 필요 없고, 지운 글을 굳이 실어 나를 이유도 없다.
app.MapGet("/api/docs/trash", async (PgPool db) =>
    Results.Ok(await db.QueryAsync("""
        select id, title, sort_order, deleted_by
             , to_char(deleted_at,'YYYY-MM-DD HH24:MI') as deleted_at
             , length(coalesce(content,'')) as size
          from public.dev_docs
         where deleted_at is not null
         order by deleted_at desc, id
        """)));

// 되돌리기 — sort_order 를 그대로 두었으므로 지운 자리로 돌아간다.
app.MapPost("/api/docs/{id:int}/restore", async (PgPool db, int id) =>
{
    var n = await db.ExecuteAsync("""
        update public.dev_docs set deleted_at = null, deleted_by = null
         where id = $1::int and deleted_at is not null
        """, [id]);
    return n > 0 ? Results.Ok(new { restored = n }) : Results.NotFound(new { error = "대상 없음", id });
});

// 개발자 정보 섹션에 HTML 한 장을 올려 iframe 으로 보여 준다
DocFiles.Map(app);

// 단건 수정 (화이트리스트 컬럼만)
// 신규 대상(화면) 추가 — 상세 목록의 [+ 대상추가] 창이 부른다.
//
// 필수는 둘뿐이다. 둘을 고른 까닭은 <이 줄이 어느 줄인지> 를 가리는 데 이 둘만 남기 때문이다.
//   systemcode : 모듈별 집계와 필터가 이것으로 나뉜다. 비면 어느 모듈에도 안 잡힌다.
//   menu_nm    : 목록의 주 표시 항목. 비면 빈 줄로 보인다.
//
// activity_id 는 받지 않아도 된다 — 엑셀 WBS 에서 나중에 확정되는 일이 있어서다.
// 다만 그때까지 그 줄은 수정(PATCH)·ProjectView 캐시·일감이 붙지 않는다. 전부 이 값으로
// 행을 찾기 때문이다. 나중에 PUT /api/rows/activity-id 로 채우면 그때부터 평범한 줄이 된다.
app.MapPost("/api/rows", async (PgPool db, IpGate g, HttpContext ctx, JsonElement body) =>
{
    // 버튼을 숨기는 것만으로는 막은 것이 아니다 — 원장에 줄을 세우는 일이라 서버에서도 막는다.
    if (!IsSuper(await g.CheckAsync(ctx)))
        return Results.Json(new { error = "대상 추가는 Super 권한만 할 수 있습니다." }, statusCode: 403);

    string? Str(string k) =>
        body.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String
            ? (string.IsNullOrWhiteSpace(v.GetString()) ? null : v.GetString()!.Trim())
            : null;

    var activityId = Str("activity_id");
    var systemcode = Str("systemcode");
    var menuNm = Str("menu_nm");
    var missing = new List<string>();
    if (systemcode is null) missing.Add("systemcode");
    if (menuNm is null) missing.Add("menu_nm");
    if (missing.Count > 0)
        return Results.BadRequest(new { error = "필수 항목이 비어 있습니다.", missing });

    // activity_id 가 없는 줄은 <모듈 + 메뉴명> 으로 가린다 (지금 211건 모두 이 둘이 안 겹친다).
    // 그래야 나중에 activity-id 를 채울 때 어느 줄인지 집어낼 수 있다.
    var same = await db.QueryAsync(
        "select activity_id from public.hhip_wbs_wrk2 where systemcode = $1::text and menu_nm = $2::text limit 1",
        [systemcode, menuNm]);
    if (same.Count > 0)
        return Results.Conflict(new
        {
            error = $"같은 모듈에 같은 메뉴명이 이미 있습니다 — {systemcode} · {menuNm}" +
                    (same[0]["activity_id"] is string a && a.Length > 0 ? $" ({a})" : " (Activity ID 없음)")
        });

    if (activityId is not null)
    {
        // 대소문자만 다른 중복도 막는다 — 목록의 조인(upper 비교)이 그렇게 맞추고 있다.
        var dup = await db.QueryAsync(
            "select activity_id from public.hhip_wbs_wrk2 where upper(activity_id) = upper($1::text) limit 1",
            [activityId]);
        if (dup.Count > 0)
            return Results.Conflict(new { error = $"이미 있는 Activity ID 입니다 — {dup[0]["activity_id"]}" });
    }

    var cols = new List<string>();
    var vals = new List<string>();
    var args = new List<object?>();
    foreach (var p in body.EnumerateObject())
    {
        var col = p.Name.ToLowerInvariant();
        if (!insertable.Contains(col) || cols.Contains(col)) continue;
        object? val = p.Value.ValueKind switch
        {
            JsonValueKind.Null => null,
            JsonValueKind.Number => p.Value.GetDouble(),
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            _ => p.Value.GetString()?.Trim()
        };
        if (val is string s && s.Length == 0) val = null;

        args.Add(val);
        cols.Add(col);
        vals.Add($"${args.Count}{(insertDateCols.Contains(col) ? "::date" : "::text")}");
    }

    var n = await db.ExecuteAsync(
        $"insert into public.hhip_wbs_wrk2 ({string.Join(", ", cols)}) values ({string.Join(", ", vals)})",
        [.. args]);
    // activity_id 가 없을 수 있으므로 <어느 줄을 만들었는지> 가리는 것들을 함께 돌려준다.
    // 화면이 방금 만든 줄을 찾아가고, 바로 첨부를 붙일 수 있게 row_uid 도 같이 준다.
    var made = await db.QueryAsync(
        "select row_uid from public.hhip_wbs_wrk2 where systemcode = $1::text and menu_nm = $2::text",
        [systemcode, menuNm]);
    return Results.Ok(new
    {
        created = n, row_uid = made.Count == 1 ? made[0]["row_uid"] : null,
        activity_id = activityId, systemcode, menu_nm = menuNm,
    });
});

// 대상 한 줄의 <모든 컬럼> — 수정 창이 값을 채워 넣을 때만 쓴다.
// 목록(GET /api/rows)에 전부 싣지 않는 까닭: 화면 설명·메모 같은 긴 글이 섞여 있어
// 211건을 그릴 때마다 함께 날아오면 목록이 무거워진다. 고칠 때만 한 줄을 더 받는다.
app.MapGet("/api/rows/one", async (PgPool db, long rowUid) =>
{
    // date 는 그대로 'YYYY-MM-DD' 문자열로 온다 (Pg.cs 가 텍스트 포맷으로 받고
    // 날짜 타입은 변환하지 않는다) — 창의 <input type="date"> 가 바로 받는 모양이다.
    var rows = await db.QueryAsync(
        "select * from public.hhip_wbs_wrk2 where row_uid = $1::bigint", [rowUid]);
    return rows.Count > 0 ? Results.Ok(rows[0]) : Results.NotFound(new { error = "대상 없음", rowUid });
});

// 대상(화면) 한 줄을 통째로 고친다 — 상세 목록의 [✎] 창이 부른다.
//
// PATCH /api/rows/{activityId} 와 나누어 둔 까닭이 둘 있다.
//  ① 고칠 수 있는 범위가 다르다. PATCH 는 목록에서 칸을 눌러 바꾸는 몇 개(editable)뿐이고,
//     이쪽은 표의 컬럼 전부(insertable)다. 한 화이트리스트로 합치면 목록의 인라인 수정 경로로도
//     모든 컬럼이 열린다 — 그러려고 만든 경로가 아니다.
//  ② 행을 집는 방법이 다르다. PATCH 는 activity_id 로만 찾는데, 그 값이 아직 없는 줄도
//     고칠 수 있어야 한다. 그래서 키를 본문으로 받는다.
//
// 본문 모양:  { row_uid, values: { ...컬럼 } }
//   values 에 <있는> 키만 건드린다. 빈 문자열은 비우라는 뜻이고, 아예 없으면 그대로 둔다.
//   (창은 늘 전부 보내므로 화면에서는 통째로 덮어쓰는 것과 같다.)
app.MapPut("/api/rows", async (PgPool db, IpGate g, HttpContext ctx, JsonElement body) =>
{
    if (!IsSuper(await g.CheckAsync(ctx)))
        return Results.Json(new { error = "대상 수정은 Super 권한만 할 수 있습니다." }, statusCode: 403);

    if (!body.TryGetProperty("row_uid", out var uidEl) || !uidEl.TryGetInt64(out var uid))
        return Results.BadRequest(new { error = "어느 줄인지 가리는 row_uid 가 필요합니다." });
    if (!body.TryGetProperty("values", out var valEl) || valEl.ValueKind != JsonValueKind.Object)
        return Results.BadRequest(new { error = "고칠 값(values)이 없습니다." });

    string? Of(JsonElement e, string k) =>
        e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String
            ? (string.IsNullOrWhiteSpace(v.GetString()) ? null : v.GetString()!.Trim())
            : null;

    var found = await db.QueryAsync(
        "select activity_id, systemcode, menu_nm from public.hhip_wbs_wrk2 where row_uid = $1::bigint", [uid]);
    if (found.Count == 0) return Results.NotFound(new { error = "고칠 대상을 찾지 못했습니다." });

    // 필수 둘은 비울 수 없다 — 모듈별 집계와 목록 표시가 이 둘로 돌아간다
    var newSys = valEl.TryGetProperty("systemcode", out _) ? Of(valEl, "systemcode") : (string?)found[0]["systemcode"];
    var newMenu = valEl.TryGetProperty("menu_nm", out _) ? Of(valEl, "menu_nm") : (string?)found[0]["menu_nm"];
    var missing = new List<string>();
    if (newSys is null) missing.Add("systemcode");
    if (newMenu is null) missing.Add("menu_nm");
    if (missing.Count > 0)
        return Results.BadRequest(new { error = "필수 항목은 비울 수 없습니다.", missing });

    // 모듈·메뉴명이 겹치면 막는다 (자기 자신은 뺀다). 사람이 목록에서 두 줄을 구별하는
    // 유일한 표시라 겹치면 어느 쪽을 고치는지 알 수 없다.
    if (newSys != (string?)found[0]["systemcode"] || newMenu != (string?)found[0]["menu_nm"])
    {
        var clash = await db.QueryAsync("""
            select activity_id from public.hhip_wbs_wrk2
             where systemcode = $1::text and menu_nm = $2::text and row_uid <> $3::bigint
             limit 1
            """, [newSys, newMenu, uid]);
        if (clash.Count > 0)
            return Results.Conflict(new { error = $"같은 모듈에 같은 메뉴명이 이미 있습니다 — {newSys} · {newMenu}" });
    }

    // activity_id 는 여기서 바꾸지 않는다. ProjectView 캐시·일감이 그 값을 가리키고 있어
    // 조용히 바꾸면 둘 다 길을 잃는다. 비어 있는 줄에 채우는 것만 따로 둔다
    // (PUT /api/rows/activity-id). 첨부는 row_uid 를 쓰므로 영향이 없다.
    var sets = new List<string>();
    var uargs = new List<object?>();
    foreach (var p in valEl.EnumerateObject())
    {
        var col = p.Name.ToLowerInvariant();
        if (col == "activity_id" || col == "row_uid" || !insertable.Contains(col)) continue;
        if (sets.Any(s => s.StartsWith(col + " ="))) continue;

        object? val = p.Value.ValueKind switch
        {
            JsonValueKind.Null => null,
            JsonValueKind.Number => p.Value.GetDouble(),
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            _ => p.Value.GetString()?.Trim()
        };
        if (val is string s && s.Length == 0) val = null;

        uargs.Add(val);
        sets.Add($"{col} = ${uargs.Count}{(insertDateCols.Contains(col) ? "::date" : "::text")}");
    }
    if (sets.Count == 0) return Results.BadRequest(new { error = "고칠 수 있는 컬럼이 없습니다." });

    uargs.Add(uid);
    var n = await db.ExecuteAsync(
        $"update public.hhip_wbs_wrk2 set {string.Join(", ", sets)} where row_uid = ${uargs.Count}::bigint",
        [.. uargs]);
    return Results.Ok(new
    {
        updated = n, row_uid = uid, activity_id = found[0]["activity_id"],
        systemcode = newSys, menu_nm = newMenu,
    });
});

// 나중에 확정된 Activity ID 를 채운다 — 상세 목록의 Activity ID 칸 [＋ ID] 가 부른다.
//
// 왜 PATCH /api/rows/{activityId} 를 못 쓰나: 그 경로는 activity_id 로 행을 찾는다.
// 아직 그 값이 없는 줄에는 쓸 손잡이가 없어 row_uid 로 집는다.
//
// 이미 ID 가 있는 줄은 건드리지 않는다. 바꿔치기는 ProjectView 캐시·일감이 가리키던 곳을
// 통째로 옮기는 일이라, 이 화면에서 조용히 할 일이 아니다.
app.MapPut("/api/rows/activity-id", async (PgPool db, IpGate g, HttpContext ctx, JsonElement body) =>
{
    if (!IsSuper(await g.CheckAsync(ctx)))
        return Results.Json(new { error = "Activity ID 지정은 Super 권한만 할 수 있습니다." }, statusCode: 403);

    var activityId = body.TryGetProperty("activity_id", out var a) && a.ValueKind == JsonValueKind.String
        ? (string.IsNullOrWhiteSpace(a.GetString()) ? null : a.GetString()!.Trim()) : null;
    if (activityId is null) return Results.BadRequest(new { error = "activity_id 가 필요합니다." });
    if (!body.TryGetProperty("row_uid", out var uidEl) || !uidEl.TryGetInt64(out var uid))
        return Results.BadRequest(new { error = "어느 줄인지 가리는 row_uid 가 필요합니다." });

    var dup = await db.QueryAsync(
        "select activity_id from public.hhip_wbs_wrk2 where upper(activity_id) = upper($1::text) limit 1",
        [activityId]);
    if (dup.Count > 0)
        return Results.Conflict(new { error = $"이미 있는 Activity ID 입니다 — {dup[0]["activity_id"]}" });

    var n = await db.ExecuteAsync("""
        update public.hhip_wbs_wrk2
           set activity_id = $1::text
         where row_uid = $2::bigint and coalesce(activity_id, '') = ''
        """, [activityId, uid]);
    return n > 0
        ? Results.Ok(new { updated = n, row_uid = uid, activity_id = activityId })
        : Results.NotFound(new { error = "Activity ID 가 비어 있는 그 줄을 찾지 못했습니다 (이미 채워졌을 수 있습니다)." });
});

// ---------- 대상 한 줄 지우기 ----------
//
// 지우기 전에 <무엇이 딸려 있는지> 세어 준다. 대상 수정 창이 삭제 단추를 누르기 전에
// 이것을 불러 보여 준다 — 되돌릴 수 없는 일이라, 무엇이 함께 사라지는지 먼저 보여야 한다.
//
// 딸린 것 셋을 서로 다르게 다루는 까닭:
//   첨부(row_uid)     그 줄만의 것이다. 함께 치운다.
//   일감(activity_id) activity_id 는 이 표에서 <겹칠 수 있다> — 화면 단위 표라 같은
//                     액티비티에 화면이 여럿 달린다(db/pv_cache.sql 의 "Dup" 주석).
//                     같은 ID 를 쓰는 다른 줄이 남아 있으면 그 일감은 그 줄 것이기도
//                     하므로 건드리지 않는다. 혼자 쓰던 ID 일 때만 함께 지운다.
//   ProjectView 캐시  다시 받으면 되는 사본이라 손대지 않는다.
static async Task<(Dictionary<string, object?>? row, int tasks, int siblings, int files, string? dir)>
    RowDepsAsync(PgPool db, IWebHostEnvironment env, long uid)
{
    var found = await db.QueryAsync("select * from public.hhip_wbs_wrk2 where row_uid = $1::bigint", [uid]);
    if (found.Count == 0) return (null, 0, 0, 0, null);
    var row = found[0];
    var aid = row.TryGetValue("activity_id", out var a) ? a as string : null;

    var tasks = 0;
    var siblings = 0;
    if (!string.IsNullOrWhiteSpace(aid))
    {
        var t = await db.QueryAsync(
            "select count(*)::int as n from public.hhip_wbs_task where activity_id = $1::text", [aid]);
        tasks = Convert.ToInt32(t[0]["n"]);
        var s = await db.QueryAsync("""
            select count(*)::int as n from public.hhip_wbs_wrk2
             where activity_id = $1::text and row_uid <> $2::bigint
            """, [aid, uid]);
        siblings = Convert.ToInt32(s[0]["n"]);
    }

    var dir = Path.Combine(RowFiles.Root(env), uid.ToString());
    var files = Directory.Exists(dir) ? Directory.GetFiles(dir).Length : 0;
    return (row, tasks, siblings, files, dir);
}

app.MapGet("/api/rows/{rowUid:long}/deps", async (PgPool db, IWebHostEnvironment env, long rowUid) =>
{
    var (row, tasks, siblings, files, _) = await RowDepsAsync(db, env, rowUid);
    if (row is null) return Results.NotFound(new { error = "그 줄을 찾지 못했습니다." });
    return Results.Ok(new
    {
        row_uid = rowUid,
        activity_id = row.TryGetValue("activity_id", out var a) ? a : null,
        systemcode = row.TryGetValue("systemcode", out var s) ? s : null,
        menu_nm = row.TryGetValue("menu_nm", out var m) ? m : null,
        files,
        tasks,
        siblings,                      // 같은 activity_id 를 쓰는 다른 줄
        tasks_kept = siblings > 0,     // 그 줄들 것이기도 하므로 일감은 남긴다
    });
});

// 진짜로 지운다 — 대상 수정 창의 [삭제] 가 부른다. <b>Super 만.</b>
//
// ⚠️ 이 표에는 지운 표시(soft delete) 칸이 없다. 넣으려면 목록·집계·엑셀 동기화의 모든
//    질의에 조건을 더해야 하는데, 한 곳만 빠뜨리면 지운 줄이 조용히 되살아난다. 그래서
//    행은 정말로 지우되 <되돌릴 거리>를 먼저 남긴다 (api/data/deleted_rows/):
//      {row_uid}_{시각}.json    그 줄의 모든 칸 + 함께 지운 일감
//      {row_uid}_{시각}_files/  첨부 폴더를 지우지 않고 통째로 옮겨 둔 것
//    되돌리기 단추는 두지 않았다 — 쓸 일이 드물고, 단추를 두면 그것도 맞는지 돌봐야 한다.
app.MapDelete("/api/rows/{rowUid:long}", async (PgPool db, IpGate g, HttpContext ctx, IWebHostEnvironment env, long rowUid) =>
{
    var me = await g.CheckAsync(ctx);
    if (!IsSuper(me))
        return Results.Json(new { error = "대상 삭제는 Super 권한만 할 수 있습니다." }, statusCode: 403);

    var (row, tasks, siblings, files, dir) = await RowDepsAsync(db, env, rowUid);
    if (row is null) return Results.NotFound(new { error = "지울 대상을 찾지 못했습니다." });

    var aid = row.TryGetValue("activity_id", out var a0) ? a0 as string : null;
    var dropTasks = tasks > 0 && siblings == 0;

    // 1) 되돌릴 거리를 먼저 남긴다. 이게 실패하면 지우지 않는다 —
    //    백업이 없는 채로 지우느니 지우지 못하는 편이 낫다.
    var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
    var bakDir = Path.Combine(env.ContentRootPath, "data", "deleted_rows");
    var bakFile = Path.Combine(bakDir, $"{rowUid}_{stamp}.json");
    var bakFiles = Path.Combine(bakDir, $"{rowUid}_{stamp}_files");
    try
    {
        Directory.CreateDirectory(bakDir);
        var taskRows = dropTasks
            ? await db.QueryAsync("select * from public.hhip_wbs_task where activity_id = $1::text", [aid])
            : [];
        await File.WriteAllTextAsync(bakFile, JsonSerializer.Serialize(new
        {
            deleted_at = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
            deleted_by = me.Name ?? me.BpId,
            row,
            tasks = taskRows,
            note = dropTasks ? null : (siblings > 0 ? $"같은 activity_id 를 쓰는 줄이 {siblings}개 남아 일감은 그대로 두었습니다." : null),
        }, new JsonSerializerOptions { WriteIndented = true, Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping }));
    }
    catch (Exception e)
    {
        return Results.Json(new { error = $"되돌릴 자료를 남기지 못해 지우지 않았습니다 — {e.Message}" }, statusCode: 500);
    }

    // 2) 첨부는 지우지 않고 옮긴다 (되돌릴 거리의 나머지 반쪽)
    var movedFiles = 0;
    if (files > 0 && dir is not null)
    {
        try { Directory.Move(dir, bakFiles); movedFiles = files; }
        catch (Exception e) { Console.WriteLine($"[rows/delete] 첨부 옮기기 실패 uid={rowUid}: {e.Message}"); }
    }

    // 3) 일감 — 혼자 쓰던 activity_id 일 때만
    var delTasks = dropTasks
        ? await db.ExecuteAsync("delete from public.hhip_wbs_task where activity_id = $1::text", [aid])
        : 0;

    // 4) 그 줄
    var n = await db.ExecuteAsync("delete from public.hhip_wbs_wrk2 where row_uid = $1::bigint", [rowUid]);

    // 되돌릴 수 없는 일이다 — 누가 언제 무엇을 지웠는지 반드시 남긴다
    Console.WriteLine($"[rows/delete] {DateTime.Now:HH:mm:ss} uid={rowUid} aid={aid ?? "-"}"
                    + $" menu={row.GetValueOrDefault("menu_nm")} tasks={delTasks} files={movedFiles}"
                    + $" by={me.Name ?? me.BpId} bak={Path.GetFileName(bakFile)}");

    return Results.Ok(new
    {
        deleted = n,
        row_uid = rowUid,
        activity_id = aid,
        menu_nm = row.GetValueOrDefault("menu_nm"),
        tasks = delTasks,
        tasks_kept = !dropTasks && tasks > 0 ? tasks : 0,
        files = movedFiles,
        backup = Path.GetFileName(bakFile),
    });
});

app.MapPatch("/api/rows/{activityId}", async (PgPool db, string activityId, JsonElement body) =>
{
    var sets = new List<string>();
    var args = new List<object?>();
    foreach (var p in body.EnumerateObject())
    {
        if (!editable.Contains(p.Name)) continue;
        object? val = p.Value.ValueKind switch
        {
            JsonValueKind.Null => null,
            JsonValueKind.Number => p.Value.GetDouble(),
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            _ => p.Value.GetString()
        };
        if (val is string s && string.IsNullOrWhiteSpace(s)) val = null;

        args.Add(val);
        var cast = dateCols.Contains(p.Name) ? "::date" : "::text";
        sets.Add($"{p.Name.ToLowerInvariant()} = ${args.Count}{cast}");
    }
    if (sets.Count == 0) return Results.BadRequest(new { error = "수정 가능한 컬럼이 없습니다." });

    args.Add(activityId);
    var n = await db.ExecuteAsync(
        $"update public.hhip_wbs_wrk2 set {string.Join(", ", sets)} where activity_id = ${args.Count}",
        [.. args]);
    return n > 0 ? Results.Ok(new { updated = n }) : Results.NotFound(new { error = "대상 없음", activityId });
});

// SPA 폴백 (wwwroot/index.html 이 있을 때만)
app.MapFallback((HttpContext ctx) =>
{
    var index = Path.Combine(app.Environment.WebRootPath ?? "wwwroot", "index.html");
    if (!File.Exists(index))
        return Results.NotFound(new { error = "프론트가 빌드되지 않았습니다. web 에서 `npm run build` 를 실행하세요." });
    ctx.Response.Headers.CacheControl = "no-cache, no-store, must-revalidate";
    return Results.File(index, "text/html");
});

// 기동 배너 — 콘솔 창이 "빌드하는 중..." 에서 멈춘 것처럼 보이지 않도록 준비 완료를 알린다
app.Lifetime.ApplicationStarted.Register(() =>
{
    var opt = PgOptions.Parse(cs);
    Console.WriteLine();
    Console.WriteLine("  ┌─ WBS 대시보드 API 준비 완료 ──────────────────────────");
    Console.WriteLine($"  │  UI/API : http://localhost:5080   (LAN: http://{LanIp()}:5080)");
    Console.WriteLine($"  │  DB     : {opt.Host}:{opt.Port}/{opt.Database} ({opt.User})");
    Console.WriteLine( "  │  접근제어: dev_user.use_ip 등록 IP 만 허용");
    Console.WriteLine( "  └───────────────────────────  종료: Ctrl+C ─────────────");
    Console.WriteLine();
});

app.Run();

static string? Nz(string? s) => string.IsNullOrWhiteSpace(s) ? null : s;

// 배너에 보여줄 사설망 IPv4 주소
static string LanIp()
{
    try
    {
        foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
        {
            if (ni.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up) continue;
            foreach (var a in ni.GetIPProperties().UnicastAddresses)
                if (a.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork
                    && !System.Net.IPAddress.IsLoopback(a.Address))
                    return a.Address.ToString();
        }
    }
    catch { }
    return "127.0.0.1";
}
