import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;

/**
 * 수빅 DB(ORAHHIP · M10) 연결을 <b>붙잡고 사는</b> 작은 상주 프로그램.
 * 대시보드 API 가 뜰 때 함께 떠서, 꺼질 때까지 커넥션을 쥐고 명령을 받는다.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * <b>왜 상주인가 — 이것이 이 기능의 핵심이다.</b>
 * 예전처럼 부를 때마다 새로 붙으면, <b>정작 필요한 순간에 못 붙는다.</b>
 * processes 한도가 차 있을 때(317/320) 새 접속은 ORA-12516/12519 로 거절당하는데,
 * 세션 정리가 필요한 때가 바로 그때다. 미리 한 자리를 잡아 두면 그 상황에서도 들어가 있다.
 *
 * <b>그래서 연결을 놓치면 끈질기게 다시 잡는다.</b> 심장박동(heartbeat)으로 살아 있는지
 * 계속 확인하고, 끊겼으면 될 때까지 다시 붙는다. 자리가 없으면 몇 초 뒤 또 두드린다 —
 * 포기하면 그 뒤로는 영영 못 들어간다.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * <b>주고받는 법</b> — 한 줄에 명령 하나, 한 줄에 JSON 답 하나.
 *   status
 *   scan  idle=3600 bponly=true keepteam=true keep=BP1,BP2 limit=50
 *   sweep idle=3600 bponly=true keepteam=true keep=BP1,BP2 limit=50 only=123,456
 *   locpor    q=J015 limit=200
 *   locporlog ifseq=CZ_CS_PD_... limit=30
 *   locporrun   ifseq=CZ_CS_PD_... by=홍길동
 *   locporscope ifseq=CZ_... | scope=shippor ship=J015 por=AA04   (세기만 한다)
 *   locporwipe  scope=shippor ship=J015 por=AA04 part=core|biz|all by=홍길동
 *   locporwipe  ifseq=CZ_... | scope=shippor ship=J015 por=AA04 by=홍길동 (지운다)
 *
 * ⚠️ 값에 <b>빈칸이 들어가면 안 된다</b> — 한 줄을 공백으로 쪼개 key=value 로 읽기 때문이다.
 * 빈칸이 섞이면 뒷부분이 통째로 버려지는데 <b>오류가 나지 않는다.</b> 보내는 쪽(api/LocPor.cs)
 * 에서 미리 걸러 낸다.
 *
 * <b>⚠️ SQL 은 여기 박혀 있다. 바깥에서 문장을 받지 않는다.</b>
 * 이 프로그램은 ALTER SYSTEM 권한으로 돈다. 문장을 받게 만들면 그 권한으로 무엇이든
 * 돌릴 수 있는 구멍이 된다. 밖에서 정하는 것은 <얼마나 묵었나 · 누구를 뺄까 · 몇 개까지> 뿐이다.
 */
public class OraPool {

    /** 어떤 설정을 주든 늘 빼는 계정. */
    static final String[] ALWAYS_KEEP_USER = { "SYS", "SYSTEM", "DBSNMP", "SYSMAN" };

    static String url, user, pw;
    static int size = 2, beat = 20;

    /** 쥐고 있는 커넥션들. null 이면 그 자리는 비어 있다(= 다시 붙어야 한다). */
    static final Connection[] slots = new Connection[8];
    static final boolean[] everOk = new boolean[8];
    static volatile String lastErr = "";
    static volatile long lastOkAt = 0, lastTryAt = 0;
    static volatile int reconnects = 0;

    public static void main(String[] args) throws Exception {
        Map<String, String> a = new HashMap<>();
        for (int i = 0; i < args.length - 1; i++)
            if (args[i].startsWith("--")) a.put(args[i].substring(2), args[i + 1]);
        url = a.get("url");
        user = a.get("user");
        pw = a.get("pw");
        size = Math.max(1, Math.min(8, num(a.get("size"), 2)));
        beat = Math.max(5, Math.min(300, num(a.get("heartbeat"), 20)));

        Class.forName("oracle.jdbc.OracleDriver");
        DriverManager.setLoginTimeout(8);

        // 심장박동 — 살아 있는지 보고, 끊겼으면 다시 붙는다. 이 일만 하는 실이 따로 돈다.
        Thread hb = new Thread(() -> {
            while (true) {
                try { heal(); } catch (Throwable ignored) { }
                try { Thread.sleep(beat * 1000L); } catch (InterruptedException e) { return; }
            }
        });
        hb.setDaemon(true);
        hb.start();
        heal();   // 뜨자마자 한 번 — 자리가 있을 때 미리 잡아 둔다

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        PrintStream out = new PrintStream(new FileOutputStream(FileDescriptor.out), true, "UTF-8");
        out.println("{\"ready\":true}");
        String line;
        while ((line = in.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;
            try { out.println(handle(line)); }
            catch (Throwable e) { out.println("{\"ok\":false,\"error\":" + q(oneLine(e.toString())) + "}"); }
        }
    }

    /** 빈 자리를 채우고, 죽은 것을 걷어낸다. */
    static synchronized void heal() {
        lastTryAt = System.currentTimeMillis();
        for (int i = 0; i < size; i++) {
            if (slots[i] != null) {
                if (alive(slots[i])) { lastOkAt = System.currentTimeMillis(); continue; }
                // 죽었다 — 닫고 자리를 비운다. 바로 아래에서 다시 붙는다.
                try { slots[i].close(); } catch (SQLException ignored) { }
                slots[i] = null;
                if (everOk[i]) reconnects++;
            }
            try {
                slots[i] = DriverManager.getConnection(url, user, pw);
                slots[i].setAutoCommit(true);
                everOk[i] = true;
                lastOkAt = System.currentTimeMillis();
                lastErr = "";
            } catch (SQLException e) {
                // 자리가 없어 거절당한 것이 보통이다. 다음 심장박동에 또 두드린다 — 포기하지 않는다.
                lastErr = oneLine(e.getMessage());
                slots[i] = null;
            }
        }
    }

    static boolean alive(Connection c) {
        try (Statement s = c.createStatement()) {
            s.setQueryTimeout(5);
            try (ResultSet r = s.executeQuery("select 1 from dual")) { return r.next(); }
        } catch (Throwable e) { return false; }
    }

    /** 지금 쓸 수 있는 커넥션 하나. 없으면 즉석에서 한 번 더 붙어 본다. */
    static synchronized Connection take() {
        for (int i = 0; i < size; i++) if (slots[i] != null && alive(slots[i])) return slots[i];
        heal();
        for (int i = 0; i < size; i++) if (slots[i] != null) return slots[i];
        return null;
    }

    static synchronized int live() {
        int n = 0;
        for (int i = 0; i < size; i++) if (slots[i] != null) n++;
        return n;
    }

    static String handle(String line) {
        String[] p = line.split("\\s+");
        String cmd = p[0];
        Map<String, String> o = new HashMap<>();
        for (int i = 1; i < p.length; i++) {
            int k = p[i].indexOf('=');
            if (k > 0) o.put(p[i].substring(0, k), p[i].substring(k + 1));
        }
        if (cmd.equals("status")) return status(null);
        if (cmd.equals("users")) return users();
        if (cmd.equals("killuser")) return killUser(o.get("osuser"));
        if (cmd.equals("tables")) return tables(o.get("owner"), o.get("q"), num(o.get("limit"), 300));
        if (cmd.equals("owners")) return owners(o.get("names"));
        if (cmd.equals("procs")) return procs(o.get("owner"), o.get("q"), num(o.get("limit"), 300));
        // 현지 POR I/F 후행처리 화면 — 목록·이력은 읽기만.
        // DB 를 바꾸는 것은 셋뿐이다 — locporrun(전개) · locporpo([3320] 흘리기) · locporwipe(지우기).
        if (cmd.equals("locpor")) return locpor(o.get("q"), num(o.get("limit"), 200));
        if (cmd.equals("locporlog")) return locporLog(o.get("ifseq"), num(o.get("limit"), 30));
        if (cmd.equals("locporrun")) return locporRun(o.get("ifseq"), o.get("by"));
        // [3320] 승인완료 직전까지 흘리기 — 고른 줄의 (호선 · POR · 라인) 하나로 부른다.
        // ⚠️ 이것도 DB 를 바꾼다. locporrun 과 달리 <업무 단계를 앞으로 민다>.
        if (cmd.equals("locporpo"))
            return locporPo(o.get("ship"), o.get("por"), o.get("seq"), o.get("by"));
        // 전개분 되돌리기 — scope 는 세기만 하고, wipe 만 지운다
        // scope=ifseq (한 묶음) · scope=shippor (그 POR 통째). 안 주면 예전처럼 ifseq.
        // biz=true 면 PO 뒤 업무로 생긴 것(견적·회신·변경이력)까지 범위에 넣는다.
        // 호선+POR 범위에서만 뜻이 있다 — IFSEQ 로는 짚을 근거가 없다(bizPlan 주석).
        if (cmd.equals("locporscope"))
            return locporScope(o.getOrDefault("scope", M_IFSEQ),
                               o.get("ifseq"), o.get("ship"), o.get("por"));
        if (cmd.equals("locporwipe"))
            return locporWipe(o.getOrDefault("scope", M_IFSEQ),
                              o.get("ifseq"), o.get("ship"), o.get("por"), o.get("by"),
                              o.getOrDefault("part", P_CORE));
        if (!cmd.equals("scan") && !cmd.equals("sweep"))
            return "{\"ok\":false,\"error\":\"모르는 명령: " + cmd + "\"}";

        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";

        boolean sweep = cmd.equals("sweep");
        int idle = num(o.get("idle"), 3600);
        int limit = Math.max(1, Math.min(500, num(o.get("limit"), 50)));
        boolean bpOnly = !"false".equalsIgnoreCase(String.valueOf(o.getOrDefault("bponly", "true")));
        // 개발팀을 뺄지 — 끄면 개발팀 세션도 정리 대상이 된다 (화면에서 끄고 켠다)
        boolean keepTeam = !"false".equalsIgnoreCase(String.valueOf(o.getOrDefault("keepteam", "true")));
        String only = o.get("only");
        List<String> keep = new ArrayList<>();
        if (keepTeam && o.get("keep") != null)
            for (String s : o.get("keep").split(",")) if (!s.trim().isEmpty()) keep.add(s.trim().toUpperCase());

        try {
            StringBuilder sql = new StringBuilder(
                  "select s.sid, s.serial#, s.username, s.osuser, s.machine, s.program,"
                + "       s.logon_time, s.last_call_et,"
                // 그 사번이 지금 <몇 자리를 쥐고 있나>. 정리하면 몇이 비는지 가늠하려면 이것이 있어야 한다 —
                // 한 사람이 PL/SQL Developer 로 열 자리를 물고 있는 일이 흔하다.
                + "       (select count(*) from v$session x"
                + "         where x.osuser = s.osuser and x.type='USER' and x.username is not null) as procs,"
                // 그중 이번에 걸린 수 (같은 조건 안에서)
                + "       count(*) over (partition by s.osuser) as tgt"
                + "  from v$session s"
                + " where s.type='USER' and s.username is not null and s.status='INACTIVE'"
                + "   and s.last_call_et > ?"
                + "   and s.sid <> sys_context('USERENV','SID')"
                + "   and s.username not in (" + marks(ALWAYS_KEEP_USER.length) + ")");
            if (bpOnly) sql.append(" and s.osuser like 'BP%'");
            if (!keep.isEmpty()) sql.append(" and s.osuser not in (").append(marks(keep.size())).append(")");
            // ⚠️ 이 줄은 반드시 keep 뒤에 붙인다. ? 는 <SQL 에 나온 차례>대로 채워지므로
            //    앞에 끼우면 sid 자리에 사번이 들어가 엉뚱한 세션을 고른다 — 오류 없이 조용히 틀린다.
            boolean one = only != null && only.matches("\\d+,\\d+");
            if (one) sql.append(" and s.sid = ? and s.serial# = ?");
            sql.append(" order by s.last_call_et desc");

            List<long[]> ids = new ArrayList<>();
            StringBuilder rows = new StringBuilder();
            try (PreparedStatement ps = c.prepareStatement(sql.toString())) {
                int i = 1;
                ps.setInt(i++, idle);
                for (String k : ALWAYS_KEEP_USER) ps.setString(i++, k);
                for (String k : keep) ps.setString(i++, k);
                if (one) {
                    String[] t = only.split(",");
                    ps.setLong(i++, Long.parseLong(t[0]));
                    ps.setLong(i++, Long.parseLong(t[1]));
                }
                try (ResultSet r = ps.executeQuery()) {
                    while (r.next() && ids.size() < limit) {
                        long sid = r.getLong(1), ser = r.getLong(2);
                        ids.add(new long[] { sid, ser });
                        if (rows.length() > 0) rows.append(',');
                        rows.append("{\"sid\":").append(sid)
                            .append(",\"serial\":").append(ser)
                            .append(",\"username\":").append(q(r.getString(3)))
                            .append(",\"osuser\":").append(q(r.getString(4)))
                            .append(",\"machine\":").append(q(r.getString(5)))
                            .append(",\"program\":").append(q(r.getString(6)))
                            .append(",\"logon\":").append(q(String.valueOf(r.getTimestamp(7))))
                            .append(",\"idle\":").append(r.getLong(8))
                            .append(",\"procs\":").append(r.getLong(9))
                            .append(",\"tgt\":").append(r.getLong(10))
                            .append('}');
                    }
                }
            }

            StringBuilder killed = new StringBuilder();
            int okCnt = 0, failCnt = 0;
            if (sweep) {
                for (long[] id : ids) {
                    // ⚠️ KILL 이 아니라 DISCONNECT ... IMMEDIATE 다.
                    //    KILL 은 세션만 죽이고 전용서버 프로세스를 남겨 processes 가 안 풀린다.
                    String stmt = "alter system disconnect session '" + id[0] + "," + id[1] + "' immediate";
                    String err = null;
                    try (Statement s = c.createStatement()) { s.execute(stmt); okCnt++; }
                    catch (SQLException e) { err = oneLine(e.getMessage()); failCnt++; }
                    if (killed.length() > 0) killed.append(',');
                    killed.append("{\"sid\":").append(id[0]).append(",\"serial\":").append(id[1])
                          .append(",\"ok\":").append(err == null)
                          .append(",\"error\":").append(err == null ? "null" : q(err)).append('}');
                }
            }

            long total = 0, inactive = 0, procCur = 0, procMax = 0;
            try (Statement s = c.createStatement();
                 ResultSet r = s.executeQuery("select count(*) t,"
                     + " sum(case when status='INACTIVE' then 1 else 0 end) i from v$session where type='USER'")) {
                if (r.next()) { total = r.getLong(1); inactive = r.getLong(2); }
            } catch (SQLException ignored) { }
            try (Statement s = c.createStatement();
                 ResultSet r = s.executeQuery("select current_utilization, limit_value from v$resource_limit"
                     + " where resource_name='processes'")) {
                if (r.next()) { procCur = r.getLong(1); procMax = parse(r.getString(2)); }
            } catch (SQLException ignored) { }

            String extra = ",\"mode\":" + q(sweep ? "sweep" : "scan")
                 + ",\"total\":" + total + ",\"inactive\":" + inactive
                 + ",\"proc_cur\":" + procCur + ",\"proc_max\":" + procMax
                 + ",\"idle\":" + idle + ",\"limit\":" + limit
                 + ",\"bponly\":" + bpOnly + ",\"keepteam\":" + keepTeam
                 + ",\"found\":" + ids.size() + ",\"ok_cnt\":" + okCnt + ",\"fail_cnt\":" + failCnt
                 + ",\"candidates\":[" + rows + "]"
                 + ",\"killed\":[" + killed + "]";
            return status(extra);
        } catch (SQLException e) {
            // 쿼리 도중 끊겼을 수 있다 — 다음 심장박동이 다시 붙인다
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0) + ",\"live\":" + live()
                 + ",\"error\":" + q(lastErr) + "}";
        }
    }

    /**
     * 사번(osuser) 별 자리 차지 현황 — <b>조건을 하나도 걸지 않는다.</b>
     * 정리 대상 목록은 <끊을 것>을 고르는 자리고, 이것은 <지금 누가 얼마나 쓰고 있나>를
     * 통째로 보는 자리다. 여기에 BP 필터나 유휴시간을 걸면 "308 중 8" 만 보여 주게 되어
     * 정작 알고 싶은 <한 사람이 몇 자리를 물고 있나>가 가려진다.
     */
    static String users() {
        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";
        try {
            long total = 0, procCur = 0, procMax = 0;
            StringBuilder rows = new StringBuilder();
            try (Statement s = c.createStatement();
                 ResultSet r = s.executeQuery(
                     "select osuser,"
                   + "       count(*) procs,"
                   + "       sum(case when status='ACTIVE' then 1 else 0 end) act,"
                   + "       sum(case when status='INACTIVE' then 1 else 0 end) ina,"
                   + "       max(last_call_et) maxidle,"
                   + "       min(last_call_et) minidle,"
                   + "       count(distinct username) unames,"
                   + "       min(username) auser,"
                   + "       min(program) prog,"
                   + "       min(machine) mach"
                   + "  from v$session"
                   + " where type='USER' and username is not null"
                   + " group by osuser"
                   + " order by count(*) desc, osuser")) {
                while (r.next()) {
                    long n = r.getLong(2);
                    total += n;
                    if (rows.length() > 0) rows.append(',');
                    rows.append("{\"osuser\":").append(q(r.getString(1)))
                        .append(",\"procs\":").append(n)
                        .append(",\"act\":").append(r.getLong(3))
                        .append(",\"ina\":").append(r.getLong(4))
                        .append(",\"maxidle\":").append(r.getLong(5))
                        .append(",\"minidle\":").append(r.getLong(6))
                        .append(",\"unames\":").append(r.getLong(7))
                        .append(",\"username\":").append(q(r.getString(8)))
                        .append(",\"program\":").append(q(r.getString(9)))
                        .append(",\"machine\":").append(q(r.getString(10)))
                        .append('}');
                }
            }
            try (Statement s = c.createStatement();
                 ResultSet r = s.executeQuery("select current_utilization, limit_value"
                   + " from v$resource_limit where resource_name='processes'")) {
                if (r.next()) { procCur = r.getLong(1); procMax = parse(r.getString(2)); }
            } catch (SQLException ignored) { }

            return status(",\"mode\":\"users\",\"total\":" + total
                 + ",\"proc_cur\":" + procCur + ",\"proc_max\":" + procMax
                 + ",\"users\":[" + rows + "]");
        } catch (SQLException e) {
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0) + ",\"error\":" + q(lastErr) + "}";
        }
    }

    /**
     * 한 스키마의 <b>테이블 목록</b>. 계통도 화면이 <무엇을 놓을지> 고를 때 쓴다.
     *
     * <b>왜 데몬이 하는가.</b> 지금 이 DB 는 processes 가 차 있어 <b>새 접속이 거절된다</b>
     * ("Got minus one from a read call"). 그래서 한 번 잡아 둔 이 연결로만 물을 수 있다 —
     * 목록 하나 보자고 따로 붙는 길은 <b>필요한 순간에 안 열린다.</b>
     *
     * <b>읽기만 한다.</b> owner 와 검색어는 바인드로 넘긴다 — 글자로 이어 붙이면
     * 목록 조회 창이 그대로 임의 SQL 창이 된다.
     */
    static String tables(String owner, String filter, int limit) {
        String own = (owner == null || owner.isEmpty() ? "M20" : owner).toUpperCase();
        String kw = (filter == null ? "" : filter.trim()).toUpperCase();
        int lim = Math.max(1, Math.min(2000, limit));

        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";
        try {
            // all_tab_comments 를 함께 읽는다 — 이름만으로는 무슨 표인지 모르는 것이 많다.
            // num_rows 는 통계값이라 실제와 다를 수 있다(화면에서 <어림>이라고 밝힌다).
            String sql =
                "select * from ("
              + "  select t.table_name, c.comments, t.num_rows"
              + "    from all_tables t"
              + "    left join all_tab_comments c"
              + "      on c.owner = t.owner and c.table_name = t.table_name"
              + "   where t.owner = ?"
              + "     and (? = '' or upper(t.table_name) like '%' || ? || '%'"
              + "          or upper(nvl(c.comments,'')) like '%' || ? || '%')"
              + "   order by t.table_name"
              + ") where rownum <= ?";
            StringBuilder rows = new StringBuilder();
            int n = 0;
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, own);
                ps.setString(2, kw);
                ps.setString(3, kw);
                ps.setString(4, kw);
                ps.setInt(5, lim);
                try (ResultSet r = ps.executeQuery()) {
                    while (r.next()) {
                        if (rows.length() > 0) rows.append(',');
                        rows.append("{\"name\":").append(q(r.getString(1)))
                            .append(",\"comment\":").append(q(r.getString(2)))
                            .append(",\"rows\":").append(r.getObject(3) == null ? "null" : r.getLong(3))
                            .append('}');
                        n++;
                    }
                }
            }
            return status(",\"mode\":\"tables\",\"owner\":" + q(own)
                 + ",\"q\":" + q(kw) + ",\"count\":" + n
                 + ",\"more\":" + (n >= lim)
                 + ",\"tables\":[" + rows + "]");
        } catch (SQLException e) {
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0) + ",\"error\":" + q(lastErr) + "}";
        }
    }

    /**
     * 한 스키마의 <b>패키지·프로시저</b> 목록. 계통도에 "무엇이 이 표를 쓰는가" 를 함께
     * 그려 두려고 쓴다 — 원본 데이터의 <쓰기 주체>(P_30B1110_1.SAVE_POR_INFO 같은 것)와
     * 같은 종류의 것이다.
     *
     * <c>all_procedures</c> 는 패키지 안의 프로시저와 홀로 선 프로시저를 함께 담는다.
     * 패키지 안의 것은 object_name=패키지 · procedure_name=프로시저,
     * 홀로 선 것은 procedure_name 이 비어 있고 object_name 이 곧 이름이다.
     * 종류(PACKAGE·PROCEDURE·FUNCTION)는 all_objects 에서 가져온다.
     */
    static String procs(String owner, String filter, int limit) {
        String own = (owner == null || owner.isEmpty() ? "M20" : owner).toUpperCase();
        String kw = (filter == null ? "" : filter.trim()).toUpperCase();
        int lim = Math.max(1, Math.min(2000, limit));

        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";
        try {
            String sql =
                "select * from ("
              + "  select p.object_name, nvl(p.procedure_name,' ') pname, o.object_type"
              + "    from all_procedures p"
              + "    join all_objects o"
              + "      on o.owner = p.owner and o.object_name = p.object_name"
              + "     and o.object_type in ('PACKAGE','PROCEDURE','FUNCTION')"
              + "   where p.owner = ?"
              + "     and (? = '' or upper(p.object_name) like '%' || ? || '%'"
              + "          or upper(nvl(p.procedure_name,'')) like '%' || ? || '%')"
              + "   order by p.object_name, p.procedure_name"
              + ") where rownum <= ?";
            StringBuilder rows = new StringBuilder();
            int n = 0;
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, own);
                ps.setString(2, kw);
                ps.setString(3, kw);
                ps.setString(4, kw);
                ps.setInt(5, lim);
                try (ResultSet r = ps.executeQuery()) {
                    while (r.next()) {
                        String pkg = r.getString(1);
                        String pr = r.getString(2).trim();
                        if (rows.length() > 0) rows.append(',');
                        rows.append("{\"pkg\":").append(q(pkg))
                            .append(",\"proc\":").append(q(pr))
                            .append(",\"name\":").append(q(pr.isEmpty() ? pkg : pkg + "." + pr))
                            .append(",\"kind\":").append(q(r.getString(3))).append('}');
                        n++;
                    }
                }
            }
            return status(",\"mode\":\"procs\",\"owner\":" + q(own)
                 + ",\"q\":" + q(kw) + ",\"count\":" + n
                 + ",\"more\":" + (n >= lim)
                 + ",\"procs\":[" + rows + "]");
        } catch (SQLException e) {
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0) + ",\"error\":" + q(lastErr) + "}";
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 현지 POR I/F 후행처리 — [현지 POR 후행처리] 화면(#/locpor)
    //
    // SAP → HHIP 수신표(SST02.Z_PD_C_LOCPOR)를 보여 주고, 고른 IFSEQ 로
    // M20.PKG_PD_LOCPOR_IF.SP_LOCPOR_AFTER_INSERT 를 부른다. 평소에는 EAI 가 적재
    // 직후에 부르는 자리인데, 개발 중에는 그 자리를 사람이 대신 눌러 봐야 한다.
    //
    // ⚠️ 여기서도 SQL 은 박혀 있다. 밖에서 정하는 것은 <어느 IFSEQ 인가> 뿐이다.
    //    이 연결은 DBA 권한으로 돈다 — 문장을 받게 만들면 그 권한이 통째로 새어 나간다.
    // ─────────────────────────────────────────────────────────────────────────

    /** 로그 표에서 이 화면이 부른 것만 가려내는 이름 (프로시저가 스스로 적는 값과 같아야 한다). */
    static final String LOCPOR_PROC = "PKG_PD_LOCPOR_IF.SP_LOCPOR_AFTER_INSERT";

    /**
     * 수신표 목록 — 한 줄에 IFSEQ 하나다(실측 46건 · IFSEQ 중복 없음).
     *
     * 호출이력(M20.Z_PD_IF_CALL_LOG)의 <b>마지막 한 줄</b>을 붙여 준다. 이것이 없으면
     * 화면에서 <이미 돌린 것>과 <아직 안 돌린 것>을 가릴 수가 없어, 같은 IFSEQ 를 두 번
     * 돌리게 된다. 이어 붙이는 열쇠가 <c>TRIM(IFSEQ)</c> 인 까닭 — 수신표 쪽은 CHAR(50)
     * 이고 로그 쪽은 VARCHAR2(50) 이라 <b>공백 채움 때문에 그냥 = 로는 안 붙는다.</b>
     *
     * 차례는 받은 날짜 내림차순이다. <b>날짜가 빈 줄이 맨 위</b>에 온다(Oracle 의 DESC 는
     * NULLS FIRST) — 손으로 넣은 시험자료가 그렇고, 지금 돌려 볼 것이 대개 그것이다.
     */
    static String locpor(String filter, int limit) {
        String kw = (filter == null ? "" : filter.trim()).toUpperCase();
        int lim = Math.max(1, Math.min(2000, limit));

        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";
        try {
            String sql =
                "select * from ("
              + "  select trim(z.ifseq)       as ifseq"
              + "       , trim(z.ship_no)     as ship_no"
              + "       , trim(z.por_no)      as por_no"
              + "       , trim(z.line_no)     as line_no"
              + "       , trim(z.rev_no)      as rev_no"
              + "       , trim(z.req_dept)    as req_dept"
              + "       , trim(z.reg_emp_id)  as reg_emp_id"
              + "       , z.work_desc         as work_desc"
              + "       , z.por_qty           as por_qty"       // 구매요구수량 NUMBER(14,2)
              + "       , trim(z.matl_unit)   as matl_unit"     // 단위 CHAR(3) — EA · SET
              + "       , trim(z.por_kind_cd) as por_kind_cd"
              + "       , to_char(z.cnfm_dt, 'YYYY-MM-DD') as cnfm_dt"
              + "       , trim(z.zifdat)      as zifdat"
              + "       , trim(z.ziftim)      as ziftim"
              + "       , trim(z.zdelflg)     as zdelflg"
              + "       , g.cnt               as run_cnt"
              + "       , l.status            as run_status"
              + "       , to_char(l.call_dtm, 'YYYY-MM-DD HH24:MI:SS') as run_at"
              + "       , l.call_user         as run_user"
              + "       , l.call_module       as run_module"
              + "       , l.err_cd            as run_err_cd"
              + "       , substr(l.err_msg, 1, 300) as run_err_msg"
              + "    from sst02.z_pd_c_locpor z"
              + "    left join ("
              + "      select trim(ifseq) as ifseq, max(log_seq) as seq, count(*) as cnt"
              + "        from m20.z_pd_if_call_log"
              + "       where proc_nm = ?"
              + "       group by trim(ifseq)"
              + "    ) g on g.ifseq = trim(z.ifseq)"
              + "    left join m20.z_pd_if_call_log l on l.log_seq = g.seq"
              // ⚠️ <검색어 없음>을 ? = '' 로 가리지 않는다. Oracle 은 바인드된 빈 문자열을
              //    NULL 로 보므로 그 비교는 늘 <참도 거짓도 아님>이 된다. 여기서는 뒤의
              //    LIKE 들이 '%' || NULL || '%' = '%%' 로 풀려 우연히 전부 걸렸을 뿐이다 —
              //    기대지 말고 is null 로 묻는다 (locporLog 는 그 우연이 없어 0건이 나왔다).
              + "   where (? is null"
              + "          or upper(trim(z.ifseq))   like '%' || ? || '%'"
              + "          or upper(trim(z.ship_no)) like '%' || ? || '%'"
              + "          or upper(trim(z.por_no))  like '%' || ? || '%')"
              + "   order by z.zifdat desc, z.ziftim desc, trim(z.ifseq) desc"
              + ") where rownum <= ?";

            StringBuilder rows = new StringBuilder();
            int n = 0;
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setQueryTimeout(30);
                ps.setString(1, LOCPOR_PROC);
                ps.setString(2, kw);
                ps.setString(3, kw);
                ps.setString(4, kw);
                ps.setString(5, kw);
                ps.setInt(6, lim);
                try (ResultSet r = ps.executeQuery()) {
                    while (r.next()) {
                        if (rows.length() > 0) rows.append(',');
                        rows.append("{\"ifseq\":").append(q(r.getString("ifseq")))
                            .append(",\"ship_no\":").append(q(r.getString("ship_no")))
                            .append(",\"por_no\":").append(q(r.getString("por_no")))
                            .append(",\"line_no\":").append(q(r.getString("line_no")))
                            .append(",\"rev_no\":").append(q(r.getString("rev_no")))
                            .append(",\"req_dept\":").append(q(r.getString("req_dept")))
                            .append(",\"reg_emp_id\":").append(q(r.getString("reg_emp_id")))
                            .append(",\"work_desc\":").append(q(oneLine(r.getString("work_desc"))))
                            // 수량은 글자로 보낸다 — JSON 수로 보내면 받는 쪽에서 소수가 되어
                            // 500 이 500.0 으로, 1.10 이 1.1000000000000001 로 흐를 수 있다.
                            // 꼬리 0 은 여기서 떨군다(NUMBER(14,2) 라 5 가 5.00 으로 온다).
                            .append(",\"por_qty\":").append(q(dec(r.getBigDecimal("por_qty"))))
                            .append(",\"matl_unit\":").append(q(r.getString("matl_unit")))
                            .append(",\"por_kind_cd\":").append(q(r.getString("por_kind_cd")))
                            .append(",\"cnfm_dt\":").append(q(r.getString("cnfm_dt")))
                            .append(",\"zifdat\":").append(q(r.getString("zifdat")))
                            .append(",\"ziftim\":").append(q(r.getString("ziftim")))
                            .append(",\"zdelflg\":").append(q(r.getString("zdelflg")))
                            .append(",\"run_cnt\":").append(r.getObject("run_cnt") == null ? 0 : r.getInt("run_cnt"))
                            .append(",\"run_status\":").append(q(r.getString("run_status")))
                            .append(",\"run_at\":").append(q(r.getString("run_at")))
                            .append(",\"run_user\":").append(q(r.getString("run_user")))
                            .append(",\"run_module\":").append(q(oneLine(r.getString("run_module"))))
                            .append(",\"run_err_cd\":").append(r.getObject("run_err_cd") == null ? "null" : r.getLong("run_err_cd"))
                            .append(",\"run_err_msg\":").append(q(oneLine(r.getString("run_err_msg"))))
                            .append('}');
                        n++;
                    }
                }
            }
            return status(",\"mode\":\"locpor\",\"q\":" + q(kw)
                 + ",\"count\":" + n + ",\"more\":" + (n >= lim)
                 + ",\"rows\":[" + rows + "]");
        } catch (SQLException e) {
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0) + ",\"error\":" + q(lastErr) + "}";
        }
    }

    /** 호출이력 — IFSEQ 를 주면 그 건만, 안 주면 이 프로시저의 최근 이력 전부. */
    static String locporLog(String ifseq, int limit) {
        String key = (ifseq == null ? "" : ifseq.trim());
        int lim = Math.max(1, Math.min(500, limit));

        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";
        try {
            String sql =
                "select * from ("
              + "  select l.log_seq, trim(l.ifseq) as ifseq, l.status, l.target_cnt"
              + "       , to_char(l.call_dtm, 'YYYY-MM-DD HH24:MI:SS') as call_dtm"
              + "       , to_char(l.end_dtm,  'YYYY-MM-DD HH24:MI:SS') as end_dtm"
              + "       , l.call_user, l.call_module, l.call_ip"
              + "       , l.err_cd, substr(l.err_msg, 1, 1000) as err_msg"
              + "    from m20.z_pd_if_call_log l"
              + "   where l.proc_nm = ?"
              // ⚠️ ? = '' 로 쓰면 <IFSEQ 를 안 준 경우>가 통째로 0건이 된다 — 위 주석 참고
              + "     and (? is null or trim(l.ifseq) = ?)"
              + "   order by l.log_seq desc"
              + ") where rownum <= ?";

            StringBuilder rows = new StringBuilder();
            int n = 0;
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setQueryTimeout(30);
                ps.setString(1, LOCPOR_PROC);
                ps.setString(2, key);
                ps.setString(3, key);
                ps.setInt(4, lim);
                try (ResultSet r = ps.executeQuery()) {
                    while (r.next()) {
                        if (rows.length() > 0) rows.append(',');
                        rows.append("{\"log_seq\":").append(r.getLong("log_seq"))
                            .append(",\"ifseq\":").append(q(r.getString("ifseq")))
                            .append(",\"status\":").append(q(r.getString("status")))
                            .append(",\"target_cnt\":").append(r.getObject("target_cnt") == null ? "null" : r.getLong("target_cnt"))
                            .append(",\"call_dtm\":").append(q(r.getString("call_dtm")))
                            .append(",\"end_dtm\":").append(q(r.getString("end_dtm")))
                            .append(",\"call_user\":").append(q(r.getString("call_user")))
                            .append(",\"call_module\":").append(q(oneLine(r.getString("call_module"))))
                            .append(",\"call_ip\":").append(q(r.getString("call_ip")))
                            .append(",\"err_cd\":").append(r.getObject("err_cd") == null ? "null" : r.getLong("err_cd"))
                            .append(",\"err_msg\":").append(q(oneLine(r.getString("err_msg"))))
                            .append('}');
                        n++;
                    }
                }
            }
            return status(",\"mode\":\"locporlog\",\"ifseq\":" + q(key)
                 + ",\"count\":" + n + ",\"more\":" + (n >= lim)
                 + ",\"logs\":[" + rows + "]");
        } catch (SQLException e) {
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0) + ",\"error\":" + q(lastErr) + "}";
        }
    }

    /**
     * 후행처리 호출 — 이 화면에서 <b>유일하게 DB 를 바꾸는</b> 자리다.
     *
     * <b>⚠️ 커밋을 우리가 쥔다.</b> 평소 JDBC 는 autoCommit 이라 호출이 끝나는 순간
     * <b>반쯤 된 것까지 그대로 굳는다.</b> 이 프로시저는 제 오류를 삼키고(WHEN OTHERS)
     * 'E' 만 돌려주므로 — 예외가 안 올라온다 — autoCommit 그대로 두면 실패한 호출의
     * 찌꺼기가 조용히 남는다. 그래서 끄고 들어가 <b>'S' 일 때만 커밋</b>한다.
     * 끝나면 반드시 되돌린다. 이 커넥션은 조회 명령들과 함께 쓰는 것이라서다.
     *
     * (호출이력 M20.Z_PD_IF_CALL_LOG 는 자율 트랜잭션이라 되돌려도 남는다 — 그것이 맞다.
     *  안쪽 전개 PKG_HHIP_P30_POR_IF_EXPAND.SP_EXPAND_POR 도 제 커밋·롤백을 스스로 한다.)
     *
     * <b>CALL_MODULE 을 먼저 적어 둔다.</b> 로그 표의 그 칸은 세션의 MODULE 을 그대로
     * 받는데, 손대지 않으면 자바 클래스 이름이 들어가 <b>EAI 가 부른 것과 구별이 안 된다.</b>
     * 누가 대시보드에서 눌렀는지가 거기 남아야 한다.
     *
     * 시간제한을 45초로 둔 것은 <b>C# 쪽이 60초에 상주 프로그램을 죽이기</b> 때문이다
     * (api/OraKill.cs 의 TimeoutMs). 먼저 답을 내놓지 않으면 프로시저가 도는 중에
     * 프로세스가 끊긴다.
     */
    static String locporRun(String ifseq, String by) {
        String key = (ifseq == null ? "" : ifseq.trim());
        if (key.isEmpty())
            return "{\"ok\":false,\"error\":\"ifseq 가 필요합니다.\"}";

        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";

        boolean auto = true;
        long t0 = System.currentTimeMillis();
        try {
            auto = c.getAutoCommit();

            // 누가 눌렀는지를 세션에 적어 둔다 — 프로시저가 이 값을 로그 표로 옮겨 적는다
            try (CallableStatement s = c.prepareCall("begin dbms_application_info.set_module(?, ?); end;")) {
                s.setString(1, "WBS/" + (by == null || by.isEmpty() ? "?" : by));
                s.setString(2, key.length() > 32 ? key.substring(0, 32) : key);
                s.execute();
            }

            if (auto) c.setAutoCommit(false);

            String cd, msg;
            try (CallableStatement s = c.prepareCall(
                     "{call M20.PKG_PD_LOCPOR_IF.SP_LOCPOR_AFTER_INSERT(?, ?, ?)}")) {
                s.setQueryTimeout(45);
                s.setString(1, key);
                s.registerOutParameter(2, Types.VARCHAR);
                s.registerOutParameter(3, Types.VARCHAR);
                s.execute();
                cd = s.getString(2);
                msg = s.getString(3);
            }

            boolean good = "S".equals(cd);
            if (good) c.commit(); else c.rollback();

            return status(",\"mode\":\"locporrun\",\"ifseq\":" + q(key)
                 + ",\"rtn_cd\":" + q(cd)
                 + ",\"rtn_msg\":" + q(oneLine(msg))
                 + ",\"done\":" + good
                 + ",\"ms\":" + (System.currentTimeMillis() - t0));
        } catch (SQLException e) {
            // 프로시저가 못 삼킨 오류(권한·없는 객체·시간초과 따위). 되돌리고 그대로 알린다.
            try { c.rollback(); } catch (SQLException ignore) { }
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0)
                 + ",\"mode\":\"locporrun\",\"ifseq\":" + q(key)
                 + ",\"ms\":" + (System.currentTimeMillis() - t0)
                 + ",\"error\":" + q(lastErr) + "}";
        } finally {
            // 빌려 쓴 커넥션이다 — 어떻게 끝나든 원래대로 돌려놓는다
            try { if (auto) c.setAutoCommit(true); } catch (SQLException ignore) { }
            try (CallableStatement s = c.prepareCall("begin dbms_application_info.set_module(null, null); end;")) {
                s.execute();
            } catch (SQLException ignore) { }
        }
    }

    /**
     * [3320] 구매 발주 — <b>승인완료 직전까지 한 라인을 흘린다.</b>
     *
     * 부르는 것은 <c>M20.QURI_MAKE_PO_3320(호선, POR, 라인)</c> 하나다. 그 프로시저는
     * [3310] 직발주 화면과 <b>같은 경로</b>로 돈다 — 채번(GET_NEW_PO_NO) → 자재 1행
     * (SAVE_PURCHASE_ORDER_LIST) → 머리 1본(SAVE_PURCHASE_ORDER_HEAD). 업무로직을
     * 여기서 새로 쓰지 않는다. 끝 상태는 <c>T30C_1110.PO_STAT='3'</c>(Waiting Approval)
     * 과 발주번호라, [3320] 화면에서 승인완료를 바로 누를 수 있는 자리까지 간다.
     *
     * <b>선행이 있다.</b> [2310] 일반재 POR 접수가 끝나 <c>T30C_1110</c> 에 행이 있어야
     * 한다. 후행처리만 돌린 줄은 아직 그 행이 없어 'E' 로 돌아온다 — 오류가 아니라
     * <b>순서가 아직 안 온 것</b>이고, 프로시저가 그렇게 적어 보낸다.
     *
     * <b>⚠️ 커밋을 우리가 쥔다.</b> 이 프로시저는 <b>일부러 COMMIT 하지 않는다</b>(원본
     * P_30 패키지들과 같은 규약이다 — 부르는 쪽의 트랜잭션이 듣게 하려는 것). 게다가
     * 실패를 예외로 던지지 않고 O_RTN_CD='E' 로 돌려준다. 그래서 autoCommit 그대로 두면
     * <b>프로시저가 SAVEPOINT 로 되감아 둔 것까지 포함해 호출 끝에 그냥 굳는다.</b>
     * 끄고 들어가 <b>'S' 일 때만 커밋</b>하고, 끝나면 반드시 되돌린다 — 이 커넥션은
     * 조회 명령들과 함께 쓰는 것이라서다 (locporRun 과 같은 까닭).
     *
     * 돌아오는 코드는 셋이다 —
     *   'S' 만들었다 · 'W' 이미 그 단계이거나 지나갔다(<b>아무것도 바꾸지 않았다</b>) ·
     *   'E' 못 했다(프로시저가 되감아 둔다).
     *
     * <b>키는 손대지 않고 그대로 넘긴다.</b> 수신표의 POR 번호는 네 자리(AA01)이고 원장은
     * 여덟 자리(J015AA01)인데, 그 결합도 CHAR 칸 자릿수 채움도 <b>프로시저 안에서</b> 한다.
     * 여기서 미리 만지면 같은 규칙이 두 군데에 생겨 한쪽만 고쳐지는 날이 온다.
     */
    static String locporPo(String ship, String por, String seq, String by) {
        String sh = (ship == null ? "" : ship.trim());
        String pr = (por == null ? "" : por.trim());
        String sq = (seq == null ? "" : seq.trim());
        if (sh.isEmpty() || pr.isEmpty() || sq.isEmpty())
            return "{\"ok\":false,\"error\":\"호선 · POR번호 · 라인이 모두 필요합니다.\"}";

        String key = sh + "/" + pr + "/" + sq;

        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";

        boolean auto = true;
        long t0 = System.currentTimeMillis();
        try {
            auto = c.getAutoCommit();

            // 누가 눌렀는지를 세션에 적어 둔다 — 이 프로시저는 제 호출이력을 남기지 않아서,
            // DB 쪽에서 이것을 보는 길은 도는 동안의 v$session.module 뿐이다.
            try (CallableStatement s = c.prepareCall("begin dbms_application_info.set_module(?, ?); end;")) {
                s.setString(1, "WBS/" + (by == null || by.isEmpty() ? "?" : by));
                s.setString(2, key.length() > 32 ? key.substring(0, 32) : key);
                s.execute();
            }

            if (auto) c.setAutoCommit(false);

            String pono, cd, msg;
            // 뒤의 여덟 인자(단가 · 업체 · 통화 · 결제·운송조건 · 부가세 · 담당자 · 작성자)는
            // DEFAULT 가 있어 자리를 비운다. 화면이 정할 값이 아니라 <흘려 보는 데 필요한
            // 기본값>이고, 그 기본값은 프로시저 쪽에 적혀 있어야 한 군데서만 바뀐다.
            try (CallableStatement s = c.prepareCall(
                     "{call M20.QURI_MAKE_PO_3320(?, ?, ?, ?, ?, ?)}")) {
                s.setQueryTimeout(45);
                s.setString(1, sh);
                s.setString(2, pr);
                s.setString(3, sq);
                s.registerOutParameter(4, Types.VARCHAR);
                s.registerOutParameter(5, Types.VARCHAR);
                s.registerOutParameter(6, Types.VARCHAR);
                s.execute();
                pono = s.getString(4);
                cd = s.getString(5);
                msg = s.getString(6);
            }

            boolean good = "S".equals(cd);
            if (good) c.commit(); else c.rollback();

            return status(",\"mode\":\"locporpo\""
                 + ",\"ship\":" + q(sh) + ",\"por\":" + q(pr) + ",\"seq\":" + q(sq)
                 + ",\"po_no\":" + q(pono)
                 + ",\"rtn_cd\":" + q(cd)
                 + ",\"rtn_msg\":" + q(oneLine(msg))
                 + ",\"done\":" + good
                 + ",\"ms\":" + (System.currentTimeMillis() - t0));
        } catch (SQLException e) {
            // 프로시저가 못 삼킨 오류(권한 · 없는 객체 · 시간초과). 되돌리고 그대로 알린다.
            try { c.rollback(); } catch (SQLException ignore) { }
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0)
                 + ",\"mode\":\"locporpo\""
                 + ",\"ship\":" + q(sh) + ",\"por\":" + q(pr) + ",\"seq\":" + q(sq)
                 + ",\"ms\":" + (System.currentTimeMillis() - t0)
                 + ",\"error\":" + q(lastErr) + "}";
        } finally {
            // 빌려 쓴 커넥션이다 — 어떻게 끝나든 원래대로 돌려놓는다
            try { if (auto) c.setAutoCommit(true); } catch (SQLException ignore) { }
            try (CallableStatement s = c.prepareCall("begin dbms_application_info.set_module(null, null); end;")) {
                s.execute();
            } catch (SQLException ignore) { }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 전개분 되돌리기 — 후행처리가 만든 것을 지워 <다시 돌릴 수 있는 상태>로
    //
    // 후행처리는 재실행 안전하게 짜여 있지만(MERGE · NOT EXISTS), 그래서 두 번째
    // 실행은 <이미 있는 것을 건드리지 않는다>. 바뀐 매핑을 시험하려면 만들어진 것을
    // 치워야 처음처럼 돈다. 그 치우는 일을 여기서 한다.
    //
    // <b>⚠️ 되돌릴 수 없다.</b> 그래서 <세는 것(scope)>과 <지우는 것(wipe)>을 갈라 둔다.
    // 화면은 반드시 먼저 세어 보여 주고, 사람이 두 번 눌러야 지운다.
    //
    // <b>범위는 수신표에서 거슬러 잡는다.</b> IFSEQ 를 들고 있는 표는 T30B_1130 하나뿐이라,
    // 나머지는 <그 IFSEQ 의 (호선6·POR·행)> 과 맞는 줄을 찾아 지운다. 그래서 두 가지가
    // 따라온다 — 반드시 알고 쓸 것:
    //   ① 같은 줄을 <다른 IFSEQ 로> 받았던 적이 있으면 그것도 함께 지워진다.
    //      키가 같은 한 갈라낼 방법이 없다(원장은 회차를 덮어쓰며 산다).
    //   ② MERGE 로 <고쳐진> 줄은 수신 전 값으로 돌아가지 않는다. 지워질 뿐이다.
    //
    // <b>차례가 곧 의존 순서다</b>(자식 → 부모). 머리 행(T30B_1110 · MTB_POR_OHD)은
    // <남은 라인이 없을 때만> 지운다 — 라인을 먼저 지우므로 그 판정이 맞아떨어진다.
    //
    // <b>무엇을 지우지 않는가.</b> 알림메일 M20.T30_MESSAGE 는 호선·POR 칸이 아예 없어
    // (MSG_NO·제목·본문뿐) 어느 POR 것인지 키로 짚을 수가 없다. 본문 글자로 맞춰 지우는
    // 것은 남의 메일을 지울 위험이 있어 하지 않는다. PO 뒤 단계(T30C_2040 따위)도
    // 후행처리가 만든 것이 아니라 손대지 않고, 대신 <남는 것>으로 세어 보여 준다.
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * 지울 범위는 <b>두 가지</b>다. 어느 쪽이든 문장 하나에 조건 하나로만 들어간다.
     *
     * <b>① IFSEQ 한 묶음</b>(mode="ifseq") — 받은 그 배치만. 평소 쓰는 쪽이다.
     * <b>② 호선+POR 통째</b>(mode="shippor") — 그 POR 의 <b>모든 줄</b>.
     *
     * ②가 필요한 까닭 — 한 POR 이 여러 IFSEQ 로 나뉘어 들어온다(J015/AA04 는 12개 · 줄 07·08).
     * ①로는 고른 묶음의 줄만 사라져 나머지가 화면에 그대로 남는다. 게다가 <b>수신표에 아예
     * 없는 줄</b>(사람이 손으로 넣은 것)은 ①로는 **원리상** 못 지운다 — 범위를 수신표에서
     * 거슬러 잡기 때문이다. ②는 원장을 직접 짚으므로 그것까지 지운다.
     *
     * ⚠️ 그래서 ②는 <b>인터페이스가 만들지 않은 줄도 지운다</b>. 미리보기가 그 수를 따로
     *    세어 보여 준다(not_if) — 모르고 누르면 남의 작업물을 지운다.
     */
    static final String M_IFSEQ = "ifseq";
    static final String M_SHIPPOR = "shippor";

    /**
     * ① 그 줄이 <이 IFSEQ 의 수신분>인가. 값은 언제나 바인드(?) 하나다.
     *
     * ⚠ 키는 전부 CHAR 라 공백으로 채워져 있다 — TRIM 없이 비교하면 <한 줄도> 안 걸린다.
     *   호선은 수신표가 24자리, 원장이 6자리다(SUBSTR 1,6 — 전개 쪽 매핑과 같다).
     */
    static String ofBatch(String ship, String por, String seq) {
        return "exists (select 1 from SST02.Z_PD_C_LOCPOR z"
             + " where z.IFSEQ = cast(? as char(50))"
             + " and substr(trim(z.SHIP_NO),1,6) = trim(" + ship + ")"
             // ⚠️ POR_NO 는 두 꼴이 섞여 있다. 원장의 POR_NO 는 <호선4 + 일련4> 한 덩어리인데
             //    (2026-10-20 전개 프로시저를 그렇게 고쳤다), 그 전에 전개된 줄은 일련부만
             //    들어가 있다. 둘 다 받아야 옛 줄도 치울 수 있다 — 한쪽만 보면 조용히 0건이다.
             //    호선은 위에서 따로 맞추므로 짧은 쪽을 받아도 남의 호선까지 걸리지 않는다.
             + " and (trim(" + por + ") = trim(z.SHIP_NO) || trim(z.POR_NO)"
             + "   or trim(" + por + ") = trim(z.POR_NO))"
             + (seq == null ? "" : " and trim(z.LINE_NO) = trim(" + seq + ")")
             + ")";
    }

    /**
     * ② 그 줄이 <이 호선·이 POR>인가. 바인드는 셋 — 호선 · POR · 호선+POR.
     *
     * 수신표를 거치지 않고 원장을 바로 짚는다. 그래서 <b>줄 번호를 가리지 않고</b>,
     * 수신표에 없는 줄도 걸린다. POR_NO 를 둘 다 받는 까닭은 ① 과 같다(옛 꼴·새 꼴).
     */
    static String ofShipPor(String ship, String por) {
        return "trim(" + ship + ") = ? and trim(" + por + ") in (?, ?)";
    }

    /** 범위 조건 하나. mode 에 따라 ① 또는 ② 를 낸다. ② 는 줄 번호를 쓰지 않는다. */
    static String scopeOf(String mode, String ship, String por, String seq) {
        return mode.equals(M_SHIPPOR) ? ofShipPor(ship, por) : ofBatch(ship, por, seq);
    }

    /** 자재마스터는 호선·POR 칸이 없어 수신표에서 자재코드를 거슬러 찾는다 (두 모드 공통 꼴). */
    static String ofMatl(String mode) {
        return "exists (select 1 from SST02.Z_PD_C_LOCPOR z where "
             + (mode.equals(M_SHIPPOR)
                 ? "substr(trim(z.SHIP_NO),1,6) = ? and trim(z.SHIP_NO) || trim(z.POR_NO) in (?, ?)"
                 : "z.IFSEQ = cast(? as char(50))")
             + " and trim(substr(z.MATL_CD,1,11)) = trim(x.MATL_CD))";
    }

    /** 한 문장에 들어간 범위조건 하나를 채운다. 돌려주는 것은 <다음에 채울 자리>. */
    static int fill(PreparedStatement ps, int at, String mode,
                    String ifseq, String ship, String por) throws SQLException {
        if (!mode.equals(M_SHIPPOR)) { ps.setString(at, ifseq); return at + 1; }
        ps.setString(at, ship);
        ps.setString(at + 1, por);
        ps.setString(at + 2, ship + por);   // 합친 키 꼴 (2026-10-20 이후 전개분)
        return at + 3;
    }

    /**
     * 지울 자리 — {표시이름, FROM 절, WHERE 절, 범위조건이 몇 번 들어갔나}.
     * <b>차례를 바꾸지 말 것</b>(자식 → 부모). 미리보기도 같은 배열을 돌아 같은 조건으로 센다 —
     * 두 벌로 두면 반드시 어긋난다.
     *
     * @param preview 머리 행 둘의 판정이 달라진다. 지울 때는 라인을 이미 지운 뒤라 <남은 라인이
     *                없는가> 로 묻지만, 미리보기 때는 아직 안 지웠으므로 <이번에 지워질 라인을
     *                뺀 나머지가 있는가> 로 물어야 같은 수가 나온다.
     */
    /**
     * POR 뒤로 업무가 흘러가며 생긴 것들 — 견적 · 회신 · 변경이력 따위.
     * <b>후행처리가 만든 것이 아니다.</b> 사람이 화면에서 일을 진행해 생긴 자료다.
     *
     * 목록은 짐작이 아니라 <b>전수로 세어</b> 골랐다(2026-10-20): M20·NEW10 에서 POR_NO 칸을
     * 가진 표 <b>307개</b>를 전부 훑어, 지금 수신분의 POR 로 <b>실제 줄이 있는 23개</b>를 찾고
     * 그중 전개분 10개를 뺀 나머지다. 짐작으로 적으면 반드시 빠뜨린다.
     *
     * ⚠️ 호선+POR 범위에서만 쓴다. IFSEQ 로는 짚을 수가 없다 — 이것들은 수신 배치가 아니라
     *    <b>업무 진행</b>으로 생기므로 어느 IFSEQ 것인지 가릴 근거가 아예 없다.
     *
     * 차례는 자식 → 부모다. 이 묶음을 <b>맨 앞</b>에 둔다 — 견적(T30C_2040…)은 발주
     * (T30C_1110)에, 회신(MTB_HVS_POR_STATUS_REPLY)은 큐에, 변경이력은 제 원장에 딸려 있다.
     */
    /**
     * 견적 헤더·업체(T30C_2010·T30C_2020)는 <b>호선·POR 칸이 없다</b> — 키가 QUOT_NO 하나다.
     * 그래서 견적 라인(T30C_2030)을 거쳐 찾는다.
     *
     * ⚠️ 이 둘은 반드시 <b>T30C_2030 앞</b>에 둔다. 2030 을 먼저 지우면 여기서 견적번호를
     *    찾을 길이 사라져 <b>조용히 0건</b>이 된다.
     * ⚠️ 견적 하나가 묶는 POR 은 <b>실측 최대 1개</b>다(견적 21건 전수 확인, 2026-10-20).
     *    그래서 지워도 남의 POR 견적을 건드리지 않는다 — 만약 한 견적이 여러 POR 을 묶는
     *    자료가 생기면 <b>이 전제가 깨진다.</b>
     */
    static String viaQuot(String mode) {
        return "exists (select 1 from M20.T30C_2030 d"
             + " where trim(d.QUOT_NO) = trim(x.QUOT_NO)"
             + " and " + scopeOf(mode, "d.SHIP_NO", "d.POR_NO", "d.POR_SEQ") + ")";
    }

    static String[][] bizPlan(String mode) {
        String kp = scopeOf(mode, "x.SHIP_NO", "x.POR_NO", null);
        return new String[][] {
            // ── 견적 ─────────────────────────────────────────────────────────
            { "M20.T30C_2040_ENCRYPT_MODIFY", "M20.T30C_2040_ENCRYPT_MODIFY x", kp, "1" },
            { "M20.T30C_2040_ENCRYPT", "M20.T30C_2040_ENCRYPT x", kp, "1" },
            { "M20.T30C_2040_MODIFY", "M20.T30C_2040_MODIFY x", kp, "1" },
            { "M20.T30C_2040", "M20.T30C_2040 x", kp, "1" },
            // 견적 업체별 → 차수 → 헤더. 2026-10-20 지시로 더했다(2010·2020 먼저, 2015 뒤에).
            // ⚠ 셋 다 T30C_2030 <앞>이어야 한다 — 그 표를 거쳐 견적번호를 찾기 때문이다.
            { "M20.T30C_2020", "M20.T30C_2020 x", viaQuot(mode), "1" },
            { "M20.T30C_2015", "M20.T30C_2015 x", viaQuot(mode), "1" },
            { "M20.T30C_2010", "M20.T30C_2010 x", viaQuot(mode), "1" },
            { "M20.T30C_2030", "M20.T30C_2030 x", kp, "1" },
            // ⚠ 이 표만 SHIP_NO 칸이 없다. 그래서 <합친 키(호선+일련)> 로만 지운다 —
            //   옛 꼴(일련부만)로 지우면 호선을 가릴 수가 없어 남의 호선 줄을 건드린다.
            //   바인드 차례(호선·POR·호선+POR)를 맞추려고 앞 둘은 조건만 맞춰 쓴다.
            { "M20.T30C_2013", "M20.T30C_2013 x",
              "? is not null and ? is not null and trim(x.POR_NO) = ?", "1" },
            { "NEW10.CHECK_EST_QT", "NEW10.CHECK_EST_QT x", kp, "1" },
            // ── 현지 POR 한국전환(KSOE) · 변경 회신 ─────────────────────────────
            { "M20.T30B_1132", "M20.T30B_1132 x", kp, "1" },   // 변경 승인/반려 회신 이력
            { "M20.T30B_1131", "M20.T30B_1131 x", kp, "1" },   // 한국전환 처리 이력
            { "M20.T30B_1121", "M20.T30B_1121 x", kp, "1" },
            { "NEW10.MTB_HVS_POR_STAT_RPLY_MOD", "NEW10.MTB_HVS_POR_STAT_RPLY_MOD x", kp, "1" },
            { "NEW10.MTB_HVS_POR_STATUS_REPLY", "NEW10.MTB_HVS_POR_STATUS_REPLY x", kp, "1" },
            // ── 그 밖의 업무·이력 ───────────────────────────────────────────────
            // ※ M20.T30L_1110 은 2026-10-20 지시로 <전개분>(corePlan)으로 옮겼다. 여기 두지 말 것 —
            //   양쪽에 있으면 [둘 다] 의 미리보기가 같은 줄을 두 번 센다.
            { "NEW10.MTB_POR_OHD_MODIFY", "NEW10.MTB_POR_OHD_MODIFY x", kp, "1" },
        };
    }

    /** 두 배열을 잇는다 — 업무분을 앞에, 전개분을 뒤에. */
    static String[][] join(String[][] a, String[][] b) {
        String[][] r = new String[a.length + b.length][];
        System.arraycopy(a, 0, r, 0, a.length);
        System.arraycopy(b, 0, r, a.length, b.length);
        return r;
    }

    /** 지울 때 쓰는 묶음 — 화면의 단추 셋과 하나씩 짝이다. */
    static final String P_CORE = "core";    // 전개분만
    static final String P_BIZ  = "biz";     // PO 뒤 업무분만
    static final String P_ALL  = "all";     // 둘 다

    /**
     * <b>지울 때</b>의 계획. 미리보기(preview=true)가 아니라 실제 삭제용이다 —
     * 머리 행 판정이 <라인을 이미 지운 뒤> 기준이라 그렇다(corePlan 주석).
     *
     * ⚠ <b>업무분만</b>(P_BIZ)은 전개분을 건드리지 않는다. POR 원장은 그대로 두고 그 뒤
     *   업무 자취만 걷어내고 싶을 때 쓴다 — 다시 전개할 필요 없이 업무를 다시 태울 수 있다.
     */
    static String[][] partPlan(String mode, String part) {
        String[][] core = corePlan(mode, false);
        if (P_BIZ.equals(part)) return bizPlan(mode);
        if (P_ALL.equals(part)) return join(bizPlan(mode), core);
        return core;
    }

    static String[][] corePlan(String mode, boolean preview) {
        String k3 = scopeOf(mode, "x.SHIP_NO", "x.POR_NO", "x.POR_SEQ");
        String k2 = scopeOf(mode, "x.SHIP_NO", "x.POR_NO", "x.LINE_NO");
        String kh = scopeOf(mode, "x.SHIP_NO", "x.POR_NO", null);

        String b1110 = kh + " and not exists (select 1 from M20.T30B_1120 l"
                     + " where trim(l.SHIP_NO) = trim(x.SHIP_NO) and trim(l.POR_NO) = trim(x.POR_NO)"
                     + (preview ? " and not " + scopeOf(mode, "l.SHIP_NO", "l.POR_NO", "l.POR_SEQ") : "")
                     + ")";
        String bohd = kh + " and not exists (select 1 from NEW10.MTB_POR_OLN l"
                     + " where trim(l.SHIP_NO) = trim(x.SHIP_NO) and trim(l.POR_NO) = trim(x.POR_NO)"
                     + (preview ? " and not " + scopeOf(mode, "l.SHIP_NO", "l.POR_NO", "l.LINE_NO") : "")
                     + ")";
        String n2 = preview ? "2" : "1";

        return new String[][] {
            // ── POR 라인에 딸린 것들 ──────────────────────────────────────────
            { "M20.T30B_1120_MODIFY", "M20.T30B_1120_MODIFY x", k3, "1" },
            { "M20.T30B_1150", "M20.T30B_1150 x", k3, "1" },
            // ⚠ 전개가 만드는 표가 아니다 — [2310] 화면의 SAVE_MASTER·INSERT_RECEIPT 가 쓴다
            //   (실측: J015AA04/08 줄의 등록자는 사람 사번이었다). 그래도 2026-10-20 지시로
            //   <전개분>에 넣는다 — 이 줄이 남아 있으면 다시 전개한 자리가 깨끗하지 않다.
            //   그래서 [전개분만] 으로도 지워진다. 업무분(bizPlan)에는 두지 말 것 — 두 번 센다.
            { "M20.T30L_1110", "M20.T30L_1110 x", k3, "1" },
            // IFSEQ 를 들고 있는 유일한 표지만 <키로> 지운다 — PK(호선·POR·행·회차)에
            // IFSEQ 가 없어, 그 줄이 남아 있으면 다시 돌려도 NOT EXISTS 에 걸려 안 생긴다.
            { "M20.T30B_1130", "M20.T30B_1130 x", k3, "1" },
            // 발주(PO) — 후행처리가 만든 것은 아니다. 2026-10-20 사용자 지시로 함께 지운다.
            { "M20.T30C_1110", "M20.T30C_1110 x", k3, "1" },
            { "M20.T30B_1120", "M20.T30B_1120 x", k3, "1" },
            { "NEW10.MTB_HVS_POR_STATUS", "NEW10.MTB_HVS_POR_STATUS x", k2, "1" },
            { "NEW10.MTB_POR_OLN", "NEW10.MTB_POR_OLN x", k2, "1" },

            // ── 머리 행 — 남은 라인이 없을 때만 (라인을 먼저 지웠으므로 여기서 맞다) ──
            { "M20.T30B_1110", "M20.T30B_1110 x", b1110, n2 },
            { "NEW10.MTB_POR_OHD", "NEW10.MTB_POR_OHD x", bohd, n2 },

            // ── 자재마스터 — 2026-10-20 사용자 지시로 전개분을 모두 지운다 ───────────
            // ⚠ 키가 MATL_CD 하나뿐이라 <다른 호선이 쓰던 자재>도 같이 지워질 수 있다.
            //   원장은 11자리, 수신표는 18자리다(전개 쪽 SUBSTR 1,11 과 같이 맞춘다).
            //   자재코드가 빈 줄은 trim 이 NULL 이 되어 저절로 빠진다 — 그래야 맞다.
            { "M20.T30A_1130", "M20.T30A_1130 x", ofMatl(mode), "1" },
        };
    }

    // ※ <남는 것>(leftPlan)은 없앴다 — 그 표들이 전부 bizPlan 으로 넘어가, 이제는
    //    «남는 것» 이 아니라 «업무분» 으로 건수와 함께 제 자리에서 보인다(2026-10-20).

    /**
     * 호선+POR 범위에서 <b>수신표에 없는 POR 라인</b>이 몇 줄인가.
     *
     * 이 모드에서 가장 위험한 수다 — 인터페이스가 만들지 않은 줄, 곧 <b>사람이 손으로 넣은
     * 줄</b>이다(실측: J015/AA04 의 POR_SEQ 09 는 등록자가 BP33772 다). IFSEQ 범위로는
     * 닿지도 않던 것이라, 모르고 누르면 남의 작업물이 사라진다. 화면이 반드시 적어야 한다.
     */
    static long notFromIf(Connection c, String ship, String por) throws SQLException {
        // ⚠ ofBatch 를 쓰면 안 된다 — 그것은 <어느 한 IFSEQ> 를 묻는 조건이라, 여기서는
        //   <어느 IFSEQ 로든 받은 적이 있나> 를 물어야 한다. IFSEQ 조건을 뺀 꼴로 따로 쓴다.
        String sql =
            "select count(*) from M20.T30B_1120 x"
          + " where " + ofShipPor("x.SHIP_NO", "x.POR_NO")
          + " and not exists (select 1 from SST02.Z_PD_C_LOCPOR z"
          + "   where substr(trim(z.SHIP_NO),1,6) = trim(x.SHIP_NO)"
          + "     and (trim(x.POR_NO) = trim(z.SHIP_NO) || trim(z.POR_NO)"
          + "       or trim(x.POR_NO) = trim(z.POR_NO))"
          + "     and trim(z.LINE_NO) = trim(x.POR_SEQ))";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setQueryTimeout(30);
            ps.setString(1, ship);
            ps.setString(2, por);
            ps.setString(3, ship + por);
            try (ResultSet r = ps.executeQuery()) { return r.next() ? r.getLong(1) : 0; }
        }
    }

    /** 한 문장을 세기만 한다. 범위조건이 n 번 들어간 문장이면 그만큼 채운다. */
    static long count(Connection c, String sql, String mode, int n,
                      String ifseq, String ship, String por) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setQueryTimeout(30);
            int at = 1;
            for (int i = 0; i < n; i++) at = fill(ps, at, mode, ifseq, ship, por);
            try (ResultSet r = ps.executeQuery()) { return r.next() ? r.getLong(1) : 0; }
        }
    }

    /** 한 줄짜리 JSON 조각 — {"t":"표이름","n":건수} */
    static String pair(String t, long n) {
        return "{\"t\":" + q(t) + ",\"n\":" + n + "}";
    }

    /**
     * 미리보기 — <b>아무것도 바꾸지 않는다.</b> 지울 것과 남을 것을 세기만 한다.
     * mode 가 shippor 면 <수신표에 없는 줄>(not_if)도 함께 센다.
     */
    /**
     * 한 묶음을 세어 JSON 조각과 합계를 돌려준다. [0]=조각, [1]=합계.
     * 세는 쪽과 지우는 쪽이 <b>같은 배열</b>을 돌므로 둘이 어긋날 수가 없다.
     */
    static Object[] tally(Connection c, String[][] plan, String mode,
                          String key, String sh, String pr) throws SQLException {
        StringBuilder b = new StringBuilder();
        long total = 0;
        for (String[] p : plan) {
            long n = count(c, "select count(*) from " + p[1] + " where " + p[2],
                           mode, num(p[3], 1), key, sh, pr);
            if (b.length() > 0) b.append(',');
            b.append(pair(p[0], n));
            total += n;
        }
        return new Object[] { b.toString(), total };
    }

    static String locporScope(String mode, String ifseq, String ship, String por) {
        String key = (ifseq == null ? "" : ifseq.trim());
        String sh = (ship == null ? "" : ship.trim());
        String pr = (por == null ? "" : por.trim());
        if (mode.equals(M_SHIPPOR) ? (sh.isEmpty() || pr.isEmpty()) : key.isEmpty())
            return "{\"ok\":false,\"error\":\"범위가 모자랍니다 (ifseq 또는 ship+por).\"}";

        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";
        try {
            // 두 묶음을 <언제나 따로> 센다. 화면이 단추를 셋 세우기 때문이다 —
            // 전개분만 · 업무분만 · 둘 다. 각 단추가 제 건수를 달고 있어야 한다.
            Object[] coreT = tally(c, corePlan(mode, true), mode, key, sh, pr);
            String del = (String) coreT[0];
            long total = (Long) coreT[1];

            // 업무분은 호선+POR 범위에서만 뜻이 있다 (bizPlan 주석) — IFSEQ 면 빈 묶음.
            String bizJson = "";
            long bizTotal = 0;
            if (mode.equals(M_SHIPPOR)) {
                Object[] bizT = tally(c, bizPlan(mode), mode, key, sh, pr);
                bizJson = (String) bizT[0];
                bizTotal = (Long) bizT[1];
            }

            // <남는 것> 은 이제 업무분이 그대로 보여 주므로 따로 세지 않는다.
            StringBuilder left = new StringBuilder();
            long leftTotal = 0;

            // 수신표에 그 범위가 아예 없으면 지울 것도 없다 — <0건> 과 <없는 범위> 는 다르다
            long recv = mode.equals(M_SHIPPOR)
                ? count(c, "select count(*) from SST02.Z_PD_C_LOCPOR x where "
                         + "substr(trim(x.SHIP_NO),1,6) = ? and trim(x.SHIP_NO) || trim(x.POR_NO) in (?, ?)",
                        mode, 1, key, sh, pr)
                : count(c, "select count(*) from SST02.Z_PD_C_LOCPOR z"
                         + " where z.IFSEQ = cast(? as char(50))", mode, 1, key, sh, pr);

            long notIf = mode.equals(M_SHIPPOR) ? notFromIf(c, sh, pr) : 0;

            return status(",\"mode\":\"locporscope\",\"scope\":" + q(mode)
                 + ",\"ifseq\":" + q(key) + ",\"ship\":" + q(sh) + ",\"por\":" + q(pr)
                 + ",\"recv\":" + recv + ",\"not_if\":" + notIf
                 + ",\"total\":" + total + ",\"del\":[" + del + "]"
                 + ",\"biz_total\":" + bizTotal + ",\"biz\":[" + bizJson + "]"
                 + ",\"left_total\":" + leftTotal + ",\"left\":[" + left + "]");
        } catch (SQLException e) {
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0) + ",\"error\":" + q(lastErr) + "}";
        }
    }

    /**
     * 되돌리기 — <b>지운다.</b> 한 트랜잭션으로 묶어, 하나라도 실패하면 통째로 되돌린다.
     * 반쯤 지워진 상태가 가장 나쁘다 — 다시 돌릴 수도, 쓸 수도 없는 원장이 된다.
     *
     * locporRun 과 같은 이유로 autoCommit 을 꺼서 커밋을 직접 쥔다(그쪽 주석 참고).
     */
    static String locporWipe(String mode, String ifseq, String ship, String por, String by, String part) {
        String key = (ifseq == null ? "" : ifseq.trim());
        String sh = (ship == null ? "" : ship.trim());
        String pr = (por == null ? "" : por.trim());
        if (mode.equals(M_SHIPPOR) ? (sh.isEmpty() || pr.isEmpty()) : key.isEmpty())
            return "{\"ok\":false,\"error\":\"범위가 모자랍니다 (ifseq 또는 ship+por).\"}";

        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";

        boolean auto = true;
        long t0 = System.currentTimeMillis();
        try {
            auto = c.getAutoCommit();
            try (CallableStatement s = c.prepareCall("begin dbms_application_info.set_module(?, ?); end;")) {
                s.setString(1, "WBS-WIPE/" + (by == null || by.isEmpty() ? "?" : by));
                String tag = mode.equals(M_SHIPPOR) ? sh + "/" + pr : key;
                s.setString(2, tag.length() > 32 ? tag.substring(0, 32) : tag);
                s.execute();
            }
            if (auto) c.setAutoCommit(false);

            StringBuilder done = new StringBuilder();
            long total = 0;
            for (String[] p : partPlan(mode, part)) {
                try (PreparedStatement ps =
                         c.prepareStatement("delete from " + p[1] + " where " + p[2])) {
                    ps.setQueryTimeout(45);
                    int at = 1;
                    for (int i = 0; i < num(p[3], 1); i++) at = fill(ps, at, mode, key, sh, pr);
                    int n = ps.executeUpdate();
                    if (done.length() > 0) done.append(',');
                    done.append(pair(p[0], n));
                    total += n;
                }
            }
            c.commit();

            return status(",\"mode\":\"locporwipe\",\"scope\":" + q(mode)
                 + ",\"part\":" + q(part)
                 + ",\"ifseq\":" + q(key) + ",\"ship\":" + q(sh) + ",\"por\":" + q(pr)
                 + ",\"total\":" + total + ",\"del\":[" + done + "]"
                 + ",\"ms\":" + (System.currentTimeMillis() - t0));
        } catch (SQLException e) {
            try { c.rollback(); } catch (SQLException ignore) { }
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0)
                 + ",\"mode\":\"locporwipe\",\"scope\":" + q(mode)
                 + ",\"ifseq\":" + q(key) + ",\"ship\":" + q(sh) + ",\"por\":" + q(pr)
                 + ",\"ms\":" + (System.currentTimeMillis() - t0)
                 + ",\"error\":" + q(lastErr) + "}";
        } finally {
            try { if (auto) c.setAutoCommit(true); } catch (SQLException ignore) { }
            try (CallableStatement s = c.prepareCall("begin dbms_application_info.set_module(null, null); end;")) {
                s.execute();
            } catch (SQLException ignore) { }
        }
    }

    /**
     * 표 이름들이 <b>어느 스키마에 있는지</b>. 계통도 화면이 <다른 스키마의 표>에 꼬리표를
     * 붙일 때 쓴다 (예: MTB_POR_OHD 는 NEW05 에 있다).
     *
     * 한 번에 묻는다 — 48개를 하나씩 물으면 왕복이 48번이고, 이 DB 는 그럴 여유가 없다.
     * 같은 이름이 여러 스키마에 있으면 <b>전부</b> 돌려준다. 고르는 것은 화면의 몫이다 —
     * 여기서 하나로 줄이면 "왜 M20 인데 M10 이라고 나오지" 를 서버가 정하게 된다.
     */
    static String owners(String names) {
        if (names == null || names.trim().isEmpty())
            return "{\"ok\":false,\"error\":\"names 가 필요합니다.\"}";

        // 이름은 영문·숫자·밑줄만 받는다. 글자로 이어 붙이는 IN 목록이라 여기서 막는다.
        List<String> want = new ArrayList<>();
        for (String raw : names.split(",")) {
            String t = raw.trim().toUpperCase();
            if (!t.isEmpty() && t.matches("[A-Z0-9_$#]{1,30}") && !want.contains(t)) want.add(t);
            if (want.size() >= 500) break;
        }
        if (want.isEmpty()) return "{\"ok\":false,\"error\":\"쓸 수 있는 이름이 없습니다.\"}";

        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"live\":0,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";
        try {
            StringBuilder marks = new StringBuilder();
            for (int i = 0; i < want.size(); i++) marks.append(i > 0 ? ",?" : "?");
            // all_tables 만 보면 <뷰·시노님>이 빠져 "어느 스키마에도 없다" 로 잘못 나온다.
            // 실제로 WORK_LIST·XFIA00700 이 그랬다. all_objects 로 넓히되 종류도 함께 준다.
            String sql = "select owner, object_name, object_type from all_objects"
                       + " where object_type in ('TABLE','VIEW','SYNONYM','MATERIALIZED VIEW')"
                       + "   and object_name in (" + marks + ")"
                       + " order by object_name, owner";
            StringBuilder rows = new StringBuilder();
            int n = 0;
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                for (int i = 0; i < want.size(); i++) ps.setString(i + 1, want.get(i));
                try (ResultSet r = ps.executeQuery()) {
                    while (r.next()) {
                        if (rows.length() > 0) rows.append(',');
                        rows.append("{\"owner\":").append(q(r.getString(1)))
                            .append(",\"name\":").append(q(r.getString(2)))
                            .append(",\"kind\":").append(q(r.getString(3))).append('}');
                        n++;
                    }
                }
            }
            return status(",\"mode\":\"owners\",\"asked\":" + want.size()
                 + ",\"count\":" + n + ",\"rows\":[" + rows + "]");
        } catch (SQLException e) {
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0) + ",\"error\":" + q(lastErr) + "}";
        }
    }

    /**
     * 한 사번의 세션을 <b>전부</b> 끊는다 — 놀고 있든 일하고 있든 가리지 않는다.
     *
     * ⚠️ 유휴 정리와는 무게가 다르다. 그 사람이 지금 쓰고 있는 것까지 끊기므로
     * 화면에서 두 번 눌러야 실행되게 해 두었다(실수로 한 번 눌러 날아가지 않도록).
     * 여기서도 막을 것은 막는다 — 관리 계정과 <나 자신>은 절대 건드리지 않는다.
     */
    static String killUser(String osuser) {
        if (osuser == null || !osuser.matches("[A-Za-z0-9_.\\-]{1,64}"))
            return "{\"ok\":false,\"error\":\"osuser 가 올바르지 않습니다.\"}";
        Connection c = take();
        if (c == null)
            return "{\"ok\":false,\"connected\":false,\"busy\":true,\"error\":"
                 + q(lastErr.isEmpty() ? "연결 없음" : lastErr) + "}";
        try {
            List<long[]> ids = new ArrayList<>();
            StringBuilder rows = new StringBuilder();
            try (PreparedStatement ps = c.prepareStatement(
                     "select sid, serial#, username, osuser, machine, program, logon_time, last_call_et,"
                   + "       (select count(*) from v$session x where x.osuser = s.osuser"
                   + "         and x.type='USER' and x.username is not null) procs,"
                   + "       status"
                   + "  from v$session s"
                   + " where s.type='USER' and s.username is not null"
                   + "   and s.osuser = ?"
                   + "   and s.sid <> sys_context('USERENV','SID')"
                   + "   and s.username not in (" + marks(ALWAYS_KEEP_USER.length) + ")"
                   + " order by s.last_call_et desc")) {
                int i = 1;
                ps.setString(i++, osuser);
                for (String k : ALWAYS_KEEP_USER) ps.setString(i++, k);
                try (ResultSet r = ps.executeQuery()) {
                    while (r.next()) {
                        ids.add(new long[] { r.getLong(1), r.getLong(2) });
                        if (rows.length() > 0) rows.append(',');
                        rows.append("{\"sid\":").append(r.getLong(1))
                            .append(",\"serial\":").append(r.getLong(2))
                            .append(",\"username\":").append(q(r.getString(3)))
                            .append(",\"osuser\":").append(q(r.getString(4)))
                            .append(",\"machine\":").append(q(r.getString(5)))
                            .append(",\"program\":").append(q(r.getString(6)))
                            .append(",\"logon\":").append(q(String.valueOf(r.getTimestamp(7))))
                            .append(",\"idle\":").append(r.getLong(8))
                            .append(",\"procs\":").append(r.getLong(9))
                            .append(",\"tgt\":").append(0)
                            .append(",\"status\":").append(q(r.getString(10)))
                            .append('}');
                    }
                }
            }

            StringBuilder killed = new StringBuilder();
            int okCnt = 0, failCnt = 0;
            for (long[] id : ids) {
                String stmt = "alter system disconnect session '" + id[0] + "," + id[1] + "' immediate";
                String err = null;
                try (Statement s = c.createStatement()) { s.execute(stmt); okCnt++; }
                catch (SQLException e) { err = oneLine(e.getMessage()); failCnt++; }
                if (killed.length() > 0) killed.append(',');
                killed.append("{\"sid\":").append(id[0]).append(",\"serial\":").append(id[1])
                      .append(",\"ok\":").append(err == null)
                      .append(",\"error\":").append(err == null ? "null" : q(err)).append('}');
            }

            long total = 0, inactive = 0, procCur = 0, procMax = 0;
            try (Statement s = c.createStatement();
                 ResultSet r = s.executeQuery("select count(*) t,"
                   + " sum(case when status='INACTIVE' then 1 else 0 end) i from v$session where type='USER'")) {
                if (r.next()) { total = r.getLong(1); inactive = r.getLong(2); }
            } catch (SQLException ignored) { }
            try (Statement s = c.createStatement();
                 ResultSet r = s.executeQuery("select current_utilization, limit_value"
                   + " from v$resource_limit where resource_name='processes'")) {
                if (r.next()) { procCur = r.getLong(1); procMax = parse(r.getString(2)); }
            } catch (SQLException ignored) { }

            return status(",\"mode\":\"killuser\",\"osuser\":" + q(osuser)
                 + ",\"total\":" + total + ",\"inactive\":" + inactive
                 + ",\"proc_cur\":" + procCur + ",\"proc_max\":" + procMax
                 + ",\"found\":" + ids.size() + ",\"ok_cnt\":" + okCnt + ",\"fail_cnt\":" + failCnt
                 + ",\"candidates\":[" + rows + "]"
                 + ",\"killed\":[" + killed + "]");
        } catch (SQLException e) {
            lastErr = oneLine(e.getMessage());
            return "{\"ok\":false,\"connected\":" + (live() > 0) + ",\"error\":" + q(lastErr) + "}";
        }
    }

    static String status(String extra) {
        long now = System.currentTimeMillis();
        return "{\"ok\":true,\"connected\":" + (live() > 0)
             + ",\"live\":" + live() + ",\"size\":" + size
             + ",\"reconnects\":" + reconnects
             + ",\"ok_ago\":" + (lastOkAt == 0 ? -1 : (now - lastOkAt) / 1000)
             + ",\"try_ago\":" + (lastTryAt == 0 ? -1 : (now - lastTryAt) / 1000)
             + ",\"last_error\":" + q(lastErr)
             + (extra == null ? "" : extra) + "}";
    }

    static String marks(int n) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < n; i++) { if (i > 0) b.append(','); b.append('?'); }
        return b.toString();
    }

    static int num(String s, int d) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return d; } }
    static long parse(String s) { try { return Long.parseLong(s.trim()); } catch (Exception e) { return 0; } }
    static String oneLine(String s) { return s == null ? "" : s.replaceAll("[\\r\\n]+", " ").trim(); }

    /**
     * NUMBER 한 칸을 <보여 줄 글자>로 편다. 꼬리의 0 은 떨군다 — NUMBER(14,2) 는 5 를
     * 5.00 으로 돌려주는데, 수량 칸에 5.00 이 깔리면 눈이 소수점에 걸린다.
     * <p>⚠️ 자릿수 구분 쉼표는 <b>넣지 않는다.</b> 이 화면의 칸 거르기는 «보이는 그대로 치면
     * 걸린다» 가 유일한 규칙이라, 1,200 으로 그려 두면 1200 을 쳤을 때 안 걸린다.
     * <p>⚠️ JSON 수가 아니라 글자로 내보낸다. 수로 보내면 받는 쪽에서 double 이 되어
     * 꼬리가 흔들린다(1.10 → 1.1000000000000001). null 은 빈칸이다.
     */
    static String dec(java.math.BigDecimal v) {
        return v == null ? "" : v.stripTrailingZeros().toPlainString();
    }

    static String q(String s) {
        if (s == null) return "null";
        StringBuilder b = new StringBuilder("\"");
        for (char ch : s.toCharArray()) {
            switch (ch) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default: if (ch < 0x20) b.append(String.format("\\u%04x", (int) ch)); else b.append(ch);
            }
        }
        return b.append('"').toString();
    }
}
