-- 개발자 관리에 모니터 3대를 더 둔다.
-- 노트북(notebook_no / notebook_chk_no)과 같은 짝이라 길이·형식도 같게 맞춘다.
--   *_no     장비번호
--   *_chk_no 확인번호

alter table public.dev_user
    add column if not exists monitor1_no     varchar(60),
    add column if not exists monitor1_chk_no varchar(60),
    add column if not exists monitor2_no     varchar(60),
    add column if not exists monitor2_chk_no varchar(60),
    add column if not exists monitor3_no     varchar(60),
    add column if not exists monitor3_chk_no varchar(60);

comment on column public.dev_user.monitor1_no     is '모니터1 장비번호';
comment on column public.dev_user.monitor1_chk_no is '모니터1 확인번호';
comment on column public.dev_user.monitor2_no     is '모니터2 장비번호';
comment on column public.dev_user.monitor2_chk_no is '모니터2 확인번호';
comment on column public.dev_user.monitor3_no     is '모니터3 장비번호';
comment on column public.dev_user.monitor3_chk_no is '모니터3 확인번호';
