<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { api } from '../api'
import { state, isSuper } from '../store'
import { useDragMove } from '../dragmove'

// 상세 목록의 대상(화면) 한 줄을 <만들고 고치는> 창. 두 가지를 한 창으로 하는 까닭은
// 입력칸이 37개이기 때문이다 — 두 벌로 두면 한쪽만 고쳐지는 고장이 조용히 난다.
//
//   row 가 없으면 추가,  row 가 있으면 수정.
//
// 평소 이 표(hhip_wbs_wrk2)는 엑셀 WBS 에서 들어온다. 그런데 엑셀에 아직 없는 화면이
// 먼저 생기는 일이 있어, 손으로 한 줄을 세우고 고칠 수 있어야 했다. 그래서 <목록에서
// 인라인으로 고칠 수 있는 것>만이 아니라 표의 컬럼 전부를 여기서 다룬다.
//
// 필수는 둘뿐이다 — 나머지는 비워 두고 나중에 고쳐도 된다.
//   systemcode : 모듈별 집계와 필터가 이것으로 나뉜다.
//   menu_nm    : 목록의 주 표시 항목.
//
// activity_id 는 받지 않아도 된다 — 엑셀 WBS 에서 나중에 확정되는 일이 있다.
// 그때까지 그 줄에는 ProjectView 캐시·일감이 붙지 않는다(그 둘은 이 값으로 행을 찾는다).
// 수정과 첨부는 row_uid 로 돌아가므로 ID 가 없어도 된다.
//
// 수정할 때 activity_id 는 <읽기 전용>이다. 바꿔치기는 ProjectView 캐시·일감이 가리키던
// 곳을 옮기는 일이라 이 창에서 조용히 할 일이 아니다. 비어 있을 때 채우는 것만 허락한다.
const props = defineProps({ row: { type: Object, default: null } })
const emit = defineEmits(['close', 'created', 'saved', 'deleted'])

const edit = computed(() => !!props.row)

const drag = useDragMove()

// ---------- 넣을 수 있는 것 전부 ----------
// 화면과 서버(Program.cs 의 insertable)가 같은 목록을 보고 있어야 한다. 한쪽만 늘리면
// 입력칸은 생겼는데 저장되지 않는, 눈에 안 보이는 고장이 난다.
//
// t: text(한 줄) · area(여러 줄) · date · check('o') · user(개발자 목록) · prio
const FIELDS = [
  { g: '기본', k: 'activity_id', label: 'Activity ID', t: 'text', ph: 'AAC-A376 (나중에 채워도 됩니다)',
    // 수정할 때는 잠근다 — 바꿔치기는 ProjectView 캐시·일감이 가리키던 곳을 옮기는 일이다
    lockOnEdit: true,
    tip: '엑셀 WBS 와 맞추는 키입니다. 비워 두면 목록의 Activity ID 칸에서 나중에 채울 수 있고, '
       + '채우기 전까지 그 줄은 ProjectView 캐시·일감이 붙지 않습니다.' },
  { g: '기본', k: 'pv_test_case_id', label: '단위테스트 코드', t: 'text', ph: 'AAC-TC729',
    tip: 'ProjectView 단위테스트 코드입니다. 목록에서 Activity ID 를 누르면 뜨는 메뉴의 '
       + '<단위테스트 상세> 가 이 값으로 열립니다 — 비워 두면 그 줄이 눌리지 않습니다. '
       + '여러 건을 한꺼번에 넣는 길은 따로 있습니다 (db/pv_test_case_id.sql).' },
  { g: '기본', k: 'systemcode', label: '모듈 코드', req: true, t: 'text', list: 'syscodes', ph: 'PMM004' },
  { g: '기본', k: 'system_nm', label: '모듈명', t: 'text', ph: '입고 관리' },
  { g: '기본', k: 'menu_nm', label: '메뉴명', req: true, t: 'text', wide: true, ph: '[4190] 국내자재 입고' },
  { g: '기본', k: 'program_id', label: '프로그램 ID', t: 'text', ph: 'PMM004.A010001' },
  { g: '기본', k: 'priority_order', label: '우선순위', t: 'prio' },
  { g: '기본', k: 'module', label: '업무 대분류', t: 'text' },
  { g: '기본', k: 'module_name', label: '업무 대분류명', t: 'text' },
  { g: '기본', k: 'new_dev2', label: '실작업대상', t: 'check', wide: true,
    tip: "목록의 기본 조회가 실작업대상(new_dev2='o')만 보여 줍니다. 끄면 만들어도 목록에 안 보입니다." },

  { g: '일정', k: 'plan_sdt', label: '계획시작일', t: 'date' },
  { g: '일정', k: 'plan_edt', label: '계획종료일', t: 'date' },
  { g: '일정', k: 'plan_sdt_c', label: '실적시작일', t: 'date' },
  { g: '일정', k: 'plan_edt_c', label: '실적종료일', t: 'date' },

  { g: '담당', k: 'user_bp_id', label: '담당자', t: 'user' },
  { g: '담당', k: 'user_real_id', label: '개발자', t: 'user' },
  { g: '담당', k: 'complate_yn', label: '완료', t: 'check' },
  { g: '담당', k: 'complate_real_yn', label: '개발자완료', t: 'check' },
  { g: '담당', k: 'recheck_yn', label: '재확인요청', t: 'check' },
  { g: '담당', k: 'comp_desc', label: '완료 코멘트', t: 'area', wide: true },

  { g: '대형', k: 'complate_big_yn', label: '대형완료', t: 'check' },
  { g: '대형', k: 'complate_real_big_yn', label: '대형개발자완료', t: 'check' },
  { g: '대형', k: 'recheck_big_yn', label: '대형재확인요청', t: 'check' },
  { g: '대형', k: 'db_ready_big_yn', label: '대형DB준비여부', t: 'check' },

  { g: '화면 속성', k: 'prog_type', label: '화면유형', t: 'text', list: 'progtypes',
    ph: '단일그리드(CRUD) / 마스터 디테일 / 조회·리포트' },
  { g: '화면 속성', k: 'asis_cs', label: 'AS-IS C# 소스', t: 'text', ph: 'P_30D1030_9.cs' },
  { g: '화면 속성', k: 'prog_type_desc', label: '화면 기능 요약', t: 'area', wide: true },
  { g: '화면 속성', k: 'menu_desc', label: '화면 설명', t: 'area', wide: true },
  { g: '화면 속성', k: 'report_use', label: '리포트 사용', t: 'check' },
  { g: '화면 속성', k: 'sheet_use', label: '엑셀 사용', t: 'check' },
  { g: '화면 속성', k: 'dwg_view_use', label: '도면 조회 사용', t: 'check' },
  { g: '화면 속성', k: 'por_view_use', label: 'POR 조회 사용', t: 'check' },
  { g: '화면 속성', k: 'mon_req_comp', label: '월 완료 요청본', t: 'check' },

  { g: '트리거', k: 'trg_exsit_chk', label: '트리거 존재 확인', t: 'text' },
  { g: '트리거', k: 'trg_use_chk', label: '발화 트리거', t: 'text', list: 'trgs', wide: true },
  { g: '트리거', k: 'trg_evt_rel', label: '연계 이벤트', t: 'area', wide: true },

  { g: '메모', k: 'comment', label: '개발 준비 메모', t: 'area', wide: true },
  { g: '메모', k: 'etc_desc', label: '기타 특이사항', t: 'area', wide: true },
]

const GROUPS = [...new Set(FIELDS.map((f) => f.g))]
const REQUIRED = FIELDS.filter((f) => f.req).map((f) => f.k)
const fieldsOf = (g) => FIELDS.filter((f) => f.g === g)

// ---------- 입력값 ----------
// 기본값은 <지금 표에 들어 있는 것과 같은 모양>으로 깔아 둔다 (전 행 MM / 자재관리 / 실작업대상).
function blank() {
  const f = {}
  for (const x of FIELDS) f[x.k] = x.t === 'check' ? false : ''
  f.module = 'MM'
  f.module_name = '자재관리'
  f.new_dev2 = true
  return f
}
const form = ref(blank())
const err = ref('')
const busy = ref(false)
const loading = ref(false)

// 수정 모드 — 목록에는 37개 중 일부만 실려 오므로(긴 글은 빼 둔다) 한 줄을 따로 받아 채운다.
// 받기 전에 손대지 못하도록 창을 잠가 둔다. 반쯤 채워진 칸에 글을 쓰다가 덮어써지면
// 무엇을 잃었는지 알 수가 없다.
async function fill() {
  if (!props.row) return
  loading.value = true
  try {
    const d = await api.rowOne(props.row.row_uid)
    const f = blank()
    for (const x of FIELDS) {
      const v = d[x.k]
      f[x.k] = x.t === 'check' ? v === 'o' : (v ?? '')
    }
    form.value = f
  } catch (e) {
    err.value = e.message
  } finally {
    loading.value = false
  }
}

// 이미 쓰고 있는 값들을 고를 수 있게 모아 둔다 (지금 조회된 목록이 근거라 완전하지는 않다)
const uniq = (key) => [...new Set(state.rows.map((r) => r[key]).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b), 'ko'))
const syscodes = computed(() => {
  const m = new Map()
  for (const r of state.rows) if (r.systemcode && !m.has(r.systemcode)) m.set(r.systemcode, r.system_nm || '')
  return [...m].sort((a, b) => a[0].localeCompare(b[0]))
})
const progtypes = computed(() => uniq('prog_type'))
const trgs = computed(() => uniq('trg_use_chk'))
const listOf = (name) => (name === 'syscodes' ? syscodes.value.map((x) => x[0]) : name === 'progtypes' ? progtypes.value : trgs.value)

/** 모듈 코드를 이미 쓰는 것으로 넣으면 모듈명을 함께 채워 준다 (손으로 고쳐 쓸 수 있다) */
function onSyscode() {
  const hit = syscodes.value.find((x) => x[0] === form.value.systemcode.trim())
  if (hit && !form.value.system_nm.trim()) form.value.system_nm = hit[1]
}

// ---------- 필수 · 중복 ----------
const missing = computed(() => REQUIRED.filter((k) => !String(form.value[k] ?? '').trim()))
/** 지금 고치고 있는 줄은 중복 검사에서 뺀다 (자기 자신과 겹친다고 할 수는 없다) */
const notSelf = (r) => !props.row || r.row_uid !== props.row.row_uid

// 서버도 막지만, 다 적고 나서 거절당하기 전에 미리 알려 준다
const dupId = computed(() => {
  const v = String(form.value.activity_id ?? '').trim().toUpperCase()
  if (!v) return null
  return state.rows.find((r) => notSelf(r) && String(r.activity_id ?? '').toUpperCase() === v) ?? null
})

// 모듈 + 메뉴명이 겹치면 목록에서 두 줄을 구별할 길이 없다 — 사람이 보는 표시가 이 둘뿐이다.
const dupName = computed(() => {
  const sc = String(form.value.systemcode ?? '').trim()
  const nm = String(form.value.menu_nm ?? '').trim()
  if (!sc || !nm) return null
  return state.rows.find((r) => notSelf(r) && r.systemcode === sc && r.menu_nm === nm) ?? null
})

/** Activity ID 를 비워 둔 채인가 (그래도 되지만 무엇이 미뤄지는지 알려 준다) */
const noId = computed(() => !String(form.value.activity_id ?? '').trim())

const canSave = computed(() =>
  !missing.value.length && !dupId.value && !dupName.value && !busy.value && !loading.value)

const labelOf = (k) => FIELDS.find((f) => f.k === k)?.label ?? k

async function submit() {
  if (!canSave.value) {
    err.value = missing.value.length
      ? `필수 항목이 비어 있습니다 — ${missing.value.map(labelOf).join(' · ')}`
      : err.value
    return
  }
  busy.value = true
  err.value = ''
  try {
    if (edit.value) {
      // 수정은 <전부> 보낸다. 빈 칸은 빈 문자열로 보내야 <비웠다> 는 뜻이 전해진다 —
      // 빼 버리면 서버가 그대로 두므로 지운 값이 되살아난다.
      const values = {}
      for (const f of FIELDS) {
        if (f.k === 'activity_id') continue      // 수정에서는 키를 바꾸지 않는다
        const v = form.value[f.k]
        values[f.k] = f.t === 'check' ? (v ? 'o' : '') : String(v ?? '').trim()
      }
      emit('saved', await api.rowUpdate(props.row.row_uid, values))
    } else {
      // 추가는 빈 칸을 아예 보내지 않는다 — 보내지 않는 쪽이 <무엇을 입력했는지> 그대로 드러난다
      const body = {}
      for (const f of FIELDS) {
        const v = form.value[f.k]
        if (f.t === 'check') { if (v) body[f.k] = 'o' }
        else if (String(v ?? '').trim()) body[f.k] = String(v).trim()
      }
      // activity_id 가 없을 수 있어 통째로 넘긴다 — 목록이 <어느 줄인지> 가려야 한다
      emit('created', await api.rowCreate(body))
    }
  } catch (e) {
    err.value = e.message
  } finally {
    busy.value = false
  }
}

// ---------- 삭제 ----------
//
// 되돌릴 수 없는 일이라 <한 번 누르면 바로> 로 두지 않았다. 다른 화면의 끊기와 무게가
// 다르다 — 저쪽은 다시 접속하면 그만이지만 이 줄은 돌아오지 않는다. 그렇다고 창(alert)을
// 띄우지도 않는다. 대신 이 창 안에서 <무엇이 함께 사라지는지>를 먼저 읽어 보여 주고,
// 그것을 본 사람이 [정말 삭제] 를 누르게 한다. 물어보기 위한 물어보기가 아니라
// 보여 주기 위한 한 박자다.
const asking = ref(false)
const deps = ref(null)
const depsErr = ref('')

async function askDelete() {
  asking.value = true
  deps.value = null
  depsErr.value = ''
  try { deps.value = await api.rowDeps(props.row.row_uid) }
  catch (e) { depsErr.value = e.message }
}

async function doDelete() {
  busy.value = true
  err.value = ''
  try {
    emit('deleted', await api.rowDelete(props.row.row_uid))
  } catch (e) {
    err.value = e.message
    asking.value = false
  } finally {
    busy.value = false
  }
}

function onKey(e) {
  // 확인 중이면 Esc 가 창이 아니라 <확인>을 먼저 닫는다 — 삭제를 물은 채로 창이
  // 사라지면 사람은 자기가 무엇을 눌렀는지 모른 채 끝난다.
  if (e.key === 'Escape' && asking.value) { asking.value = false; return }
  if (e.key === 'Escape') emit('close')
  // Enter 로 실수로 저장되지 않게 — 여러 칸짜리 창이라 Ctrl+Enter 로만 받는다.
  // 삭제를 묻는 중에는 받지 않는다 (지금 눌린 Enter 는 저장하려던 것이 아니다).
  else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && !e.isComposing && !asking.value) submit()
}
onMounted(() => {
  window.addEventListener('keydown', onKey)
  fill()
})
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <div class="mask">
    <div class="dlg" :class="{ moving: drag.moving.value }" :style="drag.style.value">
      <header class="grab" @pointerdown="drag.start($event)">
        <span class="hgrip" title="여기를 잡아 창을 옮깁니다">⠿</span>
        <strong>{{ edit ? '대상 수정' : '대상 추가' }}</strong>
        <span class="hint">
          <template v-if="edit">{{ row.activity_id || 'ID 미정' }} · {{ row.menu_nm }}</template>
          <template v-else>상세 목록에 새 화면 한 줄을 만듭니다</template>
          · <b class="req">*</b> 는 필수
        </span>
        <span class="spacer"></span>
        <button v-if="drag.moved()" title="창을 원래 자리로" @click="drag.reset()">⌖</button>
        <button class="x" title="닫기 (Esc)" @click="emit('close')">✕</button>
      </header>

      <div class="body" :class="{ wait: loading }">
        <p v-if="loading" class="loading">지금 값을 읽는 중입니다…</p>

        <section v-for="g in GROUPS" :key="g" class="grp">
          <h3>{{ g }}</h3>
          <div class="grid">
            <label v-for="f in fieldsOf(g)" :key="f.k" class="fld" :class="{ wide: f.wide, miss: f.req && !String(form[f.k] ?? '').trim() }">
              <span class="lb" :title="f.tip">
                {{ f.label }}<b v-if="f.req" class="req" aria-label="필수">*</b>
                <em class="col">{{ f.k }}</em>
              </span>

              <textarea v-if="f.t === 'area'" v-model="form[f.k]" rows="2" :placeholder="f.ph"></textarea>

              <input v-else-if="f.t === 'date'" v-model="form[f.k]" type="date" />

              <span v-else-if="f.t === 'check'" class="chk">
                <input :id="`f_${f.k}`" v-model="form[f.k]" type="checkbox" />
                <label :for="`f_${f.k}`">{{ form[f.k] ? "예 (o)" : '아니오' }}</label>
              </span>

              <select v-else-if="f.t === 'user'" v-model="form[f.k]">
                <option value="">(미지정)</option>
                <option v-for="u in state.devUsers" :key="u.bp_id" :value="u.bp_id">
                  {{ u.name }} ({{ u.bp_id }})
                </option>
              </select>

              <select v-else-if="f.t === 'prio'" v-model="form[f.k]">
                <option value="">(미지정)</option>
                <option value="1">1 · 선행</option>
                <option value="2">2 · 후행</option>
              </select>

              <!-- 수정할 때 Activity ID 는 잠근다. 비어 있으면 어디서 채우는지 알려 준다. -->
              <input
                v-else
                v-model="form[f.k]"
                type="text"
                :placeholder="f.ph"
                :readonly="edit && f.lockOnEdit"
                :class="{ ro: edit && f.lockOnEdit }"
                :title="edit && f.lockOnEdit
                  ? (form[f.k]
                      ? '여기서는 바꾸지 않습니다 — ProjectView 캐시·일감이 이 값을 가리킵니다'
                      : '목록의 Activity ID 칸에 있는 [＋ ID] 로 채웁니다')
                  : f.tip"
                :list="f.list ? `dl_${f.list}` : undefined"
                @change="f.k === 'systemcode' ? onSyscode() : null"
              />
            </label>
          </div>
        </section>

        <!-- 이미 쓰고 있는 값들 — 고르면 되고, 새 값을 적어도 된다 -->
        <datalist id="dl_syscodes">
          <option v-for="[code, nm] in syscodes" :key="code" :value="code">{{ nm }}</option>
        </datalist>
        <datalist id="dl_progtypes"><option v-for="v in progtypes" :key="v" :value="v"></option></datalist>
        <datalist id="dl_trgs"><option v-for="v in trgs" :key="v" :value="v"></option></datalist>
      </div>

      <footer>
        <p v-if="dupId" class="msg bad">
          이미 있는 Activity ID 입니다 — <b>{{ dupId.activity_id }}</b> {{ dupId.menu_nm }}
        </p>
        <p v-else-if="dupName" class="msg bad">
          같은 모듈에 같은 메뉴명이 이미 있습니다 — <b>{{ dupName.systemcode }}</b> {{ dupName.menu_nm }}
          ({{ dupName.activity_id || 'Activity ID 없음' }})
        </p>
        <p v-else-if="missing.length" class="msg">
          필수 항목 {{ missing.length }}개가 비어 있습니다 — {{ missing.map(labelOf).join(' · ') }}
        </p>
        <p v-else-if="err" class="msg bad">{{ err }}</p>
        <p v-else-if="noId" class="msg warn">
          Activity ID 가 비어 있습니다 — 채우기 전까지 이 줄에는 <b>ProjectView 캐시 · 일감</b>이 붙지 않습니다
          (수정과 첨부는 됩니다). 목록의 Activity ID 칸 <b>＋ ID</b> 로 채웁니다.
        </p>
        <p v-else-if="edit" class="msg ok">빈 칸으로 두면 그 값은 <b>비워집니다</b>.</p>
        <p v-else class="msg ok">입력한 것만 저장합니다. 나머지는 나중에 고칠 수 있습니다.</p>
        <span class="spacer"></span>
        <!-- 삭제는 저장 단추에서 멀리 떼어 놓는다 — 둘이 붙어 있으면 손이 미끄러진다 -->
        <button v-if="edit && isSuper" class="del" :disabled="busy || asking" @click="askDelete">삭제</button>
        <button :disabled="busy" @click="emit('close')">취소</button>
        <button class="go" :disabled="!canSave" title="Ctrl+Enter" @click="submit">
          {{ busy ? '저장 중…' : edit ? '저장' : '추가' }}
        </button>
      </footer>

      <!-- 무엇이 함께 사라지는지 보여 주고 나서 누르게 한다. 되돌릴 수 없는 일이다. -->
      <div v-if="asking" class="ask">
        <div class="askbox">
          <strong>이 대상을 지웁니다 — 되돌릴 수 없습니다.</strong>
          <p class="who">
            <b>{{ row.systemcode }}</b> · {{ row.menu_nm }}
            <span class="aid">{{ row.activity_id || 'Activity ID 없음' }}</span>
          </p>

          <p v-if="depsErr" class="msg bad">{{ depsErr }}</p>
          <p v-else-if="!deps" class="msg">무엇이 딸려 있는지 읽는 중입니다…</p>
          <ul v-else class="deps">
            <li :class="{ none: !deps.files }">
              첨부 <b>{{ deps.files }}</b>건
              <em v-if="deps.files">— 지우지 않고 <code>api/data/deleted_rows/</code> 로 옮깁니다</em>
            </li>
            <li v-if="deps.tasks_kept" class="keep">
              일감 <b>{{ deps.tasks }}</b>건 — <b>그대로 둡니다.</b>
              같은 Activity ID 를 쓰는 줄이 {{ deps.siblings }}개 더 있어 그 줄들 것이기도 합니다
            </li>
            <li v-else :class="{ none: !deps.tasks }">
              일감 <b>{{ deps.tasks }}</b>건<em v-if="deps.tasks"> — 함께 지웁니다</em>
            </li>
            <li class="none">ProjectView 캐시는 건드리지 않습니다 (다시 받으면 되는 사본입니다)</li>
          </ul>

          <p class="bak">지우기 전에 이 줄의 모든 값을 <code>api/data/deleted_rows/</code> 에 남깁니다.</p>

          <div class="askbtn">
            <span class="spacer"></span>
            <button :disabled="busy" @click="asking = false">그만두기</button>
            <button class="del go" :disabled="busy || !deps" @click="doDelete">
              {{ busy ? '지우는 중…' : '정말 삭제' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.mask {
  position: fixed;
  inset: 0;
  background: var(--overlay);
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 40px 20px;
  z-index: 100;
}
.dlg {
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 10px;
  width: min(900px, 100%);
  max-height: calc(100vh - 80px);
  display: flex;
  flex-direction: column;
  box-shadow: 0 8px 28px var(--shadow);
  position: relative;   /* 삭제 확인(.ask)이 이 창 안에 겹치도록 */
}
.dlg header,
.dlg footer { display: flex; align-items: center; gap: 8px; padding: 10px 14px; flex: none; }
.dlg header { border-bottom: 1px solid var(--line); }
.dlg header.grab { cursor: move; user-select: none; touch-action: none; }
.dlg.moving { box-shadow: 0 14px 40px var(--shadow-2); }
.hgrip { color: var(--muted-3); font-size: 13px; }
.dlg header .hint { font-size: 11.5px; color: var(--muted); }
.spacer { flex: 1; }

.body { flex: 1 1 auto; min-height: 0; overflow: auto; padding: 4px 14px 14px; }
/* 값을 읽어 오는 동안은 손대지 못하게 — 쓰던 글이 덮어써지면 무엇을 잃었는지 알 수 없다 */
.body.wait { opacity: 0.5; pointer-events: none; }
.loading { margin: 10px 0 0; font-size: 12px; color: var(--muted); text-align: center; }
.grp { margin-top: 12px; }
.grp h3 {
  font-size: 11.5px; color: var(--muted); font-weight: 600; margin: 0 0 6px;
  border-bottom: 1px solid var(--line); padding-bottom: 4px;
}
.grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 14px; }
@media (max-width: 680px) { .grid { grid-template-columns: 1fr; } }
.fld { display: flex; flex-direction: column; gap: 3px; min-width: 0; }
.fld.wide { grid-column: 1 / -1; }
.fld .lb { font-size: 11.5px; color: var(--muted); display: flex; align-items: baseline; gap: 4px; }
/* 컬럼 이름을 함께 보여 준다 — 엑셀 WBS·DB 와 맞춰 넣을 때 이것이 있어야 헷갈리지 않는다 */
.fld .lb .col { font-style: normal; font-size: 10px; color: var(--muted-2); margin-left: auto; }
.fld input[type='text'],
.fld input[type='date'],
.fld select,
.fld textarea { width: 100%; font-size: 12.5px; }
.fld textarea { resize: vertical; font-family: inherit; line-height: 1.5; }
/* 필수인데 비어 있으면 테두리로 알려 준다 (제출해 봐야 아는 일이 없게) */
.fld.miss input, .fld.miss select { border-color: var(--warn); }
/* 수정에서 잠긴 칸 — 눌리기는 하지만 고쳐지지 않는다는 것이 보여야 한다 */
.fld input.ro { background: var(--bg); color: var(--muted); cursor: default; }
.req { color: var(--danger-2); font-weight: 700; }
.chk { display: flex; align-items: center; gap: 6px; height: 26px; }
.chk label { font-size: 12.5px; color: var(--text); cursor: pointer; }

.dlg footer { border-top: 1px solid var(--line); }
.dlg footer .msg { margin: 0; font-size: 11.5px; color: var(--muted); min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dlg footer .msg.bad { color: var(--danger-2); }
.dlg footer .msg.warn { color: var(--warn); }
.dlg footer .msg.ok { color: var(--muted); }
.go:disabled { opacity: 0.5; }
header .x { border: 0; background: transparent; font-size: 14px; color: var(--muted); padding: 2px 6px; }
header .x:hover { color: var(--text); }

/* 삭제 확인 — 창 위에 겹쳐 띄운다. 새 창을 띄우지 않는 까닭: 이 자리에서 보여 줘야
   <지금 열어 둔 그 줄>을 지운다는 것이 분명하다. 바깥을 눌러도 닫히지 않는다. */
.ask {
  position: absolute;
  inset: 0;
  background: var(--overlay);
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  padding: 16px;
}
.askbox {
  background: var(--panel);
  border: 1px solid var(--danger-line);
  border-radius: 10px;
  box-shadow: 0 10px 30px var(--shadow);
  padding: 14px 16px;
  width: min(560px, 100%);
  max-height: 100%;
  overflow: auto;
}
.askbox > strong { color: var(--danger-text); font-size: 13.5px; }
.askbox .who { margin: 6px 0 10px; font-size: 12.5px; }
.askbox .who .aid { color: var(--muted); margin-left: 8px; font-variant-numeric: tabular-nums; }
.askbox .deps { margin: 0 0 10px; padding-left: 18px; font-size: 12.5px; line-height: 1.75; }
.askbox .deps li.none { color: var(--muted); }
.askbox .deps li.keep { color: var(--warn); }
.askbox .deps em { font-style: normal; color: var(--muted); font-size: 11.5px; }
.askbox .bak { margin: 0 0 12px; font-size: 11.5px; color: var(--muted); }
.askbox .askbtn { display: flex; align-items: center; gap: 8px; }
.askbtn .spacer { flex: 1; }
button.del { color: var(--danger-text); border-color: var(--danger-line); }
button.del:hover:not(:disabled) { background: var(--danger-soft); border-color: var(--danger); }
button.del.go { background: var(--danger); border-color: var(--danger); color: #fff; }
button.del.go:hover:not(:disabled) { background: var(--danger-text); }
</style>
