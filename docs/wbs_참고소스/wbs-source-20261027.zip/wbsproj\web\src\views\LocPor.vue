<script setup>
import { computed, ref } from 'vue'
import { api } from '../api'
import { useViewRefresh } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'

// 현지 POR I/F 후행처리 — SAP 이 보낸 현지 POR 수신분(SST02.Z_PD_C_LOCPOR)을 보여 주고,
// 고른 IFSEQ 로 M20.PKG_PD_LOCPOR_IF.SP_LOCPOR_AFTER_INSERT 를 부른다 (api/LocPor.cs).
//
// 평소 이 프로시저를 부르는 것은 EAI 다. 적재가 끝나면 이어서 부른다. 개발 중에는 그
// <뒷부분만> 따로 돌려 봐야 하는데 — SAP 에 다시 보내 달라고 할 수가 없다 — 그 자리를
// 사람 손으로 대신 누르는 화면이다.
//
// ⚠️ 이 화면의 실행은 <돌이킬 수 없다>. 그래서 셋을 지킨다.
//   ① 목록(읽기)과 실행(쓰기)을 갈라 둔다 — 무엇을 돌리는지 먼저 보여 준다.
//   ② 실행은 두 번 눌러야 한다. 한 번으로 되는 자리가 아니다.
//   ③ 돌린 자취를 숨기지 않는다 — 목록에 <이미 돌림> 꼬리표를 붙이고 이력을 함께 보여 준다.

const rows = ref([])
const conn = ref(null)      // 상주 연결 상태 (목록 응답에 함께 실려 온다)
const logs = ref([])
const picked = ref(null)    // 고른 한 줄 (IFSEQ 가 아니라 줄 자체 — 화면에 함께 보여 준다)
const result = ref(null)    // 마지막 실행 결과
const q = ref('')
const busy = ref('')
const msg = ref('')
const armed = ref(false)    // 실행 단추가 <한 번 눌린> 상태인지
const loadedAt = ref('')    // 수신 목록을 언제 읽었나 (다시 읽기가 먹었는지 보이려고)
let disarm = null

const count = computed(() => rows.value.length)
const done = computed(() => rows.value.filter((r) => r.run_status).length)

// ---------- 표 접기 ----------
//
// 두 표가 다 길다(수신 46줄 · 이력 50줄). 실행 자리까지 가려면 늘 한참을 굴려야 해서
// 머리줄에서 접는다. 다음에 들어와도 접힌 채로 보이도록 브라우저에 기억한다 —
// 들어올 때마다 다시 접어야 하면 접는 뜻이 없다.
const FOLD_KEY = 'wbs.locpor.folded'
function readLs(k) {
  try { return localStorage.getItem(k) } catch { return null }
}
function writeLs(k, v) {
  try { localStorage.setItem(k, v) } catch { /* 못 적어도 이번 화면에서는 그대로 쓴다 */ }
}
function readFold() {
  try { return new Set(JSON.parse(readLs(FOLD_KEY) || '[]')) } catch { return new Set() }
}
const folded = ref(readFold())

function fold(key) {
  const n = new Set(folded.value)
  if (n.has(key)) n.delete(key)
  else n.add(key)
  folded.value = n
  writeLs(FOLD_KEY, JSON.stringify([...n]))
}

/** 수신일시 — ZIFDAT(YYYYMMDD) · ZIFTIM(HH24MISS) 두 칸으로 온다. 비어 있는 줄도 많다. */
function recv(r) {
  if (!r.zifdat) return ''
  const d = r.zifdat
  const t = r.ziftim ?? ''
  return (
    `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}` +
    (t.length >= 6 ? ` ${t.slice(0, 2)}:${t.slice(2, 4)}:${t.slice(4, 6)}` : '')
  )
}

const mark = (s) => (s === 'S' ? '정상' : s === 'E' ? '오류' : s === 'R' ? '처리중' : '')

/**
 * 요청수량(`Z_PD_C_LOCPOR.POR_QTY` · 구매요구수량) 을 칸에 적을 글자로.
 *
 * 꼬리 0 은 이미 Java 쪽(`OraPool.dec`)에서 떨어져 온다 — NUMBER(14,2) 라 5 가 5.00 으로
 * 돌아온다. 여기서는 <없음>만 가린다. 0 은 지우지 않는다 — 수량 0 과 값이 안 온 것은
 * 다른 말이고, 섞어 비워 두면 «수량이 비었다» 로 읽힌다.
 *
 * ⚠️ 자릿수 쉼표를 넣지 않는다. 이 표의 칸 거르기는 «보이는 그대로 치면 걸린다» 가
 *    유일한 규칙이라, 1,200 으로 그려 두면 1200 을 쳤을 때 안 걸린다.
 */
const qty = (r) => (r.por_qty === null || r.por_qty === undefined || r.por_qty === '' ? '' : String(r.por_qty))

// 화면의 다른 시각들과 같은 꼴로 적는다(10:57:10). toLocaleTimeString 은 ko-KR 에서
// <13시 25분 55초> 를 내놓아 이 화면만 혼자 다른 말을 쓰게 된다.
const hhmmss = () => {
  const d = new Date()
  const p = (n) => String(n).padStart(2, '0')
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

// ---------- 컬럼 머리글 필터 ----------
//
// 서버 조회(위의 [조회])와 **층이 다르다.** 저쪽은 DB 에서 덜 가져오는 것이고,
// 이쪽은 **이미 가져온 것 안에서** 추리는 것이다. 둘을 같은 칸에 섞어 두면 「왜 46건이
// 그대로지」가 된다 — 그래서 머리줄에 <46건 중 12건> 꼴로 두 수를 나란히 적는다.
//
// 표마다 칸 짜임이 달라 만들어 쓰는 꼴로 둔다(makeFilter). 본문 칸은 꼬리표·말풍선이
// 칸마다 달라 손으로 그린 그대로 두고, **머리글과 필터줄만** 이 명세로 그린다.
//
// type:
//   text — 부분일치(대소문자 안 가린다). 긴 글(IFSEQ · 공사내용 · 오류)에 쓴다.
//   pick — 지금 불러온 줄에 **실제로 있는 값**만 건수와 함께 고른다. 없는 값을 고를 수
//          있으면 0건이 나오고, 그게 필터 탓인지 자료 탓인지 알 수 없다.
//   opts — 값이 코드라 눈에 보이는 말로 바꿔 줘야 하는 칸(상태·삭제여부).

/** 고를 수 있는 <빈칸> 표시. 빈 문자열은 이미 <전체>가 쓰고 있어 따로 둔다. */
const BLANK = '\u0000'

/** 그 칸의 <거르는 데 쓰는 값>. 화면에 보이는 것과 같아야 사람이 납득한다. */
const cellOf = (r, c) => String((c.val ? c.val(r) : r[c.key]) ?? '')

function makeFilter(cols, src) {
  const f = ref({})

  const on = computed(() => cols.some((c) => f.value[c.key]))

  const shown = computed(() =>
    src.value.filter((r) =>
      cols.every((c) => {
        const want = f.value[c.key]
        if (!want) return true
        const got = cellOf(r, c)
        if (c.type === 'text') return got.toUpperCase().includes(want.toUpperCase())
        return want === BLANK ? got === '' : got === want
      }),
    ),
  )

  // 고를 값은 <거르기 전 전체>에서 뽑는다. 거른 뒤에서 뽑으면 한 칸을 고르는 순간
  // 다른 칸의 고를 거리가 사라져, 고른 것을 되돌리지 않고는 다른 값으로 못 옮긴다.
  const opts = computed(() => {
    const out = {}
    for (const c of cols) {
      if (c.type !== 'pick') continue
      const cnt = new Map()
      for (const r of src.value) {
        const v = cellOf(r, c)
        cnt.set(v, (cnt.get(v) ?? 0) + 1)
      }
      out[c.key] = [...cnt.entries()]
        .sort((a, b) => a[0].localeCompare(b[0], 'ko', { numeric: true }))
        .map(([v, n]) => ({ value: v === '' ? BLANK : v, label: v === '' ? '(빈칸)' : v, cnt: n }))
    }
    return out
  })

  return { f, on, shown, opts, clear: () => (f.value = {}) }
}

// 수신 목록은 <모든 칸이 글자 검색>이다 (2026-10-20 지시).
//
// 그래서 규칙이 하나로 선다 — <b>칸에 보이는 그대로 치면 걸린다.</b> 거르는 값은 언제나
// 그 칸에 <그려지는 글자>이고, 원본 값이 아니다. 둘이 다른 칸은 val 로 맞춰 둔다:
// 수신일시는 원본이 20261020(보이는 것은 2026-10-20), 삭제·후행처리는 원본이 코드다.
//
// ⚠️ 고르는 목록이 없어졌으므로 <어떤 값이 있는지>는 화면에 안 나온다. 밑줄의 안내가
//    그것을 대신한다 — 지우면 사람이 무엇을 칠 수 있는지 알 길이 없어진다.
const LIST_COLS = [
  { key: 'ifseq', label: 'IFSEQ', type: 'text' },
  { key: 'ship_no', label: '호선', type: 'text' },
  { key: 'por_no', label: 'POR', type: 'text' },
  { key: 'line_no', label: '행', type: 'text' },
  { key: 'rev_no', label: '회차', type: 'text' },
  { key: 'req_dept', label: '요구부서', type: 'text' },
  { key: 'reg_emp_id', label: '등록자', type: 'text' },
  { key: 'work_desc', label: '공사내용', type: 'text' },
  // 수량은 줄(LINE_NO)마다 다른 값이라 호선·POR 쪽이 아니라 공사내용 옆에 둔다.
  // 단위는 수량 바로 옆이어야 한다 — 떼어 놓으면 「5」가 5개인지 5세트인지 읽히지 않는다
  // (이 도면에는 EA 와 SET 이 섞여 있다).
  { key: 'por_qty', label: '요청수량', type: 'text', val: qty, num: true },
  { key: 'matl_unit', label: '단위', type: 'text' },
  { key: 'recv', label: '수신일시', type: 'text', val: recv },
  // 칸에는 'Y' 아니면 빈칸이 보인다 — 보이는 그대로 'Y' 를 치면 걸린다
  { key: 'zdelflg', label: '삭제', type: 'text', val: (r) => (r.zdelflg === 'Y' ? 'Y' : '') },
  // 이 화면에서 가장 많이 쓰는 칸 — <아직 안 돌린 것>을 추려 보려고 들어온다.
  // 그래서 안 돌린 줄의 칸을 '—' 가 아니라 <안 돌림> 으로 적는다. 글자 검색만 남은 이상
  // 보이는 말이 곧 칠 말이라, '—' 로 두면 그 줄만 <칠 수 없는 칸>이 된다.
  { key: 'run_status', label: '후행처리', type: 'text', val: (r) => mark(r.run_status) || '안 돌림' },
]

const LOG_COLS = [
  { key: 'log_seq', label: '#', type: '' },
  { key: 'ifseq', label: 'IFSEQ', type: 'text' },
  {
    key: 'status', label: '상태', type: 'opts',
    opts: [
      { value: 'S', label: '정상' },
      { value: 'E', label: '오류' },
      { value: 'R', label: '처리중' },
    ],
  },
  { key: 'target_cnt', label: '수신', type: '' },
  { key: 'call_dtm', label: '호출', type: 'text' },
  { key: 'end_dtm', label: '종료', type: '' },
  { key: 'call_user', label: '계정', type: 'pick' },
  // 모듈로 <대시보드가 부른 것(WBS/…)>과 <EAI 가 부른 것>을 갈라 보는 것이 이 표의 쓸모다
  { key: 'call_module', label: '모듈', type: 'pick' },
  { key: 'call_ip', label: 'IP', type: 'pick' },
  { key: 'err_msg', label: '오류', type: 'text' },
]

const listF = makeFilter(LIST_COLS, rows)
const logF = makeFilter(LOG_COLS, logs)

// 템플릿에서 쓸 이름을 <맨 위 const> 로 펴 둔다. 묶음(listF) 안에 둔 채로 쓰면
// listF.on.value 처럼 적어야 하고(묶음 안의 ref 는 저절로 벗겨지지 않는다),
// v-model 에서는 그 꼴이 조용히 안 먹는다.
const lf = listF.f
const lfOpts = listF.opts
const listOn = listF.on
const shownRows = listF.shown

const gf = logF.f
const gfOpts = logF.opts
const logOn = logF.on
const shownLogs = logF.shown

// ⚠️ 찾는 중에는 접어 둔 것도 펼쳐 보여 준다. 접힌 채로 두면 찾으라고 누른 결과가
// 안 보여 <한 건도 없다>로 읽힌다. 접어 둔 기억은 건드리지 않고 보여 주기만 한다.
// 화면의 입력칸(q)이 아니라 <서버가 실제로 걸어 준 검색어>를 본다 — 치기만 하고
// 조회를 안 누른 상태에서 펼쳐지면 지금 보이는 목록과 어긋난다.
//
// ⚠️ <칸 필터>는 여기 넣지 않는다 — 접기가 이긴다. 위의 [조회]는 표 **바깥**에 있어서
// 접힌 채로도 누를 수 있지만, 칸 필터는 표 **안**에 있어 접으면 함께 숨는다. 필터가
// 걸렸다고 펼쳐 두면 **[접기]를 눌러도 아무 일이 안 일어난다** — 고장으로 보인다.
// 접은 채로 걸려 있는 필터는 머리줄의 <46건 중 12건> 으로 드러난다.
const searching = computed(() => !!conn.value?.q)
const listOpen = computed(() => searching.value || !folded.value.has('list'))
const logOpen = computed(() => !folded.value.has('log'))

async function load(keepMsg = false) {
  busy.value = 'list'
  if (!keepMsg) msg.value = ''
  try {
    const r = await api.locporList(q.value, 500)
    conn.value = r.run
    if (r.run.ok === false) {
      rows.value = []
      msg.value = r.run.error ?? '수신 목록을 읽지 못했습니다.'
    } else {
      rows.value = r.run.rows ?? []
      loadedAt.value = hhmmss()
      // 고른 줄은 유지하되 <방금 읽은 값>으로 바꿔 끼운다. 그대로 두면 실행 뒤에도
      // 옛 이력(«아직 안 돌림»)이 붙어 있어 또 눌러도 되는 것처럼 보인다.
      if (picked.value) {
        picked.value = rows.value.find((x) => x.ifseq === picked.value.ifseq) ?? null
      }
    }
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

/**
 * 표 머리줄의 다시 읽기.
 *
 * 고른 줄이 있으면 <전개분>도 함께 다시 센다 — 목록만 새로 읽고 전개분을 옛 수로 두면,
 * 방금 읽은 줄 옆에 묵은 수가 붙는다. 그 수를 보고 지우는 자리라 어긋나면 안 된다.
 */
async function reloadList() {
  await load()
  if (picked.value) await loadScope()
}

/** 화면 전체 — 머리말의 단추와 사이드바의 전체 새로고침이 함께 쓴다. */
async function reloadAll() {
  await reloadList()
  await loadLogs()
}

async function loadLogs() {
  busy.value = 'log'
  try {
    const r = await api.locporLog(picked.value?.ifseq ?? null, 50)
    logs.value = r.run.ok === false ? [] : (r.run.logs ?? [])
    if (r.run.ok === false) msg.value = r.run.error ?? '호출이력을 읽지 못했습니다.'
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

// ---------- 전개분 되돌리기 ----------
//
// 후행처리는 <재실행 안전>하게 짜여 있다(MERGE · NOT EXISTS). 그 말은 두 번째 실행이
// 이미 있는 것을 건드리지 않는다는 뜻이라, 바뀐 매핑을 시험하려면 만들어진 것을 먼저
// 치워야 처음처럼 돈다. 그 치우는 일이다.
//
// ⚠️ 이 화면에서 가장 위험한 자리다. 실행은 <만드는> 일이지만 이쪽은 <지우는> 일이고,
//    원장(POR 헤더·라인)·발주(PO)·자재마스터까지 간다. 그래서 셋을 지킨다.
//   ① 줄을 고르면 <무엇이 몇 건 지워지는지> 를 묻지 않아도 먼저 세어 보여 준다.
//   ② 지울 것이 0건이면 단추가 아예 안 눌린다.
//   ③ 두 번 눌러야 하고, 겨눈 단추에 <몇 건을 지우는지> 가 적혀 있다.
const scope = ref(null)     // 지울 것 · 남는 것 (세기만 한 결과)
const wiped = ref(null)     // 마지막으로 지운 결과
const wipeArmed = ref("")   // 겨눠진 단추 — "" · core · biz · all
let wipeDisarm = null

// 지울 범위 — 'ifseq'(고른 한 묶음) 또는 'shippor'(그 POR 통째).
//
// 호선+POR 이 필요한 까닭: 한 POR 이 <여러 IFSEQ 로 나뉘어> 들어온다(실측 J015/AA04 는
// 12개 · 줄 07·08). IFSEQ 범위로 지우면 고른 묶음의 줄만 사라지고 나머지는 화면에 그대로
// 남는다 — 「다 지웠는데 왜 보이지」가 거기서 난다.
//
// ⚠️ 대신 호선+POR 은 <수신표에 없는 줄>까지 지운다. 그것이 이 모드의 쓸모이자 위험이다.
const wipeScope = ref("ifseq")

function setScope(v) {
  if (wipeScope.value === v) return
  wipeScope.value = v
  standWipe()      // 범위가 바뀌었으면 겨눈 것을 내린다 — 다른 것을 지울 뻔한다
  loadScope()
}

function standWipe() {
  wipeArmed.value = ""
  if (wipeDisarm) { clearTimeout(wipeDisarm); wipeDisarm = null }
}

/** 지금 범위를 API 가 받는 꼴로. 고른 줄에서 호선·POR 을 그대로 가져온다. */
const scopeArg = () =>
  wipeScope.value === 'shippor'
    ? { ship: picked.value.ship_no, por: picked.value.por_no }
    : { ifseq: picked.value.ifseq }

async function loadScope() {
  if (!picked.value) { scope.value = null; return }
  busy.value = 'scope'
  try {
    const r = await api.locporScope(scopeArg())
    if (r.run.ok === false) {
      scope.value = null
      msg.value = r.run.error ?? '전개분을 세지 못했습니다.'
    } else {
      scope.value = r.run
    }
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

/** 0 건인 표는 접어 둔다 — 열 줄 가운데 둘만 걸리는 일이 흔하다. */
const delHit = computed(() => (scope.value?.del ?? []).filter((d) => d.n > 0))
const bizHit = computed(() => (scope.value?.biz ?? []).filter((d) => d.n > 0))

/**
 * 지울 묶음은 셋이고, <b>단추도 셋</b>이다 — 전개분만 · 업무분만 · 둘 다.
 * 각 단추가 제 건수를 달고, 겨누는 것도 따로다(`wipeArmed` 가 어느 단추인지 들고 있다).
 *
 * <b>업무분만</b>이 따로 있는 까닭 — POR 원장은 그대로 두고 그 뒤 업무 자취만 걷어내고
 * 싶을 때가 있다. 그러면 후행처리를 다시 돌릴 필요 없이 업무만 다시 태울 수 있다.
 */
const PARTS = {
  core: { label: '전개분', n: () => scope.value?.total ?? 0 },
  biz: { label: '업무분', n: () => scope.value?.biz_total ?? 0 },
  all: { label: '전개분+업무분', n: () => (scope.value?.total ?? 0) + (scope.value?.biz_total ?? 0) },
}
const partN = (p) => PARTS[p].n()

/** 업무분을 셀 수 있는 범위인가 — 호선+POR 일 때만 그렇다. */
const shipPorScope = computed(() => wipeScope.value === 'shippor')

async function wipe(part) {
  if (!picked.value) return

  // 업무분은 호선+POR 범위에서만 셀 수 있다. 그 범위가 아닐 때 <못 누르게만> 해 두면
  // 「왜 활성화가 안 되나」에서 막힌다(실제로 막혔다). 그래서 누르면 범위를 바꿔 주고,
  // 건수를 보여 준 뒤 다시 누르게 한다 — 한 번에 지워 버리지 않는다.
  if (part !== 'core' && !shipPorScope.value) {
    setScope('shippor')
    msg.value = '범위를 [호선+POR 통째] 로 바꿨습니다 — 건수를 확인하고 다시 누르세요.'
    return
  }
  if (!partN(part)) return
  if (wipeArmed.value !== part) {
    stand()        // 다른 단추가 겨눠져 있으면 내린다 — 둘이 같이 서 있으면 안 된다
    standPo()
    wipeArmed.value = part
    wipeDisarm = setTimeout(standWipe, 5000)
    return
  }
  standWipe()

  const what =
    wipeScope.value === 'shippor'
      ? `${picked.value.ship_no} / ${picked.value.por_no}`
      : picked.value.ifseq
  busy.value = 'wipe'
  msg.value = ''
  result.value = null
  wiped.value = null
  try {
    const r = await api.locporWipe({ ...scopeArg(), part })
    wiped.value = r.run
    scope.value = r.scope?.ok === false ? null : r.scope
    msg.value =
      r.run.ok === false
        ? (r.run.error ?? '지우지 못했습니다.')
        : `${what} — ${PARTS[part].label} ${r.run.total}건을 지웠습니다.`
          + (part === 'biz' ? ' 전개분은 그대로 두었습니다.' : ' 이제 처음처럼 다시 돌릴 수 있습니다.')
    await load(true)     // 목록의 <이미 돌림> 꼬리표는 호출이력이라 그대로 남는다
    await loadLogs()
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

function pick(r) {
  picked.value = picked.value?.ifseq === r.ifseq ? null : r
  result.value = null
  wiped.value = null
  poResult.value = null
  stand()
  standWipe()
  standPo()
  loadScope()
  // 고른 것을 풀어도 이력은 비우지 않는다 — 고르기 전으로, 곧 <최근 전체>로 돌아간다.
  // 비워 버리면 줄을 한 번 골랐다 푸는 것만으로 이력 칸이 사라져 버린다.
  loadLogs()
}

/** 겨눈 것을 내린다 — 고른 줄을 바꾸거나 시간이 지나면 처음부터 다시 누르게 한다. */
function stand() {
  armed.value = false
  if (disarm) { clearTimeout(disarm); disarm = null }
}

/**
 * 실행 — <b>한 번 누르면 겨누고, 다시 누르면 돈다.</b>
 *
 * 창을 띄워 묻는 대신 단추 자체를 두 박자로 둔 까닭: 이 화면은 목록을 보며 줄을 고르는
 * 자리라, 창이 뜨면 고른 줄이 가려진다. 무엇을 돌리는지 <보이는 채로> 한 박자를 두는 편이
 * 낫다. 5초가 지나면 저절로 풀린다 — 겨눈 채 잊고 있다가 나중에 잘못 누르지 않도록.
 */
async function fire() {
  if (!picked.value) return
  if (!armed.value) {
    standWipe()    // 다른 단추가 겨눠져 있으면 내린다 — 둘이 같이 서 있으면 안 된다
    standPo()
    armed.value = true
    disarm = setTimeout(stand, 5000)
    return
  }
  stand()

  const key = picked.value.ifseq
  busy.value = 'run'
  msg.value = ''
  result.value = null
  try {
    const r = await api.locporRun(key)
    result.value = { ...r.run, log: r.log?.logs?.[0] ?? null }
    msg.value =
      r.run.ok === false
        ? (r.run.error ?? '호출하지 못했습니다.')
        : r.run.rtn_cd === 'S'
          ? `${key} — 후행처리를 불렀습니다.`
          : `${key} — 프로시저가 오류로 끝났습니다 (${r.run.rtn_cd ?? '?'}).`
    await load(true)    // 목록의 <이미 돌림> 꼬리표를 새로 받는다
    await loadLogs()
    await loadScope()   // 방금 전개된 것이 <지울 것> 에 잡혀야 한다
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

// ---------- [3320] 승인완료 직전까지 흘리기 ----------
//
// 고른 줄의 (호선 · POR · 라인) 으로 M20.QURI_MAKE_PO_3320 을 부른다. 그 프로시저는
// [3310] 직발주 화면과 <같은 경로>로 돌아 발주번호를 매기고 PO_STAT 을 '3'
// (Waiting Approval) 까지 민다 — [3320] 에서 승인완료를 바로 누를 수 있는 자리다.
//
// ⚠️ 실행(전개)과 <층이 다르다>. 전개는 수신분을 업무표로 «펼치는» 일이고, 이쪽은
//    펼쳐진 것을 업무 단계로 «미는» 일이다. 그래서 선행이 있다 — [2310] 일반재 POR
//    접수가 끝나 T30C_1110 에 행이 있어야 한다. 없으면 'E' 로 «아직 접수되지
//    않았습니다» 가 온다. 오류가 아니라 <순서가 아직 안 온 것>이다.
//
// ⚠️ 돌이킬 수 없다. 발주번호는 한번 매겨지면 그만이다. 그래서 실행 단추와 같은
//    두 박자를 쓴다 — 한 번 누르면 겨누고, 다시 눌러야 돈다.
const poResult = ref(null)   // 마지막 [3320] 결과
const poArmed = ref(false)
let poDisarm = null

function standPo() {
  poArmed.value = false
  if (poDisarm) { clearTimeout(poDisarm); poDisarm = null }
}

/**
 * 돌아오는 코드는 셋이다 — 'S' 만들었다 · 'W' <b>이미 그 단계이거나 지나갔다</b> ·
 * 'E' 못 했다. 'W' 를 오류로 칠하지 않는 까닭: 두 번 눌러도 안전하도록 프로시저가
 * 일부러 그렇게 돌려주는 값이고, 그때는 <b>아무것도 바뀌지 않는다.</b> 빨갛게 칠하면
 * 「뭔가 잘못됐다」로 읽혀 같은 줄을 자꾸 다시 누르게 된다.
 */
async function firePo() {
  if (!picked.value) return
  if (!poArmed.value) {
    stand()        // 다른 단추가 겨눠져 있으면 내린다 — 둘이 같이 서 있으면 안 된다
    standWipe()
    poArmed.value = true
    poDisarm = setTimeout(standPo, 5000)
    return
  }
  standPo()

  // ⚠️ POR 번호는 수신표에 있는 그대로(네 자리 · AA01) 보낸다. 원장의 여덟 자리
  //    (J015AA01) 로 붙이는 일도 CHAR 칸 자릿수 채움도 프로시저가 한다.
  const arg = { ship: picked.value.ship_no, por: picked.value.por_no, seq: picked.value.line_no }
  const what = `${arg.ship}/${arg.por}/${arg.seq}`
  busy.value = 'po'
  msg.value = ''
  poResult.value = null
  try {
    const r = await api.locporPo(arg)
    poResult.value = r.run
    msg.value =
      r.run.ok === false
        ? (r.run.error ?? '호출하지 못했습니다.')
        : r.run.rtn_cd === 'S'
          ? `${what} — 승인대기까지 흘렸습니다. 발주번호 ${r.run.po_no || '(없음)'}`
          : r.run.rtn_cd === 'W'
            ? `${what} — ${r.run.rtn_msg || '이미 지나간 단계입니다.'}`
            : `${what} — 흘리지 못했습니다 (${r.run.rtn_cd ?? '?'}).`
    // 목록의 꼬리표는 후행처리 이력이라 이것으로는 안 바뀐다. 그래도 다시 읽는 까닭은
    // <지울 것> 의 건수가 달라지기 때문이다 — 발주(T30C_1110)가 이 호출로 늘어난다.
    await loadScope()
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

// 처음에는 <최근 전체> 이력을 보여 준다. 줄을 골라야만 이력이 뜨게 두면,
// 「누가 무엇을 돌렸나」를 보러 들어온 사람이 아무것도 못 보고 나간다.
load()
loadLogs()
useViewRefresh(reloadAll)
</script>

<template>
  <section class="panel head">
    <h2>
      현지 POR 후행처리
      <span class="hint">SST02.Z_PD_C_LOCPOR → M20.PKG_PD_LOCPOR_IF.SP_LOCPOR_AFTER_INSERT</span>
      <span class="spacer"></span>
      <!-- 여기는 <화면 전체>다. 수신 목록만 다시 읽는 단추는 그 표의 머리줄에 따로 있다. -->
      <RefreshBtn :fn="reloadAll" label="" title="화면 전체 다시 읽기 (목록 · 전개분 · 이력)" />
    </h2>

    <p class="note muted">
      SAP 이 보낸 현지 POR 을 EAI 가 수신표에 쌓은 뒤 <b>이어서 부르는</b> 프로시저를,
      여기서 사람이 대신 부릅니다. 줄을 골라 아래 단추를 누르면 그 <code>IFSEQ</code> 한
      묶음이 업무표로 전개됩니다 — 평소 EAI 가 하는 일과 같은 경로입니다.
    </p>

    <!-- 연결은 세션 정리 화면이 쥐고 있는 것을 빌려 쓴다 (api/LocPor.cs) -->
    <div v-if="conn" class="conn" :class="{ ok: conn.connected, bad: !conn.connected }">
      <b>{{ conn.connected ? '● DB 연결됨' : '○ DB 연결 없음' }}</b>
      <span>ORAHHIP · 상주 연결 {{ conn.live ?? 0 }}/{{ conn.size ?? 0 }}</span>
      <span v-if="conn.last_error" class="e">{{ conn.last_error }}</span>
    </div>

    <div class="btns">
      <input
        v-model="q"
        class="q"
        placeholder="IFSEQ · 호선 · POR번호 로 찾기"
        @keyup.enter="load()"
      />
      <button :disabled="!!busy" @click="load()">{{ busy === 'list' ? '조회 중…' : '◻ 조회' }}</button>
      <button v-if="q" :disabled="!!busy" @click="q = ''; load()">지우기</button>
      <span class="gap"></span>
      <span class="muted sm">수신 {{ count }}건 · 돌린 적 있음 {{ done }}건</span>
    </div>

    <p v-if="msg" class="msg" :class="{ bad: /못|실패|오류|없/.test(msg) }">{{ msg }}</p>
  </section>

  <!-- 고른 줄과 실행 -->
  <section class="panel">
    <h2>실행 <span class="hint">줄을 골라야 누를 수 있습니다</span></h2>

    <div v-if="!picked" class="empty">아래 목록에서 돌릴 줄을 고르세요.</div>

    <template v-else>
      <div class="sel">
        <div class="f big">
          <div class="k">IFSEQ</div>
          <div class="v">{{ picked.ifseq }}</div>
        </div>
        <div class="f"><div class="k">호선</div><div class="v">{{ picked.ship_no || '-' }}</div></div>
        <div class="f"><div class="k">POR</div><div class="v">{{ picked.por_no || '-' }}</div></div>
        <div class="f"><div class="k">행 · 회차</div><div class="v">{{ picked.line_no || '-' }} · {{ picked.rev_no || '-' }}</div></div>
        <div class="f"><div class="k">수신일시</div><div class="v">{{ recv(picked) || '(비어 있음)' }}</div></div>
      </div>

      <!-- 이미 돌린 줄이면 그 사실을 실행 단추 바로 위에 세운다. 목록 꼬리표만으로는
           줄을 고르고 스크롤한 뒤에 안 보인다 — 두 번 돌리는 사고가 거기서 난다. -->
      <p v-if="picked.run_status" class="again">
        이 IFSEQ 는 <b>이미 {{ picked.run_cnt }}번</b> 돌았습니다 —
        마지막 {{ picked.run_at }} · {{ mark(picked.run_status) }}
        <template v-if="picked.run_user">· {{ picked.run_user }}</template>
        <template v-if="picked.run_module">({{ picked.run_module }})</template>.
        같은 묶음을 또 전개하게 됩니다.
      </p>

      <div class="btns">
        <button class="fire" :class="{ armed }" :disabled="!!busy" @click="fire">
          {{ busy === 'run' ? '도는 중…' : armed ? '한 번 더 누르면 실행됩니다' : '▶ 후행처리 실행' }}
        </button>
        <button v-if="armed" :disabled="!!busy" @click="stand">그만두기</button>

        <!-- [3320] 흘리기 — 실행 «옆»에 세운다. 전개가 끝난 줄을 업무 단계로 미는
             다음 수라, 같은 줄을 고른 채로 이어서 누르게 되는 자리다. -->
        <button
          class="fire po"
          :class="{ armed: poArmed }"
          :disabled="!!busy || !picked.ship_no || !picked.por_no || !picked.line_no"
          :title="`M20.QURI_MAKE_PO_3320(${picked.ship_no}, ${picked.por_no}, ${picked.line_no})`
            + ' — [3310] 직발주와 같은 경로로 발주번호를 매기고 PO_STAT 을 3(Waiting Approval) 로 밉니다'"
          @click="firePo"
        >
          {{ busy === 'po' ? '흘리는 중…' : poArmed ? '한 번 더 누르면 흘립니다' : '⇥ PO승인전까지 흘리기' }}
        </button>
        <button v-if="poArmed" :disabled="!!busy" @click="standPo">그만두기</button>

        <span class="gap"></span>
        <span class="muted sm">보내는 것은 IFSEQ 하나뿐입니다 — 호출문은 서버에 박혀 있습니다.</span>
      </div>

      <!-- 두 단추가 하는 일이 달라서, 그 차이를 단추 바로 밑에 적어 둔다.
           «왜 흘리기가 E 로 떨어지나» 가 전부 여기서 나온다. -->
      <p class="muted sm mt">
        <b>⇥ 흘리기</b>는 전개가 아니라 <b>업무 단계를 미는</b> 일입니다 —
        <code>{{ picked.ship_no }}/{{ picked.por_no }}/{{ picked.line_no }}</code> 한 줄만 갑니다.
        <b>[2310] 일반재 POR 접수가 먼저</b> 끝나 있어야 합니다(<code>T30C_1110</code> 에 행이 있어야 합니다).
        아직이면 오류가 아니라 <b>차례가 안 온 것</b>이고, 그대로 적혀 옵니다.
      </p>

      <!-- [3320] 결과 — 제 단추 바로 밑에 둔다. 아래쪽 <실행 결과> 와 섞이면
           방금 누른 것이 어느 쪽이었는지 알 수 없게 된다. -->
      <div
        v-if="poResult"
        class="res"
        :class="{ good: poResult.rtn_cd === 'S', bad: poResult.ok === false || poResult.rtn_cd === 'E' }"
      >
        <div class="rh">
          <b class="cd">
            {{ poResult.ok === false ? '호출 실패'
               : poResult.rtn_cd === 'S' ? 'S · 승인대기까지 흘렸습니다'
               : poResult.rtn_cd === 'W' ? 'W · 할 일이 없습니다'
               : (poResult.rtn_cd ?? '?') + ' · 못 했습니다' }}
          </b>
          <span class="muted">{{ poResult.ship }}/{{ poResult.por }}/{{ poResult.seq }}</span>
          <span v-if="poResult.po_no" class="mono">발주번호 {{ poResult.po_no }}</span>
          <span v-if="poResult.ms != null" class="muted">{{ poResult.ms }}ms</span>
          <span v-if="poResult.at" class="muted">{{ poResult.at }}</span>
          <span v-if="poResult.by" class="muted">{{ poResult.by }}</span>
        </div>
        <p class="rm">{{ poResult.rtn_msg || poResult.error || '(메시지 없음)' }}</p>

        <!-- W 는 <아무것도 바꾸지 않았다> 는 뜻이다. 이 한 줄이 없으면 실패로 읽고 또 누른다. -->
        <p v-if="poResult.rtn_cd === 'W'" class="muted sm mt">
          두 번 눌러도 안전하도록 프로시저가 돌려주는 값입니다 — <b>아무것도 바뀌지 않았습니다.</b>
        </p>
        <p v-if="poResult.rtn_cd === 'S'" class="caveat">
          ⚠ <b>되돌리는 단추는 없습니다.</b> 발주번호는 한번 매겨지면 그만입니다.
          [3320] 구매 발주 관리에서 <code>P.I.C = 담당자 · PO Status = 3</code> 으로 조회하면 뜹니다.
        </p>
      </div>

      <!-- 전개분 되돌리기 — 다시 돌리려면 먼저 치워야 한다 -->
      <div class="wipe">
        <div class="wh">
          <b>전개분 되돌리기</b>
          <span class="muted sm">
            후행처리는 <b>이미 있는 것을 건드리지 않습니다</b>(MERGE · NOT EXISTS) —
            처음처럼 다시 돌리려면 만들어진 것을 먼저 치워야 합니다.
          </span>
          <span class="spacer"></span>
          <RefreshBtn :fn="loadScope" label="" title="전개분 다시 세기" />
        </div>

        <!-- 범위 — 고른 묶음만, 또는 그 POR 통째 -->
        <div class="btns">
          <span class="lbl">범위</span>
          <button
            :class="{ on: wipeScope === 'ifseq' }"
            :disabled="!!busy"
            title="고른 IFSEQ 한 묶음이 만든 것만 지웁니다"
            @click="setScope('ifseq')"
          >이 IFSEQ 만</button>
          <button
            :class="{ on: wipeScope === 'shippor', warnon: wipeScope === 'shippor' }"
            :disabled="!!busy"
            :title="`${picked.ship_no} / ${picked.por_no} 의 모든 줄을 지웁니다 — IFSEQ 를 가리지 않습니다`"
            @click="setScope('shippor')"
          >호선+POR 통째 ({{ picked.ship_no }}/{{ picked.por_no }})</button>
        </div>

        <!-- 한 POR 이 여러 IFSEQ 로 나뉘어 들어온다. 그것을 모르면 «다 지웠는데 왜 보이지» 가 된다 -->
        <p v-if="wipeScope === 'ifseq'" class="muted sm mt">
          고른 <b>한 묶음</b>이 만든 것만 지웁니다. 같은 POR 이 여러 IFSEQ 로 나뉘어 들어왔다면
          <b>나머지 줄은 남습니다</b> — 그때는 [호선+POR 통째]를 쓰세요.
        </p>

        <div v-if="busy === 'scope'" class="muted sm mt">세는 중…</div>

        <template v-else-if="scope">
          <!-- 0 건인 표는 빼고 보여 준다. 열 줄 가운데 둘만 걸리는 일이 흔하다 -->
          <div v-if="delHit.length" class="cnts">
            <span v-for="d in delHit" :key="d.t" class="cnt">
              <span class="tn">{{ d.t }}</span><b>{{ d.n }}</b>
            </span>
          </div>
          <p v-else class="muted sm mt">
            지울 전개분이 없습니다 — 아직 한 번도 전개되지 않았거나 이미 치웠습니다.
          </p>

          <!-- ⚠️ 이 모드에서 가장 위험한 수 — 인터페이스가 만들지 않은 줄, 곧 사람이 손으로
               넣은 줄이다. IFSEQ 범위로는 닿지도 않던 것이라 모르고 누르면 남의 작업물이 사라진다. -->
          <p v-if="scope.not_if > 0" class="handmade">
            ⚠ 이 가운데 <b>{{ scope.not_if }}줄</b>은 <b>수신표에 없는 POR 라인</b>입니다 —
            인터페이스가 만든 것이 아니라 <b>사람이 손으로 넣은 줄</b>입니다.
            [이 IFSEQ 만] 으로는 닿지도 않던 것이고, 다시 돌려도 <b>되살아나지 않습니다.</b>
          </p>

          <!-- PO 뒤 업무분 — 호선+POR 범위에서만 셀 수 있다 (IFSEQ 로는 짚을 근거가 없다) -->
          <template v-if="wipeScope === 'shippor'">
            <p class="bizhead sm">
              <b>PO 업무분</b> — 후행처리가 만든 것이 아니라 <b>사람이 업무로 만든 자료</b>입니다.
              견적 · 한국전환/회신 이력 · 원장 변경이력.
              <template v-if="!bizHit.length"> 지울 것이 없습니다.</template>
            </p>
            <div v-if="bizHit.length" class="cnts biz">
              <span v-for="d in bizHit" :key="d.t" class="cnt">
                <span class="tn">{{ d.t }}</span><b>{{ d.n }}</b>
              </span>
            </div>
          </template>

          <!-- 단추 셋 — 각자 제 건수를 달고 따로 겨눈다 -->
          <div class="btns">
            <button
              class="fire del"
              :class="{ armed: wipeArmed === 'core' }"
              :disabled="!!busy || !partN('core')"
              title="POR 원장·발주·자재마스터 — 후행처리가 만든 것만 지웁니다"
              @click="wipe('core')"
            >
              {{ wipeArmed === 'core' ? `${partN('core')}건을 지웁니다 — 한 번 더`
                 : `⌫ 전개분만 (${partN('core')}건)` }}
            </button>

            <!-- ⚠️ 업무분 단추는 <언제나 보인다>. 호선+POR 범위에서만 눌리지만, 숨겨 두면
                 그런 단추가 있다는 것조차 모른다 — 실제로 「업무 데이터 삭제 버튼은 어디
                 있나」를 듣고 고쳤다(2026-10-20). 못 누를 때는 까닭을 옆에 적는다. -->
            <button
              class="fire del"
              :class="{ armed: wipeArmed === 'biz' }"
              :disabled="!!busy || (shipPorScope && !partN('biz'))"
              :title="shipPorScope
                ? 'POR 원장은 그대로 두고 그 뒤 업무 자취만 걷어냅니다 — 다시 전개할 필요가 없습니다'
                : '누르면 범위를 [호선+POR 통째] 로 바꿉니다 — 업무분은 그 범위에서만 셀 수 있습니다'"
              @click="wipe('biz')"
            >
              {{ wipeArmed === 'biz' ? `업무분 ${partN('biz')}건을 지웁니다 — 한 번 더`
                 : shipPorScope ? `⌫ 업무분만 (${partN('biz')}건)` : '⌫ 업무분만' }}
            </button>
            <button
              class="fire del"
              :class="{ armed: wipeArmed === 'all' }"
              :disabled="!!busy || (shipPorScope && !partN('all'))"
              :title="shipPorScope
                ? '전개분과 업무분을 한 트랜잭션으로 모두 지웁니다'
                : '누르면 범위를 [호선+POR 통째] 로 바꿉니다'"
              @click="wipe('all')"
            >
              {{ wipeArmed === 'all' ? `${picked.ship_no}/${picked.por_no} 통째 ${partN('all')}건을 지웁니다 — 한 번 더`
                 : shipPorScope ? `⌫ 둘 다 (${partN('all')}건)` : '⌫ 둘 다' }}
            </button>

            <span v-if="!shipPorScope" class="muted sm">
              ← 업무분은 <b>[호선+POR 통째]</b> 범위의 것입니다. 눌러 보시면 범위가 바뀝니다.
            </span>
            <span v-if="busy === 'wipe'" class="muted sm">지우는 중…</span>
            <button v-if="wipeArmed" :disabled="!!busy" @click="standWipe">그만두기</button>
          </div>

          <!-- 이 셋은 지우기 전에 알고 있어야 한다. 모르고 누르면 나중에 설명할 길이 없다 -->
          <p class="caveat">
            ⚠ <b>되돌릴 수 없습니다.</b>
            ① 발주(<code>T30C_1110</code>)와 자재마스터(<code>T30A_1130</code>)까지 지웁니다
            — 자재마스터는 키가 자재코드 하나뿐이라 <b>다른 호선이 쓰던 자재</b>가 함께 지워질 수 있습니다.
            ② 같은 POR 줄을 <b>다른 IFSEQ 로</b> 받았던 적이 있으면 그것도 함께 지워집니다 —
            원장에 IFSEQ 가 없어 갈라낼 방법이 없습니다(<code>T30B_1130</code> 만 들고 있습니다).
            ③ 수신 때 <b>고쳐진</b> 줄은 수신 전 값으로 <b>돌아가지 않고 지워집니다</b>.
            알림메일(<code>T30_MESSAGE</code>)은 호선·POR 칸이 없어 짚을 수가 없어 그대로 둡니다.
          </p>
        </template>

        <div v-if="wiped" class="res" :class="{ good: wiped.ok !== false, bad: wiped.ok === false }">
          <div class="rh">
            <b class="cd">{{ wiped.ok === false ? '삭제 실패' : `지움 ${wiped.total}건` }}</b>
            <span class="muted">{{ wiped.ifseq }}</span>
            <span v-if="wiped.ms != null" class="muted">{{ wiped.ms }}ms</span>
            <span v-if="wiped.at" class="muted">{{ wiped.at }}</span>
            <span v-if="wiped.by" class="muted">{{ wiped.by }}</span>
          </div>
          <p v-if="wiped.ok === false" class="rm">{{ wiped.error }}</p>
          <div v-else class="cnts">
            <span v-for="d in (wiped.del ?? []).filter((x) => x.n > 0)" :key="d.t" class="cnt">
              <span class="tn">{{ d.t }}</span><b>{{ d.n }}</b>
            </span>
          </div>
        </div>
      </div>
    </template>

    <!-- 실행 결과 -->
    <div v-if="result" class="res" :class="{ good: result.rtn_cd === 'S', bad: result.ok === false || (result.rtn_cd && result.rtn_cd !== 'S') }">
      <div class="rh">
        <b class="cd">{{ result.ok === false ? '호출 실패' : result.rtn_cd === 'S' ? 'S · 정상' : (result.rtn_cd ?? '?') + ' · 오류' }}</b>
        <span class="muted">{{ result.ifseq }}</span>
        <span v-if="result.ms != null" class="muted">{{ result.ms }}ms</span>
        <span v-if="result.at" class="muted">{{ result.at }}</span>
        <span v-if="result.by" class="muted">{{ result.by }}</span>
      </div>
      <p class="rm">{{ result.rtn_msg || result.error || '(메시지 없음)' }}</p>

      <div v-if="result.log" class="rl muted sm">
        호출이력 #{{ result.log.log_seq }} · {{ mark(result.log.status) }} ·
        수신 {{ result.log.target_cnt ?? '-' }}건 · {{ result.log.call_dtm }} →
        {{ result.log.end_dtm || '…' }} · {{ result.log.call_user }}
        <template v-if="result.log.call_module">({{ result.log.call_module }})</template>
        <template v-if="result.log.err_msg"> · {{ result.log.err_msg }}</template>
      </div>

      <!-- 이 한 줄이 없으면 S 를 <다 잘됐다>로 읽게 된다. 실제로는 그렇지 않다. -->
      <p v-if="result.rtn_cd === 'S'" class="caveat">
        ⚠ <b>S 는 «불렀다»는 뜻</b>입니다. 안쪽 전개(<code>SP_EXPAND_POR</code>)는 제 오류를
        스스로 삼키고 되돌리는데, 그 결과가 바깥으로 올라오지 않습니다 — 전개가 실패해도
        여기에는 S 가 옵니다. 실제로 들어갔는지는 업무표에서 확인하세요.
      </p>
    </div>
  </section>

  <!-- 수신 목록 -->
  <section class="panel">
    <h2>
      <!-- 접고 펴는 것은 이 삼각형만 한다. 머리줄 전체가 받으면 제목을 긁어 복사할 때도 접힌다. -->
      <button class="caret" type="button" :title="listOpen ? '접기' : '펼치기'" @click="fold('list')">
        {{ listOpen ? '▾' : '▸' }}
      </button>
      수신 목록
      <!-- 접힌 채로도 읽혀야 한다 — 머리줄 하나로 이 표의 상태가 끝나야 접어 둘 수 있다 -->
      <span class="hint">
        SST02.Z_PD_C_LOCPOR ·
        <!-- 거른 수와 불러온 수를 나란히 — 하나만 적으면 필터가 걸린 줄 모르고 본다 -->
        <template v-if="listOn">{{ count }}건 중 <b class="hit">{{ shownRows.length }}건</b></template>
        <template v-else>{{ count }}건{{ conn?.more ? ' (더 있음)' : '' }}</template>
        · 돌린 적 있음 {{ done }}건
        <template v-if="picked"> · 고른 줄 {{ picked.ifseq }}</template>
      </span>
      <button v-if="listOn" class="clr" type="button" @click="listF.clear()">필터 지우기</button>
      <span v-if="searching && folded.has('list')" class="hint why">거르는 중이라 펼쳐 둡니다</span>
      <span class="spacer"></span>
      <!-- 언제 읽은 것인지 — 이것이 없으면 다시 읽어도 <눌렸는지> 알 수가 없다.
           EAI 가 수시로 넣고 있어 수가 안 바뀌는 일이 흔하다. -->
      <span v-if="loadedAt" class="hint">읽음 {{ loadedAt }}</span>
      <RefreshBtn :fn="reloadList" label="" title="수신 목록 다시 읽기" />
    </h2>

    <div v-show="listOpen" class="scroll">
      <table>
        <thead>
          <tr>
            <th class="w-pick"></th>
            <th v-for="c in LIST_COLS" :key="c.key" :class="{ num: c.num }">{{ c.label }}</th>
          </tr>
          <!-- 칸별 필터 — 서버 조회가 가져온 것 안에서만 추린다.
               모든 칸이 글자 검색이다(2026-10-20 지시) — 칸에 보이는 그대로 치면 걸린다. -->
          <tr class="fltr">
            <th class="w-pick"></th>
            <th v-for="c in LIST_COLS" :key="c.key">
              <input
                v-model="lf[c.key]"
                type="text"
                :placeholder="c.label"
                :title="`${c.label} 검색 — 보이는 그대로, 일부만 쳐도 됩니다`"
                :class="{ on: lf[c.key] }"
              />
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="r in shownRows"
            :key="r.ifseq"
            class="row"
            :class="{ on: picked?.ifseq === r.ifseq }"
            @click="pick(r)"
          >
            <td class="w-pick">{{ picked?.ifseq === r.ifseq ? '▶' : '' }}</td>
            <td class="mono">{{ r.ifseq }}</td>
            <td>{{ r.ship_no }}</td>
            <td>{{ r.por_no }}</td>
            <td>{{ r.line_no }}</td>
            <td>{{ r.rev_no }}</td>
            <td>{{ r.req_dept }}</td>
            <td>{{ r.reg_emp_id }}</td>
            <td class="desc" :title="r.work_desc">{{ r.work_desc }}</td>
            <td class="mono num">{{ qty(r) }}</td>
            <td class="sm">{{ r.matl_unit }}</td>
            <td class="mono sm">{{ recv(r) }}</td>
            <td>{{ r.zdelflg === 'Y' ? 'Y' : '' }}</td>
            <td>
              <span v-if="r.run_status" class="tag" :class="r.run_status === 'S' ? 'ok' : r.run_status === 'E' ? 'ng' : ''">
                {{ mark(r.run_status) }}<small v-if="r.run_cnt > 1"> ×{{ r.run_cnt }}</small>
              </span>
              <!-- '—' 가 아니라 말로 적는다 — 글자 검색이라 보이는 말이 곧 칠 말이다 -->
              <span v-else class="muted sm">안 돌림</span>
              <div v-if="r.run_at" class="muted sm">{{ r.run_at }}</div>
            </td>
          </tr>
          <!-- 자료가 없는 것과 <걸러서> 없는 것은 전혀 다른 말이다. 섞어 적으면
               필터를 걸어 둔 줄 모르고 «수신분이 하나도 없다»로 읽는다. -->
          <tr v-if="!shownRows.length">
            <td colspan="14" class="empty">
              <template v-if="busy === 'list'">읽는 중…</template>
              <template v-else-if="rows.length">
                거른 결과가 없습니다 — 불러온 {{ count }}건 가운데 맞는 줄이 없습니다.
                <button class="clr" type="button" @click="listF.clear()">필터 지우기</button>
              </template>
              <template v-else>보여 줄 수신분이 없습니다.</template>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <p v-show="listOpen" class="muted mt sm">
      머리글 아래 칸은 <b>모두 글자 검색</b>입니다 — <b>칸에 보이는 그대로</b> 치면 되고
      일부만 쳐도 걸립니다(대소문자는 가리지 않습니다). 여러 칸을 함께 걸면 <b>모두 맞는</b>
      줄만 남습니다. [후행처리]는 <code>안 돌림</code> · <code>정상</code> · <code>오류</code> ·
      <code>처리중</code>, [삭제]는 <code>Y</code>, [수신일시]는 <code>2026-10-20</code> 꼴로 칩니다.
      <br />
      받은 날짜(<code>ZIFDAT</code>) 내림차순입니다 — <b>날짜가 빈 줄이 맨 위</b>에 옵니다
      (손으로 넣은 시험자료가 그렇습니다). [후행처리] 칸은
      <code>M20.Z_PD_IF_CALL_LOG</code> 의 마지막 한 줄입니다.
    </p>
  </section>

  <!-- 호출이력 -->
  <section v-if="logs.length" class="panel">
    <h2>
      <button class="caret" type="button" :title="logOpen ? '접기' : '펼치기'" @click="fold('log')">
        {{ logOpen ? '▾' : '▸' }}
      </button>
      호출이력
      <span class="hint">
        {{ picked ? picked.ifseq : '최근' }} ·
        <template v-if="logOn">{{ logs.length }}건 중 <b class="hit">{{ shownLogs.length }}건</b></template>
        <template v-else>{{ logs.length }}건</template>
        <template v-if="logs.length"> · 마지막 {{ logs[0].call_dtm }} {{ mark(logs[0].status) }}</template>
      </span>
      <button v-if="logOn" class="clr" type="button" @click="logF.clear()">필터 지우기</button>
      <span class="spacer"></span>
      <RefreshBtn :fn="loadLogs" label="" title="이력 다시 읽기" />
    </h2>

    <div v-show="logOpen" class="scroll">
      <table>
        <thead>
          <tr>
            <th v-for="c in LOG_COLS" :key="c.key" :class="{ num: c.key === 'target_cnt' }">
              {{ c.label }}
            </th>
          </tr>
          <!-- 칸별 필터. 거를 거리가 없는 칸(번호·건수·종료시각)은 비워 둔다 -->
          <tr class="fltr">
            <th v-for="c in LOG_COLS" :key="c.key">
              <select
                v-if="c.type === 'opts'"
                v-model="gf[c.key]"
                :class="{ on: gf[c.key] }"
                :title="`${c.label} 필터`"
              >
                <option value="">전체</option>
                <option v-for="o in c.opts" :key="o.value" :value="o.value">{{ o.label }}</option>
              </select>
              <select
                v-else-if="c.type === 'pick'"
                v-model="gf[c.key]"
                :class="{ on: gf[c.key] }"
                :title="`${c.label} 필터`"
              >
                <option value="">전체</option>
                <option v-for="o in gfOpts[c.key]" :key="o.value" :value="o.value">
                  {{ o.label }} · {{ o.cnt }}
                </option>
              </select>
              <input
                v-else-if="c.type === 'text'"
                v-model="gf[c.key]"
                type="text"
                :placeholder="c.label"
                :title="`${c.label} 검색 (부분일치)`"
                :class="{ on: gf[c.key] }"
              />
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="!shownLogs.length">
            <td colspan="10" class="empty">
              거른 결과가 없습니다 — 불러온 {{ logs.length }}건 가운데 맞는 줄이 없습니다.
              <button class="clr" type="button" @click="logF.clear()">필터 지우기</button>
            </td>
          </tr>
          <tr v-for="l in shownLogs" :key="l.log_seq">
            <td class="mono sm">{{ l.log_seq }}</td>
            <td class="mono sm">{{ l.ifseq }}</td>
            <td>
              <span class="tag" :class="l.status === 'S' ? 'ok' : l.status === 'E' ? 'ng' : ''">{{ mark(l.status) }}</span>
            </td>
            <td class="num">{{ l.target_cnt ?? '' }}</td>
            <td class="mono sm">{{ l.call_dtm }}</td>
            <td class="mono sm">{{ l.end_dtm }}</td>
            <td>{{ l.call_user }}</td>
            <td class="sm">{{ l.call_module }}</td>
            <td class="mono sm">{{ l.call_ip }}</td>
            <td class="err" :title="l.err_msg">{{ l.err_msg }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <p v-show="logOpen" class="muted mt sm">
      프로시저가 <b>스스로</b> 남기는 이력입니다(자율 트랜잭션이라 되돌려도 남습니다).
      <code>모듈</code> 이 <code>WBS/…</code> 면 이 화면에서 누른 것이고,
      <code>java@hhiueaidev</code> 면 EAI 가 부른 것입니다.
    </p>
  </section>
</template>

<style scoped>
h2 { display: flex; align-items: center; gap: 8px; }
h2 .spacer { flex: 1; }
/* 접기 삼각형 — 머리줄 안에서 조용히 있다가 가리키면 선다 */
h2 .caret {
  flex: none; padding: 0 4px; font-size: 10px; line-height: 1.5;
  color: var(--muted); cursor: pointer;
  border-color: transparent; background: transparent;
}
h2 .caret:hover { border-color: var(--accent); color: var(--accent); }
/* 접어 뒀는데 지금은 펼쳐 보이는 까닭 — 안 적어 두면 접기가 고장난 것처럼 보인다 */
h2 .why { color: var(--accent); }
h2 .hit { color: var(--accent); }
/* 필터 지우기 — 걸려 있을 때만 나온다. 늘 있으면 머리줄만 복잡해진다 */
.clr { font-size: 11px; padding: 1px 8px; font-weight: 400; }

/* 1행 = 칸 이름, 2행 = 칸별 필터 (상세 목록 화면과 같은 꼴로 맞춘다) */
thead tr.fltr th { padding: 3px 5px; box-shadow: inset 0 -1px 0 var(--line); }
thead tr.fltr input,
thead tr.fltr select {
  width: 100%;
  min-width: 52px;
  padding: 2px 5px;
  font-size: 11.5px;
  font-weight: 400;
  border: 1px solid var(--line);
  border-radius: 4px;
  background: var(--panel);
}
thead tr.fltr input.on,
thead tr.fltr select.on { border-color: var(--accent); background: var(--accent-soft); color: var(--accent); }
thead tr.fltr input:focus, thead tr.fltr select:focus { outline: none; border-color: var(--accent); }
.head { margin-bottom: 12px; }
.note { margin: 8px 0 0; font-size: 11.5px; }
.note code, .sm code, .caveat code { background: var(--fill); border-radius: 3px; padding: 1px 5px; font-size: 11px; }
.msg { margin: 8px 0 0; font-size: 12px; color: var(--done); }
.msg.bad, .bad { color: var(--warn); }
.mt { margin: 10px 0 0; }
.sm { font-size: 11px; }
.mono { font-family: Consolas, 'Courier New', monospace; }
.empty { padding: 14px 2px; color: var(--muted); font-size: 12px; text-align: center; }

.conn {
  display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
  margin-top: 10px; padding: 5px 10px; border-radius: var(--radius);
  font-size: 11.5px; border: 1px solid var(--line);
}
.conn.ok { border-color: var(--done-line); background: var(--done-soft); }
.conn.ok b { color: var(--done); }
.conn.bad { border-color: var(--warn); background: var(--warn-soft); }
.conn.bad b { color: var(--warn); }
.conn span { color: var(--muted); }
.conn .e { font-family: Consolas, 'Courier New', monospace; font-size: 10.5px; }

.btns { display: flex; align-items: center; gap: 5px; flex-wrap: wrap; margin-top: 10px; }
.btns .gap { width: 12px; }
.btns button { font-size: 12px; }
.q {
  width: 260px; padding: 3px 8px; font-size: 12px;
  border: 1px solid var(--line); border-radius: var(--radius); background: var(--panel);
}

/* 고른 줄 — 여기서 무엇을 돌리는지가 한눈에 보여야 한다 */
.sel {
  display: flex; flex-wrap: wrap; gap: 18px; align-items: flex-end;
  margin-top: 4px; padding: 9px 12px;
  border: 1px solid var(--line); border-left: 3px solid var(--text);
  background: var(--panel);
}
.sel .k { font-size: 11px; color: var(--muted); }
.sel .v { font-size: 13px; margin-top: 1px; }
.sel .big .v { font-size: 16px; font-weight: 600; font-family: Consolas, 'Courier New', monospace; }

.again {
  margin: 8px 0 0; padding: 5px 10px; font-size: 11.5px;
  border: 1px solid var(--warn-line); background: var(--warn-soft); border-radius: var(--radius);
}
.again b { color: var(--warn); }

/* 실행 단추 — 평소엔 조용히, 한 번 누르면 서서 다시 누르기를 기다린다 */
.fire { border-color: var(--warn); color: var(--warn); font-weight: 600; }
.fire.armed { background: var(--warn); border-color: var(--warn); color: var(--on-accent); }
.fire:disabled { border-color: var(--line); color: var(--muted); font-weight: 400; }

/* [3320] 흘리기 — 실행·지우기와 같은 두 박자지만 하는 일이 다르다. 그 셋이 한 줄에
   나란히 서므로 색으로 갈라 둔다: 전개와 삭제는 경고색, 단계를 미는 이쪽은 먹색이다.
   (어느 쪽도 돌이킬 수 없다 — 색이 순하다고 가벼운 단추라는 뜻이 아니다.) */
.fire.po { border-color: var(--text); color: var(--text); }
.fire.po.armed { background: var(--text); border-color: var(--text); color: var(--panel); }
.fire.po:disabled { border-color: var(--line); color: var(--muted); font-weight: 400; background: none; }

/* 전개분 되돌리기 — 만드는 자리와 지우는 자리를 눈으로도 갈라 둔다 */
.wipe { margin-top: 14px; padding: 10px 12px 11px; border: 1px solid var(--line); border-top-width: 3px; }
.wh { display: flex; align-items: baseline; gap: 8px; flex-wrap: wrap; }
.wh .spacer { flex: 1; }
.cnts { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 8px; }
.cnt {
  display: inline-flex; align-items: baseline; gap: 6px;
  padding: 2px 8px; border: 1px solid var(--line); background: var(--panel); font-size: 11px;
}
.cnt .tn { color: var(--muted); font-family: Consolas, 'Courier New', monospace; }
.cnt b { font-size: 12.5px; color: var(--warn); }
.btns .lbl { font-size: 11.5px; color: var(--muted); margin-right: 2px; }
.btns button.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
.btns button.warnon { background: var(--warn); border-color: var(--warn); }
/* 손으로 넣은 줄까지 지운다는 경고 — 이 화면에서 가장 무거운 한 줄 */
.handmade {
  margin: 8px 0 0; padding: 6px 10px; font-size: 11.5px;
  border: 1px solid var(--warn); background: var(--warn-soft);
}
.handmade b { color: var(--warn); }
/* PO 업무분 — 전개분과 눈으로 갈라 둔다 */
.bizhead { margin: 12px 0 0; color: var(--muted); }
.bizhead b { color: var(--text); }
.cnts.biz .cnt { border-style: dashed; }

.res { margin-top: 12px; padding: 9px 12px; border: 1px solid var(--line); border-radius: var(--radius); }
.res.good { border-color: var(--done-line); background: var(--done-soft); }
.res.bad { border-color: var(--warn); background: var(--warn-soft); }
.res .rh { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; font-size: 11.5px; }
.res .cd { font-size: 13px; }
.res.good .cd { color: var(--done); }
.res.bad .cd { color: var(--warn); }
.res .rm { margin: 6px 0 0; font-size: 12px; }
/* 발주번호는 받아 적는 값이다 — 자간이 고른 글꼴이라야 옮겨 적다 틀리지 않는다 */
.res .mono { font-family: Consolas, 'Courier New', monospace; font-size: 12px; }
.res .rl { margin-top: 6px; }
.caveat {
  margin: 8px 0 0; padding: 5px 10px; font-size: 11px;
  border: 1px solid var(--line); border-radius: var(--radius); background: var(--panel);
}

.scroll { overflow: auto; margin-top: 8px; }
.row { cursor: pointer; }
.row:hover td { background: var(--fill); }
/* 고른 줄은 색이 아니라 <무게>로 표시한다 — 상태 꼬리표의 색과 섞이지 않게 */
.row.on td { background: var(--fill); font-weight: 600; }
.row.on td:first-child { box-shadow: inset 3px 0 0 var(--text); }
.w-pick { width: 18px; padding-right: 0; color: var(--muted); }
.desc, .err {
  max-width: 260px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.err { color: var(--warn); font-size: 11px; }

.tag {
  display: inline-block; padding: 0 6px; font-size: 11px;
  border: 1px solid var(--line); border-radius: 3px; color: var(--muted);
}
.tag.ok { border-color: var(--done-line); color: var(--done); }
.tag.ng { border-color: var(--warn); color: var(--warn); }
.tag small { font-weight: 400; }
</style>
