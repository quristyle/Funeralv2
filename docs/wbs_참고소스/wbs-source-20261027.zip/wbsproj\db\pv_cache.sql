-- ---------------------------------------------------------------------------
-- ProjectView cache  (hhip_wbs_pv / hhip_wbs_pv_task / dev_user.pv_user_id)
--
-- Why a separate table instead of columns on hhip_wbs_wrk2:
--   1) this is a cache of a FOREIGN system - keeping it apart makes it obvious
--      which value is ours (plan_sdt) and which one came from ProjectView.
--   2) wrk2 is per-screen, so activity_id may repeat (PvSync counts "Dup").
--   3) it can be truncated and re-collected without touching the ledger.
--
-- Nothing here is authoritative. Drop it and the dashboard still works,
-- it just falls back to the slow "look everything up again" path.
-- ---------------------------------------------------------------------------

create table if not exists public.hhip_wbs_pv (
  activity_id        varchar(50)  primary key,

  -- identity: removes the "list every work to build code->id" step
  pv_project_id      varchar(60),
  pv_work_id         varchar(60),
  pv_work_title      text,
  pv_seen_at         timestamp,

  -- snapshot of ProjectView's CURRENT values: enables diff-only sending
  pv_finish_rate     numeric(6,2),
  pv_actual_rate     numeric(6,2),
  pv_plan_sdt        date,
  pv_plan_edt        date,
  pv_actual_sdt      date,
  pv_actual_edt      date,
  pv_snapshot_at     timestamp,

  -- last send (progress rate)
  pv_sent_rate       numeric(6,2),
  pv_sent_at         timestamp,
  pv_sent_result     varchar(20),
  pv_sent_note       text,

  -- last send (actual start date)
  pv_sent_sdt        date,
  pv_sent_sdt_at     timestamp,

  updated_at         timestamp default now()
);

comment on table public.hhip_wbs_pv is 'ProjectView work cache - identity, snapshot, send history. Cache only, never authoritative.';

create index if not exists ix_hhip_wbs_pv_work on public.hhip_wbs_pv (pv_work_id);

-- ---------------------------------------------------------------------------
-- workflow tasks: activity 1:N task. Lets PvFlow skip re-reading tasks
-- it has already filled.
-- ---------------------------------------------------------------------------
create table if not exists public.hhip_wbs_pv_task (
  pv_task_id       varchar(60) primary key,
  activity_id      varchar(50),
  pv_work_id       varchar(60),
  pv_task_code     varchar(50),
  pv_task_title    text,
  pv_plan_sdt      date,
  pv_plan_edt      date,

  pv_node_cnt      integer,          -- nodes in the workflow
  pv_node_empty    integer,          -- nodes still missing date/charger
  pv_seen_at       timestamp,

  pv_filled_at     timestamp,        -- when we filled it
  pv_filled_nodes  integer,

  updated_at       timestamp default now()
);

comment on table public.hhip_wbs_pv_task is 'ProjectView workflow task cache for the "fill empty date/charger" screen.';

create index if not exists ix_hhip_wbs_pv_task_act  on public.hhip_wbs_pv_task (activity_id);
create index if not exists ix_hhip_wbs_pv_task_code on public.hhip_wbs_pv_task (pv_task_code);

-- ---------------------------------------------------------------------------
-- developer -> ProjectView user id (USR-...). Today PvFlow matches by NAME,
-- which breaks on duplicates and renames.
-- ---------------------------------------------------------------------------
alter table public.dev_user add column if not exists pv_user_id varchar(40);

comment on column public.dev_user.pv_user_id is 'ProjectView user id (USR-...), used as the workflow charger.';
