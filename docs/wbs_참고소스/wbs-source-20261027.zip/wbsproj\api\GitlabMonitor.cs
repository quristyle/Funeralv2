using System.Net.Http.Headers;
using System.Text.Json;

namespace WbsApi;

/// <summary>
/// GitLab 에서 뽑을 수 있는 모니터링 지표를 프로젝트별로 모아 온다.
/// 프로젝트당 7회 조회(통계·브랜치·태그·MR·Job·커밋·기여자)를 병렬로 수행한다.
/// </summary>
public sealed class GitlabMonitor(IConfiguration cfg, Gitlab gl)
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(20) };

    private readonly string _base = (cfg["Gitlab:BaseUrl"] ?? "https://code.hd.com").TrimEnd('/');
    private readonly string _token = cfg["Gitlab:Token"]
                                     ?? Environment.GetEnvironmentVariable("GITLAB_TOKEN") ?? "";
    private readonly int _ttl = cfg.GetValue("Gitlab:MonitorCacheSeconds", 120);
    private readonly int _staleDays = cfg.GetValue("Gitlab:StaleBranchDays", 30);
    private readonly int _jobSample = cfg.GetValue("Gitlab:JobSample", 20);

    private List<Dictionary<string, object?>>? _cache;
    private DateTimeOffset _at = DateTimeOffset.MinValue;
    private readonly SemaphoreSlim _lock = new(1, 1);

    public bool Configured => !string.IsNullOrWhiteSpace(_token);
    public DateTimeOffset LoadedAt => _at;

    public async Task<List<Dictionary<string, object?>>> LoadAsync(bool force = false)
    {
        if (!force && _cache is not null && DateTimeOffset.UtcNow - _at < TimeSpan.FromSeconds(_ttl))
            return _cache;

        await _lock.WaitAsync();
        try
        {
            if (!force && _cache is not null && DateTimeOffset.UtcNow - _at < TimeSpan.FromSeconds(_ttl))
                return _cache;

            var targets = gl.Targets();
            var rows = new Dictionary<string, object?>[targets.Count];
            using var gate = new SemaphoreSlim(12, 12);

            await Task.WhenAll(targets.Select(async (t, i) =>
            {
                await gate.WaitAsync();
                try { rows[i] = await OneAsync(t.Module, t.Kind, t.Path); }
                finally { gate.Release(); }
            }));

            _cache = [.. rows];
            _at = DateTimeOffset.UtcNow;
            return _cache;
        }
        finally { _lock.Release(); }
    }

    // ---------- 프로젝트 1건 ----------

    private async Task<Dictionary<string, object?>> OneAsync(string module, string kind, string path)
    {
        var row = new Dictionary<string, object?>
        {
            ["module"] = module,
            ["kind"] = kind,
            ["path"] = path,
            ["web_url"] = $"{_base}/{path}",
            ["jobs_url"] = gl.JobsUrl(path),
            ["error"] = null,
        };
        if (!Configured) { row["error"] = "토큰 미설정"; return row; }

        var p = Uri.EscapeDataString(path);
        var api = $"{_base}/api/v4/projects/{p}";
        var since = DateTimeOffset.UtcNow.AddDays(-7).ToString("yyyy-MM-ddTHH:mm:ssZ");

        try
        {
            var info = GetAsync($"{api}?statistics=true");
            var branches = GetAsync($"{api}/repository/branches?per_page=100");
            var tags = HeadCountAsync($"{api}/repository/tags?per_page=1");
            var mrs = GetAsync($"{api}/merge_requests?state=opened&per_page=20");
            var jobs = GetAsync($"{api}/jobs?per_page={_jobSample}");
            var commits = GetAsync($"{api}/repository/commits?since={since}&per_page=100");
            var contribs = GetAsync($"{api}/repository/contributors");
            var reg = GetAsync($"{api}/registry/repositories?tags_count=true&size=true");

            await Task.WhenAll(info, branches, tags, mrs, jobs, commits, contribs, reg);

            FillInfo(row, info.Result);
            FillBranches(row, branches.Result);
            row["tags"] = tags.Result;
            FillMrs(row, mrs.Result);
            FillJobs(row, jobs.Result);
            FillCommits(row, commits.Result);
            FillContribs(row, contribs.Result);
            FillRegistry(row, reg.Result);
        }
        catch (Exception e)
        {
            row["error"] = e.Message.Length > 120 ? e.Message[..120] : e.Message;
        }
        return row;
    }

    // ---------- 호출 도우미 ----------

    private HttpRequestMessage Req(string url)
    {
        var r = new HttpRequestMessage(HttpMethod.Get, url);
        r.Headers.Add("PRIVATE-TOKEN", _token);
        r.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        return r;
    }

    /// <summary>본문을 JsonDocument 로. 실패하면 null (권한 없음·기능 미사용 등은 조용히 무시)</summary>
    private async Task<JsonDocument?> GetAsync(string url)
    {
        try
        {
            using var req = Req(url);
            using var res = await Http.SendAsync(req);
            if (!res.IsSuccessStatusCode) return null;
            var body = await res.Content.ReadAsStringAsync();
            return string.IsNullOrWhiteSpace(body) ? null : JsonDocument.Parse(body);
        }
        catch { return null; }
    }

    /// <summary>X-Total 헤더만 필요한 경우 (목록 전체를 받지 않아 빠르다)</summary>
    private async Task<int?> HeadCountAsync(string url)
    {
        try
        {
            using var req = Req(url);
            using var res = await Http.SendAsync(req);
            if (!res.IsSuccessStatusCode) return null;
            if (res.Headers.TryGetValues("X-Total", out var v) && int.TryParse(v.FirstOrDefault(), out var n))
                return n;
            return null;
        }
        catch { return null; }
    }

    private static string? S(JsonElement e, string n) =>
        e.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
    private static long? L(JsonElement e, string n) =>
        e.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetInt64() : null;
    private static double? D(JsonElement e, string n) =>
        e.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDouble() : null;

    // ---------- 항목별 매핑 ----------

    private static void FillInfo(Dictionary<string, object?> row, JsonDocument? d)
    {
        if (d is null) return;
        var e = d.RootElement;
        row["project_id"] = L(e, "id");
        row["default_branch"] = S(e, "default_branch");
        row["last_activity_at"] = S(e, "last_activity_at");
        row["created_at"] = S(e, "created_at");
        row["open_issues"] = L(e, "open_issues_count");
        if (e.TryGetProperty("statistics", out var st) && st.ValueKind == JsonValueKind.Object)
        {
            row["commit_count"] = L(st, "commit_count");
            row["repo_size"] = L(st, "repository_size");
            row["artifacts_size"] = L(st, "job_artifacts_size");
            row["storage_size"] = L(st, "storage_size");
            row["registry_size"] = L(st, "container_registry_size");
        }
    }

    private void FillBranches(Dictionary<string, object?> row, JsonDocument? d)
    {
        if (d is null || d.RootElement.ValueKind != JsonValueKind.Array) return;
        var list = new List<Dictionary<string, object?>>();
        var stale = 0;
        var cut = DateTimeOffset.UtcNow.AddDays(-_staleDays);
        foreach (var b in d.RootElement.EnumerateArray())
        {
            string? at = null;
            if (b.TryGetProperty("commit", out var c) && c.ValueKind == JsonValueKind.Object)
                at = S(c, "committed_date");
            var old = at is not null && DateTimeOffset.TryParse(at, out var t) && t < cut;
            if (old) stale++;
            list.Add(new()
            {
                ["name"] = S(b, "name"),
                ["default"] = b.TryGetProperty("default", out var df) && df.ValueKind == JsonValueKind.True,
                ["merged"] = b.TryGetProperty("merged", out var mg) && mg.ValueKind == JsonValueKind.True,
                ["at"] = at,
                ["stale"] = old,
            });
        }
        row["branches"] = list.Count;
        row["stale_branches"] = stale;
        row["branch_list"] = list.OrderByDescending(x => x["at"] as string).Take(8).ToList();
    }

    private static void FillMrs(Dictionary<string, object?> row, JsonDocument? d)
    {
        if (d is null || d.RootElement.ValueKind != JsonValueKind.Array) return;
        var list = new List<Dictionary<string, object?>>();
        foreach (var m in d.RootElement.EnumerateArray())
        {
            string? author = null;
            if (m.TryGetProperty("author", out var a) && a.ValueKind == JsonValueKind.Object) author = S(a, "name");
            list.Add(new()
            {
                ["iid"] = L(m, "iid"),
                ["title"] = S(m, "title"),
                ["author"] = author,
                ["source"] = S(m, "source_branch"),
                ["target"] = S(m, "target_branch"),
                ["created_at"] = S(m, "created_at"),
                ["updated_at"] = S(m, "updated_at"),
                ["draft"] = m.TryGetProperty("draft", out var dr) && dr.ValueKind == JsonValueKind.True,
                ["web_url"] = S(m, "web_url"),
            });
        }
        row["open_mrs"] = list.Count;
        row["mr_list"] = list;
    }

    private static void FillJobs(Dictionary<string, object?> row, JsonDocument? d)
    {
        if (d is null || d.RootElement.ValueKind != JsonValueKind.Array) return;
        var recent = new List<string?>();
        int success = 0, failed = 0, other = 0;
        double durSum = 0;
        int durCnt = 0;
        Dictionary<string, object?>? last = null, lastSuccess = null, lastFailed = null;

        foreach (var j in d.RootElement.EnumerateArray())
        {
            var status = S(j, "status");
            recent.Add(status);
            if (status == "success") success++;
            else if (status == "failed") failed++;
            else other++;

            var dur = D(j, "duration");
            if (dur is not null && status is "success" or "failed") { durSum += dur.Value; durCnt++; }

            var one = new Dictionary<string, object?>
            {
                ["status"] = status,
                ["name"] = S(j, "name"),
                ["ref"] = S(j, "ref"),
                ["at"] = S(j, "finished_at") ?? S(j, "started_at") ?? S(j, "created_at"),
                ["duration"] = dur,
                ["url"] = S(j, "web_url"),
            };
            last ??= one;
            if (status == "success") lastSuccess ??= one;
            if (status == "failed") lastFailed ??= one;
        }

        var done = success + failed;
        row["jobs"] = new Dictionary<string, object?>
        {
            ["sampled"] = recent.Count,
            ["success"] = success,
            ["failed"] = failed,
            ["other"] = other,
            ["rate"] = done > 0 ? Math.Round(success * 100.0 / done, 1) : (double?)null,
            ["avg_duration"] = durCnt > 0 ? Math.Round(durSum / durCnt, 1) : (double?)null,
            ["recent"] = recent,
            ["last"] = last,
            ["last_success"] = lastSuccess,
            ["last_failed"] = lastFailed,
        };
    }

    // ---------- 커밋 드릴다운 ----------
    // 화면(GlMonitor.vue)의 <커밋 활동> 탭에서 작성자를 누르면 그 사람 목록을,
    // 목록에서 한 건을 누르면 내용과 바뀐 파일을 보여 준다.

    /// <summary>한 프로젝트에서 한 사람이 최근에 남긴 커밋.</summary>
    public async Task<List<Dictionary<string, object?>>> CommitsAsync(string path, string? author, int days)
    {
        if (!Configured) return [];
        var p = Uri.EscapeDataString(path);
        var since = DateTimeOffset.UtcNow.AddDays(-Math.Clamp(days, 1, 90))
            .ToString("yyyy-MM-ddTHH:mm:ssZ");
        var d = await GetAsync($"{_base}/api/v4/projects/{p}/repository/commits?since={since}&per_page=100");
        if (d is null || d.RootElement.ValueKind != JsonValueKind.Array) return [];

        // ⚠️ GitLab 의 author 파라미터로 거르지 않는다. 화면이 보여 주는 이름은 괄호 앞만
        //    잘라 둔 것이라(shortName) 그대로 넘기면 한 건도 안 나온다. 받아서 여기서 고른다.
        //    앞부분이 같으면 같은 사람으로 본다.
        var list = new List<Dictionary<string, object?>>();
        foreach (var c in d.RootElement.EnumerateArray())
        {
            var name = S(c, "author_name") ?? "";
            if (!string.IsNullOrWhiteSpace(author)
                && !name.Equals(author, StringComparison.OrdinalIgnoreCase)
                && !name.StartsWith(author, StringComparison.OrdinalIgnoreCase)) continue;
            list.Add(new Dictionary<string, object?>
            {
                ["id"] = S(c, "id"),
                ["short_id"] = S(c, "short_id"),
                ["title"] = S(c, "title"),
                ["author"] = name,
                ["at"] = S(c, "committed_date") ?? S(c, "created_at"),
                ["url"] = S(c, "web_url"),
            });
        }
        return list;
    }

    /// <summary>커밋 한 건 — 메시지와 바뀐 파일.</summary>
    public async Task<Dictionary<string, object?>> CommitAsync(string path, string sha)
    {
        var outp = new Dictionary<string, object?> { ["error"] = null };
        if (!Configured) { outp["error"] = "토큰 미설정"; return outp; }

        var p = Uri.EscapeDataString(path);
        var s = Uri.EscapeDataString(sha);
        var info = GetAsync($"{_base}/api/v4/projects/{p}/repository/commits/{s}");
        var diff = GetAsync($"{_base}/api/v4/projects/{p}/repository/commits/{s}/diff?per_page=100");
        await Task.WhenAll(info, diff);

        if (info.Result is { } i && i.RootElement.ValueKind == JsonValueKind.Object)
        {
            var c = i.RootElement;
            outp["short_id"] = S(c, "short_id");
            outp["title"] = S(c, "title");
            outp["message"] = S(c, "message");
            outp["author"] = S(c, "author_name");
            outp["email"] = S(c, "author_email");
            outp["at"] = S(c, "committed_date") ?? S(c, "created_at");
            outp["url"] = S(c, "web_url");
            if (c.TryGetProperty("stats", out var st) && st.ValueKind == JsonValueKind.Object)
            {
                outp["additions"] = L(st, "additions");
                outp["deletions"] = L(st, "deletions");
            }
        }

        var files = new List<Dictionary<string, object?>>();
        if (diff.Result is { } dd && dd.RootElement.ValueKind == JsonValueKind.Array)
        {
            foreach (var f in dd.RootElement.EnumerateArray())
            {
                // 차이 본문(diff)은 보내지 않는다 — 한 커밋이 수 MB 가 되는 일이 있고,
                // 화면은 <어느 파일이 얼마나> 만 보여 준다. 본문은 GitLab 링크로 간다.
                var body = S(f, "diff") ?? "";
                int add = 0, del = 0;
                foreach (var line in body.Split('\n'))
                {
                    if (line.StartsWith("+++") || line.StartsWith("---")) continue;
                    if (line.StartsWith('+')) add++;
                    else if (line.StartsWith('-')) del++;
                }
                var kind = B(f, "new_file") ? "added"
                    : B(f, "deleted_file") ? "deleted"
                    : B(f, "renamed_file") ? "renamed" : "modified";
                files.Add(new Dictionary<string, object?>
                {
                    ["path"] = S(f, "new_path") ?? S(f, "old_path"),
                    ["old_path"] = S(f, "old_path"),
                    ["kind"] = kind,
                    ["add"] = add,
                    ["del"] = del,
                });
            }
        }
        outp["files"] = files;
        return outp;
    }

    private static bool B(JsonElement e, string name) =>
        e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.True;

    private static void FillCommits(Dictionary<string, object?> row, JsonDocument? d)
    {
        if (d is null || d.RootElement.ValueKind != JsonValueKind.Array) return;
        var arr = d.RootElement;
        row["commits_7d"] = arr.GetArrayLength();

        var byAuthor = new Dictionary<string, int>();
        foreach (var c in arr.EnumerateArray())
        {
            var a = S(c, "author_name") ?? "-";
            byAuthor[a] = byAuthor.GetValueOrDefault(a) + 1;
        }
        row["commit_authors_7d"] = byAuthor.OrderByDescending(k => k.Value)
            .Take(5).Select(k => new Dictionary<string, object?> { ["name"] = k.Key, ["count"] = k.Value }).ToList();

        if (arr.GetArrayLength() > 0)
        {
            var c = arr[0];
            row["last_commit"] = new Dictionary<string, object?>
            {
                ["id"] = S(c, "short_id"),
                ["title"] = S(c, "title"),
                ["author"] = S(c, "author_name"),
                ["at"] = S(c, "committed_date") ?? S(c, "created_at"),
                ["url"] = S(c, "web_url"),
            };
        }
    }

    private static void FillContribs(Dictionary<string, object?> row, JsonDocument? d)
    {
        if (d is null || d.RootElement.ValueKind != JsonValueKind.Array) return;
        var list = d.RootElement.EnumerateArray()
            .Select(c => new Dictionary<string, object?>
            {
                ["name"] = S(c, "name"),
                ["commits"] = L(c, "commits"),
            })
            .OrderByDescending(x => (long?)x["commits"] ?? 0)
            .ToList();
        row["contributors"] = list.Count;
        row["contributor_list"] = list.Take(5).ToList();
    }

    private static void FillRegistry(Dictionary<string, object?> row, JsonDocument? d)
    {
        if (d is null || d.RootElement.ValueKind != JsonValueKind.Array) return;
        var repos = new List<Dictionary<string, object?>>();
        long tags = 0, size = 0;
        foreach (var r in d.RootElement.EnumerateArray())
        {
            var tc = L(r, "tags_count") ?? 0;
            var sz = L(r, "size") ?? 0;
            tags += tc;
            size += sz;
            repos.Add(new()
            {
                ["name"] = S(r, "name") ?? S(r, "path"),
                ["location"] = S(r, "location"),
                ["tags"] = tc,
                ["size"] = sz,
                ["created_at"] = S(r, "created_at"),
            });
        }
        row["registry"] = new Dictionary<string, object?>
        {
            ["repos"] = repos.Count,
            ["tags"] = tags,
            ["size"] = size,
            ["list"] = repos,
        };
    }
}
