-- ---------------------------------------------------------------------------
-- 대형DB준비여부 (db_ready_big_yn)
--
-- Managed the same way as the other 대형 items (complate_big_yn /
-- complate_real_big_yn / recheck_big_yn): a single-character flag,
-- 'o' means yes, empty/null means no.
-- ---------------------------------------------------------------------------

alter table public.hhip_wbs_wrk2 add column if not exists db_ready_big_yn varchar(1);

comment on column public.hhip_wbs_wrk2.db_ready_big_yn is '대형 DB 준비여부 - o = ready';
