using System.Text;
using System.Text.Json;

namespace WbsApi;

/// <summary>
/// 자재 업무흐름 시나리오 — [업무흐름 시나리오] 화면(#/mflow)이 읽고 쓰는 <b>글 한 벌</b>.
///
/// 원본은 DRM 이 감싼 pptx(<c>HHIP-자재-DE-09(업무흐름시나리오)_V2.0</c>)였다. 그 파일은
/// 파워포인트로만 열리고, 열어도 고친 것을 남에게 보여 줄 길이 없다. 그래서 내용을
/// <b>마크다운 한 장</b>으로 옮기고 화면이 그것을 도식으로 그린다 — 고치는 사람은 글만 고친다.
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>왜 DB 가 아니라 파일인가.</b> 이 글은 <i>문서</i>다. 통째로 복사해 가고, 메일로 보내고,
/// 나중에 git 에 올릴 수도 있어야 한다. 한 장짜리 텍스트면 그 전부가 공짜로 된다.
///
/// <b>왜 wwwroot 가 아닌가.</b> <c>npm run build</c> 가 <c>emptyOutDir</c> 로 wwwroot 를 통째로
/// 비운다. 거기 두면 <b>프런트를 빌드할 때마다 글이 날아간다.</b> 그래서 <c>api/data</c> 아래다
/// (첨부·로그와 같은 자리다 — README 의 [보관 파일] 참고).
///
/// <b>덮어쓰기 사고를 막는 법.</b> 두 사람이 같은 글을 열어 두고 따로 저장하면 나중 사람이
/// 앞사람의 글을 <b>조용히 지운다.</b> 그래서 화면이 <읽을 때의 수정시각>(<c>base</c>)을 돌려주고,
/// 저장할 때 그것이 파일의 지금 수정시각과 다르면 <b>409 로 거절</b>하고 지금 글을 함께 준다.
/// 화면은 그 사실을 알리고 사람이 고르게 한다.
/// </summary>
public static class Flow
{
    private static string _file = "";
    private static string _histDir = "";

    /// <summary>저장할 때마다 직전 글을 남긴다 — 되돌릴 길이 없으면 고치기가 무섭다.</summary>
    private const int KeepHistory = 40;

    public static void Init(IConfiguration cfg, string contentRoot)
    {
        _file = cfg["Flow:File"] ?? Path.Combine(contentRoot, "data", "flow", "scenario.md");
        _histDir = Path.Combine(Path.GetDirectoryName(_file)!, "history");
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_file)!);
            Directory.CreateDirectory(_histDir);
        }
        catch { /* 못 만들면 읽기 전용으로 동작한다 */ }
    }

    /// <summary>파일의 수정시각 — 덮어쓰기 판정의 기준값. 밀리초까지 봐야 같은 초의 두 저장이 갈린다.</summary>
    private static string Stamp() =>
        File.Exists(_file) ? File.GetLastWriteTimeUtc(_file).ToString("yyyyMMddHHmmssfff") : "";

    private static object Payload(string text) => new
    {
        text,
        stamp = Stamp(),
        bytes = Encoding.UTF8.GetByteCount(text),
        file = _file,
        saved_at = File.Exists(_file)
            ? File.GetLastWriteTime(_file).ToString("yyyy-MM-dd HH:mm:ss") : null,
        saved_by = SavedBy(),
        history = HistoryList().Count,
    };

    // 마지막으로 저장한 사람은 글 옆이 아니라 따로 적어 둔다 —
    // 본문에 적으면 고치는 사람이 지워 버리고, 지워도 아무도 모른다.
    private static string WhoFile => _file + ".who";

    private static string? SavedBy()
    {
        try { return File.Exists(WhoFile) ? File.ReadAllText(WhoFile).Trim() : null; }
        catch { return null; }
    }

    private static List<FileInfo> HistoryList()
    {
        try
        {
            var d = new DirectoryInfo(_histDir);
            return d.Exists
                ? [.. d.GetFiles("*.md").OrderByDescending(f => f.Name)]
                : [];
        }
        catch { return []; }
    }

    public static void Map(WebApplication app)
    {
        app.MapGet("/api/flow/doc", () =>
        {
            try
            {
                var text = File.Exists(_file) ? File.ReadAllText(_file) : "";
                return Results.Ok(Payload(text));
            }
            catch (Exception e)
            {
                return Results.Json(new { error = "글을 읽지 못했습니다 — " + e.Message }, statusCode: 500);
            }
        });

        app.MapPut("/api/flow/doc", async (IpGate g, HttpContext ctx, JsonElement body) =>
        {
            var me = await g.CheckAsync(ctx);
            var text = body.TryGetProperty("text", out var t) && t.ValueKind == JsonValueKind.String
                ? t.GetString() ?? "" : null;
            if (text is null) return Results.BadRequest(new { error = "text 가 필요합니다." });
            // 빈 글로 통째로 날리는 실수를 막는다 — 지우려면 파일을 직접 지운다
            if (text.Trim().Length < 10)
                return Results.BadRequest(new { error = "글이 비어 있습니다. 통째로 지우려면 파일에서 지우세요." });

            var baseStamp = body.TryGetProperty("stamp", out var b) ? b.GetString() : null;
            var now = Stamp();
            if (baseStamp is not null && baseStamp != now && now.Length > 0)
                return Results.Json(new
                {
                    error = "다른 사람이 먼저 저장했습니다. 지금 글을 받아 고친 내용을 다시 옮겨 주세요.",
                    conflict = true,
                    current = Payload(File.Exists(_file) ? File.ReadAllText(_file) : ""),
                }, statusCode: 409);

            try
            {
                // 직전 글을 먼저 남기고 쓴다. 순서가 바뀌면 덮어쓴 뒤라 남길 것이 없다.
                if (File.Exists(_file))
                {
                    var keep = Path.Combine(_histDir, DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".md");
                    try { File.Copy(_file, keep, true); } catch { /* 이력은 덤이다 */ }
                    foreach (var old in HistoryList().Skip(KeepHistory))
                        try { old.Delete(); } catch { }
                }
                // 줄끝은 저장할 때 LF 로 맞춘다 — 사람마다 편집기가 달라 매번 전 줄이 바뀐 것처럼 보인다
                await File.WriteAllTextAsync(_file, text.Replace("\r\n", "\n"), new UTF8Encoding(false));
                var who = me.Name ?? me.BpId ?? "미상";
                try { await File.WriteAllTextAsync(WhoFile, who, new UTF8Encoding(false)); } catch { }
                return Results.Ok(Payload(text));
            }
            catch (Exception e)
            {
                return Results.Json(new { error = "저장하지 못했습니다 — " + e.Message }, statusCode: 500);
            }
        });

        // 되돌리기 — 남겨 둔 직전 글 목록과 그 내용
        app.MapGet("/api/flow/history", () => Results.Ok(HistoryList().Select(f => new
        {
            name = Path.GetFileNameWithoutExtension(f.Name),
            at = f.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"),
            bytes = f.Length,
        })));

        app.MapGet("/api/flow/history/{name}", (string name) =>
        {
            // 경로를 섞어 올려 다른 파일을 읽는 길을 막는다
            if (name.Any(c => !char.IsLetterOrDigit(c) && c != '-'))
                return Results.BadRequest(new { error = "이름이 올바르지 않습니다." });
            var f = Path.Combine(_histDir, name + ".md");
            return File.Exists(f)
                ? Results.Ok(new { name, text = File.ReadAllText(f) })
                : Results.NotFound(new { error = "그런 이력이 없습니다." });
        });
    }
}
