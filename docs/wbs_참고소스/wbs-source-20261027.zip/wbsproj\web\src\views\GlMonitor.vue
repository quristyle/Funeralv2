<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { api } from '../api'
import { state, useViewRefresh } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'

// GitLab 에서 뽑을 수 있는 모니터링 지표를 탭으로 나눠 보여준다.
const data = ref({ configured: false, rows: [], loadedAt: null })
const loading = ref(false)
const tab = ref('overview')
const kindF = ref('') // '' | be | fe
const q = ref('')
const auto = ref(0)
let timer = null

const TABS = [
  { key: 'overview', label: '개요' },
  { key: 'build', label: '빌드 품질' },
  { key: 'activity', label: '커밋 활동' },
  { key: 'repo', label: '저장소' },
  { key: 'mr', label: 'Merge Request' },
]

async function load(force = true) {
  loading.value = true
  try {
    data.value = await api.glMonitor(force)
  } catch (e) {
    state.error = e.message
  } finally {
    loading.value = false
  }
}

// ---------- 표시 도우미 ----------
const bytes = (n) => {
  if (n == null) return '-'
  const u = ['B', 'KB', 'MB', 'GB']
  let i = 0
  let v = n
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++ }
  return `${v >= 100 || i === 0 ? Math.round(v) : v.toFixed(1)}${u[i]}`
}
const secs = (s) => {
  if (s == null) return '-'
  const n = Math.round(s)
  return n < 60 ? `${n}s` : `${Math.floor(n / 60)}m ${n % 60}s`
}
const ago = (t) => {
  if (!t) return '-'
  const min = Math.floor((Date.now() - new Date(t).getTime()) / 60000)
  if (min < 1) return '방금'
  if (min < 60) return `${min}분 전`
  if (min < 1440) return `${Math.floor(min / 60)}시간 전`
  return `${Math.floor(min / 1440)}일 전`
}
const stCls = (s) =>
  s === 'success' ? 'ok' : s === 'failed' ? 'ng' : s === 'running' ? 'run'
  : s === 'pending' || s === 'created' ? 'wait' : 'off'
// git 설정 이름이 "주우인(Joo Woo-in )/위원/PwC컨설팅(…)" 처럼 길어 표에서는 앞부분만 쓴다
const shortName = (n) => (n ? String(n).split(/[(\/]/)[0].trim() || n : '-')
const people = (list) =>
  (list ?? []).map((x) => `${shortName(x.name)} ${x.count ?? x.commits}`).join(' · ') || '—'
const peopleFull = (list) =>
  (list ?? []).map((x) => `${x.name} — ${x.count ?? x.commits}`).join('\n')

const at = (t) => (t ? new Date(t).toLocaleString('ko-KR') : '-')

// ---------- 커밋 드릴다운 ----------
// 작성자를 누르면 그 사람이 그 프로젝트에 남긴 커밋 목록을,
// 목록에서 한 건을 누르면 내용과 바뀐 파일을 본다.
// 차이 본문은 가져오지 않는다 — 한 커밋이 수 MB 가 되는 일이 있다. 본문은 GitLab 으로 간다.
const cm = ref(null) // { path, label, author, rows, loading, err }
const cmSel = ref(null) // 고른 커밋의 상세
const cmSelId = ref(null)

const FILE_KIND = { added: '추가', deleted: '삭제', renamed: '이름변경', modified: '수정' }

async function openCommits(r, name) {
  cm.value = { path: r.path, label: `${r.module}-${r.kind}`, author: name, rows: [], loading: true, err: '' }
  cmSel.value = null
  cmSelId.value = null
  try {
    // 이름은 자른 것이 아니라 원본을 보낸다 — 서버가 그 이름으로 고른다
    const d = await api.glCommits(r.path, name, 7)
    if (cm.value) {
      cm.value.rows = d.rows ?? []
      cm.value.loading = false
    }
  } catch (e) {
    if (cm.value) {
      cm.value.err = e.message
      cm.value.loading = false
    }
  }
}

async function openCommit(c) {
  if (!cm.value) return
  cmSelId.value = c.id
  cmSel.value = { loading: true }
  try {
    const d = await api.glCommit(cm.value.path, c.id)
    // 기다리는 사이에 다른 커밋을 눌렀으면 늦게 온 것을 그리지 않는다
    if (cmSelId.value === c.id) cmSel.value = d
  } catch (e) {
    if (cmSelId.value === c.id) cmSel.value = { error: e.message }
  }
}

function closeCommits() {
  cm.value = null
  cmSel.value = null
  cmSelId.value = null
}

const stLbl = (s) =>
  ({ success: '성공', failed: '실패', running: '실행중', pending: '대기', created: '생성됨',
     canceled: '취소', skipped: '건너뜀', manual: '수동' }[s] ?? s ?? '-')

// ---------- 필터 · 정렬 ----------
const rows = computed(() => {
  let list = data.value.rows ?? []
  if (kindF.value) list = list.filter((r) => r.kind === kindF.value)
  if (q.value) {
    const s = q.value.toLowerCase()
    list = list.filter((r) => `${r.module}-${r.kind}`.toLowerCase().includes(s))
  }
  const { col, dir } = sort.value
  if (col) {
    const sign = dir === 'asc' ? 1 : -1
    list = [...list].sort((a, b) => {
      const x = val(a, col)
      const y = val(b, col)
      if (x === y) return 0
      if (x == null) return 1
      if (y == null) return -1
      return typeof x === 'number' ? sign * (x - y) : sign * String(x).localeCompare(String(y), 'ko')
    })
  }
  return list
})

const sort = ref({ col: '', dir: 'asc' })
function toggleSort(col) {
  if (sort.value.col !== col) sort.value = { col, dir: 'desc' }
  else if (sort.value.dir === 'desc') sort.value = { col, dir: 'asc' }
  else sort.value = { col: '', dir: 'asc' }
}
function val(r, col) {
  switch (col) {
    case 'name': return `${r.module}-${r.kind}`
    case 'activity': return r.last_activity_at ? new Date(r.last_activity_at).getTime() : null
    case 'rate': return r.jobs?.rate ?? null
    case 'avg': return r.jobs?.avg_duration ?? null
    case 'last': return r.jobs?.last?.at ? new Date(r.jobs.last.at).getTime() : null
    case 'commits7': return r.commits_7d ?? null
    case 'commits': return r.commit_count ?? null
    case 'branches': return r.branches ?? null
    case 'stale': return r.stale_branches ?? null
    case 'tags': return r.tags ?? null
    case 'mrs': return r.open_mrs ?? null
    case 'issues': return r.open_issues ?? null
    case 'repo': return r.repo_size ?? null
    case 'artifacts': return r.artifacts_size ?? null
    case 'storage': return r.storage_size ?? null
    case 'contrib': return r.contributors ?? null
    default: return null
  }
}
const arw = (c) => (sort.value.col === c ? (sort.value.dir === 'asc' ? '▲' : '▼') : '⇅')

// ---------- 요약 ----------
const sum = computed(() => {
  const r = data.value.rows ?? []
  const rates = r.map((x) => x.jobs?.rate).filter((v) => v != null)
  return {
    projects: r.length,
    commits7: r.reduce((s, x) => s + (x.commits_7d ?? 0), 0),
    mrs: r.reduce((s, x) => s + (x.open_mrs ?? 0), 0),
    failing: r.filter((x) => x.jobs?.last?.status === 'failed').length,
    rate: rates.length ? Math.round((rates.reduce((a, b) => a + b, 0) / rates.length) * 10) / 10 : null,
    storage: r.reduce((s, x) => s + (x.storage_size ?? 0), 0),
    stale: r.reduce((s, x) => s + (x.stale_branches ?? 0), 0),
  }
})

// MR 통합 목록
const allMrs = computed(() =>
  rows.value.flatMap((r) => (r.mr_list ?? []).map((m) => ({ ...m, project: `${r.module}-${r.kind}` })))
)

function setAuto(sec) {
  auto.value = sec
  if (timer) clearInterval(timer)
  timer = sec ? setInterval(() => load(true), sec * 1000) : null
}

useViewRefresh(() => load(true))
onMounted(() => load(false))
onUnmounted(() => timer && clearInterval(timer))
</script>

<template>
  <div class="topbar">
    <span class="hint">
      {{ data.group }} · {{ sum.projects }}개 프로젝트
      <template v-if="data.loadedAt"> · 마지막 갱신 {{ data.loadedAt }}</template>
      <template v-if="loading"> · 조회 중…</template>
    </span>
    <span class="spacer"></span>
    <select v-model="kindF" title="프로젝트 종류">
      <option value="">BE + FE</option>
      <option value="be">BE 만</option>
      <option value="fe">FE 만</option>
    </select>
    <input v-model="q" type="text" placeholder="프로젝트 검색" style="width: 150px" />
    <select :value="auto" title="자동 새로고침" @change="setAuto(Number($event.target.value))">
      <option :value="0">자동 끔</option>
      <option :value="60">1분</option>
      <option :value="300">5분</option>
      <option :value="600">10분</option>
    </select>
    <RefreshBtn :fn="() => load(true)" label="전체 새로고침" />
  </div>

  <section v-if="!data.configured" class="panel">
    <h2>GitLab 토큰이 설정되지 않았습니다</h2>
    <p class="muted"><code>api/appsettings.json</code> 의 <code>Gitlab.Token</code> 을 설정한 뒤 API 를 재시작하세요.</p>
  </section>

  <template v-else>
    <div class="cards">
      <div class="card"><div class="k">프로젝트</div><div class="v">{{ sum.projects }}</div></div>
      <div class="card">
        <div class="k">평균 빌드 성공률</div>
        <div class="v" :class="sum.rate >= 90 ? 'ok' : sum.rate >= 70 ? '' : 'ng'">{{ sum.rate ?? '-' }}%</div>
      </div>
      <div class="card"><div class="k">현재 실패</div><div class="v" :class="sum.failing ? 'ng' : 'ok'">{{ sum.failing }}</div></div>
      <div class="card"><div class="k">최근 7일 커밋</div><div class="v">{{ sum.commits7 }}</div></div>
      <div class="card"><div class="k">열린 MR</div><div class="v">{{ sum.mrs }}</div></div>
      <div class="card"><div class="k">오래된 브랜치</div><div class="v">{{ sum.stale }}</div></div>
      <div class="card"><div class="k">저장소 총량</div><div class="v" style="font-size: 16px">{{ bytes(sum.storage) }}</div></div>
    </div>

    <div class="tabs">
      <button
        v-for="t in TABS" :key="t.key"
        :class="{ on: tab === t.key }"
        @click="tab = t.key"
      >{{ t.label }}</button>
      <span class="spacer"></span>
      <span class="hint">{{ tab === 'mr' ? allMrs.length + '건' : rows.length + '개 프로젝트' }}</span>
    </div>

    <!-- 개요 -->
    <section v-if="tab === 'overview'" class="panel">
      <div class="scroll">
        <table>
          <thead>
            <tr>
              <th class="s" @click="toggleSort('name')">프로젝트 <i>{{ arw('name') }}</i></th>
              <th class="s" @click="toggleSort('activity')">마지막 활동 <i>{{ arw('activity') }}</i></th>
              <th>기본 브랜치</th>
              <th class="s num" @click="toggleSort('rate')">빌드 성공률 <i>{{ arw('rate') }}</i></th>
              <th>최근 Job</th>
              <th class="s num" @click="toggleSort('commits7')">7일 커밋 <i>{{ arw('commits7') }}</i></th>
              <th class="s num" @click="toggleSort('commits')">총 커밋 <i>{{ arw('commits') }}</i></th>
              <th class="s num" @click="toggleSort('branches')">브랜치 <i>{{ arw('branches') }}</i></th>
              <th class="s num" @click="toggleSort('mrs')">MR <i>{{ arw('mrs') }}</i></th>
              <th class="s num" @click="toggleSort('issues')">이슈 <i>{{ arw('issues') }}</i></th>
              <th class="s num" @click="toggleSort('storage')">저장소 <i>{{ arw('storage') }}</i></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="r in rows" :key="r.path">
              <td class="nowrap"><a :href="r.web_url" target="_blank" rel="noopener">{{ r.module }}-{{ r.kind }}</a></td>
              <td class="nowrap muted">{{ ago(r.last_activity_at) }}</td>
              <td class="nowrap muted">{{ r.default_branch || '-' }}</td>
              <td class="num">
                <span v-if="r.jobs?.rate != null" :class="r.jobs.rate >= 90 ? 'ok' : r.jobs.rate >= 70 ? '' : 'ng'">
                  {{ r.jobs.rate }}%
                </span><span v-else class="muted">-</span>
              </td>
              <td class="nowrap">
                <a v-if="r.jobs?.last" :href="r.jobs.last.url" target="_blank" rel="noopener"
                   class="badge" :class="stCls(r.jobs.last.status)">
                  {{ stLbl(r.jobs.last.status) }} · {{ ago(r.jobs.last.at) }}
                </a>
                <span v-else class="muted">-</span>
              </td>
              <td class="num">{{ r.commits_7d ?? '-' }}</td>
              <td class="num muted">{{ r.commit_count ?? '-' }}</td>
              <td class="num">
                {{ r.branches ?? '-' }}<span v-if="r.stale_branches" class="warn2"> ({{ r.stale_branches }})</span>
              </td>
              <td class="num" :class="{ hl: r.open_mrs }">{{ r.open_mrs ?? 0 }}</td>
              <td class="num muted">{{ r.open_issues ?? 0 }}</td>
              <td class="num muted">{{ bytes(r.storage_size) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <p class="muted note">브랜치 칸의 괄호는 {{ 30 }}일 이상 커밋이 없는 오래된 브랜치 수입니다.</p>
    </section>

    <!-- 빌드 품질 -->
    <section v-if="tab === 'build'" class="panel">
      <div class="scroll">
        <table>
          <thead>
            <tr>
              <th class="s" @click="toggleSort('name')">프로젝트 <i>{{ arw('name') }}</i></th>
              <th class="s num" @click="toggleSort('rate')">성공률 <i>{{ arw('rate') }}</i></th>
              <th>최근 {{ 20 }}건 추이 <span class="hint">(왼쪽이 최신)</span></th>
              <th class="s num" @click="toggleSort('avg')">평균 소요 <i>{{ arw('avg') }}</i></th>
              <th>현재 상태</th>
              <th>마지막 성공</th>
              <th>마지막 실패</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="r in rows" :key="r.path">
              <td class="nowrap"><a :href="r.jobs_url" target="_blank" rel="noopener">{{ r.module }}-{{ r.kind }}</a></td>
              <td class="num">
                <span v-if="r.jobs?.rate != null" :class="r.jobs.rate >= 90 ? 'ok' : r.jobs.rate >= 70 ? '' : 'ng'">
                  {{ r.jobs.rate }}%
                </span><span v-else class="muted">-</span>
                <span v-if="r.jobs?.sampled" class="muted sm"> ({{ r.jobs.success }}/{{ r.jobs.success + r.jobs.failed }})</span>
              </td>
              <td>
                <div class="spark">
                  <span v-for="(s, i) in r.jobs?.recent ?? []" :key="i" class="tick" :class="stCls(s)" :title="stLbl(s)"></span>
                </div>
              </td>
              <td class="num muted">{{ secs(r.jobs?.avg_duration) }}</td>
              <td class="nowrap">
                <a v-if="r.jobs?.last" :href="r.jobs.last.url" target="_blank" rel="noopener"
                   class="badge" :class="stCls(r.jobs.last.status)">{{ stLbl(r.jobs.last.status) }}</a>
                <span class="muted sm gap">{{ ago(r.jobs?.last?.at) }}</span>
              </td>
              <td class="nowrap muted">
                <template v-if="r.jobs?.last_success">
                  {{ ago(r.jobs.last_success.at) }} · {{ secs(r.jobs.last_success.duration) }}
                </template>
                <span v-else class="ng">최근 {{ r.jobs?.sampled ?? 0 }}건 내 없음</span>
              </td>
              <td class="nowrap muted">
                <template v-if="r.jobs?.last_failed">{{ ago(r.jobs.last_failed.at) }}</template>
                <span v-else>—</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <!-- 커밋 활동 -->
    <section v-if="tab === 'activity'" class="panel">
      <div class="scroll">
        <table>
          <thead>
            <tr>
              <th class="s" @click="toggleSort('name')">프로젝트 <i>{{ arw('name') }}</i></th>
              <th class="s num" @click="toggleSort('commits7')">7일 커밋 <i>{{ arw('commits7') }}</i></th>
              <th>최근 7일 작성자</th>
              <th>마지막 커밋</th>
              <th class="s num" @click="toggleSort('contrib')">기여자 <i>{{ arw('contrib') }}</i></th>
              <th>상위 기여자</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="r in rows" :key="r.path">
              <td class="nowrap"><a :href="r.web_url" target="_blank" rel="noopener">{{ r.module }}-{{ r.kind }}</a></td>
              <td class="num" :class="{ hl: r.commits_7d }">{{ r.commits_7d ?? 0 }}</td>
              <td class="authors">
                <template v-if="r.commit_authors_7d?.length">
                  <button
                    v-for="a in r.commit_authors_7d"
                    :key="a.name"
                    class="who"
                    :title="`${a.name} — 커밋 ${a.count}건. 눌러서 목록을 봅니다.`"
                    @click="openCommits(r, a.name)"
                  >
                    {{ shortName(a.name) }} <b>{{ a.count }}</b>
                  </button>
                </template>
                <span v-else class="muted">—</span>
              </td>
              <td>
                <template v-if="r.last_commit">
                  <span class="muted sm">{{ ago(r.last_commit.at) }} · {{ shortName(r.last_commit.author) }}</span>
                  <div class="ttl" :title="r.last_commit.title">{{ r.last_commit.title }}</div>
                </template>
                <span v-else class="muted">—</span>
              </td>
              <td class="num muted">{{ r.contributors ?? '-' }}</td>
              <td class="nowrap muted sm cut" :title="peopleFull(r.contributor_list)">
                {{ people(r.contributor_list) }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <!-- 저장소 -->
    <section v-if="tab === 'repo'" class="panel">
      <div class="scroll">
        <table>
          <thead>
            <tr>
              <th class="s" @click="toggleSort('name')">프로젝트 <i>{{ arw('name') }}</i></th>
              <th class="s num" @click="toggleSort('repo')">저장소 <i>{{ arw('repo') }}</i></th>
              <th class="s num" @click="toggleSort('artifacts')">아티팩트 <i>{{ arw('artifacts') }}</i></th>
              <th class="s num" @click="toggleSort('storage')">합계 <i>{{ arw('storage') }}</i></th>
              <th class="s num" @click="toggleSort('branches')">브랜치 <i>{{ arw('branches') }}</i></th>
              <th class="s num" @click="toggleSort('stale')">오래됨 <i>{{ arw('stale') }}</i></th>
              <th class="s num" @click="toggleSort('tags')">태그 <i>{{ arw('tags') }}</i></th>
              <th>브랜치 목록 <span class="hint">(최근 커밋순)</span></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="r in rows" :key="r.path">
              <td class="nowrap"><a :href="r.web_url" target="_blank" rel="noopener">{{ r.module }}-{{ r.kind }}</a></td>
              <td class="num muted">{{ bytes(r.repo_size) }}</td>
              <td class="num muted">{{ bytes(r.artifacts_size) }}</td>
              <td class="num">{{ bytes(r.storage_size) }}</td>
              <td class="num">{{ r.branches ?? '-' }}</td>
              <td class="num" :class="{ warn2: r.stale_branches }">{{ r.stale_branches ?? 0 }}</td>
              <td class="num muted">{{ r.tags ?? 0 }}</td>
              <td>
                <span
                  v-for="b in r.branch_list ?? []" :key="b.name"
                  class="br" :class="{ def: b.default, stale: b.stale, merged: b.merged }"
                  :title="`${b.name}\n최근 커밋 ${ago(b.at)}${b.merged ? '\n병합됨' : ''}`"
                >{{ b.name }}</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <p class="muted note">
        브랜치 칩 — 파랑: 기본 브랜치 · 회색 취소선: 병합됨 · 주황: {{ 30 }}일 이상 커밋 없음
      </p>
    </section>

    <!-- MR -->
    <section v-if="tab === 'mr'" class="panel">
      <div class="scroll">
        <table>
          <thead>
            <tr>
              <th>프로젝트</th><th>!IID</th><th>제목</th><th>작성자</th>
              <th>브랜치</th><th>생성</th><th>최근 수정</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="m in allMrs" :key="m.project + m.iid">
              <td class="nowrap">{{ m.project }}</td>
              <td class="nowrap muted">!{{ m.iid }}</td>
              <td>
                <a :href="m.web_url" target="_blank" rel="noopener">{{ m.title }}</a>
                <span v-if="m.draft" class="badge wait sm">Draft</span>
              </td>
              <td class="nowrap muted">{{ m.author }}</td>
              <td class="nowrap muted sm">{{ m.source }} → {{ m.target }}</td>
              <td class="nowrap muted">{{ ago(m.created_at) }}</td>
              <td class="nowrap muted">{{ ago(m.updated_at) }}</td>
            </tr>
            <tr v-if="!allMrs.length">
              <td colspan="7" class="muted ctr" style="padding: 20px">열린 Merge Request 가 없습니다.</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <!-- 커밋 드릴다운 -->
    <div v-if="cm" class="mask" @click.self="closeCommits">
      <div class="dlg">
        <h3>
          {{ cm.label }} · {{ shortName(cm.author) }}
          <span class="hint">최근 7일 · {{ cm.rows.length }}건</span>
          <span class="spacer"></span>
          <button class="mini" @click="closeCommits">닫기</button>
        </h3>
        <div class="cmwrap">
          <div class="cmlist">
            <p v-if="cm.loading" class="muted pad">불러오는 중…</p>
            <p v-else-if="cm.err" class="muted pad">{{ cm.err }}</p>
            <p v-else-if="!cm.rows.length" class="muted pad">최근 7일 커밋이 없습니다.</p>
            <button
              v-for="c in cm.rows"
              :key="c.id"
              class="cmrow"
              :class="{ on: c.id === cmSelId }"
              @click="openCommit(c)"
            >
              <span class="t" :title="c.title">{{ c.title }}</span>
              <span class="m">{{ c.short_id }} · {{ ago(c.at) }}</span>
            </button>
          </div>
          <div class="cmdet">
            <p v-if="!cmSel" class="muted pad">왼쪽에서 커밋을 고르면 내용과 바뀐 파일이 나옵니다.</p>
            <p v-else-if="cmSel.loading" class="muted pad">불러오는 중…</p>
            <p v-else-if="cmSel.error" class="muted pad">{{ cmSel.error }}</p>
            <template v-else>
              <div class="dh">
                <b>{{ cmSel.title }}</b>
                <div class="m">
                  {{ cmSel.short_id }} · {{ cmSel.author }} · {{ at(cmSel.at) }}
                  <a v-if="cmSel.url" :href="cmSel.url" target="_blank" rel="noopener">GitLab ↗</a>
                </div>
              </div>
              <pre v-if="cmSel.message" class="msg">{{ cmSel.message.trim() }}</pre>
              <div class="fh">
                바뀐 파일 {{ cmSel.files?.length ?? 0 }}개
                <template v-if="cmSel.additions != null">
                  <i class="ad">+{{ cmSel.additions }}</i> <i class="dl">−{{ cmSel.deletions }}</i>
                </template>
              </div>
              <div v-for="f in cmSel.files" :key="f.path" class="frow">
                <span class="k" :class="f.kind">{{ FILE_KIND[f.kind] ?? f.kind }}</span>
                <span class="p" :title="f.kind === 'renamed' ? `${f.old_path} → ${f.path}` : f.path">
                  {{ f.path }}
                </span>
                <span class="n"><i class="ad">+{{ f.add }}</i> <i class="dl">−{{ f.del }}</i></span>
              </div>
              <p v-if="!cmSel.files?.length" class="muted pad">바뀐 파일 정보가 없습니다.</p>
            </template>
          </div>
        </div>
      </div>
    </div>

    <p class="muted note">
      프로젝트당 8개 API(통계 · 브랜치 · 태그 · MR · Job · 커밋 · 기여자 · 레지스트리)를 병렬 조회합니다.
      결과는 2분간 캐시되며 <strong>전체 새로고침</strong> 으로 즉시 갱신됩니다.
    </p>
  </template>
</template>

<style scoped>
/* 작성자 칩 — 눌러서 그 사람 커밋을 본다 */
.authors { white-space: normal; max-width: 260px; }
.authors .who {
  padding: 0 6px; margin: 1px 2px 1px 0; font-size: 11px; line-height: 17px;
  border-radius: 999px; color: var(--muted);
}
.authors .who:hover { border-color: var(--accent); color: var(--accent); }
.authors .who b { font-variant-numeric: tabular-nums; }

.mask {
  position: fixed; inset: 0; background: var(--shadow-2);
  display: flex; align-items: center; justify-content: center; z-index: 50;
}
.dlg {
  background: var(--panel); border-radius: var(--radius); width: min(1040px, 94vw);
  height: min(660px, 88vh); display: flex; flex-direction: column; padding: 12px 14px;
}
.dlg h3 { display: flex; align-items: center; gap: 6px; margin: 0 0 8px; font-size: 13px; }
.dlg h3 .hint { font-weight: 400; font-size: 11px; color: var(--muted); }
.dlg h3 .spacer { flex: 1; }
.dlg .mini { padding: 1px 8px; font-size: 11px; }
/* 목록과 상세를 나란히 — 커밋을 갈아 가며 볼 때 목록이 사라지면 안 된다 */
.cmwrap { flex: 1; min-height: 0; display: flex; gap: 10px; }
.cmlist {
  width: 320px; flex: none; overflow: auto;
  border: 1px solid var(--line); border-radius: var(--radius);
}
.cmrow {
  display: block; width: 100%; text-align: left; border: 0; border-bottom: 1px solid var(--line);
  border-radius: 0; padding: 6px 9px; background: transparent;
}
.cmrow:hover { background: var(--hover); }
.cmrow.on { background: var(--accent-soft); }
.cmrow .t { display: block; font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cmrow .m { display: block; font-size: 10.5px; color: var(--muted); margin-top: 1px; }
.cmdet { flex: 1; min-width: 0; overflow: auto; border: 1px solid var(--line); border-radius: var(--radius); padding: 10px 12px; }
.cmdet .pad { padding: 14px 2px; font-size: 12px; }
.cmdet .dh b { font-size: 13px; }
.cmdet .dh .m { font-size: 11px; color: var(--muted); margin-top: 2px; }
.cmdet .dh .m a { margin-left: 6px; color: var(--accent); }
.cmdet .msg {
  margin: 8px 0; padding: 7px 9px; background: var(--surface); border: 1px solid var(--line);
  border-radius: 4px; font-size: 11.5px; white-space: pre-wrap; word-break: break-word;
}
.cmdet .fh { font-size: 11.5px; font-weight: 600; margin: 10px 0 4px; }
.cmdet .frow { display: flex; align-items: center; gap: 6px; font-size: 11.5px; padding: 2px 0; border-bottom: 1px dashed var(--line); }
.cmdet .frow .k { flex: none; width: 46px; font-size: 10px; color: var(--muted); }
.cmdet .frow .k.added { color: var(--done); }
.cmdet .frow .k.deleted { color: var(--danger-2); }
.cmdet .frow .p { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; direction: rtl; text-align: left; }
.cmdet .frow .n { flex: none; font-variant-numeric: tabular-nums; }
.ad { color: var(--done); }
.dl { color: var(--danger-2); }
.topbar {
  display: flex; align-items: center; gap: 8px; margin-bottom: 10px;
  padding: 7px 12px; background: var(--panel); border: 1px solid var(--line); border-radius: 8px;
}
.topbar .spacer { flex: 1; }
.topbar .hint { font-size: 12px; color: var(--muted); }

.tabs { display: flex; align-items: center; gap: 4px; margin: 12px 0 10px; }
.tabs .spacer { flex: 1; }
.tabs button { padding: 5px 14px; font-size: 12.5px; }
.tabs button.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); font-weight: 600; }

.nowrap { white-space: nowrap; }
.ctr { text-align: center; }
.sm { font-size: 11px; }
.note { margin: 8px 0 0; }
th.s { cursor: pointer; user-select: none; white-space: nowrap; }
th.s:hover { color: var(--accent); }
th.s i { font-style: normal; font-size: 9px; opacity: 0.45; }

.ok { color: var(--done); font-weight: 600; }
.ng { color: var(--danger); font-weight: 600; }
.hl { color: var(--accent); font-weight: 600; }
.warn2 { color: var(--warn); font-weight: 600; }
.card .v.ok { color: var(--done); }
.card .v.ng { color: var(--danger); }

.badge {
  display: inline-block; padding: 1px 8px; border-radius: 10px;
  font-size: 11px; font-weight: 600; text-decoration: none; white-space: nowrap;
}
.badge.ok { background: var(--done-soft); color: var(--done); }
.badge.ng { background: var(--danger-soft); color: var(--danger-text); }
.badge.run { background: var(--accent-soft); color: var(--accent); }
.badge.wait { background: var(--warn-soft); color: var(--warn); }
.badge.off { background: var(--surface); color: var(--muted); }

/* 최근 Job 추이 스파크라인 */
.spark { display: flex; gap: 2px; }
.spark .tick { width: 7px; height: 15px; border-radius: 2px; background: var(--fill); }
.spark .tick.ok { background: var(--done); }
.spark .tick.ng { background: var(--danger); }
.spark .tick.run { background: var(--accent); }
.spark .tick.wait { background: var(--warn-line); }

.ttl { font-size: 11.5px; max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
/* 이름 목록이 길어 표를 밀지 않도록 잘라 보여주고 전체는 툴팁으로 */
td.cut { max-width: 260px; overflow: hidden; text-overflow: ellipsis; }
.gap { margin-left: 5px; }

.br {
  display: inline-block; margin: 1px 3px 1px 0; padding: 1px 7px;
  border-radius: 9px; background: var(--fill); color: var(--muted); font-size: 10.5px; white-space: nowrap;
}
.br.def { background: var(--accent-soft); color: var(--accent); font-weight: 600; }
.br.stale { background: var(--warn-soft); color: var(--warn); }
.br.merged { text-decoration: line-through; opacity: 0.7; }
</style>
