using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace WbsApi;

/// <summary>
/// 로컬 개발서버 관제 — PMM001~PMM0NN 의 BE/FE 를 따로 기동·중지·재기동한다.
///
/// <b>이 화면이 조종하는 것은 <i>대시보드 API 가 도는 PC</i> 다.</b>
/// 사내 주소(10.13.45.51:5080)로 들어와 ▶ 를 눌러도 그 사람 PC 가 아니라
/// 이 서버 장비에서 gradle/pnpm 이 뜬다. 그래서 기본값은 <b>서버 로컬 + 최고 관리자</b>
/// 에게만 동작 버튼을 허용한다 — appsettings 의 <c>Dev:AllowRemote</c> 로 연다.
/// 상태 조회는 누구나 볼 수 있다(어떤 포트가 물려 있는지는 막을 이유가 없다).
///
/// <b>같은 기능이 한 벌 더 있다</b> — <c>Material Management/tools/devserver</c> 의 단독 콘솔
/// (<c>dev-ui.bat</c> → 127.0.0.1:4620). 그쪽은 <i>보는 사람 PC</i> 에서 돌고 이쪽은 서버 장비에서 돈다.
/// 아래 우회책 다섯(TEMP 우회 · netstat 필터 금지 · PORT 처리 · <c>.gradlew.bat</c> · 컴파일 1회 재시도)은
/// 두 벌에 <b>복사되어</b> 있다. 여기서 고치면 그쪽도 같이 봐야 한다 —
/// 한쪽만 고쳐도 <b>아무 오류가 나지 않는</b> 종류라서 갈라진 것을 한참 모른다.
///
/// 포트 규칙: BE = 8200 + N, FE = 3200 + N (PMM001 → 8201 / 3201).
/// BE 는 application.yml, FE 는 vite.config.ts 에 이미 같은 값이 박혀 있다 — 여기서 주입하지 않는다.
///
/// ⚠️ 우회책 두 가지가 <c>run.bat</c> / <c>tools/devserver</c> 에서 그대로 넘어왔다. 지우기 전에 읽을 것.
///
///  1) <b>TEMP/TMP → C:\devtmp</b>
///     이 PC 의 JDK 21 은 <c>%LOCALAPPDATA%\Temp</c> 안에서 AF_UNIX 소켓쌍의 connect() 가
///     EINVAL 로 실패한다. Selector.open() 이 죽으니 gradle 런처조차 못 뜬다
///     (<c>Unable to establish loopback connection</c>). 런처·데몬·포크된 앱 JVM 셋 다에
///     걸려야 하므로 자식 프로세스 환경변수로 넘긴다 (gradle.properties 만으로는 부족).
///
///  2) <b>BE 컴파일 1회 재시도</b>
///     gradle 데몬이 빌드 도중 죽으면 깨진 증분컴파일 스냅샷이 남아 그 다음 컴파일이
///     <c>package ... does not exist</c> 로 거짓 실패한다. 그래서 compileJava 를 먼저
///     단독으로 돌리고, 실패했을 때만 clean 후 한 번 더 돌린다. 성공 경로는 증분 그대로다.
/// </summary>
public static class DevRun
{
    private const int LogLimit = 3000;      // 서비스당 보관 줄 수
    private const int PollMs = 1500;        // netstat 결과를 이만큼 재사용한다
    private const int BePortBase = 8200;
    private const int FePortBase = 3200;

    private static string _root = ""; // 콘솔 zip 을 담아 올 곳 (dev-ui.bat 이 있는 저장소)
    private static string[] _roots = []; // 프로젝트를 훑을 뿌리들
    private static HashSet<int> _dupPorts = [];
    /// <summary>한 덩어리로 묶어 볼 폴더 이름들 — 그 아래는 얼마나 깊든 한 작업공간으로 본다.</summary>
    private static string[] _groupRoots = [];
    private static string _tmpDir = "";
    private static string _logDir = "";
    private static string _stateFile = "";
    private static bool _allowRemote;
    private static HashSet<string> _adminBpIds = new(StringComparer.OrdinalIgnoreCase);

    private static readonly List<DevProject> Projects = [];
    private static readonly ConcurrentDictionary<string, DevSvc> Services = new();

    // ---------- 포트 점유 ----------
    // 서비스마다 TCP probe 를 던지면 36번이 된다. netstat 한 번이 훨씬 싸고 PID 도 준다.
    private static Dictionary<int, int> _listen = [];
    private static DateTimeOffset _polledAt = DateTimeOffset.MinValue;
    private static readonly SemaphoreSlim PollLock = new(1, 1);

    // ⚠️ `netstat -ano -p TCP` 로 훑으면 안 된다 — IPv4 만 나온다. vite 는 [::1]:32NN 에만
    //    붙는 일이 있어서, 멀쩡히 뜬 FE 가 영영 "기동중"으로 남는다. 필터 없이 받아서
    //    LISTENING 줄만 고른다 (UDP 줄에는 LISTENING 이 없으므로 자연히 빠진다).
    private static readonly Regex ListenRe =
        new(@"^\s*TCP\s+(\S+):(\d+)\s+\S+\s+LISTENING\s+(\d+)", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    // ⚠️ 'gradlew.bat' 을 그냥 쓰면 "내부 또는 외부 명령이 아닙니다" 가 난다.
    //    cmd 가 현재 디렉터리를 탐색 경로에서 빼도록 설정된 환경이 있다
    //    (NoDefaultCurrentDirectoryInExePath). '.\gradlew.bat' 으로 못을 박는다.
    //    절대경로는 쓰지 않는다 — 프로젝트 경로에 공백이 있어 cmd /s 의 따옴표 처리에 걸린다.
    private const string Gradlew = @".\gradlew.bat";

    // ---------- 초기화 ----------
    public static void Init(IConfiguration cfg, string contentRoot)
    {
        _root = cfg["Dev:Root"] ?? @"C:\projs\G6X0\XU62\Material Management";
        // 훑는 범위는 따로 둔다 — 한 저장소가 아니라 작업공간 전체다.
        // 세미콜론으로 여러 곳을 줄 수 있다: "C:\projs\G6X0;D:\other"
        // 폴더 구조가 작업공간마다 다르다. XU62 는 <작업공간\프로젝트> 인데 CX90 은
        // <CX90\제품군\저장소> 라, 그대로 두면 CDX01·CF03·CG01… 이 저마다 작업공간이 된다.
        // 여기 적힌 이름을 만나면 그 아래를 통째로 그 이름의 작업공간으로 묶는다.
        _groupRoots = (cfg["Dev:GroupRoots"] ?? "CX90")
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        _roots = (cfg["Dev:Roots"] ?? @"C:\projs\G6X0")
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        _tmpDir = EnsureDir(cfg["Dev:Tmp"] ?? @"C:\devtmp")
                  ?? Path.Combine(Environment.GetEnvironmentVariable("SystemRoot") ?? @"C:\Windows", "Temp");
        _logDir = EnsureDir(Path.Combine(contentRoot, "data", "devlogs")) ?? _tmpDir;
        _stateFile = Path.Combine(_logDir, "devrun-state.json");
        _allowRemote = string.Equals(cfg["Dev:AllowRemote"], "true", StringComparison.OrdinalIgnoreCase);
        _adminBpIds = new HashSet<string>(
            (cfg["Admin:BpIds"] ?? "BP33772").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries),
            StringComparer.OrdinalIgnoreCase);
        // 로그인 사번을 바꿀 파일 — 기본은 이 서버 체크아웃의 PMM001 BE.
        // 체크아웃 구조가 다른 장비에서는 appsettings 의 Dev:UserIdFile 로 가리킨다.
        _userIdFile = cfg["Dev:UserIdFile"] is { Length: > 0 } uf
            ? uf
            : Path.Combine(_root, "PMM001", "pmm001-be", ".env.properties");
        Discover();
    }

    private static string? EnsureDir(string path)
    {
        try { Directory.CreateDirectory(path); return path; }
        catch { return null; }
    }

    /// <summary>훑을 때 들어가지 않는 폴더 — 안에 -be/-fe 가 있을 리 없고 수만 개가 들어 있다.</summary>
    private static readonly string[] SkipDirs =
        ["node_modules", "build", "out", "dist", "target", "bin", "obj", "logs", "coverage"];

    /// <summary>
    /// 대상 훑기 — 이름 규칙도 개수도 박지 않는다.
    ///
    /// 예전에는 <c>PMMNNN/pmmNNN-{be,fe}</c> 만 보고 포트를 8200+N / 3200+N 으로 <b>계산</b>했다.
    /// 작업공간이 늘면서 그 규칙이 깨졌다 — PPD001 은 8101/3101 이고 PPD002~009 는 아직
    /// 기본값(8080/3000)이다. 이름으로 짐작하면 없는 포트를 들여다보게 된다.
    ///
    /// 그래서 두 가지를 바꿨다.
    ///   ① <c>-be</c> / <c>-fe</c> 로 끝나는 폴더를 찾는다 (gradlew.bat / package.json 이 있는 것만).
    ///   ② 포트는 그 프로젝트의 설정 파일에서 <b>읽는다</b> — BE 는 application[-local].yml 의
    ///      server.port, FE 는 vite.config 의 server.port.
    ///
    /// 프로젝트 이름은 -be/-fe 를 담고 있는 폴더 이름이고, 작업공간은 그 위 폴더다.
    ///   G6X0\XU62\Design Management\PPD001\ppd001-be  →  PPD001 · Design Management
    ///   G6X0\XU59\xu59-be                             →  XU59   · G6X0
    /// </summary>
    // ---------- 카드 이름 (VITE_APP_TITLE) ----------
    //
    // 카드에 <PMM003> 만 있으면 번호를 외운 사람만 읽을 수 있다. FE 가 제 이름을
    // `.env` 에 적어 두고 있으므로(`VITE_APP_TITLE=PO(발주서관리)`) 그것을 붙여
    // <PMM003 · PO(발주서관리)> 로 보여 준다.
    //
    // ⚠️ <b>정규식으로 파일 전체를 훑지 말 것.</b> `VITE_APP_TITLE\s*=\s*(.*)` 로 잡으면
    // <값이 빈 줄>에서 `\s*` 가 줄바꿈까지 먹고 <다음 줄>을 값으로 집어 온다
    // (pmm016 에서 실제로 `VITE_MFE_NAME=pmm016Web` 이 이름으로 올라왔다).
    // 오류도 안 나고 그럴듯해 보여서 한참 모른다. 그래서 <한 줄씩> 읽는다.
    private static readonly string[] EnvFiles =
        [".env.production", ".env", ".env.development", ".env.local"];

    private static string? TitleOf(string? feDir, string id)
    {
        if (string.IsNullOrWhiteSpace(feDir)) return null;
        foreach (var name in EnvFiles)
        {
            var f = Path.Combine(feDir, name);
            if (!File.Exists(f)) continue;
            string[] lines;
            try { lines = File.ReadAllLines(f); } catch { continue; }

            foreach (var raw in lines)
            {
                var line = raw.Trim();
                if (line.Length == 0 || line[0] == '#') continue;
                var eq = line.IndexOf('=');
                if (eq < 0) continue;
                // VITE_APP_TITLE_SUB 같은 다른 키에 걸리지 않게 이름을 통째로 견준다
                if (!line[..eq].Trim().Equals("VITE_APP_TITLE", StringComparison.Ordinal)) continue;
                return CleanTitle(line[(eq + 1)..].Trim().Trim('"', '\'').Trim(), id);
            }
            // 파일에 키가 아예 없으면 다음 후보 파일을 본다.
            // 키는 있는데 값이 비어 있으면 <비워 둔 것> 이므로 여기서 끝낸다(위 return).
        }
        return null;
    }

    /// <summary>
    /// 이름으로 쓸 만한 값인지 가른다. <b>쓸모없는 값은 안 붙이는 것이 낫다</b> —
    /// 카드에 <c>PPD004 · your_app_title</c> 이라고 적히면 고장으로 보인다.
    /// </summary>
    private static string? CleanTitle(string v, string id)
    {
        if (string.IsNullOrWhiteSpace(v)) return null;
        if (v.Contains('=')) return null;                       // 다른 키를 집어 온 것

        // 끝에 붙은 <( PPD001 )> 는 카드가 이미 보여 주는 번호다 — 두 번 적지 않는다
        var m = Regex.Match(v, @"^(.*?)\s*\(\s*([A-Za-z0-9_-]+)\s*\)\s*$");
        if (m.Success && m.Groups[2].Value.Equals(id, StringComparison.OrdinalIgnoreCase))
            v = m.Groups[1].Value.Trim();

        if (v.Length == 0) return null;
        if (v.Equals(id, StringComparison.OrdinalIgnoreCase)) return null;   // 번호를 되풀이할 뿐
        // your_app_title · ppd_app_name — 본보기 값을 그대로 둔 것이다
        if (Regex.IsMatch(v, @"^[A-Za-z0-9_]+$") && v.Contains('_')) return null;
        return v.Length > 60 ? v[..60] : v;
    }

    private static void Discover()
    {
        Projects.Clear();
        Services.Clear();

        var byParent = new Dictionary<string, DevProject>(StringComparer.OrdinalIgnoreCase);
        var usedIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var root in _roots)
        {
            if (!Directory.Exists(root)) continue;
            var rootName = Path.GetFileName(root.TrimEnd(Path.DirectorySeparatorChar));

            foreach (var dir in Walk(root, 0))
            {
                var name = Path.GetFileName(dir);
                var tier = name.EndsWith("-be", StringComparison.OrdinalIgnoreCase) ? "be"
                         : name.EndsWith("-fe", StringComparison.OrdinalIgnoreCase) ? "fe"
                         : null;

                // -be/-fe 짝이 아닌 <홀로 선 저장소> 도 있다 (xu62-launcher, xu62-batch-runner …).
                // 그런 폴더는 그 자체가 프로젝트다 — 빌드 파일이 있고 git 저장소인 것만 잡는다.
                // .git 을 요구하는 까닭: 그것이 없으면 gradle <모듈>(hacs/data 같은)까지 프로젝트로
                // 잡혀 목록이 부풀어 오른다.
                var standalone = false;
                if (tier is null)
                {
                    if (!Directory.Exists(Path.Combine(dir, ".git"))) continue;
                    if (File.Exists(Path.Combine(dir, "package.json"))) tier = "fe";
                    else if (File.Exists(Path.Combine(dir, "gradlew.bat"))
                             || File.Exists(Path.Combine(dir, "build.gradle.kts"))
                             || File.Exists(Path.Combine(dir, "build.gradle"))) tier = "be";
                    else continue;
                    standalone = true;
                }

                // 못 돌리는 폴더도 기억해 둔다 — 편집기로 열거나 git pull 은 할 수 있고,
                // 대개 <받아오면 돌릴 수 있게 되는> 상태이기 때문이다.
                var marker = tier == "be" ? "gradlew.bat" : "package.json";
                var runnable = File.Exists(Path.Combine(dir, marker));
                // <내용이 있는 프로젝트인가> — 빈 클론과 가르는 기준이다.
                var known = runnable
                    || (tier == "be" && (File.Exists(Path.Combine(dir, "build.gradle.kts"))
                                         || File.Exists(Path.Combine(dir, "build.gradle"))));

                // 홀로 선 저장소는 제 폴더가 곧 프로젝트다. 짝을 이루는 것은 윗 폴더가 프로젝트다.
                var parent = standalone ? dir : Path.GetDirectoryName(dir);
                if (parent is null) continue;

                if (!byParent.TryGetValue(parent, out var proj))
                {
                    // 홀로 선 것은 이름을 그대로 쓴다 — xu62-launcher 를 XU62-LAUNCHER 로 외치면
                    // 저장소 이름과 눈으로 맞춰 보기 어렵다.
                    var label = standalone ? Path.GetFileName(parent) : Path.GetFileName(parent).ToUpperInvariant();
                    var up = Path.GetDirectoryName(parent);
                    var group = up is null || string.Equals(up, root, StringComparison.OrdinalIgnoreCase)
                        ? rootName
                        : Path.GetFileName(up);
                    // 묶어 보기로 한 폴더가 위에 있으면 그 이름이 이긴다
                    var lump = LumpGroup(parent, root);
                    if (lump is not null) group = lump;

                    // id 는 로그 파일 이름(<id>-<tier>.log)과 기동 기록의 열쇠다 —
                    // 폴더 이름이 겹치면 작업공간을 앞에 붙여 갈라 둔다.
                    var id = Slug(label);
                    if (!usedIds.Add(id))
                    {
                        id = Slug(group + "_" + label);
                        usedIds.Add(id);
                    }

                    proj = new DevProject { Id = id, Label = label, Group = group, Dir = parent };
                    byParent[parent] = proj;
                }

                if (tier == "be")
                {
                    proj.BeDir = dir;
                    proj.BeRunnable = runnable;
                    proj.BeKnown = known;
                    proj.BeWhy = runnable ? "" : $"{marker} 이 없습니다";
                    if (runnable) proj.BePort = BePort(dir);
                }
                else
                {
                    proj.FeDir = dir;
                    proj.FeRunnable = runnable;
                    proj.FeKnown = known;
                    proj.FeWhy = runnable ? "" : $"{marker} 이 없습니다";
                    if (runnable) proj.FePort = FePort(dir);
                }
            }
        }

        foreach (var p in byParent.Values)
        {
            // 폴더만 있고 내용이 없는 클론은 올리지 않는다 — 열 개가 넘어 목록을 덮는다.
            // 다만 <돌릴 수는 없지만 내용은 있는> 것은 올린다. git pull 로 돌릴 수 있게
            // 되는 경우가 많고, 받아올 길을 막아 둘 이유가 없다 (xu62-batch-runner 가 그렇다).
            if (!p.BeRunnable && !p.FeRunnable && !p.BeKnown && !p.FeKnown) continue;

            p.Title = TitleOf(p.FeDir, p.Id);

            Projects.Add(p);
            if (p.BeRunnable && p.BeDir is not null)
                Services[$"{p.Id}:be"] = new DevSvc { Id = p.Id, Tier = "be", Dir = p.BeDir, Port = p.BePort };
            if (p.FeRunnable && p.FeDir is not null)
                Services[$"{p.Id}:fe"] = new DevSvc { Id = p.Id, Tier = "fe", Dir = p.FeDir, Port = p.FePort };
        }
        Projects.Sort((a, b) =>
        {
            var g = string.CompareOrdinal(a.Group, b.Group);
            return g != 0 ? g : string.CompareOrdinal(a.Id, b.Id);
        });

        // 같은 포트를 두 곳이 적어 둔 경우 — 하나만 뜰 수 있고, 떠 있어도 어느 쪽인지 가릴 수 없다.
        // 화면에서 표시해 주려고 여기서 모아 둔다 (PPD002~009 가 아직 8080/3000 으로 겹쳐 있다).
        _dupPorts = Services.Values
            .Where(s => s.Port > 0)
            .GroupBy(s => s.Port)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToHashSet();
    }

    /// <summary>경로를 거슬러 올라가 <묶어 보기로 한 폴더> 가 있으면 그 이름을 준다.</summary>
    private static string? LumpGroup(string dir, string root)
    {
        var cur = dir;
        while (!string.IsNullOrEmpty(cur) && !string.Equals(cur, root, StringComparison.OrdinalIgnoreCase))
        {
            var name = Path.GetFileName(cur);
            foreach (var g in _groupRoots)
                if (string.Equals(name, g, StringComparison.OrdinalIgnoreCase)) return name;
            cur = Path.GetDirectoryName(cur);
        }
        return null;
    }

    private static string Slug(string s)
    {
        var chars = s.Trim().ToLowerInvariant()
            .Select(c => char.IsLetterOrDigit(c) ? c : '_')
            .ToArray();
        return new string(chars).Trim('_');
    }

    private static IEnumerable<string> Walk(string dir, int depth)
    {
        if (depth > 5) yield break;
        string[] subs;
        try { subs = Directory.GetDirectories(dir); }
        catch { yield break; }

        foreach (var s in subs)
        {
            var n = Path.GetFileName(s);
            if (n.StartsWith('.') || SkipDirs.Contains(n, StringComparer.OrdinalIgnoreCase)) continue;
            yield return s;

            // 프로젝트 안으로는 더 들어가지 않는다 — 그 아래는 소스이거나 gradle 모듈이다.
            // (모듈까지 프로젝트로 잡으면 hacs/data · hacs/domain 같은 것이 줄줄이 올라온다)
            if (n.EndsWith("-be", StringComparison.OrdinalIgnoreCase)
                || n.EndsWith("-fe", StringComparison.OrdinalIgnoreCase)
                || File.Exists(Path.Combine(s, "package.json"))
                || File.Exists(Path.Combine(s, "build.gradle.kts"))
                || File.Exists(Path.Combine(s, "build.gradle"))) continue;
            foreach (var d in Walk(s, depth + 1)) yield return d;
        }
    }

    /// <summary>BE 포트 — <c>gradlew local</c> 로 띄우므로 local 프로필이 있으면 그것이 이긴다.</summary>
    private static int BePort(string dir)
    {
        var res = Path.Combine(dir, "src", "main", "resources");
        foreach (var f in new[] { "application-local.yml", "application-local.yaml", "application.yml", "application.yaml" })
        {
            var p = Path.Combine(res, f);
            if (!File.Exists(p)) continue;
            var port = ServerPort(p);
            if (port > 0) return port;
        }
        return 0;
    }

    /// <summary>yml 에서 server.port 만 집어 온다. 다른 port(관리·데이터소스)를 잘못 집지 않게 한다.</summary>
    private static int ServerPort(string path)
    {
        try
        {
            var inServer = false;
            foreach (var raw in File.ReadLines(path))
            {
                var line = raw.TrimEnd();
                if (line.Length == 0 || line.TrimStart().StartsWith('#')) continue;
                if (Regex.IsMatch(line, @"^server\s*:\s*$")) { inServer = true; continue; }
                if (!inServer) continue;

                var m = Regex.Match(line, @"^\s+port\s*:\s*(\d+)");
                if (m.Success) return int.Parse(m.Groups[1].Value);
                if (!char.IsWhiteSpace(line[0])) inServer = false; // 다음 최상위 키로 넘어갔다
            }
        }
        catch { /* 못 읽으면 포트를 모르는 채로 둔다 */ }
        return 0;
    }

    /// <summary>FE 포트 — vite.config 의 server.port. <c>Number(env.PORT) || 3201</c> 꼴이 많다.</summary>
    private static int FePort(string dir)
    {
        foreach (var f in new[] { "vite.config.ts", "vite.config.mts", "vite.config.js" })
        {
            var p = Path.Combine(dir, f);
            if (!File.Exists(p)) continue;
            try
            {
                var text = File.ReadAllText(p);
                // env.PORT 를 끼고 있는 쪽이 개발서버 포트다. preview·hmr 의 port 를 집지 않으려고 먼저 본다.
                var m = Regex.Match(text, @"port\s*:\s*Number\(\s*env\.PORT\s*\)\s*\|\|\s*(\d{2,5})");
                if (!m.Success) m = Regex.Match(text, @"port\s*:\s*(\d{2,5})");
                if (m.Success) return int.Parse(m.Groups[1].Value);
            }
            catch { /* 못 읽으면 포트를 모르는 채로 둔다 */ }
        }
        return 0;
    }
    // ---------- 포트 훑기 ----------
    private static async Task PollPortsAsync(bool force = false)
    {
        if (!force && DateTimeOffset.UtcNow - _polledAt < TimeSpan.FromMilliseconds(PollMs)) return;
        await PollLock.WaitAsync();
        try
        {
            if (!force && DateTimeOffset.UtcNow - _polledAt < TimeSpan.FromMilliseconds(PollMs)) return;
            var psi = new ProcessStartInfo("netstat", "-ano")
            {
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true,
            };
            using var p = Process.Start(psi);
            if (p is null) return;
            var text = await p.StandardOutput.ReadToEndAsync();
            await p.WaitForExitAsync();

            var next = new Dictionary<int, int>();
            foreach (var line in text.Split('\n'))
            {
                var m = ListenRe.Match(line);
                if (!m.Success) continue;
                var port = int.Parse(m.Groups[2].Value);
                if (!next.ContainsKey(port)) next[port] = int.Parse(m.Groups[3].Value);
            }
            _listen = next;
            _polledAt = DateTimeOffset.UtcNow;
        }
        catch { /* netstat 이 실패하면 직전 결과를 그대로 쓴다 */ }
        finally { PollLock.Release(); }
    }

    private static int? PidOnPort(int port) => _listen.TryGetValue(port, out var pid) ? pid : null;

    // ---------- 상태 ----------
    // 우리가 띄운 것 + 포트 열림      → running
    // 우리가 띄운 것 + 포트 아직 닫힘 → phase (compiling / starting)
    // 우리가 안 띄웠는데 포트 열림    → external (run.bat 으로 띄웠거나 남은 프로세스)
    private static object Snapshot(DevSvc s)
    {
        var listenPid = PidOnPort(s.Port);
        var managed = s.Child is { HasExited: false } || s.Busy || s.Detached;
        string status;
        if (managed) status = listenPid is not null ? "running" : (s.Phase == "stopping" ? "stopping" : s.Phase);
        else if (listenPid is not null) status = "external";
        else if (s.Phase == "failed") status = "failed";
        else status = "stopped";

        return new
        {
            id = s.Id,
            tier = s.Tier,
            port = s.Port == 0 ? (int?)null : s.Port,
            // 두 곳이 같은 포트를 적어 둔 경우 — 하나만 뜰 수 있고 떠 있어도 누구 것인지 모른다
            dup = s.Port > 0 && _dupPorts.Contains(s.Port),
            status,
            phase = s.Phase,
            managed,
            pid = listenPid ?? s.PortPid ?? (s.Child is { HasExited: false } ? s.Child.Id : null),
            startedAt = s.StartedAt == 0 ? (long?)null : s.StartedAt,
            lastExit = s.LastExit,
            message = s.Message,
            logLines = s.LineCount,
        };
    }

    /// <summary>
    /// 배포 상태를 붙일 대상 — 이 화면이 아는 <b>모든</b> be/fe 폴더다 (DevDeploy.cs 가 쓴다).
    ///
    /// 기동할 수 있는 것(Services)만 주지 않는 까닭 — 여기서 못 돌리는 폴더도 개발 서버에는
    /// 떠 있을 수 있다. 받아 두지 않았다고 배포까지 없는 것이 아니다.
    /// </summary>
    public static List<(string Id, string Label, string Group, string Tier, string Dir)> DeployTargets()
    {
        var list = new List<(string, string, string, string, string)>();
        foreach (var p in Projects)
        {
            if (p.BeDir is not null) list.Add((p.Id, p.Label, p.Group, "be", p.BeDir));
            if (p.FeDir is not null) list.Add((p.Id, p.Label, p.Group, "fe", p.FeDir));
        }
        return list;
    }

    private static object StateJson(bool canControl, string why) => new
    {
        root = _root,
        roots = _roots,
        rootOk = _roots.Any(Directory.Exists),
        dupPorts = _dupPorts.OrderBy(x => x),
        tmp = _tmpDir,
        polledAt = _polledAt == DateTimeOffset.MinValue ? (long?)null : _polledAt.ToUnixTimeMilliseconds(),
        host = Environment.MachineName,
        canControl,
        why,
        // 개발 서버(Docker)에 떠 있는 것 — 여기서 기동·중지하는 것과 대상이 다르다.
        // 직전 한 바퀴의 결과를 그대로 얹는다(여기서 두드리지 않는다 · DevDeploy.cs 머리말).
        deploy = DevDeploy.Json(),
        projects = Projects.Select(p => new
        {
            id = p.Id,
            label = p.Label,
            // 사람이 읽는 이름 (FE 의 VITE_APP_TITLE) — 없으면 null 이고 화면은 번호만 보여 준다
            title = p.Title,
            group = p.Group,
            dir = p.Dir,
            // 작업공간 폴더 — 프로젝트 폴더의 윗 폴더. 통째로 편집기에 열 때 쓴다.
            groupDir = Path.GetDirectoryName(p.Dir),
            // 못 돌리는 쪽도 폴더는 있다 — 편집기·git pull 버튼을 거기에 붙인다
            beDir = p.BeDir,
            feDir = p.FeDir,
            beWhy = p.BeWhy,
            feWhy = p.FeWhy,
            be = p.BeRunnable ? Snapshot(Services[$"{p.Id}:be"]) : null,
            fe = p.FeRunnable ? Snapshot(Services[$"{p.Id}:fe"]) : null,
        }),
    };

    // ---------- 프로세스 ----------
    // ⚠️ PORT 를 그대로 물려주면 안 된다. 대시보드 API 가 PORT 를 달고 떠 있으면
    //    vite.config.ts 의 `Number(env.PORT) || 32NN` 이 그 값을 집어 FE 가 엉뚱한 포트에
    //    <조용히> 뜬다. 화면은 영원히 "기동중"으로 남는다.
    //    FE 에는 제 포트를 명시해 주고, BE 에서는 지운다(application.yml 이 정한다).
    private static Process Spawn(DevSvc s, string command)
    {
        // cmd.exe 를 명시적으로 거친다 — gradlew.bat / pnpm 은 모두 배치라 직접 실행이 안 된다.
        // chcp 65001 은 자식의 콘솔 코드페이지를 UTF-8 로 맞추려는 것이다. gradle/vite 가
        // CP949 와 UTF-8 을 섞어 내보내서, 이것이 없으면 한글 줄이 깨져 들어온다.
        var psi = new ProcessStartInfo
        {
            FileName = "cmd.exe",
            Arguments = $"/d /s /c \"chcp 65001>nul & {command}\"",
            WorkingDirectory = s.Dir,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = new UTF8Encoding(false),
            StandardErrorEncoding = new UTF8Encoding(false),
        };
        psi.Environment["TEMP"] = _tmpDir;
        psi.Environment["TMP"] = _tmpDir;
        if (s.Tier == "fe") psi.Environment["PORT"] = s.Port.ToString();
        else psi.Environment.Remove("PORT");

        var p = new Process { StartInfo = psi, EnableRaisingEvents = true };
        p.OutputDataReceived += (_, e) => { if (e.Data is not null) s.Push(e.Data); };
        p.ErrorDataReceived += (_, e) => { if (e.Data is not null) s.Push(e.Data, "err"); };
        p.Start();
        p.BeginOutputReadLine();
        p.BeginErrorReadLine();
        s.Child = p;
        return p;
    }

    /// <summary>끝날 때까지 기다리는 단계. 종료코드를 준다.</summary>
    private static async Task<int> RunStepAsync(DevSvc s, string command)
    {
        s.Push($"[dev] > {command}", "sys");
        var p = Spawn(s, command);
        await p.WaitForExitAsync();
        var code = p.ExitCode;
        if (ReferenceEquals(s.Child, p)) s.Child = null;
        p.Dispose();
        return code;
    }

    /// <summary>
    /// 계속 떠 있는 본체 — <b>대시보드에서 떼어 내어</b> 띄운다.
    ///
    /// 그냥 자식으로 띄우면 두 가지로 같이 죽는다.
    ///  ① start.cmd 나 관리자가 대시보드를 <c>taskkill /F /T</c> 로 내리면 트리째 딸려 간다.
    ///  ② 대시보드 콘솔 창을 닫으면 그 콘솔에 붙은 자식들도 종료 신호를 받는다.
    /// 개발서버는 대시보드가 올라갔다 내려가도 계속 돌아야 하므로 부모 사슬을 끊는다.
    ///
    /// 끊는 방법 — WMI(<c>Win32_Process.Create</c>)에 부탁한다. 만드는 것은 WmiPrvSE 이므로
    /// 부모 사슬이 우리와 끊긴다. 창은 <c>ShowWindow=0</c> 으로 감추고, PID 는 Create 가
    /// 돌려주므로 중지할 때 그 트리를 잡는다.
    ///
    /// ⚠️ <b>이것만으로는 부족하다.</b> 부모 사슬을 끊어도 대시보드가 죽을 때 같이 죽는 일이 있었다.
    ///    범인은 부모·자식이 아니라 <b>작업 개체(job object)</b> 였다 — <c>dotnet run</c> 이 자기가
    ///    띄운 것을 job 에 묶고, 자기가 죽으면 그 안의 것을 전부 죽인다. job 소속은 자손에게
    ///    물려지므로 부모를 바꿔도(고아·WMI 어느 쪽이든) 벗어나지 못한다.
    ///
    ///    그래서 <b>대시보드를 `dotnet run` 으로 띄우면 안 된다</b>. tools/serve.ps1 이 빌드된
    ///    WbsApi.exe 를 직접 띄우는 까닭이 이것이다. 거기를 되돌리면 이 문제가 그대로 돌아온다.
    ///
    /// 떼어 냈으니 stdout 파이프를 쓸 수 없다. 기동 스크립트가 로그 파일에 직접 덧붙이고,
    /// 화면에 보여 줄 줄은 그 파일을 뒤따라 읽어 채운다(TailAsync).
    /// </summary>
    private static async Task LaunchDetachedAsync(DevSvc s, string command)
    {
        s.Push($"[dev] > {command}   (대시보드와 분리해 기동)", "sys");

        var log = s.LogPath(_logDir);
        var bat = Path.Combine(_logDir, $"{s.Id}-{s.Tier}.start.cmd");
        WriteStartScript(s, bat, log, command);

        // 여기까지 쓴 줄은 이미 화면에 있다 — 뒤따라 읽기는 이 지점부터 시작한다.
        s.CloseLogFile();
        s.TailOffset = SafeLength(log);

        // ⚠️ 로그 파일을 남이 쓰기로 열어 두고 있으면 기동이 <조용히> 실패한다.
        //    기동 스크립트의 `call ... >> 로그` 는 cmd 의 리다이렉션인데, cmd 는 남이
        //    쓰기로 연 파일을 열지 못한다("다른 프로세스가 사용 중"). 그 오류는 감춰진
        //    창(ShowWindow=0)으로 가 버리므로 로그에는 한 줄도 남지 않고, 프로세스는
        //    그 자리에서 끝난다 — 화면만 영원히 <기동중> 으로 남는다. 미리 짚어서
        //    조용히 죽는 대신 사유를 말한다.
        //    쥐고 있는 범인은 대개 <이 서비스의 옛 기동> 이다(FindRunnerPidsAsync 참고).
        //
        // ⚠️ 반드시 CloseLogFile() <뒤에> 본다. 그 전에는 대시보드 자신이 이 파일을
        //    쓰기로 열고 있어서(OpenLogFile) 언제나 <남이 쓰고 있다> 로 나온다.
        if (!await WaitAppendableAsync(log))
        {
            Fail(s, $"로그 파일을 다른 프로세스가 쓰고 있다 ({log}) — 이 서비스의 옛 기동이 "
                    + "아직 살아 있다. [중지] 로 내린 뒤 다시 띄워라.");
            return;
        }

        var pid = await SpawnDetachedAsync(s, bat);
        if (pid is null)
        {
            Fail(s, "기동 스크립트를 띄우지 못했다 (WMI Win32_Process.Create 실패).");
            return;
        }

        s.RunPid = pid;
        s.PortPid = null;
        s.Detached = true;
        s.StartedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        s.Push($"[dev] 분리 기동됨 — PID {pid}. 대시보드를 내려도 계속 돈다.", "sys");
        StartTail(s, log);
        SaveState();
        WatchPort(s);
    }

    /// <summary>
    /// 로그 파일이 풀릴 때까지 잠깐 기다린다.
    ///
    /// 바로 앞에서 중지한 트리가 있으면(재기동이 그렇다) taskkill 이 돌아온 뒤에도
    /// 커널이 핸들을 거두기까지 잠깐 걸린다. 한 번 보고 포기하면 <멀쩡한 재기동> 이
    /// 로그 잠김으로 실패한다.
    /// </summary>
    private static async Task<bool> WaitAppendableAsync(string path, int tries = 20)
    {
        for (var i = 0; i < tries; i++)
        {
            if (CanAppend(path)) return true;
            await Task.Delay(400);
        }
        return false;
    }

    /// <summary>cmd 의 <c>&gt;&gt;</c> 가 이 파일을 열 수 있는가 — 남이 쓰기로 쥐고 있으면 못 연다.</summary>
    private static bool CanAppend(string path)
    {
        try
        {
            // FileShare.Read = <남의 쓰기를 막고 연다>. cmd 의 리다이렉션과 같은 조건이라
            // 여기서 열리면 거기서도 열린다.
            using var fs = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.Read);
            return true;
        }
        catch (IOException) { return false; }
        // 권한·경로 문제는 여기서 판정하지 않는다 — cmd 가 같은 이유로 실패하고,
        // 그 오류는 우리가 막을 수 있는 종류가 아니다.
        catch { return true; }
    }

    /// <summary>
    /// 포트를 문 주인을 적어 둘 때까지 지켜본다.
    ///
    /// 이 기록이 있어야 대시보드가 다시 떴을 때 <우리가 띄운 것> 으로 되살린다. 예전에는
    /// 화면이 상태를 물어볼 때만 적었는데, 띄워 놓고 아무도 안 보는 사이에 대시보드를
    /// 재시작하면 기록이 없어 멀쩡히 도는 것이 <외부> 로 떨어졌다.
    ///
    /// 끝까지 포트가 안 열리면 <기동중> 을 거두고 사유를 남긴다. 조용히 포기하면 화면이
    /// 영원히 기동중으로 남아, 뜨지도 않은 것을 뜬 줄 알고 기다리게 된다.
    /// Busy·Detached 는 그대로 둔다 — 늦게라도 포트가 열리면 Snapshot 이 스스로 running 으로
    /// 되돌린다(포트가 열려 있으면 phase 를 보지 않는다).
    /// </summary>
    private static void WatchPort(DevSvc s)
    {
        if (s.Port <= 0) return;
        const int tries = 150, everyMs = 2000;
        _ = Task.Run(async () =>
        {
            // 컴파일까지 하는 BE 는 포트를 물기까지 오래 걸린다
            for (var i = 0; i < tries; i++)
            {
                if (!s.Detached) return;
                await Task.Delay(everyMs);
                await PollPortsAsync(true);
                if (PidOnPort(s.Port) is null) continue;
                NotePortOwners();
                return;
            }
            if (!s.Detached) return;
            s.Phase = "failed";
            s.Message = $"{tries * everyMs / 60000}분이 지나도 포트 {s.Port} 가 열리지 않았다 — 로그를 보라.";
            s.Push($"[dev] {s.Message}", "err");
        });
    }

    /// <summary>기동 스크립트 — 기동할 때마다 다시 쓴다. 손으로 고쳐도 다음 기동에 지워진다.</summary>
    private static void WriteStartScript(DevSvc s, string batPath, string logPath, string command)
    {
        var sb = new StringBuilder();
        sb.AppendLine("@echo off");
        sb.AppendLine("rem WBS 대시보드(api/DevRun.cs)가 만든 기동 스크립트 — 기동할 때마다 덮어쓴다.");
        sb.AppendLine("rem 손으로 실행해도 된다. 그때는 대시보드에 <외부> 로 보인다.");
        sb.AppendLine("chcp 65001>nul");
        sb.AppendLine($"cd /d \"{s.Dir}\"");
        sb.AppendLine($"set \"TEMP={_tmpDir}\"");
        sb.AppendLine($"set \"TMP={_tmpDir}\"");
        // FE 에는 제 포트를 명시하고 BE 에서는 지운다 — Spawn 의 주석과 같은 이유다.
        // 포트를 모르면(설정에서 못 읽었으면) 주지 않는다 — PORT=0 을 주면 vite 가 아무 포트나 문다
        sb.AppendLine(s.Tier == "fe" && s.Port > 0 ? $"set \"PORT={s.Port}\"" : "set \"PORT=\"");
        sb.AppendLine($"call {command} >> \"{logPath}\" 2>&1");
        // 파이프가 없으니 <끝났다> 도 로그로 알린다. TailAsync 가 이 줄을 보고 상태를 내린다.
        sb.AppendLine($"echo [dev-exit] %ERRORLEVEL%>> \"{logPath}\"");
        File.WriteAllText(batPath, sb.ToString(), new UTF8Encoding(false));
    }

    /// <summary>PowerShell 을 한 번 거쳐 고아로 띄우고 그 PID 를 받아 온다.</summary>
    private static async Task<int?> SpawnDetachedAsync(DevSvc s, string batPath)
    {
        // PowerShell 을 거치는 까닭은 WMI 를 부르기 쉬워서일 뿐이다. 중요한 것은 <누가 만드는가> 다.
        var ps =
            "$bat = '" + batPath.Replace("'", "''") + "'; " +
            "$dir = '" + s.Dir.Replace("'", "''") + "'; " +
            "$si = ([WMIClass]'Win32_ProcessStartup').CreateInstance(); $si.ShowWindow = 0; " +
            "$cl = 'cmd.exe /d /s /c ' + [char]34 + $bat + [char]34; " +
            "$r = ([WMIClass]'Win32_Process').Create($cl, $dir, $si); " +
            "if ($r.ReturnValue -eq 0) { $r.ProcessId } " +
            "else { Write-Error ('Win32_Process.Create 실패 ' + $r.ReturnValue) }";
        var psi = new ProcessStartInfo("powershell.exe")
        {
            WorkingDirectory = s.Dir,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = new UTF8Encoding(false),
            StandardErrorEncoding = new UTF8Encoding(false),
        };
        psi.ArgumentList.Add("-NoProfile");
        psi.ArgumentList.Add("-NonInteractive");
        psi.ArgumentList.Add("-Command");
        psi.ArgumentList.Add(ps);

        try
        {
            using var p = Process.Start(psi);
            if (p is null) return null;
            var outText = await p.StandardOutput.ReadToEndAsync();
            var errText = await p.StandardError.ReadToEndAsync();
            await p.WaitForExitAsync();
            if (!string.IsNullOrWhiteSpace(errText)) s.Push($"[dev] {errText.Trim()}", "err");
            return int.TryParse(outText.Trim(), out var pid) ? pid : null;
        }
        catch (Exception e)
        {
            s.Push($"[dev] 기동 실패: {e.Message}", "err");
            return null;
        }
    }

    /// <summary>
    /// 이 서비스의 <b>기동 스크립트를 물고 있는</b> 프로세스를 찾는다 — 포트를 보지 않는다.
    ///
    /// 포트로만 찾으면 놓치는 길이 있다. 프로젝트의 설정 파일에서 포트가 바뀐 뒤
    /// [새로고침](다시 훑기)을 하면, <b>돌고 있는 것은 옛 포트</b>에 있는데 우리는
    /// <b>새 포트</b>를 들여다보게 된다. 그러면 이렇게 어긋난다.
    ///   ① 중지가 아무것도 못 죽인다 — RunPid 는 다시 훑으며 날아갔고(RestoreState 가
    ///      <적어 둔 포트 주인이 지금도 그 포트를 물고 있을 때만> 되살린다) 새 포트는 비어 있다.
    ///      살아 있던 쪽은 그대로 고아가 된다.
    ///   ② 이어지는 기동이 그 자리에서 죽는다 — 고아가 로그 파일을 쓰기로 쥐고 있어
    ///      기동 스크립트의 <c>&gt;&gt;</c> 가 열리지 않는다(LaunchDetachedAsync 의 ⚠️ 참고).
    /// 기동 스크립트 경로는 서비스마다 하나뿐이므로, 그것을 명령줄에 달고 있는 cmd 가 곧
    /// <우리가 띄운 것> 이다. 포트가 어디로 갔든 상관없이 찾아낸다.
    ///
    /// 손으로 start.cmd 를 돌린 것도 똑같이 걸린다 — 그것도 <이 서비스를 돌리고 있는 것> 이라
    /// 중지가 내려야 맞고, 그대로 두면 다음 기동이 ②로 죽는다.
    /// </summary>
    private static async Task<List<int>> FindRunnerPidsAsync(DevSvc s)
    {
        var bat = Path.Combine(_logDir, $"{s.Id}-{s.Tier}.start.cmd");
        // Name='cmd.exe' 로 좁히는 까닭 — 지금 이 질의를 돌리는 powershell 의 명령줄에도
        // 같은 경로가 들어 있어서, 좁히지 않으면 제 자신을 잡는다.
        var ps =
            "$bat = '" + bat.Replace("'", "''") + "'; " +
            "Get-CimInstance Win32_Process -Filter \"Name='cmd.exe'\" | " +
            "Where-Object { $_.CommandLine -and $_.CommandLine.Contains($bat) } | " +
            "ForEach-Object { $_.ProcessId }";
        var psi = new ProcessStartInfo("powershell.exe")
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = new UTF8Encoding(false),
            StandardErrorEncoding = new UTF8Encoding(false),
        };
        psi.ArgumentList.Add("-NoProfile");
        psi.ArgumentList.Add("-NonInteractive");
        psi.ArgumentList.Add("-Command");
        psi.ArgumentList.Add(ps);

        var pids = new List<int>();
        try
        {
            using var p = Process.Start(psi);
            if (p is null) return pids;
            var outText = await p.StandardOutput.ReadToEndAsync();
            _ = await p.StandardError.ReadToEndAsync();
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(20));
            try { await p.WaitForExitAsync(cts.Token); }
            catch (OperationCanceledException) { await KillTreeAsync(p.Id); return pids; }

            foreach (var line in outText.Split('\n'))
                if (int.TryParse(line.Trim(), out var pid) && pid > 0) pids.Add(pid);
        }
        catch { /* 못 찾으면 예전처럼 포트로만 판단한다 — 나빠지지는 않는다 */ }
        return pids;
    }

    private static long SafeLength(string path)
    {
        try { return new FileInfo(path).Length; } catch { return 0; }
    }

    // ---------- 로그 뒤따라 읽기 ----------
    // 분리해 띄웠으니 stdout 파이프가 없다. 스크립트가 파일에 덧붙이는 것을 읽어 화면을 채운다.
    private static void StartTail(DevSvc s, string log)
    {
        s.TailCts?.Cancel();
        var cts = new CancellationTokenSource();
        s.TailCts = cts;
        _ = Task.Run(() => TailAsync(s, log, cts.Token));
    }

    private static async Task TailAsync(DevSvc s, string log, CancellationToken ct)
    {
        var pending = Array.Empty<byte>();
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var len = SafeLength(log);
                if (len < s.TailOffset) s.TailOffset = 0;   // 다시 기동하며 잘렸다
                if (len > s.TailOffset)
                {
                    using var fs = new FileStream(log, FileMode.Open, FileAccess.Read,
                                                  FileShare.ReadWrite | FileShare.Delete);
                    fs.Seek(s.TailOffset, SeekOrigin.Begin);
                    var buf = new byte[len - s.TailOffset];
                    var n = await fs.ReadAsync(buf, ct);
                    s.TailOffset += n;

                    // 줄 끝이 아직 안 온 조각은 다음 바퀴로 넘긴다 — 한글이 반 토막 나지 않게.
                    var chunk = new byte[pending.Length + n];
                    Buffer.BlockCopy(pending, 0, chunk, 0, pending.Length);
                    Buffer.BlockCopy(buf, 0, chunk, pending.Length, n);
                    var cut = Array.LastIndexOf(chunk, (byte)10);
                    if (cut < 0) pending = chunk;
                    else
                    {
                        pending = chunk.AsSpan(cut + 1).ToArray();
                        var text = Encoding.UTF8.GetString(chunk, 0, cut + 1);
                        foreach (var raw in text.Split('\n'))
                        {
                            var line = raw.TrimEnd('\r');
                            if (line.StartsWith("[dev-exit]")) { NoteExit(s, line); return; }
                            s.Push(line);
                        }
                    }
                }
            }
            catch { /* 파일이 잠깐 잠겨도 다음 바퀴에 읽으면 된다 */ }
            try { await Task.Delay(700, ct); } catch { return; }
        }
    }

    private static void NoteExit(DevSvc s, string line)
    {
        var code = int.TryParse(line.Replace("[dev-exit]", "").Trim(), out var c) ? c : -1;
        s.LastExit = code;
        s.Busy = false;
        s.Detached = false;
        s.RunPid = null;
        s.PortPid = null;
        if (s.StopRequested) { s.Phase = "idle"; s.Message = "중지됨"; }
        else
        {
            s.Phase = code == 0 ? "exited" : "failed";
            s.Message = code == 0 ? "프로세스가 정상 종료했다" : $"프로세스가 코드 {code} 로 끝났다";
        }
        s.Push($"[dev] 프로세스 종료 (code={code})", "sys");
        SaveState();
    }

    // ---------- 기동 기록 ----------
    // 대시보드가 내려갔다 올라와도 <우리가 띄운 것> 이 <외부> 로 바뀌지 않게 적어 둔다.
    // 서비스는 대시보드와 따로 도는 것이니, 대시보드의 기억이 끊긴다고 남의 것이 되면 안 된다.
    private sealed record SavedRun(int? RunPid, int? PortPid, long StartedAt);

    private static void SaveState()
    {
        try
        {
            var map = new Dictionary<string, SavedRun>();
            foreach (var s in Services.Values)
                if (s.Detached) map[$"{s.Id}:{s.Tier}"] = new SavedRun(s.RunPid, s.PortPid, s.StartedAt);
            File.WriteAllText(_stateFile, JsonSerializer.Serialize(map));
        }
        catch { /* 기록을 못 남겨도 동작은 그대로다 — 다음에 <외부> 로 보일 뿐이다 */ }
    }

    private static bool _restored;

    /// <summary>포트를 훑은 뒤에 부른다 — 살아 있는지 판정에 netstat 결과가 필요하다.</summary>
    private static void RestoreState()
    {
        if (_restored) return;
        _restored = true;
        try
        {
            if (!File.Exists(_stateFile)) return;
            var map = JsonSerializer.Deserialize<Dictionary<string, SavedRun>>(File.ReadAllText(_stateFile));
            if (map is null) return;
            foreach (var (key, v) in map)
            {
                if (!Services.TryGetValue(key, out var s)) continue;
                // 그 사이 죽었을 수도, 남이 그 포트를 물었을 수도 있다.
                // 적어 둔 포트 주인이 <지금도> 그 포트를 잡고 있을 때만 우리 것으로 되살린다.
                if (v.PortPid is null || PidOnPort(s.Port) != v.PortPid) continue;
                s.Detached = true;
                s.Busy = true;
                s.RunPid = v.RunPid;
                s.PortPid = v.PortPid;
                s.StartedAt = v.StartedAt;
                s.Phase = "starting";
                var log = s.LogPath(_logDir);
                s.TailOffset = SafeLength(log);
                StartTail(s, log);
                s.Push("[dev] 대시보드가 다시 떴다 — 이 서비스는 그동안 계속 돌고 있었다.", "sys");
            }
        }
        catch { /* 기록이 깨졌으면 그냥 <외부> 로 보이면 된다 */ }
    }

    /// <summary>분리 기동한 뒤 실제로 포트를 문 주인을 적어 둔다 — 다시 떴을 때 되살리는 열쇠다.</summary>
    private static void NotePortOwners()
    {
        var dirty = false;
        foreach (var s in Services.Values)
        {
            if (!s.Detached || s.PortPid is not null) continue;
            if (PidOnPort(s.Port) is not int pid) continue;
            s.PortPid = pid;
            dirty = true;
        }
        if (dirty) SaveState();
    }
    private static int SafeExitCode(Process p)
    {
        try { return p.ExitCode; } catch { return -1; }
    }

    private static async Task KillTreeAsync(int pid)
    {
        try
        {
            var psi = new ProcessStartInfo("taskkill", $"/PID {pid} /T /F")
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
            };
            using var p = Process.Start(psi);
            if (p is not null) await p.WaitForExitAsync();
        }
        catch { /* 이미 죽었으면 그만이다 */ }
    }

    // ---------- 기동 / 중지 ----------
    private static async Task<object> StartAsync(DevSvc s)
    {
        if (s.Busy || s.Child is { HasExited: false })
            return new { ok = false, message = "이미 기동 중이다" };

        await PollPortsAsync(true);
        if (PidOnPort(s.Port) is int owner)
            return new { ok = false, message = $"포트 {s.Port} 를 이미 PID {owner} 가 쓰고 있다 (외부 프로세스 — 먼저 중지하라)" };

        // 포트가 비어 있다고 안 돌고 있는 것이 아니다 — 설정 포트가 바뀐 뒤 다시 훑으면
        // 옛 기동은 <옛 포트> 에 그대로 살아 있다. 그 위에 겹쳐 띄우면 로그 파일을 그쪽이
        // 쥐고 있어 새 프로세스가 조용히 죽는다. 띄우기 전에 짚고 사유를 말한다.
        // (재기동은 StopAsync 가 먼저 돌며 이것들을 내리므로 여기서 걸리지 않는다.)
        //
        // 잠김 확인이 먼저다 — FileStream 한 번이라 값이 싸고, 아직 OpenLogFile 을 하기
        // 전이라 우리 손은 걸리지 않는다. 비싼 프로세스 훑기는 잠겼을 때만 해서 범인의
        // PID 를 집어 준다 (<모두 기동> 처럼 여러 건을 한꺼번에 돌릴 때 느려지지 않게).
        if (!CanAppend(s.LogPath(_logDir)))
        {
            var leftover = await FindRunnerPidsAsync(s);
            var who = leftover.Count > 0 ? $" (PID {string.Join(", ", leftover)})" : "";
            return new
            {
                ok = false,
                message = $"이 서비스의 옛 기동이 아직 돌고 있다{who} — [중지] 로 내린 뒤 띄워라. "
                          + "설정 포트가 바뀌어 옛 기동이 다른 포트에 남아 있는 경우다.",
            };
        }

        s.StopRequested = false;
        s.Busy = true;
        s.Detached = false;
        s.RunPid = null;
        s.PortPid = null;
        s.LastExit = null;
        s.Message = "";
        s.OpenLogFile(_logDir);
        s.Push($"[dev] {s.Id}/{s.Tier} 기동 — dir={s.Dir} port={s.Port} TEMP={_tmpDir}", "sys");

        // 기동 시퀀스는 뒤에서 돈다 — 화면이 기다리지 않게 한다.
        _ = Task.Run(async () =>
        {
            try
            {
                if (s.Tier == "be") await StartBackendAsync(s);
                else await StartFrontendAsync(s);
            }
            catch (Exception e) { Fail(s, $"기동 중 오류: {e.Message}"); }
        });
        return new { ok = true };
    }

    private static async Task StartBackendAsync(DevSvc s)
    {
        if (!File.Exists(Path.Combine(s.Dir, "gradlew.bat")))
        {
            Fail(s, $"gradlew.bat 이 없다 ({s.Dir}) — BE 가 체크아웃되지 않았다.");
            return;
        }

        s.Phase = "compiling";
        var rc = await RunStepAsync(s, $"{Gradlew} compileJava --console=plain");
        if (s.StopRequested) { Abort(s); return; }

        if (rc != 0)
        {
            // 환경 문제는 clean 으로 못 고친다. clean 자체가 같은 이유로 죽는다.
            if (s.Tail(200).Contains("Unable to establish loopback connection"))
            {
                Fail(s, $"JDK AF_UNIX loopback 이 막혔다 (TEMP={_tmpDir}). "
                        + "appsettings 의 Dev:Tmp 로 다른 디렉터리를 지정해 보고, "
                        + "그래도 안 되면 파일시스템 필터 드라이버 문제다 (fltmc filters).");
                return;
            }
            s.Push("[dev] 컴파일 실패 → 증분컴파일 스냅샷이 깨졌을 수 있다. clean 후 1회 재시도.", "sys");
            await RunStepAsync(s, $"{Gradlew} clean --console=plain");
            if (s.StopRequested) { Abort(s); return; }
            rc = await RunStepAsync(s, $"{Gradlew} compileJava --console=plain");
            if (s.StopRequested) { Abort(s); return; }
            if (rc != 0) { Fail(s, "clean 후에도 컴파일이 실패한다 — 실제 소스 오류다. 로그를 보라."); return; }
            s.Push("[dev] clean 후 컴파일 성공 — 첫 실패는 캐시 문제였다.", "sys");
        }

        s.Phase = "starting";
        await LaunchDetachedAsync(s, $"{Gradlew} local --console=plain");
    }

    private static async Task StartFrontendAsync(DevSvc s)
    {
        if (!Directory.Exists(Path.Combine(s.Dir, "node_modules")))
        {
            Fail(s, "node_modules 가 없다 — 먼저 pnpm install (또는 refresh-all-fe.bat) 을 돌려라.");
            return;
        }
        s.Phase = "starting";
        await LaunchDetachedAsync(s, "pnpm dev");
    }

    private static void Fail(DevSvc s, string message)
    {
        s.Busy = false;
        s.Phase = "failed";
        s.Message = message;
        s.Push($"[dev] {message}", "err");
    }

    private static void Abort(DevSvc s)
    {
        s.Busy = false;
        s.Phase = "idle";
        s.Message = "기동 중 중지됨";
        s.Push("[dev] 기동 시퀀스를 중단했다.", "sys");
    }

    private static async Task<object> StopAsync(DevSvc s)
    {
        s.StopRequested = true;
        s.Phase = "stopping";
        s.TailCts?.Cancel();
        // 우리 손부터 놓는다 — 아래에서 <로그 파일이 아직 잠겨 있는가> 로 남은 것을 가리는데,
        // 대시보드 자신이 쥐고 있으면(컴파일 단계에서 중지한 경우) 언제나 잠긴 것으로 보인다.
        s.CloseLogFile();

        // 분리해 띄운 것은 우리 자식이 아니다 — 받아 둔 PID 로 그 트리를 잡는다.
        if (s.RunPid is int runPid)
        {
            s.Push($"[dev] 분리 기동 PID {runPid} 트리 종료 (taskkill /T /F)", "sys");
            await KillTreeAsync(runPid);
        }

        if (s.Child is { HasExited: false } child)
        {
            s.Push("[dev] 프로세스 트리 종료 (taskkill /T /F)", "sys");
            await KillTreeAsync(child.Id);
        }

        // PID 도 포트도 못 짚은 <고아> 가 남아 있을 수 있다 — 설정 포트가 바뀐 뒤
        // 다시 훑으면 돌고 있는 것은 옛 포트에 있고 RunPid 는 날아간 상태가 된다.
        //
        // 남았는지는 <로그 파일이 아직 잠겨 있는가> 로 가린다. 기동 스크립트는 로그를
        // 쓰기로 쥐고 있으므로, 방금 제대로 내렸으면 곧 풀린다(핸들이 거둬지기까지 잠깐
        // 걸려서 몇 번 기다려 본다). 끝내 안 풀리면 아직 누가 돌리고 있다는 뜻이고,
        // 그때만 비싼 프로세스 훑기로 기동 스크립트의 주인을 찾아 끊는다.
        if (!await WaitAppendableAsync(s.LogPath(_logDir), 5))
            foreach (var pid in await FindRunnerPidsAsync(s))
            {
                s.Push($"[dev] 남아 있는 기동 스크립트 PID {pid} 트리 종료 (포트가 아니라 스크립트로 찾았다)", "sys");
                await KillTreeAsync(pid);
            }

        // 자식이 없거나 죽였는데도 포트가 남아 있으면 포트 주인을 잡는다.
        for (var i = 0; i < 6; i++)
        {
            await PollPortsAsync(true);
            if (PidOnPort(s.Port) is not int pid) break;
            s.Push($"[dev] 포트 {s.Port} 를 PID {pid} 가 잡고 있다 → 종료", "sys");
            await KillTreeAsync(pid);
            await Task.Delay(400);
        }

        s.Busy = false;
        s.Child = null;
        s.Detached = false;
        s.RunPid = null;
        s.PortPid = null;
        s.Phase = "idle";
        s.Message = "중지됨";
        SaveState();
        return new { ok = true };
    }

    // ---------- 그 폴더에서 명령창 열기 ----------
    // 손으로 뭔가 돌려 봐야 할 때 — 경로를 복사해 붙이지 않게 한다.
    //
    // ⚠️ 창은 <대시보드 API 가 도는 PC> 의 바탕화면에 뜬다. 사내 주소로 보고 있는
    //    사람 화면에는 아무것도 나타나지 않는다 — 기동·중지와 같은 이야기다.
    //
    // start 를 한 번 거치는 까닭 — 우리 자식으로 두면 대시보드를 내릴 때(taskkill /T)
    // 사람이 쓰던 창까지 같이 닫힌다. 껍데기 cmd 는 곧바로 끝나므로 창은 고아가 된다.
    private static object OpenCmd(DevSvc s)
    {
        if (!Directory.Exists(s.Dir)) return new { ok = false, message = $"폴더가 없다 ({s.Dir})." };
        try
        {
            var psi = new ProcessStartInfo("cmd.exe")
            {
                Arguments = $"/d /s /c start \"{s.Id}-{s.Tier}\" cmd /K cd /d \"{s.Dir}\"",
                UseShellExecute = false,
                CreateNoWindow = true, // 껍데기는 보이지 않게. 진짜 창은 start 가 띄운다.
            };
            using var p = Process.Start(psi);
            s.Push($"[dev] 명령창 열기 — {s.Dir}", "sys");
            return new { ok = true, message = $"{s.Dir} 에서 명령창을 열었습니다 (서버 장비 화면)." };
        }
        catch (Exception e)
        {
            return new { ok = false, message = $"명령창을 열지 못했다: {e.Message}" };
        }
    }

    // ---------- VS Code 로 열기 ----------
    // `code .` 는 배치 셸(code.cmd)이라 cmd 를 거쳐야 한다.
    //
    // 기다렸다가 결과를 본다 — code 가 PATH 에 없으면 그 말을 화면에 돌려주기 위해서다.
    // 떼어 내 띄우면 실패해도 아무도 모른다. code.cmd 는 편집기를 띄우고 곧바로 끝나므로
    // 기다려도 오래 잡히지 않고, 우리 cmd 가 끝나면 편집기는 고아가 되어 남는다.
    private static Task<object> OpenCodeAsync(DevSvc s) => OpenCodeDirAsync(s.Dir, s);

    /// <summary>폴더 하나를 VS Code 로 연다. 서비스 폴더(-be/-fe)든 프로젝트 폴더든 같다.</summary>
    private static async Task<object> OpenCodeDirAsync(string dir, DevSvc? s = null)
    {
        if (!Directory.Exists(dir)) return new { ok = false, message = $"폴더가 없다 ({dir})." };

        var (code, so, se) = await RunCaptureAsync(dir, "cmd.exe", "/d /s /c code .", 30);
        if (code != 0)
        {
            var why = Summary(se.Length > 0 ? se : so);
            s?.Push($"[dev] VS Code 열기 실패 — {why}", "err");
            return new { ok = false, message = $"VS Code 를 띄우지 못했다 — {why}" };
        }
        s?.Push($"[dev] VS Code 열기 — {dir}", "sys");
        return new { ok = true, message = $"{dir} 를 VS Code 로 열었습니다 (서버 장비 화면)." };
    }

    // ---------- git pull ----------
    // 기동과 달리 <짧게 끝나고 결과를 봐야 하는> 일이라 떼어 내지 않는다.
    // 기다렸다가 출력을 그대로 로그(≡)에 넣고, 마지막 줄을 화면에 돌려준다.
    private static async Task<object> PullAsync(DevSvc s)
    {
        if (s.Pulling) return new { ok = false, message = "이미 받는 중이다." };
        s.Pulling = true;
        try { return await PullDirAsync(s.Dir, s); }
        finally { s.Pulling = false; }
    }

    /// <summary>폴더 하나에서 git pull. 서비스가 없는 폴더(못 돌리는 쪽)도 같은 길로 받는다.</summary>
    private static async Task<object> PullDirAsync(string dir, DevSvc? s = null)
    {
        if (!Directory.Exists(Path.Combine(dir, ".git")))
            return new { ok = false, message = $"git 저장소가 아니다 ({dir})." };

        {
            s?.Push($"[dev] > git pull   ({s.Dir})", "sys");
            var (code, so, se) = await RunCaptureAsync(dir, "git", "pull");

            // ⚠️ git 은 진행상황(From …, 브랜치 갱신)을 stderr 로 쓴다. 성공했는데도
            //    빨갛게 칠하면 실패한 것처럼 보인다 — 실패했을 때만 err 로 넣는다.
            foreach (var raw in (so + "\n" + se).Split('\n'))
            {
                var line = raw.TrimEnd('\r');
                if (line.Length > 0) s?.Push(line, code == 0 ? "out" : "err");
            }
            s?.Push($"[dev] git pull 끝 (code={code})", "sys");

            // 결론은 stdout 끝에 있다 (Already up to date. / … 3 files changed …).
            // 둘을 이어 붙여 마지막 줄을 고르면 stderr 의 <From …> 이 결론으로 뽑힌다.
            var head = Summary(so.Length > 0 ? so : se);
            return new { ok = code == 0, code, message = head, output = (so + "\n" + se).Trim() };
        }
    }

    /// <summary>
    /// 여러 서비스에 걸쳐 git pull 하고 한 줄로 요약한다.
    ///
    /// 프로젝트·작업공간 폴더에서 pull 하면 안 된다 — 저장소는 be/fe <각각> 이고
    /// 그 위 폴더는 git 이 아니다. 그래서 대상을 펼쳐 하나씩 돌린다.
    /// </summary>
    private static async Task<object> PullManyAsync(List<DevSvc> list, string what)
    {
        if (list.Count == 0) return new { ok = false, message = $"{what} 에 받아올 저장소가 없습니다." };

        var changed = new List<string>();
        var failed = new List<string>();
        foreach (var s in list)
        {
            var r = await PullAsync(s);
            var j = System.Text.Json.JsonSerializer.SerializeToElement(r);
            var ok = j.TryGetProperty("ok", out var okv) && okv.ValueKind == JsonValueKind.True;
            var msg = j.TryGetProperty("message", out var mv) ? mv.GetString() ?? "" : "";
            var tag = $"{s.Id.ToUpperInvariant()} {s.Tier.ToUpperInvariant()}";
            if (!ok) failed.Add($"{tag}: {msg}");
            else if (!msg.Contains("up to date", StringComparison.OrdinalIgnoreCase)) changed.Add($"{tag} ({msg})");
        }

        var head = $"{what} · 저장소 {list.Count}곳";
        if (failed.Count > 0)
            return new { ok = false, message = $"{head} — 실패 {failed.Count}건: {string.Join(" / ", failed)}" };
        if (changed.Count == 0) return new { ok = true, message = $"{head} — 모두 최신입니다." };
        return new { ok = true, message = $"{head} — 받아온 곳 {changed.Count}: {string.Join(" / ", changed)}" };
    }

    /// <summary>마지막 뜻있는 줄 — git 은 결론을 끝에 적는다 (Already up to date. / Fast-forward …).</summary>
    private static string Summary(string text)
    {
        var lines = text.Split('\n').Select(x => x.Trim()).Where(x => x.Length > 0).ToList();
        if (lines.Count == 0) return "(출력 없음)";
        var last = lines[^1];
        return last.Length > 200 ? last[..200] + "…" : last;
    }

    /// <summary>짧은 명령 하나를 돌리고 출력을 모아 온다.</summary>
    private static async Task<(int code, string stdout, string stderr)> RunCaptureAsync(
        string dir, string file, string args, int timeoutSec = 90)
    {
        var psi = new ProcessStartInfo(file, args)
        {
            WorkingDirectory = dir,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = new UTF8Encoding(false),
            StandardErrorEncoding = new UTF8Encoding(false),
        };
        // ⚠️ 자격증명을 물으면 그 자리에서 영영 멈춘다 — 창이 없어 아무도 답할 수 없다.
        //    묻지 말고 실패하게 두고, 그래도 안 끝나면 아래 시간제한으로 끊는다.
        psi.Environment["GIT_TERMINAL_PROMPT"] = "0";
        psi.Environment["GCM_INTERACTIVE"] = "never";

        try
        {
            using var p = Process.Start(psi);
            if (p is null) return (-1, "", "프로세스를 띄우지 못했다.");
            var so = p.StandardOutput.ReadToEndAsync();
            var se = p.StandardError.ReadToEndAsync();
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(timeoutSec));
            try
            {
                await p.WaitForExitAsync(cts.Token);
            }
            catch (OperationCanceledException)
            {
                await KillTreeAsync(p.Id);
                return (-1, "", $"{timeoutSec}초 안에 끝나지 않아 끊었다 — 자격증명을 묻고 있을 수 있다.");
            }
            return (p.ExitCode, (await so).Trim(), (await se).Trim());
        }
        catch (Exception e)
        {
            return (-1, "", e.Message);
        }
    }

    private static async Task<object> RestartAsync(DevSvc s)
    {
        await StopAsync(s);
        await Task.Delay(800);
        return await StartAsync(s);
    }

    // ---------- 로그인 사번 (.env.properties 의 USER_ID) ----------
    //
    // [서버] 탭의 [사용자 반영] 이 쓰는 자리다. 바꾸는 파일은 <대시보드 API 가 도는 장비>의
    // 체크아웃이다 — 누르는 사람 PC 가 아니다. 기동·중지와 같은 성질이라 CanControlAsync 로 막는다.
    // 제 PC 를 바꾸려면 [내 PC] 탭의 콘솔(tools/devserver)에 같은 단추가 한 벌 더 있다.
    // ⚠️ 두 벌이다. 여기 규칙을 고치면 그쪽(server.mjs 의 writeEnvUserId)도 같이 봐야 한다 —
    //    한쪽만 고쳐도 아무 오류가 나지 않는 종류다.
    //
    // ⚠️ 줄 번호로 찾지 않는다. 지금은 17번째 줄이지만, 위쪽 주석이 한 줄만 늘거나 줄어도
    //    엉뚱한 줄 — 바로 위가 DB 비밀번호다 — 을 덮어쓴다. USER_ID= 로 시작하는 첫 줄을 찾는다.
    // ⚠️ 파일을 통째로 다시 쓰므로 원본 모양을 그대로 지킨다: BOM 유무 · 줄별 CRLF 유무 ·
    //    마지막 줄의 개행 유무까지. 이 파일은 .gitignore 대상이라 되돌릴 길이 없다.
    private static string _userIdFile = "";
    private static readonly Regex UserIdRe = new(@"^(\s*USER_ID\s*=)(.*)$", RegexOptions.Compiled);
    private static readonly Regex UserIdOk = new(@"^[A-Za-z0-9_-]{1,30}$", RegexOptions.Compiled);

    /// <summary>파일을 줄로 쪼개고 USER_ID 줄의 자리를 찾아 준다. 못 찾으면 Idx 가 -1 이다.</summary>
    private static (string[] Lines, bool Bom, int Idx, string Head, string Value) LoadUserIdFile()
    {
        var bytes = File.ReadAllBytes(_userIdFile);
        var bom = bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF;
        var skip = bom ? 3 : 0;
        var lines = new UTF8Encoding(false).GetString(bytes, skip, bytes.Length - skip).Split('\n');
        for (var i = 0; i < lines.Length; i++)
        {
            // 줄 끝의 \r 은 떼고 맞춘 뒤 다시 붙인다 — 섞여 있어도 그 줄의 모양을 지킨다.
            var body = lines[i].EndsWith('\r') ? lines[i][..^1] : lines[i];
            var m = UserIdRe.Match(body);
            if (m.Success) return (lines, bom, i, m.Groups[1].Value, m.Groups[2].Value.Trim());
        }
        return (lines, bom, -1, "", "");
    }

    private static object ReadUserId()
    {
        if (!File.Exists(_userIdFile))
            return new { ok = false, file = _userIdFile, userId = (string?)null, line = (int?)null,
                         message = $"{_userIdFile} 이 없습니다. appsettings 의 Dev:UserIdFile 을 확인하세요." };
        try
        {
            var f = LoadUserIdFile();
            return f.Idx < 0
                ? new { ok = false, file = _userIdFile, userId = (string?)null, line = (int?)null,
                        message = $"{_userIdFile} 에 USER_ID= 로 시작하는 줄이 없습니다." }
                : new { ok = true, file = _userIdFile, userId = (string?)f.Value, line = (int?)(f.Idx + 1),
                        message = "" };
        }
        catch (Exception e)
        {
            return new { ok = false, file = _userIdFile, userId = (string?)null, line = (int?)null,
                         message = $"읽지 못했습니다: {e.Message}" };
        }
    }

    private static object WriteUserId(string raw, List<DevPerson> devs)
    {
        var typed = (raw ?? "").Trim();
        // 명부에 있는 사번이면 <명부의 철자> 를 그대로 쓴다. 없으면 대문자로 올린다.
        //
        // 두 쪽이 다 필요하다. 이 프로젝트 사번은 거의 다 대문자고(BP33772) DB 비교도
        // TRIM(REG_EMPNO)='BP34173' 처럼 대문자 기준이라, 소문자로 들어가면 조회가 조용히
        // 0행이 된다. 그런데 dev_user 에는 sunakim87 처럼 소문자 id 도 있다 — 그것까지
        // 올려 버리면 명부에서 고른 값이 명부에 없는 값으로 바뀐다.
        var id = devs.FirstOrDefault(d => string.Equals(d.bpId, typed, StringComparison.OrdinalIgnoreCase))?.bpId
                 ?? typed.ToUpperInvariant();
        if (!UserIdOk.IsMatch(id))
            return new { ok = false, message = "사번이 올바르지 않습니다 — 영문·숫자·_- 로 30자 이내 (예: BP33772)" };
        if (!File.Exists(_userIdFile))
            return new { ok = false, message = $"{_userIdFile} 이 없습니다. appsettings 의 Dev:UserIdFile 을 확인하세요." };

        var tmp = _userIdFile + ".wbs.tmp";
        try
        {
            var f = LoadUserIdFile();
            if (f.Idx < 0)
                return new { ok = false, message = $"{_userIdFile} 에 USER_ID= 로 시작하는 줄이 없습니다." };
            if (string.Equals(f.Value, id, StringComparison.Ordinal))
                return new { ok = true, changed = false, userId = id, previous = id, line = f.Idx + 1,
                             file = _userIdFile, host = Environment.MachineName, message = $"이미 {id} 입니다." };

            var previous = f.Value;
            var cr = f.Lines[f.Idx].EndsWith('\r') ? "\r" : "";
            f.Lines[f.Idx] = f.Head + id + cr;

            // UTF8Encoding(true).GetBytes() 는 BOM 을 넣어 주지 않는다 — 직접 앞에 붙여야 한다.
            var payload = new UTF8Encoding(false).GetBytes(string.Join("\n", f.Lines));
            if (f.Bom)
            {
                var pre = Encoding.UTF8.GetPreamble();
                var all = new byte[pre.Length + payload.Length];
                Buffer.BlockCopy(pre, 0, all, 0, pre.Length);
                Buffer.BlockCopy(payload, 0, all, pre.Length, payload.Length);
                payload = all;
            }

            // 임시 파일에 다 쓰고 바꿔 끼운다 — 쓰다 죽어도 반쪽짜리 파일이 남지 않는다.
            File.WriteAllBytes(tmp, payload);
            File.Move(tmp, _userIdFile, overwrite: true);

            // 스프링은 기동 때 한 번 읽는다 — 떠 있는 BE 는 내렸다 올려야 바뀐 사번을 쓴다.
            var be = Services.Values.FirstOrDefault(
                s => s.Tier == "be" && string.Equals(
                    Path.GetFullPath(Path.Combine(s.Dir, ".env.properties")),
                    Path.GetFullPath(_userIdFile), StringComparison.OrdinalIgnoreCase));
            var live = be is not null && (be.Busy || be.Child is not null || PidOnPort(be.Port) is not null);

            return new { ok = true, changed = true, userId = id, previous, line = f.Idx + 1,
                         file = _userIdFile, host = Environment.MachineName,
                         message = $"USER_ID {previous} → {id}"
                                   + (live ? $" · {be!.Id.ToUpperInvariant()} BE 를 재기동해야 반영됩니다" : "") };
        }
        catch (Exception e)
        {
            try { if (File.Exists(tmp)) File.Delete(tmp); } catch { /* 임시 파일 치우기 실패는 넘긴다 */ }
            return new { ok = false, message = $"쓰지 못했습니다: {e.Message}" };
        }
    }

    /// <summary>
    /// 콤보박스 후보 — 개발자 마스터(public.dev_user)에서 사번·이름 <b>두 칸만</b> 가져온다.
    /// 그 표에는 전화·비상연락처·장비번호가 같이 들어 있다. 콤보박스에 필요 없는 것은 내보내지 않는다.
    /// DB 가 안 붙거나 표가 없어도 빈 목록으로 돌려준다 — 그래도 직접 입력으로 쓸 수 있어야 한다.
    ///
    /// ⚠️ <c>block_yn</c> 으로 거르지 않는다. 그것은 <i>대시보드에 들어오지 못하게 막은 것</i>
    ///    이지 <i>개발자가 아니다</i> 가 아니다. 걸러 보니 지금 쓰고 있는 사번(BP33772)부터
    ///    목록에서 사라졌다 — 바로 그 값이 파일에 들어 있는데도.
    /// </summary>
    private static async Task<List<DevPerson>> DevelopersAsync(PgPool db)
    {
        try
        {
            var rows = await db.QueryAsync("""
                select bp_id, coalesce(name, '') as name
                  from public.dev_user
                 where bp_id is not null
                 order by name, bp_id
                """);
            return rows
                .Select(r => new DevPerson(
                    r["bp_id"]?.ToString()?.Trim() ?? "",
                    r["name"]?.ToString()?.Trim() ?? ""))
                .Where(x => UserIdOk.IsMatch(x.bpId))
                .ToList();
        }
        catch
        {
            return [];
        }
    }

    // ---------- 권한 ----------
    // 동작(기동/중지)은 서버 장비를 움직이는 일이다. 조회와 달리 좁게 연다.
    private static async Task<(bool ok, string why)> CanControlAsync(IpGate g, PgPool db, HttpContext ctx)
    {
        var r = await g.CheckAsync(ctx);
        if (!r.Allowed) return (false, "접근이 허용되지 않은 IP 입니다.");

        // 서버 장비(루프백)는 whoami 와 같은 규칙으로 전체를 연다 — 스스로를 잠그지 않기 위해서다.
        if (r.Loopback) return (true, "");

        // [메뉴 권한] 에서 이 화면을 막아 둔 사람은 동작도 막는다. Super 라도 마찬가지다
        // (whoami 의 ② 규칙과 같다).
        //
        // Menus.cs 는 메뉴 권한이 <화면을 가리는> 장치이고 API 는 막지 않는다고 못박아 두었다.
        // 이 화면만 예외로 두는 까닭 — 다른 화면의 API 는 데이터를 <읽어> 주지만 이 API 는
        // 서버 장비에서 프로세스를 <띄우고 내린다>. 가리기만 하고 열어 두면 그 설정이 거짓말이 된다.
        var denied = await Menus.DeniedAsync(db, r.BpId);
        if (denied.Any(k => string.Equals(k, "devui", StringComparison.OrdinalIgnoreCase)))
            return (false, "[메뉴 권한] 에서 <로컬 개발서버> 가 막혀 있어 기동·중지를 할 수 없습니다.");

        if (_allowRemote) return (true, "");
        if (r.Super || (r.BpId is not null && _adminBpIds.Contains(r.BpId))) return (true, "");
        return (false,
            $"기동·중지는 서버 장비({Environment.MachineName})를 움직이는 동작이라 "
            + "서버 로컬 또는 최고 관리자에게만 열려 있습니다. "
            + "다른 사람에게도 열려면 appsettings 의 Dev:AllowRemote 를 true 로 두고 API 를 재시작하세요.");
    }

    // ---------- 라우팅 ----------
    public static void Map(WebApplication app)
    {
        app.MapGet("/api/dev/state", async (IpGate g, PgPool db, HttpContext ctx) =>
        {
            await PollPortsAsync();
            RestoreState();
            NotePortOwners();
            // 묵었으면 뒤에서 한 바퀴 돌게만 해 둔다 — 기다리지 않는다(2초마다 불리는 자리다).
            DevDeploy.Touch();
            var (ok, why) = await CanControlAsync(g, db, ctx);
            return Results.Ok(StateJson(ok, why));
        });

        // 콘솔 한 벌 내려받기 — 개발자가 제 PC 에 깔아 [내 PC] 모드를 쓰기 위한 것.
        //
        // 미리 만들어 둔 zip 을 wwwroot 에 두지 않는 까닭 — 원본(tools/devserver)은 다른 쪽에서
        // 계속 손본다. 복사본을 두면 반드시 낡고, 낡아도 아무 오류가 나지 않는다.
        // 그래서 부를 때마다 그 폴더를 그대로 담는다.
        app.MapGet("/api/dev/console.zip", () =>
        {
            var bat = Path.Combine(_root, "dev-ui.bat");
            var dir = Path.Combine(_root, "tools", "devserver");
            if (!File.Exists(bat) || !Directory.Exists(dir))
                return Results.NotFound(new { error = $"콘솔 원본을 찾을 수 없습니다 ({dir})." });

            var ms = new MemoryStream();
            using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, leaveOpen: true))
            {
                // 어느 체크아웃에서 담았는지 밝힌다 — 대시보드 서버가 다른 PC 로 옮겨 가면
                // 여기가 그 PC 의 체크아웃이 되고, 갱신이 늦으면 낡은 콘솔이 조용히 나간다.
                var stamp = $"(이 zip 은 {Environment.MachineName} 의 {_root} 에서 "
                            + $"{DateTime.Now:yyyy-MM-dd HH:mm} 에 담았습니다.)";
                AddText(zip, "INSTALL.txt", InstallGuide + "\n\n" + stamp + "\n");
                AddFile(zip, bat, "dev-ui.bat");
                foreach (var f in Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories))
                {
                    var rel = Path.GetRelativePath(_root, f).Replace('\\', '/');
                    // 이 서버에서 돌린 로그다 — 받는 사람 것이 아니다
                    if (rel.Contains("/logs/", StringComparison.OrdinalIgnoreCase)) continue;
                    AddFile(zip, f, rel);
                }
            }
            ms.Position = 0;
            return Results.File(ms, "application/zip", "mm-dev-ui.zip");
        });

        // 로그 — since 이후의 줄만 준다. 화면이 주기적으로 불러 이어 붙인다.

        app.MapGet("/api/dev/log", (string id, string tier, long? since) =>
        {
            if (!Services.TryGetValue($"{id}:{tier}", out var s))
                return Results.NotFound(new { error = "없는 서비스입니다." });
            var (lines, last) = s.Since(since ?? 0);
            return Results.Ok(new { id, tier, dir = s.Dir, port = s.Port, last, lines });
        });

        // 로그인 사번 — 지금 값과 콤보박스 후보. 읽기라 누구나 볼 수 있지만, 쓰기는 기동·중지와
        // 같은 권한이라 canControl 을 함께 내려 화면이 미리 단추를 잠그게 한다.
        app.MapGet("/api/dev/userid", async (IpGate g, PgPool db, HttpContext ctx) =>
        {
            var (can, why) = await CanControlAsync(g, db, ctx);
            return Results.Ok(new
            {
                current = ReadUserId(),
                developers = await DevelopersAsync(db),
                host = Environment.MachineName,
                canControl = can,
                why,
            });
        });

        app.MapPost("/api/dev/{action}", async (IpGate g, PgPool db, HttpContext ctx, string action, JsonElement body) =>
        {
            var (allowed, why) = await CanControlAsync(g, db, ctx);
            // 403 으로 돌려주면 안 된다 — 화면의 api.js 가 403 을 <IP 권한이 사라졌다> 로 보고
            // 페이지를 통째로 새로 부른다. 여기서는 그냥 ok:false 로 사유만 알린다.
            if (!allowed) return Results.Ok(new { ok = false, message = why });

            // 로그인 사번 바꾸기 — 파일 한 줄을 쓴다. 자세한 것은 WriteUserId 머리말.
            if (action == "userid")
                return Results.Ok(WriteUserId(Str(body, "userId"), await DevelopersAsync(db)));

            if (action == "kill-port")
            {
                var port = body.TryGetProperty("port", out var pv) && pv.TryGetInt32(out var pn) ? pn : 0;
                await PollPortsAsync(true);
                if (PidOnPort(port) is not int pid)
                    return Results.Ok(new { ok = false, message = $"포트 {port} 는 비어 있습니다." });
                await KillTreeAsync(pid);
                await PollPortsAsync(true);
                return Results.Ok(new { ok = true, message = $"PID {pid} 종료" });
            }

            // 다시 훑기 — 프로젝트를 새로 받아 왔을 때. 대시보드를 재시작하지 않아도 되게 한다.
            if (action == "rescan")
            {
                // 돌고 있는 것을 잃지 않으려고 기록에서 되살린다 —
                // Discover() 가 Services 를 비우므로 <분리 기동> 표시가 함께 날아간다.
                Discover();
                // 폴더가 바뀌었으니 배포 쪽이 읽어 둔 것(git 경로·CI 포트)도 함께 버린다
                DevDeploy.Reset();
                _restored = false;
                await PollPortsAsync(true);
                RestoreState();
                NotePortOwners();
                return Results.Ok(new { ok = true, projects = Projects.Count, services = Services.Count });
            }

            // 기동할 수 없는 폴더(gradlew.bat·package.json 이 없는 쪽)에도 편집기·git pull 은 준다.
            // 서비스가 없으니 아래 targets 로는 못 찾는다 — 프로젝트에 적어 둔 폴더로 간다.
            if (action is "code" or "pull")
            {
                var sid = Str(body, "id");
                var str = Str(body, "tier");
                if (sid.Length > 0 && !Services.ContainsKey($"{sid}:{str}"))
                {
                    var pj = Projects.FirstOrDefault(x => x.Id == sid);
                    var pdir = str == "be" ? pj?.BeDir : pj?.FeDir;
                    if (pdir is null)
                        return Results.NotFound(new { error = "그 폴더를 모릅니다.", id = sid, tier = str });
                    return Results.Ok(action == "code"
                        ? await OpenCodeDirAsync(pdir)
                        : await PullDirAsync(pdir));
                }
            }

            // 프로젝트·작업공간 단위 git pull — 폴더가 아니라 그 아래 be/fe 저장소마다 돌린다.
            if (action == "pull-project")
            {
                var pid2 = Str(body, "id");
                var list = Services.Values.Where(x => x.Id == pid2)
                    .OrderBy(x => x.Tier).ToList();
                return Results.Ok(await PullManyAsync(list, pid2.ToUpperInvariant()));
            }

            if (action == "pull-group")
            {
                var gname2 = Str(body, "group");
                var ids = Projects.Where(x => x.Group == gname2).Select(x => x.Id).ToHashSet();
                var list = Services.Values.Where(x => ids.Contains(x.Id))
                    .OrderBy(x => x.Id).ThenBy(x => x.Tier).ToList();
                return Results.Ok(await PullManyAsync(list, gname2));
            }

            // 작업공간 폴더를 통째로 연다.
            //
            // ⚠️ 경로를 받지 않고 <이름> 을 받아 우리가 아는 목록에서 찾는다. 경로를 그대로
            //    받으면 서버의 아무 폴더나 편집기로 여는 통로가 된다.
            if (action == "code-group")
            {
                var gname = Str(body, "group");
                var one = Projects.FirstOrDefault(x => x.Group == gname && x.Dir.Length > 0);
                var gdir = one is null ? null : Path.GetDirectoryName(one.Dir);
                if (gdir is null)
                    return Results.NotFound(new { error = "없는 작업공간입니다.", group = gname });
                return Results.Ok(await OpenCodeDirAsync(gdir));
            }

            // 프로젝트 폴더(-be/-fe 를 담은 폴더)를 통째로 연다. 대상이 tier 가 아니라 id 하나다.
            if (action == "code-project")
            {
                var pid = Str(body, "id");
                var proj = Projects.FirstOrDefault(x => x.Id == pid);
                if (proj is null || proj.Dir.Length == 0)
                    return Results.NotFound(new { error = "없는 프로젝트입니다.", id = pid });
                return Results.Ok(await OpenCodeDirAsync(proj.Dir));
            }

            if (action == "clear-log")
            {
                var key = $"{Str(body, "id")}:{Str(body, "tier")}";
                if (!Services.TryGetValue(key, out var one))
                    return Results.NotFound(new { error = "없는 서비스입니다." });
                one.Clear();
                return Results.Ok(new { ok = true });
            }

            if (action is not ("start" or "stop" or "restart" or "pull" or "cmd" or "code"))
                return Results.NotFound(new { error = "모르는 동작입니다." });

            // 대상 모으기 — {id,tier} 하나 또는 {targets:[{id,tier},...]}
            var targets = new List<DevSvc>();
            if (body.TryGetProperty("targets", out var arr) && arr.ValueKind == JsonValueKind.Array)
            {
                foreach (var t in arr.EnumerateArray())
                    if (Services.TryGetValue($"{Str(t, "id")}:{Str(t, "tier")}", out var sv)) targets.Add(sv);
            }
            else if (Services.TryGetValue($"{Str(body, "id")}:{Str(body, "tier")}", out var sv)) targets.Add(sv);

            if (targets.Count == 0) return Results.BadRequest(new { error = "대상이 없습니다." });

            var results = new List<object>();
            foreach (var s in targets)
            {
                // be → fe 순서는 부르는 쪽이 정한다 (화면이 그렇게 보낸다)
                object r = action switch
                {
                    "start" => await StartAsync(s),
                    "stop" => await StopAsync(s),
                    "pull" => await PullAsync(s),
                    "cmd" => OpenCmd(s),
                    "code" => await OpenCodeAsync(s),
                    _ => await RestartAsync(s),
                };
                results.Add(new { id = s.Id, tier = s.Tier, result = r });
            }
            await PollPortsAsync(true);
            return Results.Ok(new { ok = true, results });
        });
    }

    private static void AddFile(ZipArchive zip, string path, string entryName)
    {
        var e = zip.CreateEntry(entryName, CompressionLevel.Optimal);
        using var dst = e.Open();
        using var src = File.OpenRead(path);
        src.CopyTo(dst);
    }

    private static void AddText(ZipArchive zip, string entryName, string text)
    {
        var e = zip.CreateEntry(entryName, CompressionLevel.Optimal);
        using var dst = e.Open();
        // 메모장이 한글을 깨뜨리지 않도록 BOM 을 붙인다. 받는 사람이 메모장으로 연다.
        // GetBytes 는 BOM 을 넣어 주지 않는다 — GetPreamble 을 따로 써야 한다.
        var enc = new UTF8Encoding(true);
        var head = enc.GetPreamble();
        var body = enc.GetBytes(text.ReplaceLineEndings("\r\n"));
        dst.Write(head, 0, head.Length);
        dst.Write(body, 0, body.Length);
    }

    private const string InstallGuide = """
        로컬 개발서버 콘솔 설치
        =======================

        1. 이 zip 을 소스를 받아 둔 폴더(PMM001, PMM002 … 가 들어 있는 폴더)에
           통째로 풉니다. 경로는 PC 마다 달라도 됩니다 — dev-ui.bat 이 자기 위치에서
           소스 루트를 찾습니다.

               <소스폴더>\dev-ui.bat
               <소스폴더>\tools\devserver\...

        2. dev-ui.bat 을 실행합니다. 브라우저가 http://127.0.0.1:4620 으로 열립니다.
           포트를 바꾸려면  dev-ui.bat 4700  처럼 뒤에 붙입니다.

        3. WBS 대시보드의 [로컬 개발서버] 화면에서 대상을 [내 PC] 로 두면
           이 콘솔이 그 화면 안에 실립니다. (포트를 바꿨으면 화면의 포트 칸도 같이 바꾸세요.)

        필요한 것
        ---------
        - node 18 이상 (PATH 에 있어야 합니다. 없으면 dev-ui.bat 이 그 자리에서 알려 줍니다)
          콘솔이 top-level await 와 TextDecoder('euc-kr') 를 씁니다 — 낡은 node 에서는 뜨지 않습니다.
        - 기동하려는 프로젝트에 맞는 JDK 21 / pnpm

        알아 둘 것
        ----------
        - 창을 닫으면 이 콘솔이 띄운 개발서버도 같이 내려갑니다(고아 프로세스 방지).
          남기려면  set KEEP_ON_EXIT=1  후 실행하세요.
        - 이 콘솔은 127.0.0.1 에만 붙습니다. 다른 PC 에서는 접속할 수 없습니다.
        - 자세한 내용은 tools\devserver\README.md 를 보세요.
        """;

    private static string Str(JsonElement e, string name) =>

        e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : "";
}

/// <summary>
/// 로그인 사번 콤보박스의 후보 한 사람 — 사번과 이름뿐이다.
/// 속성 이름을 소문자로 둔 것은 화면이 그대로 쓰기 때문이다(이 API 는 이름을 바꾸지 않는다).
/// </summary>
public sealed record DevPerson(string bpId, string name);

/// <summary>PMM 한 묶음 — be/fe 두 칸을 가진다.</summary>
public sealed class DevProject
{
    public string Id { get; set; } = "";
    public string Label { get; set; } = "";
    /// <summary>FE 의 VITE_APP_TITLE — 카드에 번호와 함께 보여 준다. 쓸 만한 값이 없으면 null.</summary>
    public string? Title { get; set; }
    /// <summary>-be/-fe 를 담고 있는 폴더 (…\PMM001). 편집기로 통째로 열 때 쓴다.</summary>
    public string Dir { get; set; } = "";
    /// <summary>작업공간 — -be/-fe 를 담은 폴더의 윗 폴더 (Design Management 등).</summary>
    public string Group { get; set; } = "";
    public string? BeDir { get; set; }
    public string? FeDir { get; set; }
    /// <summary>그 폴더를 기동할 수 있는가 (gradlew.bat / package.json 이 있는가).</summary>
    public bool BeRunnable { get; set; }
    public bool FeRunnable { get; set; }
    /// <summary>내용이 있는가 (빌드 파일이 있는가). 빈 클론을 목록에서 거르는 기준.</summary>
    public bool BeKnown { get; set; }
    public bool FeKnown { get; set; }
    /// <summary>못 돌리는 까닭 — 화면이 그대로 보여 준다.</summary>
    public string BeWhy { get; set; } = "";
    public string FeWhy { get; set; } = "";
    public int BePort { get; set; }
    public int FePort { get; set; }
}

/// <summary>서비스 한 칸(BE 또는 FE)의 상태와 로그.</summary>
public sealed class DevSvc
{
    public string Id { get; set; } = "";
    public string Tier { get; set; } = "";
    public string Dir { get; set; } = "";
    public int Port { get; set; }

    public Process? Child;
    /// <summary>우리가 띄운 프로세스의 진행 단계. 실제 응답 여부는 netstat 가 판정한다.</summary>
    public volatile string Phase = "idle";   // idle | compiling | starting | stopping | failed | exited
    public volatile string Message = "";
    public long StartedAt;
    public int? LastExit;
    public volatile bool StopRequested;
    public volatile bool Busy;
    /// <summary>git pull 이 도는 중. 같은 폴더에서 두 번 겹쳐 돌리지 않으려는 것이다.</summary>
    public volatile bool Pulling;

    // ---- 분리 기동(LaunchDetachedAsync) ----
    /// <summary>대시보드 트리 밖에서 도는 중. Child 는 없다.</summary>
    public volatile bool Detached;
    /// <summary>기동 스크립트를 물고 있는 cmd 의 PID — 중지할 때 이 트리를 잡는다.</summary>
    public int? RunPid;
    /// <summary>실제로 포트를 문 주인(java/node). 대시보드가 다시 떴을 때 <우리 것>인지 가리는 열쇠다.</summary>
    public int? PortPid;
    /// <summary>로그 파일에서 여기까지 읽었다.</summary>
    public long TailOffset;
    public CancellationTokenSource? TailCts;

    private readonly List<object[]> _lines = [];   // [n, t, kind, text]
    private readonly Lock _gate = new();
    private long _seq;
    private StreamWriter? _file;

    public int LineCount { get { lock (_gate) return _lines.Count; } }

    public void Push(string text, string kind = "out")
    {
        lock (_gate)
        {
            _seq += 1;
            _lines.Add([_seq, DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(), kind, text]);
            if (_lines.Count > 3000) _lines.RemoveRange(0, _lines.Count - 3000);
            try { _file?.WriteLine(text); } catch { /* 파일이 막혀도 화면 로그는 산다 */ }
        }
    }

    /// <summary>since 다음 줄부터 준다. 마지막 일련번호를 함께 돌려 화면이 이어 받게 한다.</summary>
    public (List<object[]> lines, long last) Since(long since)
    {
        lock (_gate)
        {
            var outp = new List<object[]>();
            foreach (var l in _lines)
                if ((long)l[0] > since) outp.Add(l);
            // 처음 열 때(since=0) 통째로 주면 3000줄이 한 번에 나간다. 뒤에서 600줄만.
            if (since == 0 && outp.Count > 600) outp.RemoveRange(0, outp.Count - 600);
            return (outp, _seq);
        }
    }

    public string Tail(int n)
    {
        lock (_gate)
        {
            var from = Math.Max(0, _lines.Count - n);
            return string.Join("\n", _lines.Skip(from).Select(l => (string)l[3]));
        }
    }

    public void Clear()
    {
        lock (_gate) _lines.Clear();
    }

    public string LogPath(string dir) => Path.Combine(dir, $"{Id}-{Tier}.log");

    /// <summary>분리 기동 직전에 놓아 준다 — 그때부터는 기동 스크립트가 이 파일에 덧붙인다.</summary>
    public void CloseLogFile()
    {
        lock (_gate)
        {
            try { _file?.Dispose(); } catch { /* 이미 닫혔으면 그만이다 */ }
            _file = null;
        }
    }

    /// <summary>기동할 때마다 덮어쓴다 — 직전 기동의 로그는 남기지 않는다.</summary>
    public void OpenLogFile(string dir)
    {
        lock (_gate)
        {
            try
            {
                _file?.Dispose();
                // FileShare.ReadWrite — 뒤따라 읽기(TailAsync)와 기동 스크립트가 같은 파일을 본다.
                var fs = new FileStream(LogPath(dir), FileMode.Create, FileAccess.Write,
                                        FileShare.ReadWrite | FileShare.Delete);
                _file = new StreamWriter(fs, new UTF8Encoding(false)) { AutoFlush = true };
            }
            catch { _file = null; }
        }
    }
}
