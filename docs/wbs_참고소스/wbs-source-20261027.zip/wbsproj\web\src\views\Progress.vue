<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { api } from '../api'
import { state, useViewRefresh, taskOf, loadTaskCounts } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'
import TaskDialog from '../components/TaskDialog.vue'
import PvDialog from '../components/PvDialog.vue'
import { buildPvScript, FULL_AT, FULL_RATE } from '../pvScript'

// 일감 다이얼로그 대상 행 (null 이면 닫힘)
const taskRow = ref(null)

// ---------- ProjectView 전송 스크립트 ----------
// 보낼 값: plan = 계획진척률 / done = 완료율(완료 100, 미완료 0)
// FULL_AT(90%) 이상은 FULL_RATE(100%)로 올려 보낸다 — 그 미만은 계산된 값 그대로.
const pvValue = ref('plan')
const pvScript = ref('')
const pvCount = ref(0)
const pvFull = ref(0)     // 100% 로 나가는 건수 (ProjectView 에서 완료로 읽힌다)
const pvSame = ref(0)     // 캐시와 값이 같아 제외한 건수
const pvDiffOnly = ref(true)

// ProjectView 캐시 — 있으면 workId 로 목록 조회를 건너뛰고, 값이 바뀐 건만 보낸다.
// 없어도 동작한다(예전과 같은 느린 경로).
const pvCache = ref({ ids: {}, cur: {}, projectId: '', at: null, n: 0 })

async function loadPvCache() {
  try {
    const rs = await api.pvCacheRows(state.scope)
    const ids = {}
    const cur = {}
    let projectId = ''
    let at = null
    for (const r of rs) {
      if (r.pv_work_id) ids[r.activity_id] = r.pv_work_id
      if (r.pv_finish_rate !== null && r.pv_finish_rate !== undefined) {
        cur[r.activity_id] = Number(r.pv_finish_rate)
      }
      if (!projectId && r.pv_project_id) projectId = r.pv_project_id
      if (r.pv_snapshot_at && (!at || r.pv_snapshot_at > at)) at = r.pv_snapshot_at
    }
    pvCache.value = { ids, cur, projectId, at, n: Object.keys(ids).length }
  } catch {
    // 캐시는 없어도 되는 것이라 조용히 넘어간다
  }
}

/** ProjectView 로 보낼 값. 90% 올림은 스크립트 쪽에서 한 번 더 적용한다. */
const pvRate = (r) =>
  pvValue.value === 'done' ? (r.complate_yn === 'o' ? 100 : 0) : r.plan_rate

function openPvScript() {
  const all = viewRows.value
    .map((r) => ({ activity_id: r.activity_id, rate: pvRate(r) }))
    .filter((i) => i.activity_id && i.rate != null)

  // 캐시가 아는 ProjectView 현재값과 같은 건은 보낼 이유가 없다.
  // 90% 이상은 100 으로 올라가 나가므로 비교도 올린 값으로 한다.
  const cur = pvCache.value.cur
  const toSend = (v) => (Number(v) >= FULL_AT ? FULL_RATE : Number(v))
  const changed = all.filter((i) => !(i.activity_id in cur) || cur[i.activity_id] !== toSend(i.rate))

  const items = pvDiffOnly.value ? changed : all
  pvSame.value = all.length - changed.length
  pvCount.value = items.length
  pvFull.value = items.filter((i) => Number(i.rate) >= FULL_AT).length

  const label = pvValue.value === 'done' ? '완료율(0/100)' : '계획진척률'
  pvScript.value = buildPvScript(items, label, new Date().toLocaleString('ko-KR'), {
    ids: pvCache.value.ids,
    projectId: pvCache.value.projectId,
  })
}

// 계획진척률: 계획시작일 도래 전 0%, 종료일 경과 100%,
// 그 사이는 (오늘-시작일)/(종료일-시작일). 실적완료율(complate_yn)과 나란히 비교한다.
const sum = ref({})
const byPlan = ref([])
const byReal = ref([])
const byModule = ref([])
const rows = ref([])
const loading = ref(false)

const selUser = ref('')
const selReal = ref('')
const selModule = ref('')

async function loadAll() {
  loading.value = true
  try {
    const [s, p, r, m] = await Promise.all([
      api.progressSummary(state.scope),
      api.progressByUser(state.scope, 'plan'),
      api.progressByUser(state.scope, 'real'),
      api.progressByModule(state.scope),
      loadTaskCounts(),
      loadPvCache(),
    ])
    sum.value = s
    byPlan.value = p
    byReal.value = r
    byModule.value = m
    await loadRows()
  } catch (e) {
    state.error = e.message
  } finally {
    loading.value = false
  }
}

async function loadRows() {
  try {
    rows.value = await api.progressRows(state.scope, selUser.value, selReal.value, selModule.value)
  } catch (e) {
    state.error = e.message
  }
}

function pickUser(u) {
  selUser.value = selUser.value === u ? '' : u
  selReal.value = ''
  selModule.value = ''
}
function pickReal(u) {
  selReal.value = selReal.value === u ? '' : u
  selUser.value = ''
  selModule.value = ''
}
function pickModule(m) {
  selModule.value = selModule.value === m ? '' : m
  selUser.value = ''
  selReal.value = ''
}
function clearSel() {
  selUser.value = ''
  selReal.value = ''
  selModule.value = ''
}
const hasSel = computed(() => !!selUser.value || !!selReal.value || !!selModule.value)

// 계획 대비 실적 격차 (계획진척률 - 실적완료율). 클수록 계획보다 뒤처진 상태
const gap = (r) => (r.plan_rate == null ? null : Math.round((r.plan_rate - (r.done_rate ?? 0)) * 10) / 10)
const rate = (v) => (v == null ? '-' : v + '%')

// ---------- 항목별 목록: 상태 필터 + 컬럼 정렬/필터 ----------
// status: all | open(계획시작일 도래 & 미완료) | notyet(미도래) | done(완료)
const status = ref('open')

const COLS = [
  { key: 'activity_id', label: 'Activity ID', ft: 'text', w: 96 },
  { key: 'systemcode', label: '모듈', ft: 'text', w: 80 },
  { key: 'menu_nm', label: '메뉴명', ft: 'text', w: 220 },
  { key: 'plan_sdt', label: '시작일', ft: 'text', w: 86 },
  { key: 'plan_edt', label: '종료일', ft: 'text', w: 86 },
  { key: 'span_days', label: '기간', ft: 'num', w: 60 },
  { key: 'passed_days', label: '경과', ft: 'num', w: 60 },
  { key: 'plan_rate', label: '계획진척률', ft: 'num', w: 150 },
  { key: 'complate_yn', label: '완료', ft: 'check', w: 56 },
  { key: 'user_nm', label: '담당자', ft: 'pick', w: 100 },
  { key: 'user_real_nm', label: '개발자', ft: 'pick', w: 100 },
  { key: 'complate_real_yn', label: '개발자완료', ft: 'check', w: 70 },
  { key: 'task_cnt', label: '일감', ft: 'task', w: 66 },
]
const colF = ref({})
const sortState = ref({ col: '', dir: 'asc' })

function toggleSort(col) {
  if (sortState.value.col !== col) sortState.value = { col, dir: 'asc' }
  else if (sortState.value.dir === 'asc') sortState.value = { col, dir: 'desc' }
  else sortState.value = { col: '', dir: 'asc' }
}
const colFilterCount = computed(() => Object.values(colF.value).filter((v) => v !== '' && v != null).length)
function clearColF() {
  colF.value = {}
}

// 담당자 / 개발자 선택 목록 (조회 결과 기준). dev_user 에 없는 값은 '(미할당)' 으로 묶는다.
function buildOpts(key) {
  const m = new Map()
  for (const r of rows.value) {
    const k = r[key] || '(미할당)'
    m.set(k, (m.get(k) ?? 0) + 1)
  }
  return [...m].map(([label, cnt]) => ({ label, cnt })).sort((a, b) => a.label.localeCompare(b.label, 'ko'))
}
const pickOpts = computed(() => ({
  user_nm: buildOpts('user_nm'),
  user_real_nm: buildOpts('user_real_nm'),
}))

// 숫자 필터: '>50' '<=10' '=0' '50'(=이상) 형태 지원
function numMatch(v, expr) {
  if (v == null) return false
  const m = String(expr).trim().match(/^(>=|<=|>|<|=)?\s*(-?\d+(\.\d+)?)$/)
  if (!m) return true
  const [, op = '>=', num] = m
  const n = Number(num)
  switch (op) {
    case '>': return v > n
    case '<': return v < n
    case '<=': return v <= n
    case '=': return v === n
    default: return v >= n
  }
}

const cellText = (r, col) =>
  col === 'user_nm' || col === 'user_real_nm' ? (r[col] || '(미할당)')
  : col === 'complate_yn' || col === 'complate_real_yn' ? (r[col] === 'o' ? 'y' : 'n')
  : col === 'task_cnt'
    ? (() => {
        const t = taskOf(r)
        return t.cnt === 0 ? 'none' : t.done < t.cnt ? 'open' : 'done'
      })()
  : String(r[col] ?? '')

const statusRows = computed(() =>
  rows.value.filter((r) => {
    const done = r.complate_yn === 'o'
    const started = (r.plan_rate ?? 0) > 0
    switch (status.value) {
      case 'open': return started && !done
      case 'notyet': return !started
      case 'done': return done
      default: return true
    }
  })
)

const viewRows = computed(() => {
  const active = Object.entries(colF.value).filter(([, v]) => v !== '' && v != null)
  let list = statusRows.value.filter((r) =>
    active.every(([col, v]) => {
      const c = COLS.find((x) => x.key === col)
      if (c?.ft === 'num') return numMatch(r[col], v)
      if (c?.ft === 'check' || c?.ft === 'pick' || c?.ft === 'task') return cellText(r, col) === v
      return cellText(r, col).toLowerCase().includes(String(v).toLowerCase())
    })
  )
  const { col, dir } = sortState.value
  if (col) {
    const c = COLS.find((x) => x.key === col)
    const sign = dir === 'asc' ? 1 : -1
    list = [...list].sort((a, b) => {
      if (c?.ft === 'num') return sign * ((a[col] ?? -1) - (b[col] ?? -1))
      if (c?.ft === 'task') return sign * (taskOf(a).cnt - taskOf(b).cnt)
      const x = cellText(a, col)
      const y = cellText(b, col)
      if (x === y) return 0
      if (x === '') return 1
      if (y === '') return -1
      return sign * x.localeCompare(y, 'ko', { numeric: true })
    })
  }
  return list
})

watch([selUser, selReal, selModule], loadRows)
watch(() => state.scope, loadAll)
useViewRefresh(loadAll)
onMounted(loadAll)
</script>

<template>
  <div class="cards">
    <div class="card">
      <div class="k">전체 계획진척률</div>
      <div class="v">{{ rate(sum.plan_rate) }}</div>
      <div class="gauge"><div class="bar plan" :style="{ width: (sum.plan_rate ?? 0) + '%' }"></div></div>
    </div>
    <div class="card">
      <div class="k">실적완료율</div>
      <div class="v done">{{ rate(sum.done_rate) }} <small>{{ sum.done_cnt ?? '-' }}건</small></div>
      <div class="gauge"><div class="bar done" :style="{ width: (sum.done_rate ?? 0) + '%' }"></div></div>
    </div>
    <div class="card">
      <div class="k">대형완료율</div>
      <div class="v big">{{ rate(sum.done_big_rate) }} <small>{{ sum.done_big_cnt ?? '-' }}건</small></div>
      <div class="gauge"><div class="bar big" :style="{ width: (sum.done_big_rate ?? 0) + '%' }"></div></div>
    </div>
    <div class="card"><div class="k">착수 전 (0%)</div><div class="v">{{ sum.not_started ?? '-' }}</div></div>
    <div class="card"><div class="k">진행 중</div><div class="v">{{ sum.in_progress ?? '-' }}</div></div>
    <div class="card"><div class="k">기간 경과 (100%)</div><div class="v">{{ sum.elapsed ?? '-' }}</div></div>
    <div class="card"><div class="k">기준일 (오늘)</div><div class="v" style="font-size: 14px">{{ sum.asof ?? '-' }}</div></div>
  </div>

  <div class="grid2" style="margin-top: 14px">
    <section class="panel">
      <h2>
        담당자별 계획진척률 <span class="hint">행 클릭 시 아래 목록 필터</span>
        <span class="spacer"></span><RefreshBtn :fn="loadAll" />
      </h2>
      <div class="scroll">
        <table>
          <thead>
            <tr>
              <th>담당자</th><th class="num">건수</th>
              <th style="width: 30%">계획진척률</th><th class="num">실적완료</th><th class="num">대형완료</th><th class="num">격차</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="u in byPlan" :key="u.user_bp_id" class="clk" :class="{ on: selUser === u.user_bp_id }" @click="pickUser(u.user_bp_id)">
              <td class="nowrap">
                <span class="nm">{{ u.user_nm }}</span>
                <span v-if="u.user_nm !== u.user_bp_id" class="uid">{{ u.user_bp_id }}</span>
              </td>
              <td class="num muted">{{ u.cnt }}</td>
              <td>
                <div class="row2">
                  <div class="gauge"><div class="bar plan" :style="{ width: (u.plan_rate ?? 0) + '%' }"></div></div>
                  <span class="pct">{{ rate(u.plan_rate) }}</span>
                </div>
              </td>
              <td class="num">{{ rate(u.done_rate) }}</td>
              <td class="num big">{{ rate(u.done_big_rate) }}</td>
              <td class="num" :class="{ warn: gap(u) >= 50, bad: gap(u) >= 80 }">{{ gap(u) == null ? '-' : gap(u) + 'p' }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <section class="panel real">
      <h2>
        개발자별 계획진척률 <span class="hint">user_real_id 기준</span>
        <span class="spacer"></span><RefreshBtn :fn="loadAll" />
      </h2>
      <div class="scroll">
        <table>
          <thead>
            <tr>
              <th>개발자</th><th class="num">건수</th>
              <th style="width: 30%">계획진척률</th><th class="num">실적완료</th><th class="num">대형완료</th><th class="num">격차</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="u in byReal" :key="u.user_bp_id" class="clk" :class="{ on: selReal === u.user_bp_id }" @click="pickReal(u.user_bp_id)">
              <td class="nowrap">
                <span class="nm">{{ u.user_nm }}</span>
                <span v-if="u.user_nm !== u.user_bp_id" class="uid">{{ u.user_bp_id }}</span>
              </td>
              <td class="num muted">{{ u.cnt }}</td>
              <td>
                <div class="row2">
                  <div class="gauge"><div class="bar plan" :style="{ width: (u.plan_rate ?? 0) + '%' }"></div></div>
                  <span class="pct">{{ rate(u.plan_rate) }}</span>
                </div>
              </td>
              <td class="num">{{ rate(u.done_rate) }}</td>
              <td class="num big">{{ rate(u.done_big_rate) }}</td>
              <td class="num" :class="{ warn: gap(u) >= 50, bad: gap(u) >= 80 }">{{ gap(u) == null ? '-' : gap(u) + 'p' }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </div>

  <section class="panel">
    <h2>
      모듈별 계획진척률
      <span class="spacer"></span><RefreshBtn :fn="loadAll" />
    </h2>
    <div class="scroll">
      <table>
        <thead>
          <tr>
            <th>모듈</th><th>이름</th><th class="num">건수</th>
            <th style="width: 34%">계획진척률</th><th class="num">실적완료</th><th class="num">대형완료</th><th>기간</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="m in byModule" :key="m.systemcode" class="clk" :class="{ on: selModule === m.systemcode }" @click="pickModule(m.systemcode)">
            <td class="nowrap"><strong>{{ m.systemcode }}</strong></td>
            <td class="nowrap">{{ m.system_nm }}</td>
            <td class="num muted">{{ m.cnt }}</td>
            <td>
              <div class="row2">
                <div class="gauge"><div class="bar plan" :style="{ width: (m.plan_rate ?? 0) + '%' }"></div></div>
                <span class="pct">{{ rate(m.plan_rate) }}</span>
              </div>
            </td>
            <td class="num">{{ rate(m.done_rate) }}</td>
            <td class="num big">{{ rate(m.done_big_rate) }}</td>
            <td class="nowrap muted">{{ m.min_dt }} ~ {{ m.max_dt }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section class="panel">
    <h2>
      항목별 계획진척률
      <span class="hint">
        {{ viewRows.length }}건<template v-if="viewRows.length !== rows.length"> / 전체 {{ rows.length }}</template>
        {{ loading ? ' · 조회 중…' : '' }}
      </span>
      <span class="spacer"></span>
      <select v-model="status" title="진행 상태 필터">
        <option value="open">착수(도래) &amp; 미완료</option>
        <option value="notyet">미도래 (0%)</option>
        <option value="done">완료</option>
        <option value="all">전체</option>
      </select>
      <button v-if="colFilterCount" @click="clearColF">컬럼필터 해제 ({{ colFilterCount }})</button>
      <button v-if="hasSel" @click="clearSel">필터 해제</button>
      <RefreshBtn :fn="loadRows" />

      <!-- ProjectView 전송: 현재 목록에 보이는 행만 스크립트로 만든다 -->
      <span class="sep"></span>
      <select v-model="pvValue" title="ProjectView 로 보낼 값">
        <option value="plan">계획진척률</option>
        <option value="done">완료율(0/100)</option>
      </select>
      <label class="chk" title="ProjectView 캐시가 아는 현재값과 다른 건만 보냅니다">
        <input v-model="pvDiffOnly" type="checkbox" :disabled="!pvCache.n" />
        바뀐 것만
      </label>
      <button class="pv" @click="openPvScript">ProjectView 전송 스크립트</button>
    </h2>

    <p class="pvnote" :class="pvCache.n ? '' : 'off'">
      <template v-if="pvCache.n">
        ProjectView 캐시 {{ pvCache.n }}건 사용 — 목록 조회를 건너뛰고
        <strong>바뀐 건만</strong> 보냅니다.
        <span class="muted">마지막 수집 {{ (pvCache.at || '').slice(0, 16) || '—' }}</span>
      </template>
      <template v-else>
        ProjectView 캐시가 비어 있어 예전 방식(목록 전체 조회 + 전 건 전송)으로 나갑니다.
        <strong>[상세 목록]</strong> 의 <strong>⛁</strong> 로 한 번 수집해 두면 훨씬 빨라집니다.
      </template>
    </p>

    <p v-if="hasSel" class="muted" style="margin: -4px 0 8px">
      필터:
      <template v-if="selUser">담당자 {{ byPlan.find((u) => u.user_bp_id === selUser)?.user_nm }}</template>
      <template v-if="selReal">개발자 {{ byReal.find((u) => u.user_bp_id === selReal)?.user_nm }}</template>
      <template v-if="selModule">모듈 {{ selModule }}</template>
    </p>

    <div class="scroll tall">
      <table>
        <thead>
          <tr>
            <th
              v-for="c in COLS" :key="c.key"
              class="sortable" :class="{ on: sortState.col === c.key, num: c.ft === 'num' }"
              :style="{ minWidth: c.w + 'px' }"
              :title="`${c.label} 정렬 (클릭: 오름 → 내림 → 해제)`"
              @click="toggleSort(c.key)"
            >
              {{ c.label }}
              <span class="arw">{{ sortState.col === c.key ? (sortState.dir === 'asc' ? '▲' : '▼') : '⇅' }}</span>
            </th>
          </tr>
          <tr class="fltr">
            <th v-for="c in COLS" :key="c.key">
              <select
                v-if="c.ft === 'check'"
                v-model="colF[c.key]"
                :class="{ on: colF[c.key] }"
                :title="`${c.label} 필터`"
              >
                <option value="">전체</option>
                <option value="y">✓ 완료</option>
                <option value="n">미완료</option>
              </select>
              <select
                v-else-if="c.ft === 'pick'"
                v-model="colF[c.key]"
                :class="{ on: colF[c.key] }"
                :title="`${c.label} 필터`"
              >
                <option value="">전체</option>
                <option v-for="o in pickOpts[c.key]" :key="o.label" :value="o.label">
                  {{ o.label }} · {{ o.cnt }}
                </option>
              </select>
              <select v-else-if="c.ft === 'task'" v-model="colF[c.key]" :class="{ on: colF[c.key] }" title="일감 필터">
                <option value="">전체</option>
                <option value="open">미완료 있음</option>
                <option value="done">전부 완료</option>
                <option value="none">일감 없음</option>
              </select>
              <input
                v-else
                v-model="colF[c.key]"
                type="text"
                :class="{ on: colF[c.key] }"
                :placeholder="c.ft === 'num' ? '>50' : c.label"
                :title="c.ft === 'num' ? `${c.label} 숫자 조건 — 예: >50, <=10, =0, 50(이상)` : `${c.label} 검색 (부분일치)`"
              />
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in viewRows" :key="r.activity_id + r.menu_nm">
            <td>{{ r.activity_id || '—' }}</td>
            <td class="nowrap">{{ r.systemcode }}</td>
            <td>{{ r.menu_nm }}</td>
            <td class="nowrap">{{ r.plan_sdt || '—' }}</td>
            <td class="nowrap">{{ r.plan_edt || '—' }}</td>
            <td class="num muted">{{ r.span_days ?? '' }}일</td>
            <td class="num muted">{{ r.passed_days ?? '' }}일</td>
            <td>
              <div class="row2">
                <div class="gauge">
                  <div
                    class="bar"
                    :class="r.plan_rate === 100 ? 'full' : 'plan'"
                    :style="{ width: (r.plan_rate ?? 0) + '%' }"
                  ></div>
                </div>
                <span class="pct">{{ rate(r.plan_rate) }}</span>
              </div>
            </td>
            <td class="ctr"><span v-if="r.complate_yn === 'o'" class="chk">✓</span><span v-else class="muted">·</span></td>
            <td class="nowrap">
              <template v-if="r.user_nm"><span class="nm">{{ r.user_nm }}</span></template>
              <span v-else class="muted">—</span>
            </td>
            <!-- 개발자 (user_real_id) — dev_user 에 없는 값은 미할당으로 보고 비워 둔다 -->
            <td
              class="nowrap"
              :class="{ unset: !r.user_real_nm }"
              :title="!r.user_real_nm && r.user_real_id ? `미할당 (저장된 값: ${r.user_real_id})` : ''"
            >
              <template v-if="r.user_real_nm"><span class="nm">{{ r.user_real_nm }}</span></template>
              <span v-else class="blank"></span>
            </td>
            <!-- 개발자완료 (complate_real_yn) -->
            <td class="ctr">
              <span v-if="r.complate_real_yn === 'o'" class="chk">✓</span>
              <span v-else class="muted">·</span>
            </td>
            <!-- 일감 건수 — 클릭하면 일감 관리 다이얼로그 (상세 목록 화면과 동일) -->
            <td class="ctr">
              <button
                class="tbadge"
                :class="{ open: taskOf(r).done < taskOf(r).cnt, alldone: taskOf(r).cnt && taskOf(r).done === taskOf(r).cnt }"
                :title="taskOf(r).cnt ? `일감 ${taskOf(r).done}/${taskOf(r).cnt} 완료 — 클릭하면 관리` : '일감 없음 — 클릭하면 추가'"
                :disabled="!r.activity_id"
                @click="taskRow = r"
              >
                <template v-if="taskOf(r).cnt">{{ taskOf(r).done }}/{{ taskOf(r).cnt }}</template>
                <template v-else>+</template>
              </button>
            </td>
          </tr>
          <tr v-if="!viewRows.length && !loading">
            <td :colspan="COLS.length" class="muted ctr" style="padding: 20px">해당 조건의 항목이 없습니다</td>
          </tr>
        </tbody>
      </table>
    </div>

    <p class="muted note">
      계획진척률 = 계획시작일 도래 전 <strong>0%</strong> · 계획종료일 경과 <strong>100%</strong> ·
      그 사이는 <code>경과 ÷ 기간</code> = <code>(오늘 − 시작일) ÷ (종료일 − 시작일)</code>.
      기준일 <strong>{{ sum.asof }}</strong> · 시작일=종료일인 1일 작업은 도래 시 100%.
      집계값은 항목별 진척률의 <strong>단순 평균</strong>이며, 격차(p)는 계획진척률 − 실적완료율입니다.
      컬럼 머리글은 클릭 정렬, 아래 칸은 검색 필터입니다 (숫자 컬럼은 <code>&gt;50</code>, <code>&lt;=10</code> 형태 사용 가능).
      <strong>일감</strong> 칸을 클릭하면 해당 화면의 일감을 등록·수정·완료·삭제할 수 있습니다.
    </p>
    <p class="muted note">
      <strong>ProjectView 전송</strong> — 위 버튼은 <em>현재 목록에 보이는 {{ viewRows.length }}건</em>만 담은
      콘솔 스크립트를 복사합니다. ProjectView 로그인 탭의 F12 → Console 에 붙여넣어 실행하면 먼저
      <code>DRY RUN</code> 으로 대상과 값만 출력하고, 이어서 콘솔에 <code>pvSend()</code> 를 입력할 때
      실제 전송(<code>finishRate</code>·<code>actualProgressRate</code>)됩니다.
      ProjectView 기준으로 이 값은 <strong>실적</strong> 진척률이라는 점을 확인하고 사용하세요.
      <strong>{{ FULL_AT }}% 이상</strong>은 <strong>{{ FULL_RATE }}%</strong> 로 올려 보냅니다
      (그 미만은 계산된 값 그대로). 100% 로 올라간 건은 ProjectView 에서 완료로 읽히니
      대상 목록을 확인하고 보내세요.
    </p>
  </section>

  <TaskDialog v-if="taskRow" :row="taskRow" @close="taskRow = null" @changed="loadTaskCounts" />

  <!-- ProjectView 전송 스크립트 창 -->
  <PvDialog
    v-if="pvScript"
    :script="pvScript"
    :meta="pvCount + '건 · ' + (pvValue === 'done' ? '완료율(0/100)' : '계획진척률') + ' · ' + FULL_AT + '% 이상은 ' + FULL_RATE + '%' + (pvFull ? ' (' + FULL_RATE + '% 전송 ' + pvFull + '건)' : '') + (pvDiffOnly && pvSame ? ' · 값이 같아 제외 ' + pvSame + '건' : '')"
    :sends="'바뀌는 값: finishRate · actualProgressRate (ProjectView 기준 실적 진척률) · ' + FULL_AT + '% 이상은 ' + FULL_RATE + '% 로 보냅니다'"
    @close="pvScript = ''"
  />
</template>

<style scoped>
h2 .spacer { flex: 1; }
.panel.real { border-left: 3px solid var(--done); }
.nowrap { white-space: nowrap; }
/* 대형은 별도 트랙 — 회색톤으로 구분한다 */
.big, td.big { color: var(--muted); }
.gauge .bar.big { background: var(--muted); }
.ctr { text-align: center; }
.nm { font-weight: 600; }
.uid { color: var(--muted); font-size: 11px; margin-left: 5px; font-variant-numeric: tabular-nums; }
.scroll.tall { max-height: calc(100vh - 300px); overflow: auto; }
/* 1행 = 컬럼명(정렬), 2행 = 컬럼 검색 필터. 둘 다 고정 */
.scroll.tall thead tr:first-child th { position: sticky; top: 0; z-index: 3; background: var(--panel); }
.scroll.tall thead tr.fltr th {
  position: sticky;
  top: 28px;
  z-index: 2;
  background: var(--panel);
  padding: 3px 5px;
  box-shadow: inset 0 -1px 0 var(--line);
}
thead tr.fltr input, thead tr.fltr select {
  width: 100%;
  padding: 2px 5px;
  font-size: 11.5px;
  font-weight: 400;
  border: 1px solid var(--line);
  border-radius: 4px;
  background: var(--panel);
}
thead tr.fltr input.on, thead tr.fltr select.on {
  border-color: var(--accent);
  background: var(--accent-soft);
  color: var(--accent);
}
th.sortable { cursor: pointer; user-select: none; white-space: nowrap; }
th.sortable:hover { color: var(--accent); }
th.sortable.on { color: var(--accent); }
th .arw { font-size: 9px; margin-left: 3px; opacity: 0.4; }
th.sortable.on .arw { opacity: 1; }

.row2 { display: flex; align-items: center; gap: 7px; }
.row2 .gauge { flex: 1; }
.gauge { height: 8px; background: var(--fill); border-radius: 4px; overflow: hidden; }
.gauge .bar { height: 100%; border-radius: 4px; transition: width 0.2s; }
.bar.plan { background: var(--accent); }
.bar.full { background: var(--warn); }
.bar.done { background: var(--done); }
.pct { font-size: 11px; font-variant-numeric: tabular-nums; min-width: 42px; text-align: right; }
.card .gauge { margin-top: 6px; height: 4px; }
.card .v.done { color: var(--done); }
.card .v small { font-size: 11.5px; font-weight: 400; color: var(--muted); }

tr.clk { cursor: pointer; }
tr.clk:hover { background: var(--surface); }
tr.clk.on { background: var(--accent-soft); }
td.warn { color: var(--warn); font-weight: 600; }
td.bad { color: var(--danger); font-weight: 700; }
.chk { color: var(--done); font-weight: 700; }
/* 개발자 미할당 — 상세 목록 화면과 같은 옅은 빗금 표시 */
td.unset {
  background: repeating-linear-gradient(-45deg, transparent, transparent 5px, var(--surface) 5px, var(--surface) 10px);
}
.blank { display: inline-block; min-width: 60px; }

/* 일감 건수 배지 (상세 목록 화면과 동일 규칙) */
.tbadge {
  min-width: 46px;
  padding: 1px 7px;
  border-radius: 10px;
  border: 1px solid var(--line);
  background: var(--panel);
  color: var(--muted-3);
  font-size: 11px;
  font-variant-numeric: tabular-nums;
  cursor: pointer;
}
.tbadge:hover { border-color: var(--accent); color: var(--accent); }
.tbadge.open { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); font-weight: 600; }
.tbadge.alldone { background: var(--done-soft); border-color: var(--done); color: var(--done); font-weight: 600; }
.tbadge:disabled { opacity: 0.35; cursor: not-allowed; }

.note { margin: 8px 0 0; }
h2 .sep { width: 1px; height: 16px; background: var(--line); margin: 0 3px; }
button.pv { border-color: var(--accent); color: var(--accent); }
/* 전송 스크립트 옆 안내 — 캐시가 있으면 파랑, 없으면 회색 */
.chk { font-size: 11.5px; font-weight: 400; display: flex; align-items: center; gap: 4px; }
.pvnote {
  margin: -4px 0 8px;
  font-size: 11.5px;
  color: var(--accent);
  background: var(--accent-soft);
  border: 1px solid var(--accent);
  border-radius: 6px;
  padding: 5px 9px;
}
.pvnote.off { color: var(--muted); background: var(--surface); border-color: var(--line); }
.pvnote .muted { margin-left: 6px; }
button.pv:hover { background: var(--accent-soft); }
</style>
