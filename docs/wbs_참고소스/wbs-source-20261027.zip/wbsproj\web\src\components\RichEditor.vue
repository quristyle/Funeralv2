<script setup>
import { nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import { api } from '../api'

// 외부 에디터 라이브러리 없이 contenteditable + 기본 서식 명령만 쓰는 최소 편집기.
// 저장 형식은 HTML 문자열이다.
//  - URL 을 입력/붙여넣으면 새 탭으로 열리는 링크로 자동 변환
//  - HTML 원본 편집 모드 전환 지원
const props = defineProps({
  modelValue: { type: String, default: '' },
  readonly: { type: Boolean, default: false },
  // 다이얼로그 등 좁은 곳에서 쓸 때 — 높이·안내문을 줄인다
  compact: { type: Boolean, default: false },
  placeholder: { type: String, default: '' },
})
const emit = defineEmits(['update:modelValue', 'submit'])

const el = ref(null)
const mode = ref('rich') // rich | html
const html = ref('')     // HTML 모드용 원본

// 링크로 인식할 패턴 (캐럿 앞 문자열의 끝에서 찾는다)
const URL_END = /(?:https?:\/\/|www\.)[^\s<>"']+$/i
const URL_ALL = /(?:https?:\/\/|www\.)[^\s<>"']+/gi
const href = (u) => (/^www\./i.test(u) ? 'https://' + u : u)

/** 모든 a 태그가 새 탭으로 열리도록 보정 (붙여넣기·툴바 링크 포함) */
function normalizeLinks() {
  el.value?.querySelectorAll('a[href]').forEach((a) => {
    a.target = '_blank'
    a.rel = 'noopener'
  })
}

function sync() {
  if (mode.value !== 'rich') return
  normalizeLinks()
  emit('update:modelValue', el.value?.innerHTML ?? '')
}

function cmd(name, arg) {
  el.value?.focus()
  document.execCommand(name, false, arg)
  sync()
}

/** 캐럿 바로 앞의 URL 문자열을 <a> 로 바꾼다 (공백·Enter 입력 시 호출) */
function linkifyAtCaret() {
  const sel = window.getSelection()
  if (!sel || !sel.rangeCount) return false
  const range = sel.getRangeAt(0)
  const node = range.startContainer
  if (node.nodeType !== 3) return false               // 텍스트 노드만
  if (node.parentElement?.closest('a')) return false  // 이미 링크 안

  const m = node.textContent.slice(0, range.startOffset).match(URL_END)
  if (!m) return false

  const r = document.createRange()
  r.setStart(node, range.startOffset - m[0].length)
  r.setEnd(node, range.startOffset)

  const a = document.createElement('a')
  a.href = href(m[0])
  a.target = '_blank'
  a.rel = 'noopener'
  a.textContent = m[0]

  r.deleteContents()
  r.insertNode(a)

  // 캐럿을 링크 바깥(뒤)으로 옮겨 이어지는 입력이 링크에 붙지 않게 한다
  const tail = document.createTextNode('')
  a.after(tail)
  const nr = document.createRange()
  nr.setStart(tail, 0)
  nr.collapse(true)
  sel.removeAllRanges()
  sel.addRange(nr)
  return true
}

function onKeydown(e) {
  // Ctrl+Enter 는 바깥(추가·저장)에 넘긴다 — Enter 는 줄바꿈으로 쓰기 때문
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
    e.preventDefault()
    emit('submit')
    return
  }
  // 표 안에서는 Tab 으로 다음 칸 — 표를 쓸 때 제일 아쉬운 동작이다.
  if (e.key === 'Tab') {
    const cell = cellAt()
    if (cell) {
      e.preventDefault()
      const cells = [...el.value.querySelectorAll('td, th')]
      const i = cells.indexOf(cell)
      placeCaret(e.shiftKey ? cells[i - 1] : cells[i + 1])
      return
    }
  }
  if (e.key === ' ' || e.key === 'Enter') linkifyAtCaret()
}

const upErr = ref('')

/** 캐럿 위치에 노드를 삽입하고 뒤로 커서를 옮긴다 */
function insertNode(node) {
  const sel = window.getSelection()
  if (sel?.rangeCount) {
    const r = sel.getRangeAt(0)
    r.deleteContents()
    r.insertNode(node)
    r.setStartAfter(node)
    r.collapse(true)
    sel.removeAllRanges()
    sel.addRange(r)
  } else {
    el.value?.append(node)
  }
}

/** 클립보드 이미지를 서버에 저장하고 <img src> 로 삽입한다 */
async function pasteImage(file) {
  upErr.value = ''
  // 업로드 되는 동안 자리표시자를 넣어 두고, 끝나면 실제 이미지로 교체
  const ph = document.createElement('span')
  ph.className = 'uploading'
  ph.textContent = '이미지 올리는 중…'
  insertNode(ph)
  try {
    const { url } = await api.uploadImage(file)
    const img = document.createElement('img')
    img.src = url
    img.alt = ''
    ph.replaceWith(img)
    // 이미지 뒤에 커서를 둘 자리
    const tail = document.createTextNode('')
    img.after(tail)
    sync()
  } catch (e) {
    ph.remove()
    upErr.value = `이미지 업로드 실패: ${e.message}`
    sync()
  }
}

/** 붙여넣기: 이미지면 업로드, 그 외는 평문(URL 은 링크)으로 */
function onPaste(e) {
  // 클립보드에 이미지가 있으면 그것을 우선 처리한다
  const items = [...(e.clipboardData?.items ?? [])]
  const imgItem = items.find((i) => i.kind === 'file' && i.type.startsWith('image/'))
  if (imgItem) {
    const file = imgItem.getAsFile()
    if (file) {
      e.preventDefault()
      pasteImage(file)
      return
    }
  }

  e.preventDefault()
  const text = e.clipboardData.getData('text/plain')
  if (!text) return

  if (URL_ALL.test(text)) {
    URL_ALL.lastIndex = 0
    // URL 과 일반 텍스트를 섞어 붙여넣을 수 있게 조각으로 나눠 삽입
    const frag = document.createDocumentFragment()
    let last = 0
    for (const m of text.matchAll(URL_ALL)) {
      if (m.index > last) frag.append(document.createTextNode(text.slice(last, m.index)))
      const a = document.createElement('a')
      a.href = href(m[0])
      a.target = '_blank'
      a.rel = 'noopener'
      a.textContent = m[0]
      frag.append(a)
      last = m.index + m[0].length
    }
    if (last < text.length) frag.append(document.createTextNode(text.slice(last)))

    const sel = window.getSelection()
    if (sel?.rangeCount) {
      const r = sel.getRangeAt(0)
      r.deleteContents()
      r.insertNode(frag)
      r.collapse(false)
    }
  } else {
    document.execCommand('insertText', false, text)
  }
  sync()
}

function addLink() {
  const url = prompt('링크 주소를 입력하세요', 'https://')
  if (!url) return
  cmd('createLink', url) // sync() 안의 normalizeLinks 가 target 을 붙인다
}

/** 선택 영역(또는 문서 전체)의 URL 텍스트를 한 번에 링크로 변환 */
function linkifyAll() {
  if (!el.value) return
  const walker = document.createTreeWalker(el.value, NodeFilter.SHOW_TEXT)
  const targets = []
  while (walker.nextNode()) {
    const n = walker.currentNode
    if (n.parentElement?.closest('a')) continue
    if (URL_ALL.test(n.textContent)) targets.push(n)
    URL_ALL.lastIndex = 0
  }
  for (const n of targets) {
    const frag = document.createDocumentFragment()
    let last = 0
    for (const m of n.textContent.matchAll(URL_ALL)) {
      if (m.index > last) frag.append(document.createTextNode(n.textContent.slice(last, m.index)))
      const a = document.createElement('a')
      a.href = href(m[0])
      a.target = '_blank'
      a.rel = 'noopener'
      a.textContent = m[0]
      frag.append(a)
      last = m.index + m[0].length
    }
    if (last < n.textContent.length) frag.append(document.createTextNode(n.textContent.slice(last)))
    n.replaceWith(frag)
  }
  sync()
}

// ---------- 표 ----------
// 외부 라이브러리를 들이지 않는다는 이 편집기의 방침을 표에도 그대로 적용한다 —
// DOM 을 직접 만들어 넣고, 행·열도 DOM 으로 다룬다.
//
// ⚠️ 툴바 버튼을 누르면 편집창이 포커스를 잃어 캐럿(선택 영역)이 사라진다. 그래서
//    버튼에는 @mousedown.prevent 를 걸어 포커스를 넘기지 않고, 숫자 칸처럼 포커스를
//    가져갈 수밖에 없는 것은 열 때 범위를 적어 두었다가 되돌린다(savedRange).
const tblOpen = ref(false) // 크기 고르는 칸이 열려 있는가
const tblRows = ref(3)
const tblCols = ref(3)
const inTable = ref(false) // 캐럿이 표 안에 있는가 — 행·열 버튼을 그때만 보여 준다
let savedRange = null

/** 캐럿이 놓인 칸. 이 편집기 안의 표만 다룬다. */
function cellAt() {
  const sel = window.getSelection()
  if (!sel || !sel.rangeCount) return null
  let n = sel.getRangeAt(0).startContainer
  if (n.nodeType === 3) n = n.parentElement
  const cell = n?.closest?.('td, th')
  return cell && el.value?.contains(cell) ? cell : null
}

function refreshInTable() {
  inTable.value = mode.value === 'rich' && !!cellAt()
}

function placeCaret(node) {
  if (!node) return
  const sel = window.getSelection()
  if (!sel) return
  const r = document.createRange()
  r.selectNodeContents(node)
  r.collapse(true)
  sel.removeAllRanges()
  sel.addRange(r)
}

/** 빈 칸에도 <br> 을 넣어 둔다 — 없으면 클릭해도 커서가 들어가지 않는다. */
function newCell(tag) {
  const c = document.createElement(tag)
  c.append(document.createElement('br'))
  return c
}

function insertNodes(nodes) {
  const frag = document.createDocumentFragment()
  frag.append(...nodes)
  const last = nodes[nodes.length - 1]
  const sel = window.getSelection()
  if (sel?.rangeCount) {
    const r = sel.getRangeAt(0)
    r.deleteContents()
    r.insertNode(frag)
    r.setStartAfter(last)
    r.collapse(true)
    sel.removeAllRanges()
    sel.addRange(r)
  } else {
    el.value?.append(frag)
  }
}

function openTblPicker() {
  tblOpen.value = !tblOpen.value
  if (!tblOpen.value) return
  const sel = window.getSelection()
  savedRange = sel?.rangeCount && el.value?.contains(sel.getRangeAt(0).startContainer)
    ? sel.getRangeAt(0).cloneRange()
    : null
}

function restoreRange() {
  el.value?.focus()
  if (!savedRange) return
  const sel = window.getSelection()
  sel.removeAllRanges()
  sel.addRange(savedRange)
}

function insertTable() {
  const rows = Math.min(30, Math.max(1, Number(tblRows.value) || 1))
  const cols = Math.min(12, Math.max(1, Number(tblCols.value) || 1))
  restoreRange()

  const table = document.createElement('table')
  const thead = document.createElement('thead')
  const head = document.createElement('tr')
  for (let c = 0; c < cols; c += 1) head.append(newCell('th'))
  thead.append(head)
  const tbody = document.createElement('tbody')
  for (let r = 0; r < rows; r += 1) {
    const tr = document.createElement('tr')
    for (let c = 0; c < cols; c += 1) tr.append(newCell('td'))
    tbody.append(tr)
  }
  table.append(thead, tbody)

  // 표 뒤에 빈 문단을 같이 넣는다 — 표가 본문 끝에 있으면 그 아래로 커서를 옮길 수가 없다.
  const p = document.createElement('p')
  p.append(document.createElement('br'))

  insertNodes([table, p])
  placeCaret(head.firstChild)
  tblOpen.value = false
  sync()
  refreshInTable()
}

function addRow() {
  const cell = cellAt()
  if (!cell) return
  const tr = cell.parentElement
  const table = cell.closest('table')
  const nr = document.createElement('tr')
  for (let i = 0; i < tr.children.length; i += 1) nr.append(newCell('td'))

  // 머리행에서 눌렀으면 본문 맨 앞에 넣는다 — thead 안에 td 를 넣으면 안 된다.
  if (tr.parentElement.tagName === 'THEAD') {
    let tbody = table.querySelector('tbody')
    if (!tbody) {
      tbody = document.createElement('tbody')
      table.append(tbody)
    }
    tbody.prepend(nr)
  } else {
    tr.after(nr)
  }
  placeCaret(nr.firstChild)
  sync()
  refreshInTable()
}

function delRow() {
  const cell = cellAt()
  if (!cell) return
  const tr = cell.parentElement
  if (tr.parentElement.tagName === 'THEAD') {
    alert('머리행은 지울 수 없습니다. 표 자체를 지우려면 [표 삭제] 를 쓰세요.')
    return
  }
  const table = cell.closest('table')
  if (table.querySelectorAll('tbody tr').length <= 1) {
    alert('본문이 한 줄뿐입니다. 표 자체를 지우려면 [표 삭제] 를 쓰세요.')
    return
  }
  const next = tr.nextElementSibling ?? tr.previousElementSibling
  tr.remove()
  placeCaret(next?.firstChild)
  sync()
  refreshInTable()
}

function addCol() {
  const cell = cellAt()
  if (!cell) return
  const idx = [...cell.parentElement.children].indexOf(cell)
  const table = cell.closest('table')
  for (const tr of table.rows) {
    const c = newCell(tr.parentElement.tagName === 'THEAD' ? 'th' : 'td')
    const ref = tr.children[idx]
    if (ref) ref.after(c)
    else tr.append(c)
  }
  sync()
  refreshInTable()
}

function delCol() {
  const cell = cellAt()
  if (!cell) return
  const table = cell.closest('table')
  if ((table.rows[0]?.children.length ?? 0) <= 1) {
    alert('열이 하나뿐입니다. 표 자체를 지우려면 [표 삭제] 를 쓰세요.')
    return
  }
  const row = cell.parentElement
  const idx = [...row.children].indexOf(cell)
  for (const tr of table.rows) tr.children[idx]?.remove()
  // 캐럿이 있던 칸이 사라졌다 — 옆 칸으로 옮겨 준다. 안 그러면 행·열 버튼이 같이 사라진다.
  placeCaret(row.children[Math.min(idx, row.children.length - 1)])
  sync()
  refreshInTable()
}

function delTable() {
  const cell = cellAt()
  if (!cell) return
  if (!confirm('이 표를 지웁니다.')) return
  const table = cell.closest('table')
  const after = table.nextElementSibling
  table.remove()
  placeCaret(after)
  sync()
  refreshInTable()
}

// ---------- HTML 원본 모드 ----------
async function toggleMode() {
  if (mode.value === 'rich') {
    html.value = el.value?.innerHTML ?? ''
    mode.value = 'html'
  } else {
    mode.value = 'rich'
    await nextTick()
    if (el.value) el.value.innerHTML = html.value
    sync()
  }
}
function onHtmlInput() {
  emit('update:modelValue', html.value)
}

function focus() {
  el.value?.focus()
  // 캐럿을 본문 끝으로
  const sel = window.getSelection?.()
  if (sel && el.value) {
    const r = document.createRange()
    r.selectNodeContents(el.value)
    r.collapse(false)
    sel.removeAllRanges()
    sel.addRange(r)
  }
}
defineExpose({ focus })

onMounted(() => {
  if (el.value) el.value.innerHTML = props.modelValue || ''
  // 캐럿이 표 안으로 들어왔는지 따라다녀야 행·열 버튼을 그때만 보여 줄 수 있다
  document.addEventListener('selectionchange', refreshInTable)
})
onUnmounted(() => document.removeEventListener('selectionchange', refreshInTable))

// 외부에서 값이 통째로 바뀐 경우에만 반영 (편집 중 커서 튐 방지)
watch(
  () => props.modelValue,
  (v) => {
    if (mode.value === 'html') {
      if (html.value !== v) html.value = v || ''
      return
    }
    if (el.value && el.value.innerHTML !== v) el.value.innerHTML = v || ''
  }
)
</script>

<template>
  <div class="ed" :class="{ compact }">
    <div v-if="!readonly" class="tools">
      <template v-if="mode === 'rich'">
        <button type="button" title="굵게" @click="cmd('bold')"><b>B</b></button>
        <button type="button" title="기울임" @click="cmd('italic')"><i>I</i></button>
        <button type="button" title="밑줄" @click="cmd('underline')"><u>U</u></button>
        <button type="button" title="취소선" @click="cmd('strikeThrough')"><s>S</s></button>
        <span class="sep"></span>
        <button type="button" title="제목" @click="cmd('formatBlock', 'h3')">H</button>
        <button type="button" title="본문" @click="cmd('formatBlock', 'p')">P</button>
        <button type="button" title="고정폭 블록" @click="cmd('formatBlock', 'pre')">≡</button>
        <span class="sep"></span>
        <button type="button" title="글머리 기호" @click="cmd('insertUnorderedList')">•</button>
        <button type="button" title="번호 매기기" @click="cmd('insertOrderedList')">1.</button>
        <span class="sep"></span>
        <button
          type="button"
          title="표 넣기"
          :class="{ on: tblOpen }"
          @mousedown.prevent
          @click="openTblPicker"
        >
          ⊞ 표
        </button>
        <template v-if="tblOpen">
          <span class="tblsize">
            <input v-model.number="tblRows" type="number" min="1" max="30" title="본문 행 수" />
            ×
            <input v-model.number="tblCols" type="number" min="1" max="12" title="열 수" />
          </span>
          <button type="button" class="go" @mousedown.prevent @click="insertTable">넣기</button>
        </template>
        <template v-if="inTable">
          <button type="button" title="아래에 행 추가" @mousedown.prevent @click="addRow">행+</button>
          <button type="button" title="이 행 삭제" @mousedown.prevent @click="delRow">행−</button>
          <button type="button" title="오른쪽에 열 추가" @mousedown.prevent @click="addCol">열+</button>
          <button type="button" title="이 열 삭제" @mousedown.prevent @click="delCol">열−</button>
          <button type="button" class="dl" title="이 표 삭제" @mousedown.prevent @click="delTable">
            표 삭제
          </button>
        </template>
        <span class="sep"></span>
        <button type="button" title="선택 영역에 링크 걸기" @click="addLink">🔗</button>
        <button type="button" title="본문의 URL 을 모두 링크로 변환" @click="linkifyAll">URL→링크</button>
        <button type="button" title="서식 지우기" @click="cmd('removeFormat')">✕</button>
      </template>
      <span class="sep"></span>
      <button type="button" class="mode" :class="{ on: mode === 'html' }" title="HTML 원본 편집" @click="toggleMode">
        &lt;/&gt; HTML
      </button>
      <span v-if="!compact" class="hint">
        URL 입력 후 <b>Space</b>/<b>Enter</b> → 새 탭 링크 · 이미지 <b>Ctrl+V</b> → 파일로 저장 후
        삽입 · 표 안에서 <b>Tab</b> → 다음 칸
      </span>
    </div>

    <p v-if="upErr" class="uperr">{{ upErr }}</p>

    <!-- HTML 원본 모드 -->
    <textarea
      v-if="mode === 'html'"
      v-model="html"
      class="src"
      spellcheck="false"
      @input="onHtmlInput"
    ></textarea>

    <!-- 리치 모드 -->
    <div
      v-show="mode === 'rich'"
      ref="el"
      class="body"
      :class="{ ro: readonly }"
      :data-ph="placeholder"
      :contenteditable="!readonly"
      spellcheck="false"
      @input="sync"
      @blur="sync"
      @keydown="onKeydown"
      @paste="onPaste"
    ></div>
  </div>
</template>

<style scoped>
.ed { border: 1px solid var(--line); border-radius: 6px; overflow: hidden; background: var(--panel); }
.tools {
  display: flex;
  align-items: center;
  gap: 3px;
  padding: 5px 6px;
  background: var(--surface);
  border-bottom: 1px solid var(--line);
  flex-wrap: wrap;
}
.tools button { min-width: 26px; padding: 2px 6px; font-size: 12px; line-height: 1.4; }
.tools button.on { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); }
.tools button.dl:hover { border-color: var(--danger-2); color: var(--danger-2); }
.tblsize { display: inline-flex; align-items: center; gap: 3px; font-size: 11px; color: var(--muted); }
.tblsize input { width: 40px; padding: 1px 4px; font-size: 11px; }
.tools button.mode.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
.tools .hint { font-size: 11px; color: var(--muted); margin-left: 4px; }
.sep { width: 1px; height: 16px; background: var(--line); margin: 0 3px; }

.compact .body { min-height: 66px; padding: 8px 10px; }
.compact .tools { padding: 3px 4px; gap: 2px; }
.compact .tools button { min-width: 22px; padding: 1px 5px; font-size: 11px; }
.compact .src { min-height: 120px; }
/* 비어 있을 때 안내문 */
.body:empty::before { content: attr(data-ph); color: var(--muted); }
.body { padding: 10px 12px; min-height: 120px; outline: none; font-size: 13px; line-height: 1.65; }
.body.ro { background: var(--surface); }
.body :deep(h3) { font-size: 13.5px; margin: 14px 0 6px; padding-bottom: 3px; border-bottom: 1px solid var(--line); }
.body :deep(h3:first-child) { margin-top: 0; }
.body :deep(p) { margin: 5px 0; }
.body :deep(ul), .body :deep(ol) { margin: 5px 0; padding-left: 22px; }
.body :deep(li) { margin: 2px 0; }
.body :deep(a) { color: var(--accent); }
/* 표 — 저장된 HTML 은 읽기 화면(Docs.vue .view)에서도 그려진다. 두 곳의 모양을 같이 맞출 것. */
.body :deep(table) {
  border-collapse: collapse;
  width: 100%;
  /* 글자 수에 따라 열이 들쭉날쭉해지지 않게 고르게 나눈다 */
  table-layout: fixed;
  margin: 8px 0;
  font-size: 12.5px;
}
.body :deep(th), .body :deep(td) {
  border: 1px solid var(--line);
  padding: 4px 7px;
  vertical-align: top;
  word-break: break-word;
}
.body :deep(th) { background: var(--bg); font-weight: 600; text-align: left; }
/* 편집 중 표의 경계가 보이게 — 빈 칸도 눌러 들어갈 수 있어야 한다 */
.body :deep(td:empty), .body :deep(th:empty) { height: 1.6em; }
/* 붙여넣은 이미지 — 편집창을 넘치지 않게 */
.body :deep(img) {
  max-width: 100%;
  max-height: 320px;
  border: 1px solid var(--line);
  border-radius: 4px;
  margin: 4px 0;
  display: block;
}
.body :deep(.uploading) {
  display: inline-block;
  background: var(--accent-soft);
  color: var(--accent);
  border-radius: 4px;
  padding: 1px 8px;
  font-size: 11.5px;
}
.uperr {
  margin: 0;
  padding: 5px 12px;
  background: var(--danger-soft);
  border-bottom: 1px solid var(--danger-line);
  color: var(--danger-text);
  font-size: 11.5px;
}
.body :deep(code) {
  background: var(--fill);
  border-radius: 3px;
  padding: 1px 5px;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 12px;
}
.body :deep(pre) {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 4px;
  padding: 8px 10px;
  overflow-x: auto;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 12px;
}

.src {
  width: 100%;
  min-height: 260px;
  border: 0;
  outline: none;
  padding: 10px 12px;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 12px;
  line-height: 1.6;
  resize: vertical;
  background: var(--surface);
  white-space: pre-wrap;
}
</style>
