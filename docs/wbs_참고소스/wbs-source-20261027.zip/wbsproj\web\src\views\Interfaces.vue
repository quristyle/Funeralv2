<script setup>
import { computed, onMounted, ref } from 'vue'
import { api } from '../api'
import { state, useViewRefresh, scrollContentTop } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'

// EAI 인터페이스 카탈로그.
// 코드값(상태·방향·주기·단계유형)과 추가 관리항목은 DB 에서 읽어 그린다 — 화면에 하드코딩하지 않는다.
const list = ref([])
const codes = ref({})   // { IF_STATUS: [...], ... }
const systems = ref([])
const loading = ref(false)
const err = ref('')

const f = ref({ status: '', domain: '', q: '', useYn: 'Y' })
const sel = ref(null)   // 상세 { master, steps, attrs, notes, flow }
const mode = ref('list')

const codeList = (grp) => codes.value[grp] ?? []
const codeNm = (grp, c) => codeList(grp).find((x) => x.code === c)?.code_nm ?? c ?? ''
const sysNm = (id) => systems.value.find((s) => s.system_id === id)?.system_nm ?? ''

async function loadRefs() {
  try {
    const [c, s] = await Promise.all([api.ifCodes(), api.ifSystems()])
    const m = {}
    for (const x of c) (m[x.code_grp] ??= []).push(x)
    codes.value = m
    systems.value = s
  } catch (e) {
    err.value = e.message
  }
}

async function load() {
  loading.value = true
  err.value = ''
  try {
    list.value = await api.ifList(f.value)
    await loadFileCounts()
  } catch (e) {
    err.value = e.message
  } finally {
    loading.value = false
  }
}

// ---------- 첨부파일 ----------
// 지시서상 if_* 스키마를 못 건드리므로 서버가 파일시스템에만 보관한다.
// 목록·업로드·삭제 모두 API 를 거치므로 IP 접근 제어 안쪽이다.
const files = ref([])
const fileCounts = ref({})
const fileBusy = ref('')
const dragOver = ref(false)
const fileInput = ref(null)

const kb = (n) => (n >= 1024 * 1024 ? (n / 1024 / 1024).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB')

async function loadFiles(id) {
  try {
    files.value = await api.ifFiles(id)
  } catch (e) {
    err.value = e.message
  }
}

async function loadFileCounts() {
  try {
    const rows = await api.ifFileCounts()
    fileCounts.value = Object.fromEntries(rows.map((r) => [r.if_id, r.cnt]))
  } catch { /* 배지는 없어도 그만이다 */ }
}

async function upload(list) {
  if (!sel.value || !list?.length) return
  fileBusy.value = 'up'
  err.value = ''
  try {
    await api.ifFileUpload(sel.value.master.if_id, list)
    await loadFiles(sel.value.master.if_id)
    await loadFileCounts()
  } catch (e) {
    err.value = e.message
  } finally {
    fileBusy.value = ''
    if (fileInput.value) fileInput.value.value = ''
  }
}

function onDrop(e) {
  dragOver.value = false
  upload(e.dataTransfer?.files)
}

async function removeFile(f) {
  if (!confirm(`첨부파일 "${f.name}" 을 삭제할까요?`)) return
  fileBusy.value = f.file_id
  try {
    await api.ifFileDelete(sel.value.master.if_id, f.file_id)
    await loadFiles(sel.value.master.if_id)
    await loadFileCounts()
  } catch (e) {
    err.value = e.message
  } finally {
    fileBusy.value = ''
  }
}

async function open(id) {
  try {
    sel.value = await api.ifGet(id)
    await loadFiles(id)

    form.value = { ...sel.value.master }
    attrVals.value = Object.fromEntries((sel.value.attrs ?? []).map((a) => [a.attr_def_id, a.attr_val ?? '']))
    mode.value = 'detail'
    scrollContentTop()
  } catch (e) {
    err.value = e.message
  }
}
function backToList() {
  mode.value = 'list'
  sel.value = null
  load()
}

// ---------- 기본정보 ----------
const form = ref({})
const saving = ref(false)

async function saveMaster() {
  if (!form.value.if_cd?.trim() || !form.value.if_nm?.trim()) {
    err.value = 'if_cd 와 인터페이스명은 필수입니다.'
    return
  }
  saving.value = true
  err.value = ''
  try {
    const body = {}
    for (const k of ['if_cd', 'if_nm', 'if_desc', 'direction_cd', 'src_system_id', 'tgt_system_id',
      'domain_cd', 'trigger_cd', 'cycle_cd', 'status_cd', 'owner_nm', 'owner_bp_id',
      'plan_sdt', 'plan_edt', 'open_dt', 'remark', 'sort_order', 'use_yn']) body[k] = form.value[k] ?? null
    await api.ifUpdate(sel.value.master.if_id, body)
    await open(sel.value.master.if_id)
  } catch (e) {
    err.value = e.message
  } finally {
    saving.value = false
  }
}

// ---------- 신규 ----------
const neu = ref(null)
function startNew() {
  neu.value = { if_cd: '', if_nm: '', direction_cd: '', status_cd: 'DESIGN', domain_cd: '' }
}
async function createIf() {
  if (!neu.value.if_cd.trim() || !neu.value.if_nm.trim() || !neu.value.direction_cd || !neu.value.status_cd) {
    err.value = '코드 · 이름 · 방향 · 상태는 필수입니다.'
    return
  }
  try {
    const { if_id } = await api.ifCreate(neu.value)
    neu.value = null
    await open(if_id)
  } catch (e) {
    err.value = e.message
  }
}

async function removeIf() {
  const m = sel.value.master
  if (!confirm(`"${m.if_cd} ${m.if_nm}" 를 삭제하면 단계 · 메모 · 추가항목이 함께 사라집니다.\n` +
               `보관이 목적이라면 사용여부를 N 으로 바꾸는 편이 안전합니다.\n\n그래도 삭제할까요?`)) return
  try {
    await api.ifDelete(m.if_id)
    backToList()
  } catch (e) {
    err.value = e.message
  }
}

// ---------- 단계 ----------
const stepEdit = ref(null)
function newStep() {
  stepEdit.value = { step_id: null, step_nm: '', step_type_cd: '', system_id: null,
    object_owner: '', object_nm: '', object_type: '', step_desc: '', params: '' }
}
function editStep(s) {
  stepEdit.value = { ...s, params: s.params ?? '' }
}
async function saveStep() {
  const s = stepEdit.value
  if (!s.step_nm?.trim()) { err.value = '단계명은 필수입니다.'; return }
  if (s.params?.trim()) {
    try { JSON.parse(s.params) }
    catch (e) { err.value = `params 가 올바른 JSON 이 아닙니다: ${e.message}`; return }
  }
  const body = {
    step_nm: s.step_nm, step_type_cd: s.step_type_cd || null,
    system_id: s.system_id ? Number(s.system_id) : null,
    object_owner: s.object_owner || null, object_nm: s.object_nm || null,
    object_type: s.object_type || null, step_desc: s.step_desc || null,
    params: s.params?.trim() ? JSON.parse(s.params) : null,
  }
  try {
    if (s.step_id) await api.ifStepUpdate(s.step_id, body)
    else await api.ifStepAdd(sel.value.master.if_id, body)
    stepEdit.value = null
    await open(sel.value.master.if_id)
  } catch (e) {
    err.value = e.message
  }
}
async function delStep(s) {
  if (!confirm(`단계 ${s.step_no}. ${s.step_nm} 을 삭제할까요?`)) return
  await api.ifStepDelete(s.step_id)
  await open(sel.value.master.if_id)
}
async function moveStep(i, dir) {
  const ids = sel.value.steps.map((s) => s.step_id)
  const j = i + dir
  if (j < 0 || j >= ids.length) return
  ;[ids[i], ids[j]] = [ids[j], ids[i]]
  await api.ifStepReorder(sel.value.master.if_id, ids)
  await open(sel.value.master.if_id)
}

// ---------- 추가 관리항목 ----------
const attrVals = ref({})
const attrSaving = ref(false)
async function saveAttrs() {
  for (const a of sel.value.attrs ?? []) {
    const v = attrVals.value[a.attr_def_id]
    if (a.required_yn === 'Y' && (v == null || String(v).trim() === '')) {
      err.value = `필수 항목입니다: ${a.attr_nm}`
      return
    }
    if (a.attr_type === 'JSON' && String(v ?? '').trim()) {
      try { JSON.parse(v) }
      catch (e) { err.value = `${a.attr_nm} 이 올바른 JSON 이 아닙니다: ${e.message}`; return }
    }
  }
  attrSaving.value = true
  err.value = ''
  try {
    await api.ifAttrSave(sel.value.master.if_id, attrVals.value)
    await open(sel.value.master.if_id)
  } catch (e) {
    err.value = e.message
  } finally {
    attrSaving.value = false
  }
}

// ---------- 메모 / 이슈 ----------
const note = ref(null)
function newNote() {
  note.value = { note_type_cd: '', title: '', content: '', writer_nm: '', step_id: null, done_yn: 'N' }
}
async function saveNote() {
  if (!note.value.title?.trim()) { err.value = '메모 제목은 필수입니다.'; return }
  try {
    await api.ifNoteAdd(sel.value.master.if_id, {
      ...note.value,
      step_id: note.value.step_id ? Number(note.value.step_id) : null,
    })
    note.value = null
    await open(sel.value.master.if_id)
  } catch (e) {
    err.value = e.message
  }
}
async function toggleNote(n) {
  await api.ifNoteUpdate(n.note_id, { done_yn: n.done_yn === 'Y' ? 'N' : 'Y' })
  await open(sel.value.master.if_id)
}
async function delNote(n) {
  if (!confirm(`"${n.title}" 메모를 삭제할까요?`)) return
  await api.ifNoteDelete(n.note_id)
  await open(sel.value.master.if_id)
}

const domains = computed(() => [...new Set(list.value.map((r) => r.domain_cd).filter(Boolean))].sort())

useViewRefresh(load)
onMounted(async () => {
  await loadRefs()
  await load()
})
</script>

<template>
  <div class="topbar">
    <span class="hint">
      EAI 인터페이스 카탈로그
      <template v-if="mode === 'list'"> · {{ list.length }}건</template>
      <template v-if="loading"> · 조회 중…</template>
    </span>
    <span class="spacer"></span>
    <template v-if="mode === 'list'">
      <select v-model="f.status" title="상태" @change="load">
        <option value="">상태 전체</option>
        <option v-for="c in codeList('IF_STATUS')" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
      </select>
      <select v-model="f.domain" title="도메인" @change="load">
        <option value="">도메인 전체</option>
        <option v-for="d in domains" :key="d" :value="d">{{ d }}</option>
      </select>
      <select v-model="f.useYn" title="사용여부" @change="load">
        <option value="Y">사용</option>
        <option value="N">미사용</option>
        <option value="">전체</option>
      </select>
      <input v-model="f.q" type="text" placeholder="코드 · 이름 검색" style="width: 160px" @keyup.enter="load" />
      <button @click="startNew">+ 인터페이스 등록</button>
    </template>
    <button v-else @click="backToList">← 목록</button>
    <RefreshBtn :fn="mode === 'list' ? load : () => open(sel.master.if_id)" />
  </div>

  <p v-if="err" class="err">{{ err }}</p>

  <!-- 신규 등록 -->
  <section v-if="neu" class="panel">
    <h2>인터페이스 등록 <span class="hint">코드 · 이름 · 방향 · 상태만 입력하면 됩니다. 단계는 상세에서 추가합니다.</span></h2>
    <div class="form">
      <label>인터페이스 코드 *</label>
      <div>
        <input v-model="neu.if_cd" type="text" placeholder="HHIP-IF-02" />
        <span class="hint">프로그램이 남기는 <code>IF_ID</code> 와 같은 값이어야 합니다.</span>
      </div>
      <label>인터페이스명 *</label><input v-model="neu.if_nm" type="text" />
      <label>방향 *</label>
      <select v-model="neu.direction_cd">
        <option value="">선택</option>
        <option v-for="c in codeList('IF_DIRECTION')" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
      </select>
      <label>상태 *</label>
      <select v-model="neu.status_cd">
        <option v-for="c in codeList('IF_STATUS')" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
      </select>
      <label>도메인</label><input v-model="neu.domain_cd" type="text" placeholder="PD / pmm001 …" />
    </div>
    <div class="acts">
      <button @click="createIf">등록</button>
      <button @click="neu = null">취소</button>
    </div>
  </section>

  <!-- 목록 -->
  <section v-if="mode === 'list' && !neu" class="panel">
    <div class="scroll">
      <table>
        <thead>
          <tr>
            <th>코드</th><th>인터페이스명</th><th>도메인</th><th>방향</th>
            <th>원천 → 대상</th><th>상태</th><th>주기</th>
            <th class="num">단계</th><th class="num">미해결</th><th class="num">첨부</th><th>담당자</th><th>수정</th>
          </tr>
        </thead>
        <tbody>
          <template v-for="r in list" :key="r.if_id">
            <tr class="clk" :class="{ off: r.use_yn === 'N' }" @click="open(r.if_id)">
              <td class="nowrap"><strong>{{ r.if_cd }}</strong></td>
              <td>{{ r.if_nm }}</td>
              <td class="nowrap muted">{{ r.domain_cd }}</td>
              <td class="nowrap">{{ r.direction_nm }}</td>
              <td class="nowrap muted sm">{{ r.src_system_nm }} → {{ r.tgt_system_nm }}</td>
              <td class="nowrap"><span class="badge" :class="'st-' + r.status_cd">{{ r.status_nm }}</span></td>
              <td class="nowrap muted">{{ r.cycle_nm }}</td>
              <td class="num">{{ r.step_cnt }}</td>
              <td class="num" :class="{ bad: r.open_issue_cnt > 0 }">{{ r.open_issue_cnt || '' }}</td>
              <td class="num"><span v-if="fileCounts[r.if_id]" class="clip" title="첨부파일">📎 {{ fileCounts[r.if_id] }}</span></td>
              <td class="nowrap muted">{{ r.owner_nm || '' }}</td>
              <td class="nowrap muted sm">{{ (r.updated_at || '').slice(0, 10) }}</td>
            </tr>
            <tr class="flow clk" @click="open(r.if_id)">
              <td></td>
              <td colspan="11" class="fl">{{ r.flow || '단계 미등록' }}</td>
            </tr>
          </template>
          <tr v-if="!list.length && !loading">
            <td colspan="11" class="muted ctr" style="padding: 20px">등록된 인터페이스가 없습니다.</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <!-- 상세 -->
  <template v-if="mode === 'detail' && sel">
    <section class="panel">
      <h2>
        {{ sel.master.if_cd }} · {{ sel.master.if_nm }}
        <span class="spacer"></span>
        <span class="hint">수정 {{ sel.master.updated_at_txt }}</span>
        <button :disabled="saving" @click="saveMaster">{{ saving ? '저장 중…' : '기본정보 저장' }}</button>
        <button class="del" @click="removeIf">삭제</button>
      </h2>
      <p class="fl big">{{ sel.flow || '단계 미등록' }}</p>

      <div class="form">
        <label>인터페이스 코드</label>
        <div>
          <input v-model="form.if_cd" type="text" />
          <span class="hint">프로그램의 <code>IF_ID</code> 와 같아야 합니다 (예: 패키지 상수 <code>C_IF_ID</code>).</span>
        </div>
        <label>인터페이스명</label><input v-model="form.if_nm" type="text" />
        <label>설명</label><textarea v-model="form.if_desc" rows="2"></textarea>

        <label>방향</label>
        <select v-model="form.direction_cd">
          <option value="">선택</option>
          <option v-for="c in codeList('IF_DIRECTION')" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
        </select>
        <label>상태</label>
        <select v-model="form.status_cd">
          <option v-for="c in codeList('IF_STATUS')" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
        </select>
        <label>주기</label>
        <select v-model="form.cycle_cd">
          <option value="">선택</option>
          <option v-for="c in codeList('IF_CYCLE')" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
        </select>
        <label>기동 방식</label>
        <select v-model="form.trigger_cd">
          <option value="">선택</option>
          <option v-for="c in codeList('TRIGGER_TYPE')" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
        </select>

        <label>원천 시스템</label>
        <select v-model="form.src_system_id">
          <option :value="null">선택</option>
          <option v-for="s in systems" :key="s.system_id" :value="s.system_id">{{ s.system_nm }}</option>
        </select>
        <label>대상 시스템</label>
        <select v-model="form.tgt_system_id">
          <option :value="null">선택</option>
          <option v-for="s in systems" :key="s.system_id" :value="s.system_id">{{ s.system_nm }}</option>
        </select>

        <label>도메인</label><input v-model="form.domain_cd" type="text" />
        <label>담당자</label>
        <div class="two">
          <input v-model="form.owner_nm" type="text" placeholder="성명" />
          <input v-model="form.owner_bp_id" type="text" placeholder="BP ID" />
        </div>
        <label>계획 시작 / 종료</label>
        <div class="two">
          <input v-model="form.plan_sdt" type="date" />
          <input v-model="form.plan_edt" type="date" />
        </div>
        <label>운영 오픈일</label><input v-model="form.open_dt" type="date" />
        <label>비고</label><textarea v-model="form.remark" rows="2"></textarea>
        <label>사용여부</label>
        <select v-model="form.use_yn">
          <option value="Y">사용 (Y)</option>
          <option value="N">미사용 (N)</option>
        </select>
      </div>
    </section>

    <!-- 처리 단계 -->
    <section class="panel">
      <h2>
        처리 단계 <span class="hint">{{ sel.steps.length }}건 · step_no 순</span>
        <span class="spacer"></span>
        <button @click="newStep">+ 단계 추가</button>
      </h2>

      <div v-if="stepEdit" class="editbox">
        <div class="form">
          <label>단계명 *</label><input v-model="stepEdit.step_nm" type="text" />
          <label>단계 유형</label>
          <select v-model="stepEdit.step_type_cd">
            <option value="">선택</option>
            <option v-for="c in codeList('STEP_TYPE')" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
          </select>
          <label>시스템</label>
          <select v-model="stepEdit.system_id">
            <option :value="null">선택</option>
            <option v-for="s in systems" :key="s.system_id" :value="s.system_id">{{ s.system_nm }}</option>
          </select>
          <label>객체</label>
          <div class="three">
            <input v-model="stepEdit.object_owner" type="text" placeholder="소유자 (SST02)" />
            <input v-model="stepEdit.object_nm" type="text" placeholder="객체명 (Z_PD_C_LOCPOR)" />
            <select v-model="stepEdit.object_type">
              <option value="">유형</option>
              <option v-for="c in codeList('OBJECT_TYPE')" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
            </select>
          </div>
          <label>설명</label><textarea v-model="stepEdit.step_desc" rows="2"></textarea>
          <label>params (JSON)</label>
          <textarea v-model="stepEdit.params" rows="5" class="code"
            placeholder='{"in":[{"name":"P_IFSEQ","type":"VARCHAR2","desc":"I/F Seq. No."}]}'></textarea>
        </div>
        <div class="acts">
          <button @click="saveStep">저장</button>
          <button @click="stepEdit = null">취소</button>
        </div>
      </div>

      <div class="scroll">
        <table>
          <thead>
            <tr>
              <th class="num">#</th><th>단계명</th><th>유형</th><th>시스템</th>
              <th>객체</th><th>설명</th><th>params</th><th>작업</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(s, i) in sel.steps" :key="s.step_id">
              <td class="num"><strong>{{ s.step_no }}</strong></td>
              <td class="nowrap">{{ s.step_nm }}</td>
              <td class="nowrap muted">{{ s.step_type_nm }}</td>
              <td class="nowrap muted sm">{{ s.system_nm }}</td>
              <td class="nowrap mono">{{ s.object_full_nm }}</td>
              <!-- 설명은 여러 줄로 작성되므로 작성자가 넣은 줄바꿈 그대로 보여준다 -->
              <td class="sm muted pre desc">{{ s.step_desc }}</td>
              <td class="sm mono cut" :title="s.params">{{ s.params }}</td>
              <td class="acts">
                <button :disabled="i === 0" title="위로" @click="moveStep(i, -1)">↑</button>
                <button :disabled="i === sel.steps.length - 1" title="아래로" @click="moveStep(i, 1)">↓</button>
                <button @click="editStep(s)">수정</button>
                <button class="del" @click="delStep(s)">삭제</button>
              </td>
            </tr>
            <tr v-if="!sel.steps.length">
              <td colspan="8" class="muted ctr" style="padding: 16px">등록된 단계가 없습니다.</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <!-- 추가 관리항목 (동적) -->
    <section class="panel">
      <h2>
        추가 관리항목 <span class="hint">if_attr_def 에 항목을 추가하면 여기에 입력란이 자동으로 늘어납니다</span>
        <span class="spacer"></span>
        <button :disabled="attrSaving" @click="saveAttrs">{{ attrSaving ? '저장 중…' : '저장' }}</button>
      </h2>
      <div class="form">
        <template v-for="a in sel.attrs" :key="a.attr_def_id">
          <label>
            {{ a.attr_nm }}<span v-if="a.required_yn === 'Y'" class="req"> *</span>
            <span class="hint sm">{{ a.attr_cd }} · {{ a.attr_type }}</span>
          </label>
          <select v-if="a.attr_type === 'CODE'" v-model="attrVals[a.attr_def_id]">
            <option value="">선택</option>
            <option v-for="c in codeList(a.code_grp)" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
          </select>
          <label v-else-if="a.attr_type === 'YN'" class="ck">
            <input
              type="checkbox"
              :checked="attrVals[a.attr_def_id] === 'Y'"
              @change="attrVals[a.attr_def_id] = $event.target.checked ? 'Y' : 'N'"
            /> 예 (Y)
          </label>
          <input v-else-if="a.attr_type === 'NUMBER'" v-model="attrVals[a.attr_def_id]" type="number" />
          <input v-else-if="a.attr_type === 'DATE'" v-model="attrVals[a.attr_def_id]" type="date" />
          <textarea v-else-if="a.attr_type === 'JSON'" v-model="attrVals[a.attr_def_id]" rows="3" class="code"></textarea>
          <input v-else v-model="attrVals[a.attr_def_id]" type="text" />
        </template>
        <p v-if="!sel.attrs.length" class="muted">정의된 추가 항목이 없습니다.</p>
      </div>
    </section>

    <!-- 첨부파일 -->
    <section class="panel">
      <h2>
        첨부파일 <span class="hint">{{ files.length }}건 · 파일당 25MB · 한 번에 20개까지</span>
        <span class="spacer"></span>
        <button :disabled="fileBusy === 'up'" @click="fileInput?.click()">
          {{ fileBusy === 'up' ? '올리는 중…' : '+ 파일 선택' }}
        </button>
      </h2>

      <input
        ref="fileInput"
        type="file"
        multiple
        style="display: none"
        @change="upload($event.target.files)"
      />

      <div
        class="drop"
        :class="{ over: dragOver, busy: fileBusy === 'up' }"
        @dragover.prevent="dragOver = true"
        @dragleave="dragOver = false"
        @drop.prevent="onDrop"
        @click="fileInput?.click()"
      >
        여기로 파일을 끌어다 놓거나 눌러서 고르세요 (여러 개 가능)
      </div>

      <div v-if="files.length" class="scroll">
        <table>
          <thead>
            <tr><th>파일명</th><th class="num">크기</th><th>올린 시각</th><th>작업</th></tr>
          </thead>
          <tbody>
            <tr v-for="f in files" :key="f.file_id" :class="{ busy: fileBusy === f.file_id }">
              <td>
                <a :href="api.ifFileUrl(sel.master.if_id, f.file_id)" class="dl">{{ f.name }}</a>
              </td>
              <td class="num muted">{{ kb(f.size) }}</td>
              <td class="muted nowrap">{{ f.modified }}</td>
              <td class="nowrap">
                <a :href="api.ifFileUrl(sel.master.if_id, f.file_id)" class="btnlink">내려받기</a>
                <button class="del" :disabled="fileBusy === f.file_id" @click="removeFile(f)">삭제</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <p v-else class="muted">첨부된 파일이 없습니다.</p>
    </section>

    <!-- 메모 / 이슈 -->
    <section class="panel">
      <h2>
        메모 / 이슈 <span class="hint">{{ sel.notes.length }}건</span>
        <span class="spacer"></span>
        <button @click="newNote">+ 추가</button>
      </h2>

      <div v-if="note" class="editbox">
        <div class="form">
          <label>유형</label>
          <select v-model="note.note_type_cd">
            <option value="">선택</option>
            <option v-for="c in codeList('NOTE_TYPE')" :key="c.code" :value="c.code">{{ c.code_nm }}</option>
          </select>
          <label>제목 *</label><input v-model="note.title" type="text" />
          <label>내용</label><textarea v-model="note.content" rows="3"></textarea>
          <label>작성자</label><input v-model="note.writer_nm" type="text" />
          <label>관련 단계</label>
          <select v-model="note.step_id">
            <option :value="null">전체</option>
            <option v-for="s in sel.steps" :key="s.step_id" :value="s.step_id">{{ s.step_no }}. {{ s.step_nm }}</option>
          </select>
        </div>
        <div class="acts">
          <button @click="saveNote">저장</button>
          <button @click="note = null">취소</button>
        </div>
      </div>

      <div class="scroll">
        <table>
          <thead>
            <tr><th>유형</th><th>제목 / 내용</th><th>단계</th><th>작성자</th><th>일자</th><th>해결</th><th>작업</th></tr>
          </thead>
          <tbody>
            <tr v-for="n in sel.notes" :key="n.note_id" :class="{ done: n.done_yn === 'Y' }">
              <td class="nowrap"><span class="badge nt">{{ n.note_type_nm || n.note_type_cd }}</span></td>
              <td>
                <strong>{{ n.title }}</strong>
                <div v-if="n.content" class="sm muted pre">{{ n.content }}</div>
              </td>
              <td class="nowrap muted sm">{{ n.step_nm || '' }}</td>
              <td class="nowrap muted">{{ n.writer_nm }}</td>
              <td class="nowrap muted sm">{{ n.note_dt || (n.updated_at_txt || '').slice(0, 10) }}</td>
              <td class="ctr">
                <input
                  v-if="n.note_type_cd === 'ISSUE'"
                  type="checkbox" :checked="n.done_yn === 'Y'" title="해결 표시" @change="toggleNote(n)"
                />
                <span v-else class="muted">·</span>
              </td>
              <td class="acts"><button class="del" @click="delNote(n)">삭제</button></td>
            </tr>
            <tr v-if="!sel.notes.length">
              <td colspan="7" class="muted ctr" style="padding: 16px">메모가 없습니다.</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </template>
</template>

<style scoped>

/* 첨부파일 */
.drop {
  border: 1px dashed var(--line);
  border-radius: 8px;
  padding: 14px;
  text-align: center;
  color: var(--muted);
  font-size: 12px;
  cursor: pointer;
  margin-bottom: 10px;
  transition: background 0.12s, border-color 0.12s;
}
.drop:hover { border-color: var(--accent); color: var(--accent); }
.drop.over { border-color: var(--accent); background: var(--accent-soft); color: var(--accent); }
.drop.busy { opacity: 0.5; pointer-events: none; }
a.dl { color: var(--text); text-decoration: none; }
a.dl:hover { color: var(--accent); text-decoration: underline; }
.btnlink {
  display: inline-block;
  border: 1px solid var(--line);
  border-radius: 5px;
  padding: 1px 8px;
  font-size: 11px;
  color: var(--text);
  text-decoration: none;
  margin-right: 4px;
}
.btnlink:hover { border-color: var(--accent); color: var(--accent); }
tr.busy { opacity: 0.45; }
.clip { color: var(--accent); font-weight: 600; }

.topbar {
  display: flex; align-items: center; gap: 8px; margin-bottom: 10px;
  padding: 7px 12px; background: var(--panel); border: 1px solid var(--line); border-radius: 8px;
}
.topbar .spacer { flex: 1; }
.topbar .hint { font-size: 12px; color: var(--muted); }
h2 .spacer { flex: 1; }
.nowrap { white-space: nowrap; }
.ctr { text-align: center; }
.sm { font-size: 11px; }
.mono { font-family: Consolas, 'Courier New', monospace; font-size: 11.5px; }
.cut { max-width: 260px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.pre { white-space: pre-wrap; margin-top: 2px; }
/* 단계 설명 — 줄바꿈 유지 + 너무 넓어지지 않게 */
td.desc { min-width: 220px; max-width: 420px; line-height: 1.55; word-break: break-word; }

/* 흐름 줄 — 이 화면의 핵심 정보 */
.fl {
  font-family: Consolas, 'Courier New', monospace;
  font-size: 11.5px; color: var(--accent); padding-top: 0 !important;
}
.fl.big {
  font-size: 13px; background: var(--accent-soft); border-radius: 6px;
  padding: 8px 12px; margin: 0 0 12px;
}
tr.flow td { border-top: 0; padding-top: 0; }
tr.clk { cursor: pointer; }
tr.clk:hover, tr.clk:hover + tr.flow { background: var(--surface); }
tr.off { opacity: 0.5; }
tr.done strong { text-decoration: line-through; color: var(--muted); }

.badge { display: inline-block; padding: 1px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; }
.badge.nt { background: var(--fill); color: var(--muted); }
.st-DESIGN { background: var(--fill); color: var(--muted); }
.st-DEV { background: var(--accent-soft); color: var(--accent); }
.st-TEST { background: var(--warn-soft); color: var(--warn); }
.st-PROD { background: var(--done-soft); color: var(--done); }
.st-HOLD { background: var(--violet-soft); color: var(--violet); }
.st-DROP { background: var(--danger-soft); color: var(--danger-text); }
td.bad { color: var(--danger); font-weight: 700; }

.form { display: grid; grid-template-columns: 130px minmax(0, 1fr); gap: 7px 12px; align-items: center; }
.form label { font-size: 12px; color: var(--muted); }
.form label .req { color: var(--danger); font-weight: 700; }
.form input, .form select, .form textarea { width: 100%; }
.form textarea { padding: 5px 7px; border: 1px solid var(--line); border-radius: 4px; resize: vertical; }
.form textarea.code { font-family: Consolas, 'Courier New', monospace; font-size: 11.5px; }
.form .two { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.form .three { display: grid; grid-template-columns: 1fr 1.4fr 0.8fr; gap: 6px; }
.form .ck { display: flex; align-items: center; gap: 5px; font-size: 12.5px; color: var(--text); }
.form .hint { display: block; margin-top: 2px; }

.editbox { border: 1px solid var(--accent); border-radius: 8px; padding: 12px; margin-bottom: 12px; background: var(--surface); }
.acts { display: flex; gap: 5px; margin-top: 10px; }
td.acts { margin: 0; white-space: nowrap; }
td.acts button { padding: 2px 7px; }
.del:hover { border-color: var(--danger-2); color: var(--danger-2); }
</style>
