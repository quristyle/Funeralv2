using System.Text;

namespace WbsApi;

/// <summary>
/// 상세 목록 한 줄(화면)에 붙이는 <b>화면설계 문서</b> 첨부.
///
/// 보관 위치 — <c>api/data/row_files/{row_uid}/{파일ID}__{원래 이름}</c>
///
/// 인터페이스 첨부(<see cref="IfFiles"/>)와 <b>같은 방식</b>이다. 표를 만들지 않고 파일 이름
/// 자체를 메타데이터로 쓴다. 두 벌을 다르게 만들면 보관함 화면(#/files)이 둘을 따로
/// 다뤄야 하고, 백업·이사 때 규칙이 둘이 된다.
///
/// 키가 <b>row_uid</b> 인 까닭 (db/wrk2_row_uid.sql):
///   activity_id 는 엑셀 WBS 에서 나중에 확정되는 일이 있어 <b>비어 있을 수 있다</b>.
///   모듈+메뉴명은 사람이 고치는 값이라, 메뉴명을 고치는 순간 붙여 둔 것들이 길을 잃는다.
///   그래서 아무도 고치지 않는 번호로 폴더를 만든다 — 그 줄이 ID 를 나중에 받아도,
///   메뉴명을 고쳐도 첨부는 제자리에 있다.
///
/// 내려받기는 정적 서비스가 아니라 API 로 한다. IP 접근 제어 안쪽에 두고,
/// 무엇이 올라오든 브라우저에서 실행되지 않도록 항상 첨부(attachment)로 내려 준다.
/// </summary>
public static class RowFiles
{
    private const long MaxBytes = 25L * 1024 * 1024;   // 파일 1개 최대 25MB
    private const int MaxCount = 20;                   // 한 번에 올릴 수 있는 개수
    private const string Sep = "__";                   // 파일ID 와 원래 이름 구분자

    public static string Root(IWebHostEnvironment env) =>
        Path.Combine(env.ContentRootPath, "data", "row_files");

    private static string DirOf(IWebHostEnvironment env, long rowUid) =>
        Path.Combine(Root(env), rowUid.ToString());

    /// <summary>경로 조작·제어문자를 막고 길이를 제한한다. 확장자는 그대로 둔다.</summary>
    private static string SafeName(string? name)
    {
        var n = Path.GetFileName(name ?? "").Trim();
        if (string.IsNullOrWhiteSpace(n)) n = "file";

        var bad = Path.GetInvalidFileNameChars().Concat(['\\', '/', ':', '*', '?', '"', '<', '>', '|']).ToHashSet();
        var sb = new StringBuilder(n.Length);
        foreach (var c in n) sb.Append(bad.Contains(c) || char.IsControl(c) ? '_' : c);

        n = sb.ToString().TrimStart('.');              // 숨김파일·상위경로 흉내 방지
        if (n.Contains(Sep)) n = n.Replace(Sep, "_");  // 구분자와 충돌하지 않게
        if (n.Length > 120) n = n[..60] + "~" + n[^40..];
        return n.Length == 0 ? "file" : n;
    }

    /// <summary>파일ID 는 우리가 만든 것만 받는다 (경로 조작 차단).</summary>
    private static bool ValidId(string id) =>
        id.Length is > 8 and < 40 && id.All(c => char.IsAsciiLetterOrDigit(c) || c == '-');

    private static FileInfo? Find(IWebHostEnvironment env, long rowUid, string fileId)
    {
        if (rowUid <= 0 || !ValidId(fileId)) return null;
        var dir = new DirectoryInfo(DirOf(env, rowUid));
        if (!dir.Exists) return null;
        return dir.GetFiles($"{fileId}{Sep}*").FirstOrDefault();
    }

    /// <summary>파일 이름에서 원래 이름만 떼어 낸다.</summary>
    public static string NameOf(string fileName)
    {
        var i = fileName.IndexOf(Sep, StringComparison.Ordinal);
        return i > 0 ? fileName[(i + Sep.Length)..] : fileName;
    }

    private static object Shape(FileInfo f)
    {
        var i = f.Name.IndexOf(Sep, StringComparison.Ordinal);
        return new
        {
            file_id = i > 0 ? f.Name[..i] : f.Name,
            name = NameOf(f.Name),
            size = f.Length,
            modified = f.LastWriteTime.ToString("yyyy-MM-dd HH:mm"),
        };
    }

    public static void Map(WebApplication app, Func<IpGate.Result, bool> isSuper)
    {
        var env = app.Environment;

        // 행별 첨부 개수 — 목록의 [첨부] 컬럼 배지용. 한 번에 다 받아 간다
        // (211행마다 따로 물으면 한 화면에 211번 왕복한다).
        app.MapGet("/api/rows/files/counts", () =>
        {
            var root = new DirectoryInfo(Root(env));
            if (!root.Exists) return Results.Ok(Array.Empty<object>());

            var rows = root.GetDirectories()
                .Where(d => long.TryParse(d.Name, out _))
                .Select(d => new { row_uid = long.Parse(d.Name), cnt = d.GetFiles().Length })
                .Where(x => x.cnt > 0)
                .ToList();
            return Results.Ok(rows);
        });

        // 한 줄의 첨부 목록
        app.MapGet("/api/rows/{rowUid:long}/files", (long rowUid) =>
        {
            var dir = new DirectoryInfo(DirOf(env, rowUid));
            if (!dir.Exists) return Results.Ok(Array.Empty<object>());
            return Results.Ok(dir.GetFiles()
                .OrderByDescending(f => f.LastWriteTime)
                .Select(Shape)
                .ToList());
        });

        // 올리기 (여러 개)
        app.MapPost("/api/rows/{rowUid:long}/files", async (PgPool db, HttpRequest req, long rowUid) =>
        {
            if (!req.HasFormContentType)
                return Results.BadRequest(new { error = "파일을 multipart/form-data 로 보내세요." });

            // 없는 행에 파일이 쌓이지 않도록 확인 — 오타로 만든 폴더는 아무도 찾지 못한다
            var exists = await db.QueryAsync(
                "select 1 as ok from public.hhip_wbs_wrk2 where row_uid = $1::bigint limit 1", [rowUid]);
            if (exists.Count == 0) return Results.BadRequest(new { error = $"존재하지 않는 대상입니다: {rowUid}" });

            var form = await req.ReadFormAsync();
            var files = form.Files;
            if (files.Count == 0) return Results.BadRequest(new { error = "첨부할 파일이 없습니다." });
            if (files.Count > MaxCount) return Results.BadRequest(new { error = $"한 번에 {MaxCount}개까지 올릴 수 있습니다." });

            var tooBig = files.FirstOrDefault(f => f.Length > MaxBytes);
            if (tooBig is not null)
                return Results.BadRequest(new { error = $"{tooBig.FileName} 이(가) 너무 큽니다. 파일당 25MB 까지." });

            var dir = DirOf(env, rowUid);
            Directory.CreateDirectory(dir);

            var saved = new List<object>();
            foreach (var f in files)
            {
                if (f.Length == 0) continue;
                var id = $"{DateTime.Now:yyyyMMddHHmmss}-{Guid.NewGuid():N}"[..22];
                var path = Path.Combine(dir, $"{id}{Sep}{SafeName(f.FileName)}");
                await using (var fs = File.Create(path)) await f.CopyToAsync(fs);
                saved.Add(Shape(new FileInfo(path)));
            }

            return saved.Count == 0
                ? Results.BadRequest(new { error = "빈 파일만 있습니다." })
                : Results.Ok(saved);
        });

        // 내려받기 — 무엇이든 첨부로만 내려 준다 (브라우저에서 열리지 않게)
        app.MapGet("/api/rows/{rowUid:long}/files/{fileId}", (long rowUid, string fileId) =>
        {
            var f = Find(env, rowUid, fileId);
            if (f is null) return Results.NotFound(new { error = "파일 없음" });
            return Results.File(f.FullName, "application/octet-stream", NameOf(f.Name));
        });

        // 지우기 — 되돌릴 수 없다. 원장에 줄을 세우는 것과 같은 무게라 Super 만 한다.
        app.MapDelete("/api/rows/{rowUid:long}/files/{fileId}", async (IpGate g, HttpContext ctx, long rowUid, string fileId) =>
        {
            if (!isSuper(await g.CheckAsync(ctx)))
                return Results.Json(new { error = "첨부 삭제는 Super 권한만 할 수 있습니다." }, statusCode: 403);

            var f = Find(env, rowUid, fileId);
            if (f is null) return Results.NotFound(new { error = "파일 없음" });
            f.Delete();

            // 빈 폴더는 남기지 않는다 — 보관함 화면에서 <0건짜리 줄>로 떠다닌다
            var dir = f.Directory;
            if (dir is not null && dir.Exists && dir.GetFileSystemInfos().Length == 0) dir.Delete();

            return Results.Ok(new { deleted = 1 });
        });
    }
}
