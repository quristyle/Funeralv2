-- ============================================================
--  hhip_wbs_wrk2.pv_test_case_id  —  ProjectView 단위테스트 코드
--
--  상세 목록에서 Activity ID 를 누르면 뜨는 메뉴의 <단위테스트 상세> 가 쓰는 값이다.
--    https://dev-wbs.hd.com/projectview/#/PGE_PSU_TestDetailPage?projectKey=AAC&testCaseId=AAC-TC793
--
--  ⚠️ 이 값은 ProjectView 가 주는 것이고 수집 경로가 아직 없다. 단위테스트 목록
--     (POST /projects/{pjt}/tests · DTS_PSU_00012) 의 응답을 받아 여기에 손으로 넣는다.
--     목록의 title 이 원장의 menu_nm 과 글자 그대로 같아서 그것으로 잇는다
--     (웹 화면의 [단위테스트 상태 변경] 도 같은 방식으로 잇는다 — TestStatusDialog.vue).
--
--  ⚠️ 캐시 테이블(hhip_wbs_pv)이 아니라 원장(hhip_wbs_wrk2)에 둔다. 캐시는 수집할 때마다
--     갈아엎히는데 이 값은 수집 경로가 없어 한 번 지워지면 되돌릴 데가 없기 때문이다.
--
--  몇 번을 돌려도 같다 (컬럼은 있으면 두고, 값은 덮어쓴다).
--  돌리는 법:  psql -h localhost -U postgres -d postgres -f db/pv_test_case_id.sql
--
--  받은 자료: 단위테스트 목록 65건 (testOrderId TO_a8a8b241…, 자재)
-- ============================================================

ALTER TABLE public.hhip_wbs_wrk2
  ADD COLUMN IF NOT EXISTS pv_test_case_id character varying(50);

COMMENT ON COLUMN public.hhip_wbs_wrk2.pv_test_case_id IS
  'ProjectView 단위테스트 코드(AAC-TC###). 단위테스트 상세 화면 주소를 만드는 데 쓴다. 단위테스트 목록의 title 과 menu_nm 을 맞춰 넣는다. 수집 경로 없음 - db/pv_test_case_id.sql 로 채운다';

-- 화면명(title) ↔ 원장(menu_nm) 으로 잇는다
with src (menu_nm, test_case_id) as (values
  ('[1110]자재 분류코드 관리', 'AAC-TC729'),
  ('[1290]HMD 고객 정보', 'AAC-TC730'),
  ('[12C0] 운송비 관리', 'AAC-TC731'),
  ('[2110]일반재 요청', 'AAC-TC732'),
  ('[2130]요청부서별 POR 리스트', 'AAC-TC733'),
  ('[2140]STOCK재 요청', 'AAC-TC734'),
  ('[2160] POR for Ship', 'AAC-TC735'),
  ('[2310]일반재 POR 접수', 'AAC-TC736'),
  ('[I210]견적 승인', 'AAC-TC737'),
  ('[I220]직발주 승인', 'AAC-TC738'),
  ('[I230]HMD 계약 승인', 'AAC-TC739'),
  ('[I240]HMD에 POR 전송 승인', 'AAC-TC740'),
  ('[1120]자재코드 관리', 'AAC-TC741'),
  ('[1140]일반 STOCK재', 'AAC-TC742'),
  ('[1170]자재 품목코드 관리', 'AAC-TC743'),
  ('[2540]수정 POR 이력', 'AAC-TC744'),
  ('[3320]구매 발주 관리', 'AAC-TC745'),
  ('[1210]위치/구역코드 관리', 'AAC-TC746'),
  ('[1240]HHIP 구매 담당자', 'AAC-TC747'),
  ('[1250]구매 담당자', 'AAC-TC748'),
  ('[1270]고객 정보', 'AAC-TC749'),
  ('[2170]강재 요청', 'AAC-TC750'),
  ('[2530]Por 한국 구매/설계 수정 요청', 'AAC-TC751'),
  ('[2550]BOM 변경 요청 및 확인', 'AAC-TC752'),
  ('[3110]견적', 'AAC-TC753'),
  ('[3120]재견적', 'AAC-TC754'),
  ('[3130]가격표시', 'AAC-TC755'),
  ('[3150]입찰', 'AAC-TC756'),
  ('[3160]재입찰', 'AAC-TC757'),
  ('[3170]승인 대기', 'AAC-TC758'),
  ('[3180]구매 발주', 'AAC-TC759'),
  ('[38B0]미발주 POR', 'AAC-TC760'),
  ('[3B20]수정 견적/POR 요청', 'AAC-TC761'),
  ('[3B30]수정 견적/POR 승인', 'AAC-TC762'),
  ('[3D30]신규 견적용 POR 선택', 'AAC-TC763'),
  ('[36A0]HMD 선적정보 생성', 'AAC-TC764'),
  ('[3680]선적별 공급 계약', 'AAC-TC765'),
  ('[3670]공급 계약', 'AAC-TC766'),
  ('[3610]HMD로부터 계약서 접수', 'AAC-TC767'),
  ('[3420]견적 현황', 'AAC-TC768'),
  ('[3410]HMD 견적', 'AAC-TC769'),
  ('[3340]구매 발주 상태 검색', 'AAC-TC770'),
  ('[3330]구매 발주 (해외)', 'AAC-TC771'),
  ('[3310]구매 발주', 'AAC-TC772'),
  ('[3210]의사결정 리스트', 'AAC-TC773'),
  ('[3030]장기 계약 Follow-Up 보고', 'AAC-TC774'),
  ('[3010]장기 계약 자재 등록', 'AAC-TC775'),
  ('[3640]계약서 비교', 'AAC-TC776'),
  ('[3D40]견적 상세 정보', 'AAC-TC777'),
  ('[3D50]견적 비교', 'AAC-TC778'),
  ('[3G10]계약서 파일 관리', 'AAC-TC779'),
  ('[3G20]계약서 샘플 관리', 'AAC-TC780'),
  ('[A110]Follow-Up', 'AAC-TC781'),
  ('[A120]Follow-Up 리스트', 'AAC-TC782'),
  ('[I250]POR 서비스 엔지니어 승인', 'AAC-TC783'),
  ('[I260] 견적 연장', 'AAC-TC784'),
  ('[M110] 자재 실행 예산 관리', 'AAC-TC785'),
  ('[M120]년간 예산등록', 'AAC-TC786'),
  ('[M130]월별 예산편성', 'AAC-TC787'),
  ('[M140]예산 코드 관리', 'AAC-TC788'),
  ('[M221]예산전용 관리', 'AAC-TC789'),
  ('[B420]BOM별 자재 리스트', 'AAC-TC790'),
  ('[M122] 자재 입고 집행 현황', 'AAC-TC791'),
  ('[M232]부서별 예산대비 실적 상세현황', 'AAC-TC792'),
  ('[4190]국내자재 입고', 'AAC-TC793')
)
update public.hhip_wbs_wrk2 w
   set pv_test_case_id = src.test_case_id
  from src
 where w.menu_nm = src.menu_nm
   and w.pv_test_case_id is distinct from src.test_case_id;

-- 넣은 결과를 눈으로 본다. <못 찾은 화면명> 이 나오면 원장의 menu_nm 과 다른 것이다.
select count(*) filter (where pv_test_case_id is not null) as 테스트있음
     , count(*) filter (where pv_test_case_id is null)     as 테스트없음
     , count(*)                                            as 전체
  from public.hhip_wbs_wrk2;
