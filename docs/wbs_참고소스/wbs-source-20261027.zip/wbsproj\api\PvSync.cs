using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace WbsApi;

/// <summary>
/// ProjectView → WBS 대시보드 날짜 동기화 (읽기 방향).
///
/// 값을 가져오는 길은 두 가지다.
///  - 파일: ProjectView 의 Excel Export 를 모아 두는 폴더에서 가장 최근 파일을 읽는다 (기본).
///    엑셀은 HHI DRM 으로 암호화되어 있어 프로그램이 직접 열 수 없다. Excel COM 으로 CSV 를 만드는
///    tools/export2csv.ps1 을 자동으로 돌린 뒤 그 CSV 를 읽는다.
///  - JSON: ProjectView 콘솔에서 수집 스크립트를 돌려 나온 JSON 을 붙여넣는다 (대체 경로).
///
/// 어느 쪽이든 ProjectView 는 조회만 하고 고치지 않는다.
/// </summary>
public static partial class PvSync
{
    // ProjectView 필드 → hhip_wbs_wrk2 컬럼
    private static readonly (string Pv, string Col, string Label)[] MapCols =
    [
        ("planStartDate",   "plan_sdt",   "시작일"),
        ("planEndDate",     "plan_edt",   "종료일"),
        ("actualStartDate", "plan_sdt_c", "실적시작"),
        ("actualEndDate",   "plan_edt_c", "실적종료"),
    ];

    // 엑셀 Export 의 머리글 → ProjectView 필드. '* ' 접두사와 공백은 떼고 비교한다.
    private static readonly Dictionary<string, string> HeadMap = new()
    {
        ["ActivityID"] = "code",
        ["계획시작일"] = "planStartDate",
        ["계획종료일"] = "planEndDate",
        ["실적시작일"] = "actualStartDate",
        ["실적종료일"] = "actualEndDate",
    };

    private sealed record InItem(string Code, string? PlanStart, string? PlanEnd, string? ActStart, string? ActEnd)
    {
        public string? Get(string pv) => pv switch
        {
            "planStartDate" => PlanStart,
            "planEndDate" => PlanEnd,
            "actualStartDate" => ActStart,
            _ => ActEnd,
        };
    }

    private sealed record Cur(string ActivityId, string? SystemCode, string? MenuNm, int Dup, Dictionary<string, string?> Vals);
    private sealed record Change(string Col, string Label, string? From, string? To);
    private sealed record DiffRow(string ActivityId, string? SystemCode, string? MenuNm, int Dup, List<Change> Changes);
    private sealed record Source(string Kind, string? File, string? Modified, int Count, string? Note);

    // ---------------------------------------------------------------- 값 정리

    /// <summary>'2026-08-31' / '2026-08-31T00:00:00' 을 날짜만 남긴다. 빈 값·형식 오류는 null.</summary>
    private static string? Day(string? s)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        s = s.Trim();
        if (s.Length > 10) s = s[..10];
        return DateOnly.TryParse(s, out var d) ? d.ToString("yyyy-MM-dd") : null;
    }

    private static string? Day(JsonElement el) =>
        el.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined ? null
        : Day(el.ValueKind == JsonValueKind.String ? el.GetString() : el.ToString());

    /// <summary>머리글 비교용 정규화 — '* 계획시작일' → '계획시작일', 'Activity ID' → 'ActivityID'</summary>
    private static string NormHead(string s) =>
        new string(s.Where(c => !char.IsWhiteSpace(c)).ToArray()).TrimStart('*');

    // ---------------------------------------------------------------- CSV

    /// <summary>RFC4180 CSV 파서 (따옴표 안의 줄바꿈·쉼표 포함).</summary>
    private static List<List<string>> ParseCsv(string text)
    {
        var rows = new List<List<string>>();
        var row = new List<string>();
        var sb = new StringBuilder();
        var quoted = false;

        for (var i = 0; i < text.Length; i++)
        {
            var c = text[i];
            if (quoted)
            {
                if (c == '"')
                {
                    if (i + 1 < text.Length && text[i + 1] == '"') { sb.Append('"'); i++; }
                    else quoted = false;
                }
                else sb.Append(c);
                continue;
            }

            switch (c)
            {
                case '"': quoted = true; break;
                case ',': row.Add(sb.ToString()); sb.Clear(); break;
                case '\r': break;
                case '\n':
                    row.Add(sb.ToString()); sb.Clear();
                    rows.Add(row); row = [];
                    break;
                default: sb.Append(c); break;
            }
        }
        if (sb.Length > 0 || row.Count > 0) { row.Add(sb.ToString()); rows.Add(row); }
        return rows;
    }

    /// <summary>
    /// Export CSV 를 항목으로 바꾼다.
    /// 파일 앞머리에 안내문 행이 있어 'Activity ID' 가 있는 줄을 머리글로 잡는다.
    /// </summary>
    private static List<InItem> FromCsv(string path, out string note, out HashSet<string> found)
    {
        var text = File.ReadAllText(path, Encoding.UTF8);
        var rows = ParseCsv(text);

        var head = -1;
        for (var i = 0; i < rows.Count && i < 30; i++)
            if (rows[i].Any(c => NormHead(c).Equals("ActivityID", StringComparison.OrdinalIgnoreCase))) { head = i; break; }

        if (head < 0)
            throw new InvalidOperationException(
                "'Activity ID' 머리글을 찾지 못했습니다. ProjectView 의 Excel Export 파일이 맞는지, " +
                "CSV 가 UTF-8 로 저장되었는지 확인하세요.");

        // 머리글 → 열 번호
        var col = new Dictionary<string, int>();
        for (var c = 0; c < rows[head].Count; c++)
        {
            var key = NormHead(rows[head][c]);
            if (HeadMap.TryGetValue(key, out var field) && !col.ContainsKey(field)) col[field] = c;
        }

        var missing = HeadMap.Values.Where(f => !col.ContainsKey(f)).ToList();
        if (missing.Contains("code"))
            throw new InvalidOperationException("Activity ID 열을 찾지 못했습니다.");

        // 파일에 없던 날짜 항목은 '비었다'가 아니라 '모른다' 이므로 반영 대상에서 뺀다.
        // (머리글이 바뀐 파일로 전체 컬럼이 지워지는 사고를 막는다)
        found = col.Keys.Where(k => k != "code").ToHashSet();

        string? Cell(List<string> r, string field) =>
            col.TryGetValue(field, out var c) && c < r.Count ? r[c] : null;

        var items = new List<InItem>();
        for (var i = head + 1; i < rows.Count; i++)
        {
            var r = rows[i];
            var code = Cell(r, "code")?.Trim();
            if (string.IsNullOrWhiteSpace(code)) continue;
            items.Add(new InItem(code,
                Day(Cell(r, "planStartDate")), Day(Cell(r, "planEndDate")),
                Day(Cell(r, "actualStartDate")), Day(Cell(r, "actualEndDate"))));
        }

        note = missing.Count > 0 ? $"머리글에 없는 항목: {string.Join(", ", missing)}" : "";
        return items;
    }

    // ---------------------------------------------------------------- 파일 고르기

    private static string ExportDir(IConfiguration cfg) =>
        cfg["PvSync:ExportDir"] ?? @"D:\수빅자재\projectview_exports";

    private static string ScriptPath(IWebHostEnvironment env) =>
        Path.GetFullPath(Path.Combine(env.ContentRootPath, "..", "tools", "export2csv.ps1"));

    /// <summary>DRM 으로 잠긴 파일인지 (HHI DRM 은 앞머리에 'HHIDRMC' 를 남긴다).</summary>
    private static bool IsDrm(string path)
    {
        try
        {
            using var fs = File.OpenRead(path);
            var buf = new byte[7];
            return fs.Read(buf, 0, 7) == 7 && Encoding.ASCII.GetString(buf) == "HHIDRMC";
        }
        catch { return false; }
    }

    /// <summary>폴더에서 가장 최근 Export 를 찾는다. CSV 가 없으면 Excel COM 스크립트로 만들어 낸다.</summary>
    private static (string Csv, string Src, DateTime Modified, string Note) NewestCsv(
        IConfiguration cfg, IWebHostEnvironment env, bool convert)
    {
        var dir = ExportDir(cfg);
        if (!Directory.Exists(dir))
            throw new InvalidOperationException($"Export 폴더가 없습니다: {dir}");

        var files = new DirectoryInfo(dir).GetFiles()
            .Where(f => f.Extension.Equals(".csv", StringComparison.OrdinalIgnoreCase)
                     || f.Extension.StartsWith(".xls", StringComparison.OrdinalIgnoreCase))
            .ToList();
        if (files.Count == 0)
            throw new InvalidOperationException($"Export 파일이 없습니다: {dir}");

        // 같은 이름의 xlsx/csv 는 한 벌로 보고, 가장 최근에 받은 벌을 고른다
        var newest = files
            .GroupBy(f => Path.GetFileNameWithoutExtension(f.Name), StringComparer.OrdinalIgnoreCase)
            .OrderByDescending(g => g.Max(f => f.LastWriteTime))
            .ThenByDescending(g => g.Key, StringComparer.Ordinal)
            .First();

        var csv = newest.FirstOrDefault(f => f.Extension.Equals(".csv", StringComparison.OrdinalIgnoreCase));
        var xls = newest.FirstOrDefault(f => f.Extension.StartsWith(".xls", StringComparison.OrdinalIgnoreCase));
        var note = "";

        // 엑셀이 CSV 보다 새로우면 다시 변환한다
        var stale = csv is not null && xls is not null && xls.LastWriteTime > csv.LastWriteTime.AddSeconds(1);
        if (csv is null || stale)
        {
            if (xls is null) throw new InvalidOperationException("읽을 수 있는 CSV 가 없습니다.");
            if (!convert)
                throw new InvalidOperationException(
                    $"CSV 가 없습니다: {xls.Name}. [최신 파일 다시 읽기] 를 누르거나 " +
                    "tools\\export2csv.ps1 을 실행해 CSV 를 만드세요.");

            RunConverter(env, dir, xls.Name);
            csv = new FileInfo(Path.ChangeExtension(xls.FullName, ".csv"));
            if (!csv.Exists)
                throw new InvalidOperationException(
                    $"CSV 변환에 실패했습니다: {xls.Name}" +
                    (IsDrm(xls.FullName) ? " (DRM 으로 잠긴 파일입니다. Excel 이 설치된 계정에서 변환해야 합니다.)" : ""));
            note = $"{xls.Name} 을(를) CSV 로 변환했습니다.";
        }

        return (csv.FullName, (xls ?? csv).Name, (xls ?? csv).LastWriteTime, note);
    }

    /// <summary>Excel COM 으로 xlsx → csv 변환 (DRM 은 Excel 이 사용자 권한으로 풀어 준다).</summary>
    private static void RunConverter(IWebHostEnvironment env, string dir, string fileName)
    {
        var script = ScriptPath(env);
        if (!File.Exists(script)) throw new InvalidOperationException($"변환 스크립트가 없습니다: {script}");

        var psi = new ProcessStartInfo("powershell.exe")
        {
            Arguments = $"-NoProfile -ExecutionPolicy Bypass -File \"{script}\" -Dir \"{dir}\"",
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
        };

        using var p = Process.Start(psi) ?? throw new InvalidOperationException("powershell 실행 실패");
        var so = p.StandardOutput.ReadToEndAsync();
        var se = p.StandardError.ReadToEndAsync();
        if (!p.WaitForExit(180_000))
        {
            try { p.Kill(true); } catch { /* 무시 */ }
            throw new InvalidOperationException($"CSV 변환이 3분 안에 끝나지 않았습니다: {fileName}");
        }
        if (p.ExitCode != 0)
            throw new InvalidOperationException($"CSV 변환 오류: {se.Result.Trim()}{so.Result.Trim()}");
    }

    // ---------------------------------------------------------------- DB

    private static async Task<Dictionary<string, Cur>> LoadAsync(PgPool db)
    {
        var rows = await db.QueryAsync("""
            select activity_id
                 , max(systemcode)       as systemcode
                 , max(menu_nm)          as menu_nm
                 , count(*)              as dup
                 , max(plan_sdt)::text   as plan_sdt
                 , max(plan_edt)::text   as plan_edt
                 , max(plan_sdt_c)::text as plan_sdt_c
                 , max(plan_edt_c)::text as plan_edt_c
              from public.hhip_wbs_wrk2
             where activity_id is not null and activity_id <> ''
             group by activity_id
            """);

        var map = new Dictionary<string, Cur>(StringComparer.OrdinalIgnoreCase);
        foreach (var r in rows)
        {
            var id = r["activity_id"]?.ToString() ?? "";
            if (id.Length == 0) continue;
            var vals = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
            foreach (var (_, col, _) in MapCols) vals[col] = r[col]?.ToString();
            map[id] = new Cur(id, r["systemcode"]?.ToString(), r["menu_nm"]?.ToString(),
                              int.TryParse(r["dup"]?.ToString(), out var n) ? n : 1, vals);
        }
        return map;
    }

    // ---------------------------------------------------------------- 비교

    private static List<InItem> FromJson(JsonElement items)
    {
        var list = new List<InItem>();
        if (items.ValueKind != JsonValueKind.Array) return list;
        foreach (var it in items.EnumerateArray())
        {
            if (it.ValueKind != JsonValueKind.Object) continue;
            var code = it.TryGetProperty("code", out var c) ? c.GetString()?.Trim() : null;
            if (string.IsNullOrWhiteSpace(code)) continue;
            string? D(string k) => it.TryGetProperty(k, out var v) ? Day(v) : null;
            list.Add(new InItem(code, D("planStartDate"), D("planEndDate"), D("actualStartDate"), D("actualEndDate")));
        }
        return list;
    }

    /// <summary>보내온 항목과 DB 를 비교한다. 미리보기와 적용이 같은 계산을 쓴다.</summary>
    private static (List<DiffRow> Rows, List<string> Unknown) Diff(
        List<InItem> items, List<string> cols, bool clearEmpty, Dictionary<string, Cur> db)
    {
        var rows = new List<DiffRow>();
        var unknown = new List<string>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var it in items)
        {
            if (!seen.Add(it.Code)) continue;
            if (!db.TryGetValue(it.Code, out var cur)) { unknown.Add(it.Code); continue; }

            var chs = new List<Change>();
            foreach (var (pv, col, label) in MapCols)
            {
                if (!cols.Contains(col)) continue;
                var to = it.Get(pv);
                if (to is null && !clearEmpty) continue;
                var from = cur.Vals[col];
                if (string.Equals(from, to, StringComparison.Ordinal)) continue;
                chs.Add(new Change(col, label, from, to));
            }
            rows.Add(new DiffRow(cur.ActivityId, cur.SystemCode, cur.MenuNm, cur.Dup, chs));
        }
        return (rows, unknown);
    }

    /// <summary>
    /// ProjectView 가 빈 값이면 대시보드도 비운다 — 날짜의 기준이 ProjectView 이므로 기본값은 true.
    /// (명시적으로 false 를 보낸 경우에만 기존 값을 남긴다)
    /// </summary>
    private static bool ClearEmpty(JsonElement body) =>
        !body.TryGetProperty("clearEmpty", out var ce) || ce.ValueKind != JsonValueKind.False;

    private static List<string> Fields(JsonElement body)

    {
        var cols = new List<string>();
        if (body.TryGetProperty("fields", out var f) && f.ValueKind == JsonValueKind.Array)
            foreach (var x in f.EnumerateArray())
            {
                var v = x.GetString();
                if (v is not null && MapCols.Any(m => m.Col == v) && !cols.Contains(v)) cols.Add(v);
            }
        if (cols.Count == 0) cols.AddRange(MapCols.Select(m => m.Col));
        return cols;
    }

    /// <summary>본문의 source 에 따라 파일 또는 붙여넣은 JSON 에서 항목을 만든다.</summary>
    private static (List<InItem> Items, Source Src, HashSet<string>? Found) Read(
        JsonElement body, IConfiguration cfg, IWebHostEnvironment env)
    {
        var useJson = body.TryGetProperty("source", out var s) && s.GetString() == "json";
        if (useJson)
        {
            var items = body.TryGetProperty("items", out var i) ? FromJson(i) : [];
            return (items, new Source("json", null, null, items.Count, null), null);
        }

        var convert = !body.TryGetProperty("convert", out var cv) || cv.ValueKind != JsonValueKind.False;
        var (csv, src, mod, note) = NewestCsv(cfg, env, convert);
        var list = FromCsv(csv, out var headNote, out var found);
        var full = string.Join(" ", new[] { note, headNote }.Where(x => !string.IsNullOrEmpty(x)));
        return (list, new Source("file", src, mod.ToString("yyyy-MM-dd HH:mm"), list.Count, full), found);
    }

    /// <summary>파일에 없던 항목은 반영 대상에서 뺀다 (found 가 null 이면 제한하지 않는다).</summary>
    private static List<string> Limit(List<string> cols, HashSet<string>? found)
    {
        if (found is null) return cols;
        return cols.Where(c => found.Contains(MapCols.First(m => m.Col == c).Pv)).ToList();
    }

    private static object Shape(DiffRow r) => new

    {
        activity_id = r.ActivityId,
        systemcode = r.SystemCode,
        menu_nm = r.MenuNm,
        dup = r.Dup,
        changes = r.Changes.Select(c => new { col = c.Col, label = c.Label, from = c.From, to = c.To }),
    };

    // ---------------------------------------------------------------- 엔드포인트

    public static void Map(WebApplication app)
    {
        var cfg = app.Configuration;
        var env = app.Environment;

        // 폴더에 어떤 파일이 있는지 (변환은 하지 않는다)
        app.MapGet("/api/pv-sync/files", () =>
        {
            var dir = ExportDir(cfg);
            if (!Directory.Exists(dir)) return Results.Ok(new { dir, exists = false, files = Array.Empty<object>() });

            var files = new DirectoryInfo(dir).GetFiles()
                .Where(f => f.Extension.Equals(".csv", StringComparison.OrdinalIgnoreCase)
                         || f.Extension.StartsWith(".xls", StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(f => f.LastWriteTime)
                .Take(20)
                .Select(f => new
                {
                    name = f.Name,
                    size = f.Length,
                    modified = f.LastWriteTime.ToString("yyyy-MM-dd HH:mm"),
                    drm = f.Extension.StartsWith(".xls", StringComparison.OrdinalIgnoreCase) && IsDrm(f.FullName),
                })
                .ToList();
            return Results.Ok(new { dir, exists = true, files });
        });

        // 무엇이 바뀌는지 먼저 보여 준다 (DB 는 건드리지 않음)
        app.MapPost("/api/pv-sync/preview", async (PgPool db, JsonElement body) =>
        {
            var (items, src, found) = Read(body, cfg, env);
            var cols = Limit(Fields(body), found);
            var clearEmpty = ClearEmpty(body);

            var cur = await LoadAsync(db);
            var (rows, unknown) = Diff(items, cols, clearEmpty, cur);

            var sent = rows.Select(r => r.ActivityId).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var missing = cur.Values.Where(r => !sent.Contains(r.ActivityId))
                                    .OrderBy(r => r.ActivityId, StringComparer.Ordinal)
                                    .Select(r => new { activity_id = r.ActivityId, menu_nm = r.MenuNm })
                                    .ToList();

            return Results.Ok(new
            {
                source = src,
                fields = cols,
                clear_empty = clearEmpty,
                read = items.Count,
                matched = rows.Count,
                changed = rows.Count(r => r.Changes.Count > 0),
                same = rows.Count(r => r.Changes.Count == 0),
                unknown_count = unknown.Count,
                unknown = unknown.Take(50),
                missing_count = missing.Count,
                missing = missing.Take(300),
                rows = rows.Where(r => r.Changes.Count > 0).Select(Shape),
            });
        });

        // 실제 반영 — 바뀌는 컬럼만 UPDATE 한다
        app.MapPost("/api/pv-sync/apply", async (PgPool db, JsonElement body) =>
        {
            var (items, src, found) = Read(body, cfg, env);
            var cols = Limit(Fields(body), found);
            var clearEmpty = ClearEmpty(body);

            var cur = await LoadAsync(db);
            var (rows, unknown) = Diff(items, cols, clearEmpty, cur);

            var applied = 0;
            var affected = 0;
            var done = new List<object>();

            foreach (var r in rows)
            {
                if (r.Changes.Count == 0) continue;

                var sets = new List<string>();
                var args = new List<object?>();
                foreach (var ch in r.Changes)
                {
                    args.Add(ch.To);
                    sets.Add($"{ch.Col} = ${args.Count}::date");
                }
                args.Add(r.ActivityId);

                var n = await db.ExecuteAsync(
                    $"update public.hhip_wbs_wrk2 set {string.Join(", ", sets)} where activity_id = ${args.Count}::text",
                    args.ToArray());

                applied++;
                affected += n;
                done.Add(Shape(r));
            }

            return Results.Ok(new
            {
                source = src,
                fields = cols,
                clear_empty = clearEmpty,
                matched = rows.Count,
                applied,        // 바뀐 activity_id 수
                affected,       // 실제 UPDATE 된 행 수 (중복 activity_id 포함)
                unknown_count = unknown.Count,
                done,
            });
        });
    }
}
