@echo off
rem Share mode: build front into api\wwwroot, serve UI + API on port 5080
pushd "%~dp0web"
if errorlevel 1 goto err
call npm run build
if errorlevel 1 goto err
popd
pushd "%~dp0api"
if errorlevel 1 goto err
echo.
echo   [SHARE] http://10.13.45.51:5080
echo.
dotnet run -c Release
popd
goto :eof
:err
echo build failed
popd
