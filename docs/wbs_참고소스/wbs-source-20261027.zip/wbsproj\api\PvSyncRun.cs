using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace WbsApi;

/// <summary>
/// 동기화 파이프라인 — 버튼 하나로
/// [ProjectView 내려받기 → 내려받은 파일 회수 → CSV 변환 → 읽기 → 비교 → 반영] 을 잇는다.
/// 각 단계는 SyncJob 에 기록되어 화면에서 진행 상황으로 보인다.
///
/// 내려받기는 서버가 ProjectView 를 직접 호출한다(브라우저와 달리 mixed content 제약이 없다).
/// 다만 로그인 자격이 필요해 promise-token 을 등록해 두어야 하며, 토큰이 없으면 이 단계는
/// 건너뛰고 브라우저 다운로드 폴더에 떨어진 파일을 주워 오는 경로로 진행한다.
/// </summary>
public static partial class PvSync
{
    private const string S0 = "ProjectView 내려받기";
    private const string S1 = "내려받은 파일 회수";

    private const string S2 = "CSV 변환";
    private const string S3 = "파일 읽기";
    private const string S4 = "대시보드와 비교";
    private const string S5 = "반영";

    private static string BaseUrl(IConfiguration cfg) => cfg["PvSync:BaseUrl"] ?? "https://dev-wbs.hd.com";
    private static string ProjectId(IConfiguration cfg) =>
        cfg["PvSync:ProjectId"] ?? "PJT_ab8c9a42-204e-417d-b206-657bc268373f";

    // ProjectView 는 사내 인증서(SDS.ACT Root, CN=*.projectview.io)를 쓴다.
    // 공인 CA 가 아니고 호스트명도 맞지 않아 .NET 기본 검증을 통과하지 못하므로,
    // '아무 인증서나 허용' 대신 이 서버의 인증서 지문만 허용한다(핀 고정).
    // 인증서가 교체되면 여기 값을 바꿔야 하며, appsettings 로도 지정할 수 있다.
    private const string DefaultPin = "4E7B02720ECCF16FA8E0C941EE03E8B796C2F2D15930E58D58CDAFF7F3E0BAA1";
    private static string? _pin;

    private static readonly HttpClient Http = new(new HttpClientHandler
    {
        ServerCertificateCustomValidationCallback = (_, cert, _, errors) =>
        {
            if (errors == System.Net.Security.SslPolicyErrors.None) return true;
            if (cert is null) return false;
            var thumb = Convert.ToHexString(SHA256.HashData(cert.RawData));
            return string.Equals(thumb, _pin ?? DefaultPin, StringComparison.OrdinalIgnoreCase);
        },
    })
    { Timeout = TimeSpan.FromMinutes(3) };


    /// <summary>
    /// ProjectView 에서 Excel Export 를 직접 내려받아 보관 폴더에 저장한다.
    /// 로그인 토큰(promise-token)이 등록되어 있어야 한다.
    /// </summary>
    private static async Task<string> DownloadAsync(IConfiguration cfg)
    {
        _pin = cfg["PvSync:CertPin"];
        var token = PvToken.Value;
        if (string.IsNullOrEmpty(token))
            return "토큰이 등록되어 있지 않아 건너뜁니다. 폴더에 있는 파일로 진행합니다.";

        var url = $"{BaseUrl(cfg).TrimEnd('/')}/projectview/api/v1/promise/projects/{ProjectId(cfg)}" +
                  "/works/export-excel?pageId=PGE_PSW_WorkPage&dataServiceId=DTS_PSW_00021";

        using var req = new HttpRequestMessage(HttpMethod.Post, url);
        req.Headers.TryAddWithoutValidation("Cookie", $"promise-token={token}");
        req.Headers.TryAddWithoutValidation("x-portalid", "AAC");
        req.Headers.TryAddWithoutValidation("x-pageid", "PGE_PSW_WorkPage");
        req.Headers.TryAddWithoutValidation("x-dataserviceid", "DTS_PSW_00021");
        req.Headers.TryAddWithoutValidation("x-skiperrorhandler", "N");
        req.Headers.Accept.ParseAdd("application/json, text/plain, */*");

        // 본문이 필요한 요청이면 appsettings 의 PvSync:ExportBody 에 넣어 둔다
        var body = cfg["PvSync:ExportBody"];
        if (!string.IsNullOrWhiteSpace(body))
            req.Content = new StringContent(body, Encoding.UTF8, "application/json");

        using var res = await Http.SendAsync(req);
        var bytes = await res.Content.ReadAsByteArrayAsync();

        if (!res.IsSuccessStatusCode)
        {
            var text = Encoding.UTF8.GetString(bytes, 0, Math.Min(bytes.Length, 400));
            if ((int)res.StatusCode is 401 or 403)
                throw new InvalidOperationException(
                    $"인증 실패({(int)res.StatusCode}) — promise-token 이 만료되었을 수 있습니다. 토큰을 다시 등록하세요.");
            throw new InvalidOperationException($"Export 요청 실패 {(int)res.StatusCode} {res.ReasonPhrase} · {text}");
        }

        // 엑셀이 아니라 JSON/HTML 이 돌아온 경우 (로그인 페이지 등)
        var isXls = bytes.Length > 8 &&
                    (Encoding.ASCII.GetString(bytes, 0, 2) == "PK" ||          // 일반 xlsx
                     Encoding.ASCII.GetString(bytes, 0, 7) == "HHIDRMC" ||     // DRM 으로 감싼 xlsx
                     bytes[0] == 0xD0);                                        // 구형 xls
        if (!isXls)
        {
            var text = Encoding.UTF8.GetString(bytes, 0, Math.Min(bytes.Length, 400));
            throw new InvalidOperationException(
                $"엑셀이 아닌 응답을 받았습니다 ({res.Content.Headers.ContentType}) · {text}");
        }

        var dir = ExportDir(cfg);
        Directory.CreateDirectory(dir);
        var name = $"WBS_{DateTime.Now:yyyyMMdd_HHmm}.xlsx";
        var path = Path.Combine(dir, name);
        await File.WriteAllBytesAsync(path, bytes);

        return $"{name} 내려받음 ({bytes.Length / 1024:N0} KB)";
    }

    /// <summary>다운로드 폴더 등에서 Export 를 주워 올 폴더 목록.</summary>

    private static string[] PickupDirs(IConfiguration cfg)
    {
        var v = cfg.GetSection("PvSync:PickupDirs").Get<string[]>();
        if (v is { Length: > 0 }) return v;
        return [Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads")];
    }

    /// <summary>주워 올 파일 이름 패턴. 엉뚱한 엑셀을 끌어오지 않도록 기본은 WBS*.xls*</summary>
    private static string PickupGlob(IConfiguration cfg) => cfg["PvSync:PickupGlob"] ?? "WBS*.xls*";

    /// <summary>
    /// 다운로드 폴더의 최신 Export 가 보관 폴더의 것보다 새로우면 복사해 온다.
    /// </summary>
    private static string Pickup(IConfiguration cfg)
    {
        var dir = ExportDir(cfg);
        Directory.CreateDirectory(dir);

        var newestHere = new DirectoryInfo(dir).GetFiles()
            .Where(f => f.Extension.StartsWith(".xls", StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(f => f.LastWriteTime)
            .FirstOrDefault();

        var glob = PickupGlob(cfg);
        var found = new List<FileInfo>();
        foreach (var src in PickupDirs(cfg))
        {
            if (!Directory.Exists(src)) continue;
            found.AddRange(new DirectoryInfo(src).GetFiles(glob));
        }

        var cand = found.OrderByDescending(f => f.LastWriteTime).FirstOrDefault();
        if (cand is null)
            return newestHere is null
                ? "받아 올 파일이 없습니다."
                : $"새로 내려받은 파일이 없습니다. 보관된 {newestHere.Name} 을 씁니다.";

        if (newestHere is not null && cand.LastWriteTime <= newestHere.LastWriteTime)
            return $"보관된 {newestHere.Name} 이 최신입니다.";

        var dest = Path.Combine(dir, cand.Name);
        // 같은 이름이 이미 있으면 뒤에 시각을 붙여 덮어쓰지 않는다
        if (File.Exists(dest))
            dest = Path.Combine(dir,
                $"{Path.GetFileNameWithoutExtension(cand.Name)}_{cand.LastWriteTime:HHmmss}{cand.Extension}");

        cand.CopyTo(dest, false);
        File.SetLastWriteTime(dest, cand.LastWriteTime);
        return $"{cand.Name} 을(를) 가져왔습니다 ({cand.DirectoryName}).";
    }

    /// <summary>파이프라인 본체. 실패하면 그 단계에 사유가 남는다.</summary>
    private static async Task RunPipelineAsync(
        SyncJob job, PgPool db, IConfiguration cfg, IWebHostEnvironment env,
        List<string> cols, bool clearEmpty, bool applyChanges, bool skipDownload)
    {
        try
        {
            // 내려받기 실패는 치명적이지 않다 — 폴더에 있는 파일로 계속 진행하고,
            // 단계에는 실패로 남겨 새 파일이 아니라는 것을 화면에서 알 수 있게 한다.
            var downloadFailed = (string?)null;
            if (skipDownload)
            {
                job.Skip(S0, "브라우저가 이미 내려받았습니다.");
            }
            else
            try
            {
                await job.RunAsync(S0, async () =>
                {
                    job.Detail(S0, await DownloadAsync(cfg));
                    return 0;
                });
            }
            catch (Exception ex)
            {
                downloadFailed = ex.Message;
            }

            await job.RunAsync(S1, () =>
            {
                job.Detail(S1, Pickup(cfg));
                return Task.FromResult(0);
            });

            var csv = await job.RunAsync(S2, () =>
            {
                var (path, src, mod, note) = NewestCsv(cfg, env, convert: true);
                job.Detail(S2, string.IsNullOrEmpty(note)
                    ? $"{Path.GetFileName(path)} 사용 (변환 불필요)"
                    : note);
                return Task.FromResult((path, src, mod));
            });

            HashSet<string>? found = null;
            var items = await job.RunAsync(S3, () =>
            {
                var list = FromCsv(csv.path, out var headNote, out found);
                job.Detail(S3, $"{csv.src} · {csv.mod:yyyy-MM-dd HH:mm} · {list.Count}건" +
                               (string.IsNullOrEmpty(headNote) ? "" : $" · {headNote}"));
                return Task.FromResult(list);
            });

            cols = Limit(cols, found);
            var (rows, unknown, cur) = await job.RunAsync(S4, async () =>
            {
                var db0 = await LoadAsync(db);
                var (rs, unk) = Diff(items, cols, clearEmpty, db0);
                var ch = rs.Count(r => r.Changes.Count > 0);
                job.Detail(S4, $"매칭 {rs.Count}건 · 변경 {ch}건 · 동일 {rs.Count - ch}건 · ProjectView 에만 {unk.Count}건");
                return (rs, unk, db0);
            });

            var changed = rows.Count(r => r.Changes.Count > 0);
            var applied = 0;
            var affected = 0;

            if (!applyChanges) job.Skip(S5, "미리보기만 선택 — 반영하지 않았습니다.");
            else if (changed == 0) job.Skip(S5, "바뀔 항목이 없습니다.");
            else
                await job.RunAsync(S5, async () =>
                {
                    foreach (var r in rows)
                    {
                        if (r.Changes.Count == 0) continue;
                        var sets = new List<string>();
                        var args = new List<object?>();
                        foreach (var ch in r.Changes)
                        {
                            args.Add(ch.To);
                            sets.Add($"{ch.Col} = ${args.Count}::date");
                        }
                        args.Add(r.ActivityId);
                        affected += await db.ExecuteAsync(
                            $"update public.hhip_wbs_wrk2 set {string.Join(", ", sets)} where activity_id = ${args.Count}::text",
                            args.ToArray());
                        applied++;
                    }
                    job.Detail(S5, $"{applied}건 반영 (행 {affected}개)");
                    return 0;
                });

            var missing = cur.Values.Where(c => rows.All(r => !string.Equals(r.ActivityId, c.ActivityId, StringComparison.OrdinalIgnoreCase)))
                                    .OrderBy(c => c.ActivityId, StringComparer.Ordinal)
                                    .Select(c => new { activity_id = c.ActivityId, menu_nm = c.MenuNm })
                                    .ToList();

            job.Finish(new
            {
                source = new { kind = "file", file = csv.src, modified = csv.mod.ToString("yyyy-MM-dd HH:mm"), note = downloadFailed is null ? null : $"내려받기 실패로 기존 파일을 사용했습니다: {downloadFailed}" },
                download_failed = downloadFailed,
                fields = cols,
                clear_empty = clearEmpty,
                read = items.Count,
                matched = rows.Count,
                changed,
                same = rows.Count - changed,
                applied,
                affected,
                unknown_count = unknown.Count,
                unknown = unknown.Take(50),
                missing_count = missing.Count,
                missing = missing.Take(300),
                // 반영했으면 '방금 바꾼 내역', 미리보기면 '바꿀 내역'
                rows = rows.Where(r => r.Changes.Count > 0).Select(Shape),
            });
        }
        catch (Exception ex)
        {
            job.Finish(null, ex.Message);
        }
    }

    public static void MapRun(WebApplication app)
    {
        var cfg = app.Configuration;
        var env = app.Environment;

        // 파이프라인 시작 — 곧바로 jobId 를 돌려주고 뒤에서 진행한다
        app.MapPost("/api/pv-sync/run", (PgPool db, JsonElement body) =>
        {
            var running = SyncJob.Running();
            if (running is not null)
                return Results.Ok(new { id = running.Id, already = true });

            var cols = Fields(body);
            var clearEmpty = ClearEmpty(body);
            // apply 를 명시하지 않으면 반영까지 한다 (버튼 하나로 끝내는 것이 목적)
            var applyChanges = !body.TryGetProperty("apply", out var ap) || ap.ValueKind != JsonValueKind.False;
            // 브라우저가 세션으로 직접 내려받아 올려 준 경우 서버는 내려받기를 건너뛴다
            var skipDownload = body.TryGetProperty("skipDownload", out var sd) && sd.ValueKind == JsonValueKind.True;

            var job = SyncJob.Create(S0, S1, S2, S3, S4, S5);
            _ = Task.Run(() => RunPipelineAsync(job, db, cfg, env, cols, clearEmpty, applyChanges, skipDownload));
            return Results.Ok(new { id = job.Id, already = false });
        });

        // 브라우저가 자기 세션으로 내려받은 Export 를 받아 보관 폴더에 저장한다.
        // (대시보드는 HTTP, ProjectView 는 HTTPS 인데 HTTP→HTTPS 호출은 막히지 않으므로
        //  화면에서 fetch 로 받아 이리로 올려 준다. 토큰이 필요 없는 경로다.)
        app.MapPost("/api/pv-sync/upload", async (HttpRequest req) =>
        {
            using var ms = new MemoryStream();
            await req.Body.CopyToAsync(ms);
            var bytes = ms.ToArray();

            if (bytes.Length < 512)
                return Results.BadRequest(new { error = $"파일이 너무 작습니다 ({bytes.Length} B)." });
            if (bytes.Length > 50 * 1024 * 1024)
                return Results.BadRequest(new { error = "50MB 이하만 올릴 수 있습니다." });

            var head2 = Encoding.ASCII.GetString(bytes, 0, 2);
            var head7 = Encoding.ASCII.GetString(bytes, 0, 7);
            if (head2 != "PK" && head7 != "HHIDRMC" && bytes[0] != 0xD0)
                return Results.BadRequest(new { error = "엑셀 파일이 아닙니다 (ProjectView 응답을 확인하세요)." });

            var dir = ExportDir(cfg);
            Directory.CreateDirectory(dir);
            var name = $"WBS_{DateTime.Now:yyyyMMdd_HHmm}.xlsx";
            await File.WriteAllBytesAsync(Path.Combine(dir, name), bytes);

            return Results.Ok(new { name, size = bytes.Length, drm = head7 == "HHIDRMC" });
        });

        // 화면이 ProjectView 를 직접 부를 때 필요한 값
        app.MapGet("/api/pv-sync/config", () => Results.Ok(new
        {
            baseUrl = BaseUrl(cfg),
            projectId = ProjectId(cfg),
            exportPath = $"/projectview/api/v1/promise/projects/{ProjectId(cfg)}/works/export-excel" +
                         "?pageId=PGE_PSW_WorkPage&dataServiceId=DTS_PSW_00021",
        }));

        // ProjectView 로그인 토큰 — 메모리에만 두고, 값은 돌려주지 않는다

        app.MapGet("/api/pv-sync/token", () => Results.Ok(PvToken.Status()));

        app.MapPost("/api/pv-sync/token", (JsonElement body) =>
        {
            var t = body.TryGetProperty("token", out var v) ? v.GetString() : null;
            // 'promise-token=xxx' 처럼 통째로 붙여넣어도 받아 준다
            if (t is not null)
            {
                t = t.Trim().Trim('"');
                var eq = t.IndexOf("promise-token=", StringComparison.OrdinalIgnoreCase);
                if (eq >= 0) t = t[(eq + "promise-token=".Length)..].Split(';')[0].Trim();
            }
            PvToken.Set(t);
            return Results.Ok(PvToken.Status());
        });

        // 진행 상황 폴링
        app.MapGet("/api/pv-sync/job/{id}", (string id) =>
        {
            var job = SyncJob.Get(id);
            return job is null
                ? Results.NotFound(new { error = "작업을 찾을 수 없습니다 (오래되어 정리되었을 수 있습니다)." })
                : Results.Ok(job.Snapshot());
        });
    }
}
