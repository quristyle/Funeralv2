using System.Text.Json;

namespace WbsApi;

/// <summary>
/// 도식(그래프) 한 장 — [테이블 계통도 · 편집] 화면(#/tables2)이 읽고 쓴다.
///
/// 담는 것은 <b>Vue Flow 가 그대로 먹는 모양</b>의 JSON 이다
/// (<c>{ nodes:[{id,position,data}], edges:[{id,source,target,label,data}], lanes, flows }</c>).
/// 화면이 쓰는 모양 그대로 두는 까닭: 서버가 따로 번역하면 화면을 고칠 때마다 서버도
/// 고쳐야 하고, 한쪽만 고치면 <b>저장은 됐는데 안 보이는</b> 고장이 조용히 난다.
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>왜 DB 가 아니라 파일인가.</b> 한 장짜리 도면이다. 통째로 복사해 가고, 백업하고,
/// 나중에 git 에 올릴 수도 있어야 한다. 파일이면 그 전부가 공짜다
/// (업무흐름 시나리오 <see cref="Flow"/> 와 같은 판단이다).
///
/// <b>왜 wwwroot 가 아닌가.</b> <c>npm run build</c> 가 <c>emptyOutDir</c> 로 wwwroot 를
/// 통째로 비운다. 거기 두면 <b>프런트를 빌드할 때마다 도면이 날아간다.</b>
///
/// <b>덮어쓰기 사고.</b> 두 사람이 같은 도면을 열어 두고 따로 저장하면 나중 사람이
/// 앞사람 것을 <b>조용히 지운다.</b> 그래서 읽을 때 <c>stamp</c>(파일 수정시각)를 주고,
/// 저장할 때 그것이 지금 수정시각과 다르면 <b>409 로 거절</b>하고 지금 도면을 함께 준다.
///
/// <b>기본 배치.</b> <c>tools/graph/gen-tables.mjs</c> 가 기존 화면(flow.html)에서 구워 둔
/// <c>tables.json</c> 이 <b>처음 모습</b>이다. 사람이 옮긴 자리는 그 파일을 덮어쓰며 쌓이고,
/// 되돌리고 싶으면 <c>seed</c> 사본에서 다시 가져온다 — 그래서 구운 직후 한 벌을 <c>.seed</c>
/// 로 떠 둔다. 떠 두지 않으면 <b>한 번 저장하는 순간 처음 모습이 사라진다.</b>
/// </summary>
public static class Graph
{
    private static string _dir = "";

    /// <summary>
    /// 다룰 도면들. 이름을 열쇠로 쓰되 <b>목록에 있는 것만</b> 받는다 — 경로 조작 방지.
    ///
    /// 스키마마다 한 장이다(<c>tables-m10</c> · <c>tables-m20</c>). 한 장에 둘을 섞지 않는 까닭:
    /// 같은 이름의 표가 두 스키마에 다 있어(M10 에도 M20 에도 <c>T30B_1120</c> 이 있다)
    /// 한 도면에 담으면 <b>어느 쪽 표인지 가릴 길이 없다.</b>
    /// 처음에는 M20 을 M10 의 사본으로 두고, 이후로는 따로 자란다.
    /// </summary>
    private static readonly HashSet<string> Known = ["tables-m10", "tables-m20"];

    public static void Init(string contentRoot)
    {
        _dir = Path.Combine(contentRoot, "data", "vueflow");
        Directory.CreateDirectory(_dir);

        // 구운 직후의 모습을 한 벌 떠 둔다. 이미 있으면 그대로 둔다 —
        // 여기서 덮으면 <기본 배치로> 가 <마지막 저장으로> 가 되어 버린다.
        foreach (var name in Known)
        {
            var live = Path.Combine(_dir, name + ".json");
            var seed = Path.Combine(_dir, name + ".seed.json");
            if (File.Exists(live) && !File.Exists(seed))
            {
                try { File.Copy(live, seed); }
                catch (Exception e) { Console.WriteLine($"[graph] seed 못 떴습니다 {name}: {e.Message}"); }
            }
        }
    }

    private static string PathOf(string name, bool seed = false) =>
        Path.Combine(_dir, name + (seed ? ".seed" : "") + ".json");

    /// <summary>
    /// 업무항목 — <b>도면과 따로</b> 둔다.
    ///
    /// 담는 것은 <c>{ v, items:[ {id, name, tables:[표 이름…]} ] }</c> 다.
    /// 업무 하나를 고르면 그 표들만 또렷해진다.
    ///
    /// <b>왜 도면 안(nodes 옆)에 넣지 않나.</b> <c>기본 배치로</c>(reset)가 도면을 seed 로
    /// 되돌린다. 도면 안에 넣어 두면 <b>자리 한 번 되돌렸다가 업무항목이 통째로 사라진다</b> —
    /// 칸의 자리는 언제든 다시 끌면 그만이지만, 업무항목은 사람이 모아 둔 것이라 되돌릴 데가 없다.
    /// 그 둘은 수명이 다르니 파일도 가른다.
    /// </summary>
    private static string ItemsPathOf(string name) => Path.Combine(_dir, name + ".items.json");

    /// <summary>파일 수정시각을 한 줄로. 이것이 <c>stamp</c> 다.</summary>
    private static string StampOf(string file) =>
        File.Exists(file) ? File.GetLastWriteTimeUtc(file).Ticks.ToString() : "0";

    public static void Map(WebApplication app)
    {
        // 도면 읽기. stamp 를 함께 준다 — 저장할 때 되돌려 받아야 한다.
        app.MapGet("/api/graph/{name}", (string name) =>
        {
            if (!Known.Contains(name)) return Results.NotFound(new { error = "그런 도면이 없습니다: " + name });
            var file = PathOf(name);
            if (!File.Exists(file))
            {
                // 아직 구운 적이 없다 — 어떻게 굽는지 알려 준다. 빈 화면만 띄우면 사람이 막힌다.
                return Results.NotFound(new
                {
                    error = "도면이 아직 없습니다. `node tools/graph/gen-tables.mjs` 로 한 번 구우세요.",
                });
            }
            return Results.Content(
                $"{{\"stamp\":\"{StampOf(file)}\",\"hasSeed\":{(File.Exists(PathOf(name, true)) ? "true" : "false")}," +
                $"\"graph\":{File.ReadAllText(file)}}}",
                "application/json");
        });

        // 저장. 본문은 { stamp, graph }.
        app.MapPut("/api/graph/{name}", async (IpGate g, HttpContext ctx, string name, JsonElement body) =>
        {
            if (!Known.Contains(name)) return Results.NotFound(new { error = "그런 도면이 없습니다: " + name });
            var file = PathOf(name);

            if (!body.TryGetProperty("graph", out var graph) || graph.ValueKind != JsonValueKind.Object)
                return Results.BadRequest(new { error = "graph 가 없습니다." });

            var sent = body.TryGetProperty("stamp", out var s) ? s.GetString() ?? "" : "";
            var now = StampOf(file);
            if (sent != now)
            {
                // 내가 읽은 뒤에 누군가 저장했다. 덮지 않고 <지금 것> 을 함께 돌려준다.
                return Results.Json(new
                {
                    error = "그 사이 다른 사람이 저장했습니다. 지금 도면을 받아 다시 맞춰 주세요.",
                    stamp = now,
                    graph = JsonDocument.Parse(File.ReadAllText(file)).RootElement,
                }, statusCode: 409);
            }

            var me = await g.CheckAsync(ctx);
            var who = me.Name ?? me.BpId ?? "미상";

            // 먼저 옆에 쓰고 바꿔 끼운다 — 쓰다가 끊기면 반쪽짜리 도면이 남는다.
            var tmp = file + ".tmp";
            var text = graph.GetRawText();
            await File.WriteAllTextAsync(tmp, text);
            File.Move(tmp, file, true);

            var n = graph.TryGetProperty("nodes", out var nn) && nn.ValueKind == JsonValueKind.Array ? nn.GetArrayLength() : 0;
            var e = graph.TryGetProperty("edges", out var ee) && ee.ValueKind == JsonValueKind.Array ? ee.GetArrayLength() : 0;
            Console.WriteLine($"[graph/save] {DateTime.Now:HH:mm:ss} {name} 칸={n} 이음선={e} by={who}");

            return Results.Ok(new { saved = true, stamp = StampOf(file), nodes = n, edges = e, by = who });
        });

        // 업무항목 읽기. 없으면 빈 목록을 준다 — 처음 쓰는 스키마에서 404 를 받아 화면이
        // 멈추면, 아무것도 안 만든 사람에게 고장으로 보인다.
        app.MapGet("/api/graph/{name}/items", (string name) =>
        {
            if (!Known.Contains(name)) return Results.NotFound(new { error = "그런 도면이 없습니다: " + name });
            var file = ItemsPathOf(name);
            var body = File.Exists(file) ? File.ReadAllText(file) : """{"v":1,"items":[]}""";
            return Results.Content($"{{\"stamp\":\"{StampOf(file)}\",\"data\":{body}}}", "application/json");
        });

        // 업무항목 저장. 본문은 { stamp, items }. 도면과 같은 규칙으로 덮어쓰기를 막는다.
        app.MapPut("/api/graph/{name}/items", async (IpGate g, HttpContext ctx, string name, JsonElement body) =>
        {
            if (!Known.Contains(name)) return Results.NotFound(new { error = "그런 도면이 없습니다: " + name });
            if (!body.TryGetProperty("items", out var arr) || arr.ValueKind != JsonValueKind.Array)
                return Results.BadRequest(new { error = "items 가 없습니다." });
            if (arr.GetArrayLength() > 200)
                return Results.BadRequest(new { error = "업무항목은 200개까지입니다." });

            var file = ItemsPathOf(name);
            var sent = body.TryGetProperty("stamp", out var s) ? s.GetString() ?? "" : "";
            var now = StampOf(file);
            if (sent != now)
            {
                // 내가 읽은 뒤에 누군가 고쳤다. 덮지 않고 <지금 것> 을 함께 돌려준다.
                return Results.Json(new
                {
                    error = "그 사이 다른 사람이 업무항목을 고쳤습니다.",
                    stamp = now,
                    data = File.Exists(file)
                        ? JsonDocument.Parse(File.ReadAllText(file)).RootElement
                        : JsonDocument.Parse("""{"v":1,"items":[]}""").RootElement,
                }, statusCode: 409);
            }

            // 받은 것을 그대로 적지 않는다 — 쓰는 칸만 추려 담는다.
            // 화면이 들고 다니는 군더더기(고른 상태 같은 것)가 파일에 눌어붙지 않게.
            var items = new List<object>();
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                var id = it.TryGetProperty("id", out var i0) ? i0.GetString() : null;
                var nm = it.TryGetProperty("name", out var n0) ? n0.GetString() : null;
                if (string.IsNullOrWhiteSpace(id)) continue;
                nm = (nm ?? "").Trim();
                if (nm.Length > 120) nm = nm[..120];

                var tables = new List<string>();
                if (it.TryGetProperty("tables", out var t0) && t0.ValueKind == JsonValueKind.Array)
                    foreach (var t in t0.EnumerateArray())
                    {
                        var v = t.GetString();
                        if (!string.IsNullOrWhiteSpace(v) && !tables.Contains(v)) tables.Add(v);
                        if (tables.Count >= 500) break;
                    }

                items.Add(new { id, name = nm.Length > 0 ? nm : "이름 없음", tables });
            }

            var me = await g.CheckAsync(ctx);
            var who = me.Name ?? me.BpId ?? "미상";

            // 먼저 옆에 쓰고 바꿔 끼운다 — 쓰다가 끊기면 반쪽짜리가 남는다.
            var tmp = file + ".tmp";
            await File.WriteAllTextAsync(tmp, JsonSerializer.Serialize(new { v = 1, items }));
            File.Move(tmp, file, true);

            Console.WriteLine($"[graph/items] {DateTime.Now:HH:mm:ss} {name} 업무항목={items.Count} by={who}");
            return Results.Ok(new { saved = true, stamp = StampOf(file), count = items.Count });
        });

        // 기본 배치로 — 구웠을 때의 모습으로 되돌린다. 지금 도면은 날아가므로 화면이 한 번 묻는다.
        app.MapPost("/api/graph/{name}/reset", async (IpGate g, HttpContext ctx, string name) =>
        {
            if (!Known.Contains(name)) return Results.NotFound(new { error = "그런 도면이 없습니다: " + name });
            var seed = PathOf(name, true);
            if (!File.Exists(seed))
                return Results.NotFound(new { error = "되돌릴 기본 배치가 없습니다 (seed 파일이 없습니다)." });

            var file = PathOf(name);
            // 되돌리기도 되돌릴 수 있게 — 지금 것을 한 벌 떠 두고 바꾼다
            if (File.Exists(file))
            {
                var bak = Path.Combine(_dir, $"{name}.{DateTime.Now:yyyyMMdd_HHmmss}.bak.json");
                try { File.Copy(file, bak); } catch { /* 떠 두지 못해도 되돌리기는 한다 */ }
            }
            File.Copy(seed, file, true);

            var me = await g.CheckAsync(ctx);
            Console.WriteLine($"[graph/reset] {DateTime.Now:HH:mm:ss} {name} by={me.Name ?? me.BpId}");
            return Results.Content(
                $"{{\"reset\":true,\"stamp\":\"{StampOf(file)}\",\"graph\":{File.ReadAllText(file)}}}",
                "application/json");
        });
    }
}
