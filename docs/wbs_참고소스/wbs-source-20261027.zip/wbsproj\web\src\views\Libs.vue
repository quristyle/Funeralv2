<script setup>
import { computed, ref } from 'vue'
import { api } from '../api'
import { useViewRefresh } from '../store'
import { copyText } from '../pvScript'
import RefreshBtn from '../components/RefreshBtn.vue'

// 라이브러리 저장소 — 사내 Nexus 에 무엇이 올라와 있나 (api/Nexus.cs).
//
// 탭이 둘이고, 답하는 질문이 다르다.
//   [PMM 사용]   pmm001~018 이 못 박아 둔 것만. 그 버전이 저장소에 아직 있는지,
//                더 새로 올라온 것이 있는지. 평소에는 이쪽만 보면 된다.
//   [저장소]     한 저장소를 통째로. 무엇이 몇 버전 쌓여 있는지 볼 때.
//
// 크기·등록일·올린 계정은 `npm view` 로는 안 나오는 값이다. 전부 Nexus REST 에서 온다.

const tab = ref('used')
const loading = ref(false)
const err = ref('')

const used = ref(null)
const repos = ref([])
const browse = ref(null)
const repo = ref('')

const q = ref('')
const only = ref('') // '' | 'inhouse' | 'fe' | 'be' | 'gone'
const open = ref(new Set())
const copied = ref('')

const mb = (n) => {
  if (n == null) return ''
  if (n >= 1024 * 1024 * 1024) return (n / 1024 / 1024 / 1024).toFixed(2) + ' GB'
  if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB'
  if (n >= 1024) return Math.round(n / 1024) + ' KB'
  return n + ' B'
}

/** 우리 것 — 사내에서 만들어 올린 라이브러리. 바깥에서 받아 둔 캐시와 구분한다. */
const inhouse = (k) => k.startsWith('@dxb/') || k.startsWith('@dxbuilder/') || k.startsWith('com.hd:')

async function load() {
  loading.value = true
  err.value = ''
  try {
    if (tab.value === 'used') {
      used.value = await api.nexusUsed()
    } else {
      if (!repos.value.length) {
        const r = await api.nexusRepos()
        repos.value = r.repos
        if (!repo.value) repo.value = (await api.nexusConfig()).default
      }
      browse.value = await api.nexusBrowse(repo.value)
    }
  } catch (e) {
    err.value = e.message
  } finally {
    loading.value = false
  }
}

/** 다시 조회 — 서버 캐시까지 버린다. 저장소가 방금 바뀐 것을 확인할 때 쓰는 버튼이다. */
async function force() {
  loading.value = true
  err.value = ''
  try {
    if (tab.value === 'used') used.value = await api.nexusUsed(true)
    else browse.value = await api.nexusBrowse(repo.value, true)
  } catch (e) {
    err.value = e.message
  } finally {
    loading.value = false
  }
}

async function go(t) {
  if (tab.value === t) return
  tab.value = t
  q.value = ''
  only.value = ''
  open.value = new Set()
  if ((t === 'used' && !used.value) || (t === 'browse' && !browse.value)) await load()
}

async function pickRepo(name) {
  repo.value = name
  browse.value = null
  open.value = new Set()
  await load()
}

function toggle(k) {
  const s = new Set(open.value)
  s.has(k) ? s.delete(k) : s.add(k)
  open.value = s
}

async function copy(text, mark) {
  if (await copyText(text)) {
    copied.value = mark
    setTimeout(() => (copied.value = ''), 1200)
  }
}

// ---------- [PMM 사용] ----------

const usedRows = computed(() => {
  const list = used.value?.items ?? []
  const s = q.value.trim().toLowerCase()
  return list.filter((i) => {
    if (s && !i.key.toLowerCase().includes(s)) return false
    if (only.value === 'inhouse' && !inhouse(i.key)) return false
    if (only.value === 'fe' && i.tier !== 'fe') return false
    if (only.value === 'be' && i.tier !== 'be') return false
    if (only.value === 'gone' && !i.gone?.length) return false
    return true
  })
})

const counts = computed(() => {
  const list = used.value?.items ?? []
  return {
    all: list.length,
    inhouse: list.filter((i) => inhouse(i.key)).length,
    fe: list.filter((i) => i.tier === 'fe').length,
    be: list.filter((i) => i.tier === 'be').length,
    gone: list.filter((i) => i.gone?.length).length,
  }
})

// ---------- [저장소] ----------

const hosted = computed(() => repos.value.filter((r) => r.type === 'hosted'))
const others = computed(() => repos.value.filter((r) => r.type !== 'hosted'))

const browseRows = computed(() => {
  const list = browse.value?.packages ?? []
  const s = q.value.trim().toLowerCase()
  return s ? list.filter((p) => p.key.toLowerCase().includes(s)) : list
})

// 묶음이 몇 개 안 되면 펼쳐서 보여 준다 — 한 번 더 누르게 할 까닭이 없다.
// 수백 개짜리 저장소를 통째로 펼치면 표가 수천 줄이 되므로 그때는 접는다.
const autoOpen = computed(() => browseRows.value.length <= 12)
const isOpen = (k) => open.value.has(k)

useViewRefresh(load)
load()
</script>

<template>
  <section class="panel head">
    <h2>
      라이브러리 저장소
      <span class="hint">{{ used?.at || browse?.at || '' }}{{ loading ? ' · 조회 중…' : '' }}</span>
      <span class="spacer"></span>
      <RefreshBtn :fn="force" label="" title="저장소를 지금 다시 조회 (서버 캐시 버림)" />
    </h2>

    <div class="tabs">
      <button :class="{ on: tab === 'used' }" @click="go('used')">PMM 사용</button>
      <button :class="{ on: tab === 'browse' }" @click="go('browse')">저장소 둘러보기</button>
    </div>

    <p class="muted note">
      사내 Nexus 에 올라와 있는 것을 <strong>REST API 로 직접</strong> 읽습니다 —
      <code>npm view</code> 는 로컬 캐시를 타 저장소가 비어 있어도 옛 목록을 보여 주고,
      <strong>크기 · 등록일시 · 올린 계정</strong>은 아예 알려 주지 않습니다.
    </p>

    <p v-if="err" class="error">{{ err }}</p>
  </section>

  <!-- ══════════════ PMM 사용 ══════════════ -->
  <template v-if="tab === 'used'">
    <section v-if="used" class="panel">
      <div class="cards">
        <button class="card" :class="{ on: only === '' }" @click="only = ''">
          <div class="k">전체 패키지</div>
          <div class="v">{{ counts.all }}</div>
          <div class="b">pmm001~018 이 직접 선언한 것</div>
        </button>
        <button class="card" :class="{ on: only === 'inhouse' }" @click="only = 'inhouse'">
          <div class="k">사내 라이브러리</div>
          <div class="v">{{ counts.inhouse }}</div>
          <div class="b">@dxb · com.hd — 우리가 올린 것</div>
        </button>
        <button class="card" :class="{ on: only === 'fe' }" @click="only = 'fe'">
          <div class="k">FE (npm)</div>
          <div class="v">{{ counts.fe }}</div>
          <div class="b">package.json</div>
        </button>
        <button class="card" :class="{ on: only === 'be' }" @click="only = 'be'">
          <div class="k">BE (maven)</div>
          <div class="v">{{ counts.be }}</div>
          <div class="b">build.gradle(.kts) · pom.xml</div>
        </button>
        <button
          class="card"
          :class="{ on: only === 'gone', bad: counts.gone > 0 }"
          title="선언한 버전이 저장소에 없습니다 — 새 러너에서 빌드가 깨지는 상태입니다"
          @click="only = 'gone'"
        >
          <div class="k">저장소에 없음</div>
          <div class="v">{{ counts.gone }}</div>
          <div class="b">물고 있는데 사라진 버전</div>
        </button>
      </div>

      <p class="muted scan">
        읽은 체크아웃 <strong>{{ used.scanned.modules }}개 모듈</strong>
        (FE {{ used.scanned.fe }} · BE {{ used.scanned.be }}) ·
        <span class="tip" title="lockfile·의존성 트리는 풀지 않습니다. 직접 선언한 것만 봅니다.">
          직접 선언한 의존성만
        </span>
      </p>
      <p v-if="used.scanned.problems.length" class="muted warnline">
        못 읽은 것 {{ used.scanned.problems.length }}건 — {{ used.scanned.problems.join(' · ') }}
      </p>
    </section>

    <section v-if="used" class="panel list">
      <h2>
        <span class="hint">{{ usedRows.length }}건<template v-if="q || only"> / 전체 {{ counts.all }}</template></span>
        <span class="spacer"></span>
        <input v-model="q" type="text" placeholder="패키지명 검색" />
      </h2>

      <div class="scroll">
        <table class="grp">
          <thead>
            <tr>
              <th class="w-nm">패키지</th>
              <th class="w-ver">쓰는 버전</th>
              <th class="num w-mod">모듈</th>
              <th class="num w-sz">크기</th>
              <th class="w-dt">등록</th>
              <th class="w-repo">저장소</th>
              <th class="w-st"></th>
            </tr>
          </thead>
          <tbody v-for="p in usedRows" :key="p.key">
            <tr class="ghd" :class="{ open: isOpen(p.key) }" @click="toggle(p.key)">
              <td class="nm">
                <span class="caret">{{ isOpen(p.key) ? '▾' : '▸' }}</span>
                <span class="eco" :class="p.eco">{{ p.eco }}</span>
                <b :class="{ ours: inhouse(p.key) }">{{ p.key }}</b>
              </td>
              <td>
                <span
                  v-for="w in p.want"
                  :key="w.spec"
                  class="tag want"
                  :class="{ loose: !w.exact, dev: w.kind === 'dev' }"
                  :title="`${w.modules.join(' · ')}${w.exact ? '' : ' — 범위 표기라 어느 판인지는 풀지 않았습니다'}`"
                >{{ w.spec }}<small v-if="w.modules.length > 1">×{{ w.modules.length }}</small></span>
              </td>
              <td class="num muted">{{ p.modules }}</td>
              <td class="num muted nowrap">{{ mb(p.pinned_size) }}</td>
              <td class="muted nowrap">{{ p.pinned_at || '—' }}</td>
              <td class="muted repo nowrap" :title="(p.repos || []).join(' · ')">
                {{ (p.repos || []).join(', ') || '—' }}
              </td>
              <td class="st nowrap">
                <span v-if="p.error" class="tag bad" :title="p.error">조회 실패</span>
                <span v-else-if="p.gone?.length" class="tag bad" title="선언한 버전이 저장소에 없습니다">없음</span>
                <span v-else-if="p.behind === 0" class="tag ok" title="저장소에서 가장 늦게 올라온 판입니다">최신</span>
                <span
                  v-else-if="p.behind > 0"
                  class="tag mid"
                  :title="`이 버전 뒤로 ${p.behind}개가 더 올라왔습니다 (최근 등록 ${p.newest} · ${p.newest_at})`"
                >+{{ p.behind }}</span>
                <span
                  v-if="p.tags?.latest"
                  class="tag dist"
                  :title="Object.entries(p.tags).map(([k, v]) => `${k} → ${v}`).join(' · ')"
                >latest {{ p.tags.latest }}</span>
              </td>
            </tr>

            <tr v-if="isOpen(p.key)" class="det">
              <td colspan="7">
                <p v-if="p.error" class="muted err">{{ p.error }}</p>
                <table v-else class="vers">
                  <thead>
                    <tr>
                      <th>버전</th>
                      <th class="num">크기</th>
                      <th>등록일시</th>
                      <th>올린 계정</th>
                      <th>마지막 내려받기</th>
                      <th>체크섬</th>
                      <th class="w-act"></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="v in p.list" :key="v.version + v.repository" :class="{ hit: v.used }">
                      <td class="vv">
                        <a v-if="v.url" :href="v.url" target="_blank" rel="noopener noreferrer">{{ v.version }}</a>
                        <span v-else>{{ v.version }}</span>
                        <span v-if="v.used" class="tag want">쓰는 중</span>
                      </td>
                      <td class="num muted nowrap" :title="`자산 ${v.assets}개 합계 ${mb(v.size_all)}`">
                        {{ mb(v.size) }}
                      </td>
                      <td class="muted nowrap">{{ v.modified }}</td>
                      <td class="muted nowrap">
                        {{ v.uploader || '—' }}<small v-if="v.uploader_ip"> · {{ v.uploader_ip }}</small>
                      </td>
                      <td class="muted nowrap">{{ v.downloaded || '—' }}</td>
                      <td class="sum">
                        <code v-if="v.integrity" :title="v.integrity">{{ v.integrity.slice(0, 24) }}…</code>
                        <code v-else-if="v.sha1" :title="`sha1 ${v.sha1}`">sha1 {{ v.sha1.slice(0, 12) }}…</code>
                        <span v-else class="muted">—</span>
                      </td>
                      <td class="w-act">
                        <button
                          class="mini"
                          :title="'체크섬 복사 — lockfile 의 integrity 와 맞춰 볼 때 씁니다'"
                          @click.stop="copy(v.integrity || v.sha1 || '', p.key + v.version)"
                        >{{ copied === p.key + v.version ? '복사됨' : '⧉' }}</button>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <p v-if="p.list_capped || p.search_capped" class="muted cap">
                  버전이 많아 일부만 보여 줍니다 (최근 등록순).
                </p>
              </td>
            </tr>
          </tbody>
        </table>

        <p v-if="!usedRows.length && !loading" class="muted empty">해당하는 패키지가 없습니다.</p>
      </div>
    </section>
  </template>

  <!-- ══════════════ 저장소 둘러보기 ══════════════ -->
  <template v-else>
    <section class="panel">
      <div class="cards">
        <button
          v-for="r in hosted"
          :key="r.name"
          class="card"
          :class="{ on: r.name === repo }"
          :title="r.url"
          @click="pickRepo(r.name)"
        >
          <div class="k">{{ r.format }}</div>
          <div class="v sm">{{ r.name }}</div>
        </button>
      </div>
      <p class="muted scan">
        <strong>hosted</strong> — 우리가 올린 것입니다. 그 밖의
        프록시·그룹 저장소
        <select :value="repo" @change="pickRepo($event.target.value)">
          <option value="">(고르기)</option>
          <option v-for="r in others" :key="r.name" :value="r.name">
            {{ r.name }} — {{ r.format }} / {{ r.type }}
          </option>
        </select>
        <span class="tip" title="바깥에서 받아 둔 캐시입니다. 수천 건이라 앞쪽만 훑습니다.">
          — 바깥 저장소의 캐시라 양이 많습니다
        </span>
      </p>
    </section>

    <section v-if="browse" class="panel list">
      <h2>
        {{ browse.repository }}
        <span class="hint">
          {{ browse.format }} / {{ browse.type }} · 패키지 {{ browse.total.packages }} ·
          버전 {{ browse.total.versions }} ·
          <span
            class="tip"
            :title="`본체만 더한 값입니다. sources·javadoc·pom 까지 넣으면 ${mb(browse.total.bytes_all)}`"
          >{{ mb(browse.total.bytes) }}</span>
        </span>
        <span class="spacer"></span>
        <input v-model="q" type="text" placeholder="패키지명 검색" />
      </h2>

      <p v-if="browse.truncated" class="muted warnline">
        저장소가 커서 <strong>{{ browse.max_pages }}쪽({{ browse.total.versions }}건)까지만</strong> 읽었습니다 —
        아래 목록이 전부가 아닙니다. 찾는 것이 정해져 있으면 [PMM 사용] 탭이 더 정확합니다.
      </p>

      <div class="scroll">
        <table class="grp">
          <thead>
            <tr>
              <th class="w-nm">패키지</th>
              <th class="num w-mod">버전</th>
              <th class="num w-sz" title="본체끼리 더한 값 (sources·javadoc·pom 제외)">본체 합계</th>
              <th class="w-dt">최근 등록</th>
              <th class="w-st"></th>
            </tr>
          </thead>
          <tbody v-for="p in browseRows" :key="p.key">
            <tr class="ghd" :class="{ open: isOpen(p.key) || autoOpen }" @click="toggle(p.key)">
              <td class="nm">
                <span class="caret">{{ isOpen(p.key) || autoOpen ? '▾' : '▸' }}</span>
                <b :class="{ ours: inhouse(p.key) }">{{ p.key }}</b>
                <span v-if="p.description" class="desc" :title="p.description">{{ p.description }}</span>
              </td>
              <td class="num muted">{{ p.versions }}</td>
              <td class="num muted nowrap" :title="`자산 전부 합치면 ${mb(p.bytes_all)}`">{{ mb(p.bytes) }}</td>
              <td class="muted nowrap">{{ p.newest }}</td>
              <td class="st nowrap">
                <span
                  v-for="(ver, t) in p.tags || {}"
                  :key="t"
                  class="tag dist"
                  :title="`dist-tag ${t} → ${ver}`"
                >{{ t }} {{ ver }}</span>
              </td>
            </tr>

            <tr v-if="isOpen(p.key) || autoOpen" class="det">
              <td colspan="5">
                <table class="vers">
                  <thead>
                    <tr>
                      <th>버전</th>
                      <th class="num">크기</th>
                      <th>등록일시</th>
                      <th>올린 계정</th>
                      <th>마지막 내려받기</th>
                      <th>체크섬</th>
                      <th class="w-act"></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="v in p.list" :key="v.version">
                      <td class="vv">
                        <a v-if="v.url" :href="v.url" target="_blank" rel="noopener noreferrer">{{ v.version }}</a>
                        <span v-else>{{ v.version }}</span>
                      </td>
                      <td class="num muted nowrap" :title="`자산 ${v.assets}개 합계 ${mb(v.size_all)}`">
                        {{ mb(v.size) }}
                      </td>
                      <td class="muted nowrap">{{ v.modified }}</td>
                      <td class="muted nowrap">
                        {{ v.uploader || '—' }}<small v-if="v.uploader_ip"> · {{ v.uploader_ip }}</small>
                      </td>
                      <td class="muted nowrap">{{ v.downloaded || '—' }}</td>
                      <td class="sum">
                        <code v-if="v.integrity" :title="v.integrity">{{ v.integrity.slice(0, 24) }}…</code>
                        <code v-else-if="v.sha1" :title="`sha1 ${v.sha1}`">sha1 {{ v.sha1.slice(0, 12) }}…</code>
                        <span v-else class="muted">—</span>
                      </td>
                      <td class="w-act">
                        <button class="mini" title="체크섬 복사" @click.stop="copy(v.integrity || v.sha1 || '', p.key + v.version)">
                          {{ copied === p.key + v.version ? '복사됨' : '⧉' }}
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>

        <p v-if="!browseRows.length && !loading" class="muted empty">패키지가 없습니다.</p>
      </div>
    </section>
  </template>
</template>

<style scoped>
h2 { display: flex; align-items: center; gap: 8px; }
h2 .spacer { flex: 1; }
h2 input { width: 200px; }
.head { margin-bottom: 12px; }
.note { margin: 8px 0 0; font-size: 11.5px; }
.note code { background: var(--fill); border-radius: 3px; padding: 1px 5px; font-size: 11px; }
.error { color: var(--warn); font-size: 12.5px; margin: 8px 0 0; }

.tabs { display: flex; gap: 6px; margin-top: 8px; }
.tabs button {
  border: 1px solid var(--line); background: var(--panel); border-radius: var(--radius);
  padding: 5px 14px; font-size: 12.5px; cursor: pointer; color: var(--muted);
}
.tabs button.on { border-color: var(--accent); background: var(--accent-soft); color: var(--accent); font-weight: 600; }

.cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(165px, 1fr)); gap: 10px; }
.card {
  text-align: left; border: 1px solid var(--line); border-radius: var(--radius);
  background: var(--panel); padding: 9px 11px; cursor: pointer;
}
.card:hover { border-color: var(--accent); }
/* 전역 button.on 이 color 를 on-accent(강조색 위의 글자) 로 덮는다. 여기 바탕은 accent-soft
   (옅은 쪽)이라 그대로 두면 글자가 바탕에 묻힌다 — 글자색을 되돌려 놓는다. */
.card.on { border-color: var(--accent); background: var(--accent-soft); color: var(--text); }
.card.bad .v { color: var(--warn); }
.card .k { color: var(--muted); font-size: 11.5px; }
.card .v { font-size: 17px; font-weight: 600; margin-top: 1px; }
.card .v.sm { font-size: 13px; word-break: break-all; }
.card .b { font-size: 11px; color: var(--muted); margin-top: 2px; }

.scan { margin: 10px 0 0; font-size: 11.5px; }
.scan select { margin: 0 6px; font-size: 12px; max-width: 320px; }
.warnline { margin: 6px 0 0; font-size: 11.5px; color: var(--warn); }
.tip { border-bottom: 1px dotted var(--muted-3); cursor: help; }

.list { margin-top: 12px; }
.scroll { max-height: calc(100vh - 380px); overflow: auto; }
table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
thead th { position: sticky; top: 0; background: var(--panel); z-index: 1; text-align: left; }
.num { text-align: right; }
.nowrap { white-space: nowrap; }
.w-nm { width: auto; }
.w-ver { width: 210px; }
.w-mod { width: 56px; }
.w-sz { width: 82px; }
.w-dt { width: 116px; }
.w-repo { width: 150px; }
.w-st { width: 160px; }
.w-act { width: 34px; }

/* 패키지 한 줄 = 머리줄. 누르면 그 아래로 버전이 펼쳐진다 (보관 파일 화면과 같은 모양). */
table.grp tbody + tbody { border-top: 1px solid var(--line); }
.ghd { cursor: pointer; }
.ghd:hover td { background: var(--bg); }
.ghd.open td { background: var(--bg); }
.ghd td { padding: 5px 8px; vertical-align: middle; }
.ghd .caret { color: var(--muted-2); font-size: 10px; margin-right: 5px; }
.ghd .eco {
  font-size: 10px; border-radius: 3px; padding: 1px 5px; margin-right: 6px;
  background: var(--fill); color: var(--muted);
}
.ghd .eco.npm { background: var(--danger-soft); color: var(--danger-text); }
.ghd .eco.maven { background: var(--accent-soft); color: var(--accent); }
.ghd b { font-weight: 600; }
.ghd b.ours { color: var(--accent); }
.ghd .desc {
  margin-left: 8px; color: var(--muted); font-size: 11px;
  display: inline-block; max-width: 420px; overflow: hidden;
  text-overflow: ellipsis; white-space: nowrap; vertical-align: bottom;
}
.repo { font-size: 11px; overflow: hidden; text-overflow: ellipsis; }

.tag { font-size: 10.5px; border-radius: 3px; padding: 1px 6px; margin-right: 4px; white-space: nowrap; }
.tag small { opacity: 0.65; margin-left: 2px; }
.tag.want { color: var(--accent); background: var(--accent-soft); font-weight: 600; }
/* 범위 표기(^1.2.3)는 어느 판을 받는지 풀지 않았다 — 점선으로 그 사실을 남긴다 */
.tag.want.loose { border: 1px dashed var(--accent); }
.tag.want.dev { color: var(--muted); background: var(--fill); font-weight: 400; }
.tag.ok { color: var(--done); background: var(--done-soft); }
.tag.mid { color: var(--warn); background: var(--warn-soft); }
.tag.bad { color: var(--on-accent); background: var(--warn); }
.tag.dist { color: var(--muted); background: var(--fill); }

.det td { padding: 0 8px 10px 26px; background: var(--bg); }
.det .err { color: var(--warn); padding: 8px 0; }
table.vers { font-size: 12px; background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); }
table.vers thead th { background: var(--panel); font-weight: 500; color: var(--muted); font-size: 11px; padding: 4px 8px; }
table.vers td { padding: 4px 8px; border-top: 1px solid var(--line); }
table.vers tr.hit td { background: var(--accent-soft); }
.vv a { color: var(--accent); }
.vv { font-variant-numeric: tabular-nums; }
.sum code { font-family: Consolas, 'Courier New', monospace; font-size: 10.5px; color: var(--muted); }
.mini {
  border: 1px solid var(--line); background: var(--panel); border-radius: 3px;
  font-size: 10.5px; padding: 1px 5px; cursor: pointer; color: var(--muted);
}
.mini:hover { border-color: var(--accent); color: var(--accent); }
.cap { font-size: 11px; margin: 4px 0 0; }
.empty { text-align: center; padding: 18px 0; font-size: 12.5px; }
</style>
