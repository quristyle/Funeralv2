-- ---------------------------------------------------------------------------
-- 개발자 정보(dev_docs) — 섹션 삭제를 되돌릴 수 있게 한다.
--
-- 왜 진짜로 지우지 않나:
--   섹션 하나에 팀이 한참 쌓아 둔 글이 들어 있다. 실수로 지우면 되돌릴 방법이
--   백업 복구뿐이었다. 지우는 대신 deleted_at 을 채우고, 목록에서는 그것이
--   비어 있는 것만 보여 준다.
--
-- 휴지통은 화면에서 비운다. 거기서 <완전 삭제> 를 누르면 그때 진짜로 지운다
--   (DELETE /api/docs/{id}?purge=true).
--
-- deleted_by 를 같이 두는 까닭: 누가 지웠는지 모르면 되돌릴지 물어볼 데가 없다.
--   updated_by 와 같은 방식으로 IpGate 가 가려 준 이름이 들어간다.
-- ---------------------------------------------------------------------------

alter table public.dev_docs add column if not exists deleted_at timestamptz;
alter table public.dev_docs add column if not exists deleted_by text;

comment on column public.dev_docs.deleted_at is
  '삭제 시각. null 이면 살아 있는 섹션. 목록(/api/docs)은 null 인 것만 준다.';
comment on column public.dev_docs.deleted_by is
  '지운 사람 (IpGate 가 가려 준 이름). 되돌릴지 물어볼 상대를 남기려는 것이다.';
