<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { api } from '../api'
import { loadRows, useViewRefresh } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'
import PvDialog from '../components/PvDialog.vue'
import { buildPvCollectScript, buildPvExportScript } from '../pvScript'

// ProjectView 의 날짜를 대시보드로 가져온다(읽기 방향).
// 기본은 Export 폴더의 최신 파일. 콘솔 스크립트로 모은 JSON 도 받아 준다.
const FIELDS = [
  { col: 'plan_sdt', label: '시작일', pv: '계획시작일' },
  { col: 'plan_edt', label: '종료일', pv: '계획종료일' },
  { col: 'plan_sdt_c', label: '실적시작', pv: '실적시작일' },
  { col: 'plan_edt_c', label: '실적종료', pv: '실적종료일' },
]

const source = ref('file')          // file | json
const picked = ref(FIELDS.map((f) => f.col))
// 날짜의 기준은 언제나 ProjectView 다. ProjectView 에서 지운 날짜는 대시보드에서도 지워야
// 두 곳이 같아지므로 기본값은 켜 둔다.
const clearEmpty = ref(true)
const raw = ref('')                 // 붙여넣은 JSON

const dir = ref({})                 // 폴더 목록
const busy = ref('')
const err = ref('')
const msg = ref('')
const pv = ref(null)                // 미리보기 결과
const script = ref('')              // 스크립트 창
const scriptTitle = ref('')
const scriptMeta = ref('')
const codes = ref([])

async function loadFiles() {
  err.value = ''
  try {
    dir.value = await api.pvSyncFiles()
  } catch (e) {
    err.value = e.message
  }
}

async function loadCodes() {
  try {
    const rows = await api.rows({ scope: 'all', limit: 5000 })
    codes.value = [...new Set(rows.map((r) => r.activity_id).filter(Boolean))]
  } catch { /* 콘솔 스크립트용이라 실패해도 화면은 동작한다 */ }
}

function openExport() {
  script.value = buildPvExportScript(new Date().toLocaleString('ko-KR'))
  scriptTitle.value = 'ProjectView Export 내려받기 스크립트'
  scriptMeta.value = '읽기 전용 · 다운로드 폴더에 저장'
}

function openScript() {
  scriptTitle.value = 'ProjectView 날짜 수집 스크립트'
  scriptMeta.value = `${codes.value.length}건 · 읽기 전용(GET)`

  script.value = buildPvCollectScript(codes.value, new Date().toLocaleString('ko-KR'))
}

/** 붙여넣은 텍스트에서 JSON 배열을 꺼낸다 (콘솔 출력을 통째로 붙여넣어도 받아 준다) */
function parseItems() {
  const t = raw.value.trim()
  if (!t) throw new Error('붙여넣은 내용이 없습니다.')
  const s = t.indexOf('[')
  const e = t.lastIndexOf(']')
  if (s < 0 || e < s) throw new Error('JSON 배열을 찾지 못했습니다.')
  let arr
  try {
    arr = JSON.parse(t.slice(s, e + 1))
  } catch (x) {
    throw new Error('JSON 을 읽지 못했습니다: ' + x.message)
  }
  if (!Array.isArray(arr) || !arr.length) throw new Error('항목이 비어 있습니다.')
  return arr
}

const payload = () => ({
  source: source.value,
  items: source.value === 'json' ? parseItems() : undefined,
  fields: picked.value,
  clearEmpty: clearEmpty.value,
})

async function preview() {
  err.value = ''
  msg.value = ''
  pv.value = null
  busy.value = 'preview'
  try {
    pv.value = await api.pvSyncPreview(payload())
    if (source.value === 'file') await loadFiles()
  } catch (e) {
    err.value = e.message
  } finally {
    busy.value = ''
  }
}

async function apply() {
  if (!pv.value?.changed) return
  if (!confirm(`${pv.value.changed}건의 날짜를 ProjectView 값으로 바꿉니다. 진행할까요?`)) return
  err.value = ''
  busy.value = 'apply'
  try {
    const r = await api.pvSyncApply(payload())
    msg.value = `${r.applied}건 반영했습니다 (행 ${r.affected}개).`
    pv.value = await api.pvSyncPreview(payload())   // 남은 차이 재확인
    await loadRows()                                // 다른 화면 목록도 갱신
  } catch (e) {
    err.value = e.message
  } finally {
    busy.value = ''
  }
}

// ---------- 자동 동기화 (한 버튼) ----------
// 서버가 [파일 회수 → CSV 변환 → 읽기 → 비교 → 반영] 을 순서대로 돌리고,
// 화면은 진행 상황을 폴링해서 단계별로 보여 준다.
const job = ref(null)
const autoApply = ref(true)
const clientStep = ref(null)   // 브라우저가 직접 처리한 단계

// ProjectView 로그인 토큰 — 서버가 Export 를 직접 내려받을 때 쓴다.
// 서버는 메모리에만 갖고 있고 값을 되돌려 주지 않으므로, 화면에는 가린 형태만 보인다.
const tok = ref({})
const tokInput = ref('')
const tokOpen = ref(false)

async function loadPvConfig() {
  try {
    cfgPv.value = await api.pvSyncConfig()
  } catch { /* 설정을 못 읽으면 브라우저 내려받기만 못 한다 */ }
}

async function loadToken() {

  try {
    tok.value = await api.pvTokenGet()
  } catch { /* 조회 실패해도 나머지는 동작한다 */ }
}

async function saveToken() {
  err.value = ''
  try {
    tok.value = await api.pvTokenSet(tokInput.value)
    tokInput.value = ''
    tokOpen.value = false
    msg.value = tok.value.registered ? '토큰을 등록했습니다.' : '토큰을 지웠습니다.'
  } catch (e) {
    err.value = e.message
  }
}

let timer = null

// ProjectView 를 브라우저가 직접 부른다.
//  - HTTP 페이지 → HTTPS 요청은 막히지 않는다 (막히는 것은 그 반대 방향)
//  - 사용자가 이미 로그인해 있으므로 쿠키가 그대로 실린다 (credentials: 'include')
//  - x-* 헤더를 붙이면 프리플라이트(OPTIONS)가 도는데 서버가 405 를 주므로, 붙이지 않는다
//    (헤더 없이도 같은 응답이 오는 것을 확인했다. pageId/dataServiceId 는 쿼리에 있다)
const cfgPv = ref({})

async function browserDownload() {
  if (!cfgPv.value.baseUrl) throw new Error('ProjectView 주소 설정을 읽지 못했습니다.')
  const url = cfgPv.value.baseUrl.replace(/\/$/, '') + cfgPv.value.exportPath

  let res
  try {
    res = await fetch(url, { method: 'POST', credentials: 'include' })
  } catch (e) {
    throw new Error(
      'ProjectView 를 부르지 못했습니다 — 브라우저가 요청을 막았거나(확장·정책) 사내망이 아닐 수 있습니다. ' +
        '토큰이 등록되어 있으면 서버가 대신 내려받습니다. (' +
        e.message +
        ')'
    )
  }

  const blob = await res.blob()
  // 오류는 JSON 으로 온다 (엑셀이면 큰 바이너리)
  if (blob.size < 2048 || (blob.type || '').includes('json')) {
    const t = await blob.text()
    if (t.includes('Unauthorized'))
      throw new Error(
        '인증 없이 처리되었습니다. ProjectView 에 로그인했는데도 이 메시지가 나오면 ' +
          '쿠키가 다른 사이트 요청에 실리지 않도록 설정된 경우이니, 아래 [ProjectView 토큰] 을 등록해 두세요.'
      )
    throw new Error('ProjectView 가 엑셀 대신 응답을 돌려줬습니다: ' + t.slice(0, 200))
  }

  const r = await api.pvSyncUpload(blob)
  return `${r.name} (${Math.round(r.size / 1024).toLocaleString()} KB)${r.drm ? ' · DRM' : ''}`
}

async function runAuto() {

  err.value = ''
  msg.value = ''
  pv.value = null
  job.value = null
  clientStep.value = null
  busy.value = 'auto'

  // 0단계: 브라우저 세션으로 내려받기 (토큰 없이 되는 길)
  const t0 = Date.now()
  clientStep.value = { name: 'ProjectView 내려받기(브라우저)', state: 'run', detail: '요청 중…' }
  let got = false
  try {
    const detail = await browserDownload()
    clientStep.value = { name: 'ProjectView 내려받기(브라우저)', state: 'ok', detail, ms: Date.now() - t0 }
    got = true
  } catch (e) {
    clientStep.value = {
      name: 'ProjectView 내려받기(브라우저)',
      state: 'fail',
      detail: e.message,
      ms: Date.now() - t0,
    }
  }

  try {
    const { id } = await api.pvSyncRun({
      fields: picked.value,
      clearEmpty: clearEmpty.value,
      apply: autoApply.value,
      skipDownload: got,
    })
    await poll(id)
  } catch (e) {
    err.value = e.message
    busy.value = ''
  }
}

async function poll(id) {
  clearTimeout(timer)
  try {
    const j = await api.pvSyncJob(id)
    job.value = j
    if (!j.done) {
      timer = setTimeout(() => poll(id), 700)
      return
    }
    busy.value = ''
    if (j.error) {
      err.value = j.error
      return
    }
    pv.value = j.result
    if (j.result?.applied) {
      msg.value = `${j.result.applied}건 반영했습니다 (행 ${j.result.affected}개).`
      await loadRows()
    }
    await loadFiles()
  } catch (e) {
    err.value = e.message
    busy.value = ''
  }
}

const stateIcon = (s) => ({ wait: '○', run: '◐', ok: '●', skip: '－', fail: '✕' }[s] ?? '○')
const secs = (ms) => (ms == null ? '' : ms >= 1000 ? `${(ms / 1000).toFixed(1)}초` : `${ms}ms`)

onUnmounted(() => clearTimeout(timer))

const changedRows = computed(() => pv.value?.rows ?? [])

const chOf = (r, col) => r.changes.find((c) => c.col === col)
const newest = computed(() => dir.value.files?.[0])

useViewRefresh(loadFiles)
onMounted(() => {
  loadFiles()
  loadCodes()
  loadToken()
  loadPvConfig()
})
</script>

<template>
  <div class="topbar">
    <span class="hint">
      ProjectView 의 계획·실적 날짜를 대시보드로 가져옵니다. ProjectView 는 <strong>읽기만</strong> 합니다.
    </span>
    <span class="spacer"></span>
    <RefreshBtn :fn="loadFiles" label="폴더 다시 보기" />
  </div>

  <p v-if="err" class="errbox">{{ err }}</p>
  <p v-if="msg" class="okbox">{{ msg }}</p>

  <!-- 자동 동기화 -->
  <section class="panel auto">
    <h2>
      자동 동기화
      <span class="hint">내려받은 Export 회수 → CSV 변환 → 비교 → 반영까지 한 번에</span>
      <span class="spacer"></span>
      <label class="chk"><input v-model="autoApply" type="checkbox" /> 반영까지 실행</label>
      <button class="pv big" :disabled="busy === 'auto'" @click="runAuto">
        {{ busy === 'auto' ? '진행 중…' : '▶ 자동 동기화' }}
      </button>
    </h2>

    <!-- ProjectView 로그인 토큰 -->
    <div class="tokrow">
      <span class="lb">ProjectView 토큰</span>
      <template v-if="tok.registered">
        <code class="mask">{{ tok.masked }}</code>
        <span v-if="tok.expires" class="exp" :class="{ bad: tok.expired }">
          {{ tok.expired ? '만료됨' : '유효' }} · {{ tok.expires }}
        </span>
        <button class="sm" @click="tokOpen = !tokOpen">바꾸기</button>
        <button class="sm" @click="tokInput = ''; saveToken()">지우기</button>
      </template>
      <template v-else>
        <span class="none">미등록 — 내려받기 단계를 건너뜁니다</span>
        <button class="sm" @click="tokOpen = !tokOpen">등록</button>
      </template>
      <button class="sm" title="ProjectView 콘솔에서 Export 를 내려받는 스크립트" @click="openExport">
        수동 내려받기 스크립트
      </button>
    </div>

    <div v-if="tokOpen" class="tokedit">
      <input
        v-model="tokInput"
        type="password"
        placeholder="promise-token 값을 붙여넣으세요 (promise-token=... 통째로도 됩니다)"
        @keyup.enter="saveToken"
      />
      <button class="pv" @click="saveToken">저장</button>
      <button @click="tokOpen = false">취소</button>
      <p class="muted note">
        ProjectView 탭에서 <code>F12 → Application → Cookies → promise-token</code> 값을 복사해 넣으세요.
        <strong>서버 메모리에만</strong> 보관하며 파일·DB 에 쓰지 않습니다. 서버를 다시 띄우거나
        토큰이 만료되면 다시 등록해야 합니다.
      </p>
    </div>

    <!-- 진행 과정 -->
    <ul v-if="job || clientStep" class="prog">
      <li v-if="clientStep" :class="clientStep.state">
        <span class="ic">{{ stateIcon(clientStep.state) }}</span>
        <span class="nm">{{ clientStep.name }}</span>
        <span class="dt">{{ clientStep.detail }}</span>
        <span class="ms">{{ secs(clientStep.ms) }}</span>
      </li>
      <li v-for="s in job?.steps ?? []" :key="s.name" :class="s.state">
        <span class="ic">{{ stateIcon(s.state) }}</span>
        <span class="nm">{{ s.name }}</span>
        <span class="dt">{{ s.detail }}</span>
        <span class="ms">{{ secs(s.ms) }}</span>
      </li>
      <li v-if="job?.done" class="sum" :class="{ fail: job.error }">
        <span class="ic">{{ job.error ? '✕' : '✔' }}</span>
        <span class="nm">{{ job.error ? '중단됨' : '완료' }}</span>
        <span class="dt">{{ job.error || '' }}</span>
        <span class="ms">{{ secs(job.elapsed) }}</span>
      </li>
    </ul>
    <p v-else class="muted note">
      <strong>ProjectView 에 로그인되어 있으면</strong> 이 버튼 하나로 Export 내려받기부터 반영까지 끝납니다.
      브라우저가 자기 세션으로 Export 를 받아 서버에 올리고, 서버가 CSV 변환·비교·반영을 이어서 합니다.
      브라우저 내려받기가 막히면 등록된 토큰으로, 그것도 없으면 폴더의 최신 파일로 진행합니다.
      아래 [가져올 곳]의 반영 항목·빈 값 설정을 그대로 씁니다.
    </p>
  </section>

  <!-- 가져올 곳 -->
  <section class="panel">
    <h2>
      <span class="step">1</span> 가져올 곳
      <span class="spacer"></span>
      <button
        :disabled="busy === 'preview' || (source === 'json' && !raw.trim())"
        @click="preview"
      >
        {{ busy === 'preview' ? '읽는 중…' : '미리보기' }}
      </button>
    </h2>

    <div class="tabs">
      <label class="rd" :class="{ on: source === 'file' }">
        <input v-model="source" type="radio" value="file" /> Export 폴더의 최신 파일
      </label>
      <label class="rd" :class="{ on: source === 'json' }">
        <input v-model="source" type="radio" value="json" /> 콘솔 스크립트 결과 붙여넣기
      </label>
    </div>

    <!-- 파일 방식 -->
    <template v-if="source === 'file'">
      <p class="path">
        <code>{{ dir.dir }}</code>
        <span v-if="dir.exists === false" class="bad">폴더 없음</span>
      </p>
      <table v-if="dir.files?.length" class="files">
        <thead>
          <tr><th>파일</th><th>수정</th><th class="num">크기</th><th></th></tr>
        </thead>
        <tbody>
          <tr v-for="(f, i) in dir.files" :key="f.name" :class="{ newest: i === 0 }">
            <td class="nowrap">{{ f.name }}</td>
            <td class="nowrap muted">{{ f.modified }}</td>
            <td class="num muted">{{ Math.round(f.size / 1024).toLocaleString() }} KB</td>
            <td class="nowrap">
              <span v-if="i === 0" class="tag">최신</span>
              <span v-if="f.drm" class="tag drm" title="DRM 으로 잠겨 있어 Excel 로 CSV 변환이 필요합니다">DRM</span>
            </td>
          </tr>
        </tbody>
      </table>
      <p v-else class="muted note">폴더에 Export 파일이 없습니다.</p>
      <p class="muted note">
        가장 최근 <strong>{{ newest?.name ?? '파일' }}</strong> 을 읽습니다.
        엑셀이 DRM 으로 잠겨 있으면 <code>tools\export2csv.ps1</code> 을 자동으로 돌려
        같은 이름의 CSV 를 만든 뒤 그 CSV 를 읽습니다 (Excel 이 잠깐 실행됩니다).
      </p>
    </template>

    <!-- JSON 방식 -->
    <template v-else>
      <p class="muted note">
        ProjectView 로그인 탭의 <code>F12 → Console</code> 에 수집 스크립트를 붙여넣어 실행하면
        결과 JSON 이 클립보드에 복사됩니다. 그 내용을 아래에 붙여넣으세요.
        <button class="pv sm" :disabled="!codes.length" @click="openScript">수집 스크립트 만들기</button>
      </p>
      <textarea
        v-model="raw"
        class="paste"
        spellcheck="false"
        placeholder='[{"code":"AAC-A187","planStartDate":"2026-08-31","planEndDate":"2026-09-04","actualStartDate":"2026-08-31","actualEndDate":null}, ...]'
      ></textarea>
    </template>

    <div class="opts">
      <span class="lbl">반영 항목</span>
      <label v-for="f in FIELDS" :key="f.col" class="chk">
        <input v-model="picked" type="checkbox" :value="f.col" />
        {{ f.label }} <code>{{ f.pv }}</code>
      </label>
      <span class="sep"></span>
      <label class="chk warn" title="ProjectView 에서 비워진 날짜를 대시보드에서도 지웁니다 (ProjectView 가 기준)">
        <input v-model="clearEmpty" type="checkbox" /> 빈 값도 반영(ProjectView 에서 지운 날짜는 함께 지움)
      </label>
    </div>
  </section>

  <!-- 미리보기 · 반영 -->
  <section v-if="pv" class="panel">
    <h2>
      <span class="step">2</span> 반영
      <span class="hint">
        <template v-if="pv.source.file">{{ pv.source.file }} · {{ pv.source.modified }}</template>
        <template v-else>붙여넣은 JSON</template>
        · 읽은 항목 {{ pv.read }}건
      </span>
      <span class="spacer"></span>
      <button class="pv" :disabled="!pv.changed || busy === 'apply'" @click="apply">
        {{ busy === 'apply' ? '반영 중…' : `적용 (${pv.changed}건)` }}
      </button>
    </h2>

    <p v-if="pv.source.note" class="muted note">{{ pv.source.note }}</p>

    <div class="cards">
      <div class="card"><div class="k">매칭</div><div class="v">{{ pv.matched }}</div></div>
      <div class="card"><div class="k">변경 예정</div><div class="v">{{ pv.changed }}</div></div>
      <div class="card"><div class="k">동일</div><div class="v">{{ pv.same }}</div></div>
      <div class="card"><div class="k">ProjectView 에만</div><div class="v">{{ pv.unknown_count }}</div></div>
      <div class="card"><div class="k">대시보드에만</div><div class="v">{{ pv.missing_count }}</div></div>
    </div>

    <p v-if="pv.missing_count" class="muted note">
      대시보드에만 있는 코드 {{ pv.missing_count }}건 — ProjectView 파일에 없어 그대로 둡니다:
      <code>{{ pv.missing.slice(0, 15).map((m) => m.activity_id).join(', ') }}</code>
      <template v-if="pv.missing_count > 15"> …</template>
    </p>

    <div v-if="changedRows.length" class="scroll tall">
      <table>
        <thead>
          <tr>
            <th>Activity ID</th><th>모듈</th><th>메뉴명</th>
            <th v-for="f in FIELDS" :key="f.col">{{ f.label }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in changedRows" :key="r.activity_id">
            <td class="nowrap">
              {{ r.activity_id }}
              <span v-if="r.dup > 1" class="tag drm" :title="`같은 activity_id 행 ${r.dup}개가 함께 바뀝니다`">×{{ r.dup }}</span>
            </td>
            <td class="nowrap">{{ r.systemcode }}</td>
            <td>{{ r.menu_nm }}</td>
            <td v-for="f in FIELDS" :key="f.col" class="nowrap">
              <template v-if="chOf(r, f.col)">
                <span class="from">{{ chOf(r, f.col).from || '(없음)' }}</span>
                <span class="arw">→</span>
                <span class="to">{{ chOf(r, f.col).to || '(지움)' }}</span>
              </template>
              <span v-else class="muted">·</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <p v-else class="muted note">바뀔 항목이 없습니다. 대시보드 날짜가 ProjectView 와 같습니다.</p>

    <p class="muted note">
      <strong>빈 값 처리</strong> — 날짜의 기준은 언제나 ProjectView 입니다. 기본값(<code>빈 값도 반영</code> 켜짐)에서는
      ProjectView 에서 비워진 날짜가 대시보드에서도 <strong>지워집니다</strong>. 끄면 기존 값을 남깁니다.
      Export 파일의 머리글에 없는 항목은 '비었다'가 아니라 '모른다' 로 보고 <em>건드리지 않습니다</em>.
    </p>
  </section>

  <PvDialog
    v-if="script"
    :script="script"
    :title="scriptTitle"
    :meta="scriptMeta"
    sends="ProjectView 데이터는 조회·내려받기만 합니다. 이 스크립트는 아무것도 수정하지 않습니다."
    @close="script = ''"
  />
</template>

<style scoped>
.panel.auto { border-left: 3px solid var(--accent); }
h2 .chk { font-size: 12px; display: flex; align-items: center; gap: 4px; font-weight: 400; }
button.big { padding: 4px 14px; font-weight: 600; }

.tokrow { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 8px; font-size: 12px; }
.tokrow .lb { color: var(--muted); font-size: 11px; }
.tokrow .mask { background: var(--fill); border-radius: 4px; padding: 1px 7px; font-size: 11px; }
.tokrow .exp { font-size: 11px; color: var(--done); }
.tokrow .exp.bad { color: var(--danger-text); font-weight: 600; }
.tokrow .none { color: var(--warn); font-size: 11.5px; }
.tokedit { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; margin-bottom: 10px; }
.tokedit input { flex: 1; min-width: 280px; }
.tokedit .note { flex-basis: 100%; margin: 2px 0 0; }

.prog { list-style: none; margin: 4px 0 0; padding: 0; }

.prog li {
  display: flex;
  align-items: baseline;
  gap: 8px;
  padding: 4px 6px;
  border-radius: 5px;
  font-size: 12px;
}
.prog li + li { margin-top: 1px; }
.prog .ic { width: 14px; text-align: center; color: var(--muted); }
.prog .nm { width: 132px; flex: none; }
.prog .dt { flex: 1; color: var(--muted); min-width: 0; }
.prog .ms { color: var(--muted); font-size: 11px; font-variant-numeric: tabular-nums; }
.prog li.run { background: var(--accent-soft); }
.prog li.run .ic { color: var(--accent); animation: blink 0.9s ease-in-out infinite; }
.prog li.run .nm { color: var(--accent); font-weight: 600; }
.prog li.ok .ic { color: var(--done); }
.prog li.skip { opacity: 0.6; }
.prog li.fail { background: var(--danger-soft); }
.prog li.fail .ic, .prog li.fail .dt { color: var(--danger-text); }
.prog li.sum { border-top: 1px solid var(--line); margin-top: 4px; padding-top: 6px; font-weight: 600; }
.prog li.sum .ic { color: var(--done); }
.prog li.sum.fail .ic { color: var(--danger-text); }
@keyframes blink { 50% { opacity: 0.35; } }

.topbar { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }

.topbar .spacer { flex: 1; }
h2 .spacer { flex: 1; }
h2 .step {
  display: inline-block;
  width: 18px;
  height: 18px;
  line-height: 18px;
  text-align: center;
  border-radius: 50%;
  background: var(--accent);
  color: var(--on-accent);
  font-size: 11px;
  margin-right: 4px;
}

.tabs { display: flex; gap: 8px; margin-bottom: 10px; }
.rd {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  border: 1px solid var(--line);
  border-radius: 6px;
  padding: 5px 10px;
  cursor: pointer;
}
.rd.on { border-color: var(--accent); color: var(--accent); background: var(--accent-soft); font-weight: 600; }

.path { margin: 0 0 8px; font-size: 12px; }
.path .bad { color: var(--danger-text); margin-left: 8px; }
.files { width: auto; min-width: 380px; margin-bottom: 8px; }
.files td, .files th { padding: 3px 10px 3px 0; }
.files tr.newest td { font-weight: 600; }
.tag {
  background: var(--accent-soft);
  color: var(--accent);
  border-radius: 8px;
  padding: 0 6px;
  font-size: 10px;
  margin-right: 4px;
}
.tag.drm { background: var(--warn-soft); color: var(--warn); }

.opts { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin-top: 10px; }
.opts .lbl { font-size: 11px; color: var(--muted); }
.opts .chk { font-size: 12px; display: flex; align-items: center; gap: 4px; }
.opts .chk.warn { color: var(--warn); }
.opts .sep { width: 1px; height: 16px; background: var(--line); }

.paste {
  width: 100%;
  min-height: 120px;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 11.5px;
  line-height: 1.5;
  border: 1px solid var(--line);
  border-radius: 6px;
  padding: 8px 10px;
  background: var(--surface);
  resize: vertical;
  white-space: pre;
  overflow: auto;
}

.scroll.tall { max-height: calc(100vh - 420px); overflow: auto; }
.scroll.tall thead th { position: sticky; top: 0; background: var(--panel); box-shadow: inset 0 -1px 0 var(--line); z-index: 1; }
.nowrap { white-space: nowrap; }
.num { text-align: right; }
.from { color: var(--muted); text-decoration: line-through; }
.arw { color: var(--muted); margin: 0 4px; font-size: 10px; }
.to { color: var(--accent); font-weight: 600; }
.note { margin: 8px 0 0; }
button.pv { border-color: var(--accent); color: var(--accent); }
button.pv:hover:not(:disabled) { background: var(--accent-soft); }
button.pv:disabled { border-color: var(--line); color: var(--muted); }
button.sm { padding: 1px 8px; font-size: 11px; margin-left: 6px; }

.errbox {
  background: var(--danger-soft);
  border: 1px solid var(--danger-line);
  color: var(--danger-text);
  padding: 7px 11px;
  border-radius: 6px;
  font-size: 12px;
  margin: 0 0 12px;
}
.okbox {
  background: var(--done-soft);
  border: 1px solid var(--done);
  color: var(--done);
  padding: 7px 11px;
  border-radius: 6px;
  font-size: 12px;
  margin: 0 0 12px;
}
</style>
