<script setup>
/**
 * 모양을 바꿀 수 있는 이음선.
 *
 * 선을 <고르면> 선 위에 점이 몇 개 돋는다. 그 점을 끌면 선이 그쪽으로 휜다.
 * 끌린 점은 그 자리에 남고(경유점), 남은 점 사이에는 다시 새 점이 돋는다 —
 * 끌수록 점이 늘어나는 셈이라, 원하는 만큼만 꺾을 수 있다.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * <b>왜 「두 번 눌러 점 만들기」가 아닌가.</b> 처음에는 그렇게 두었는데, 선이 1~3px 이라
 * 두 번 누르기가 잘 맞지 않고 <점을 만들 수 있다는 것> 자체가 보이지 않았다.
 * 고르면 점이 보이는 쪽은 눌러 보면 바로 안다. (두 번 눌러 만드는 길도 남겨 두었다.)
 *
 * <b>왜 꺾은선이 아니라 곡선인가.</b> 이 화면의 규칙이다 — 객체는 각지게, 선은 휘게.
 * 경유점을 지날 때도 꺾지 않고 Catmull-Rom 을 베지어로 바꿔 부드럽게 지난다.
 *
 * <b>경유점이 없으면 예전 그대로다.</b> 점을 하나도 두지 않은 선은 Vue Flow 의 베지어와
 * 같은 공식으로 그린다 — 기능을 더했다고 이미 그려 둔 83개의 선 모양이 달라지면 안 된다.
 *
 * <b>점은 어디에 담기나.</b> <c>edge.data.pts</c> 에 <흐름 좌표>로 담는다(화면 좌표가 아니다).
 * 화면 좌표로 담으면 확대·이동만 해도 선이 딴 데로 간다. 저장은 부모가 한다.
 *
 * <b>왜 data 에 콜백을 넣지 않나.</b> 이 화면은 edge.data 를 그대로 서버에 적는다.
 * 함수를 끼워 두면 저장할 때 엉뚱한 것이 파일에 남는다. 그래서 부모가 provide 로
 * 내려 준 <c>tablesWay</c> 를 쓴다.
 */
import { computed, inject, ref } from 'vue'
import { BaseEdge, EdgeLabelRenderer, useVueFlow } from '@vue-flow/core'

const props = defineProps({
  id: { type: String, required: true },
  sourceX: { type: Number, required: true },
  sourceY: { type: Number, required: true },
  targetX: { type: Number, required: true },
  targetY: { type: Number, required: true },
  sourcePosition: { type: String, default: 'right' },
  targetPosition: { type: String, default: 'left' },
  data: { type: Object, default: () => ({}) },
  style: { type: Object, default: () => ({}) },
  markerEnd: { type: String, default: '' },
  label: { type: String, default: '' },
  labelStyle: { type: Object, default: () => ({}) },
  selected: { type: Boolean, default: false },
})

const { project } = useVueFlow()
const way = inject('tablesWay', null)

const pts = computed(() => (Array.isArray(props.data?.pts) ? props.data.pts : []))
const dim = computed(() => Number(props.style?.opacity ?? 1) < 0.5)

/**
 * 흐름 순번 — 자료가 <몇 번째로> 흐르는지.
 *
 * 한 업무 안에 갈래가 여럿이라(수신 · 접수 · 반송 …) 번호만으로는 섞인다.
 * 그래서 갈래마다 빛깔을 달리한다 — <같은 1번이라도 빛깔이 다르면 다른 갈래> 다.
 * 담기는 모양: data.seq = 번호(1,2,3…) · data.flow = 갈래 번호(0,1,2…)
 */
const SEQ_COLORS = [
  '#1D6F9E', // 0 파랑
  '#2E7D4F', // 1 초록
  '#B5630B', // 2 주황
  '#6A4FBF', // 3 보라
  '#0E7C86', // 4 청록
  '#B3263E', // 5 빨강
  '#5C6C7A', // 6 회색
  '#A8327D', // 7 자홍
]
const seq = computed(() => {
  // 업무항목을 고른 동안만 보여 준다 — 까닭은 부모의 seqOn 주석 참고.
  // 흐려진 선에서는 숫자도 지운다. 0.07 로 깔린 숫자는 읽히지도 않으면서 그림만 어지럽힌다.
  if (!way?.seqOn?.value || dim.value) return null
  const n = Number(props.data?.seq)
  return Number.isFinite(n) && n > 0 ? n : null
})
const seqColor = computed(() => SEQ_COLORS[(Number(props.data?.flow) || 0) % SEQ_COLORS.length])

const hover = ref(false)
const dragging = ref(-1)
/** 점을 보여 줄 때 — 골랐거나, 선 위에 손이 올라갔거나, 끌고 있는 중 */
const showPts = computed(() => !dim.value && (props.selected || hover.value || dragging.value >= 0))

/** 끝점이 칸의 어느 면에서 나오는지 — 그 방향으로 살짝 빼 줘야 선이 칸에 붙어 꺾이지 않는다 */
function lead(pos, x, y, d) {
  if (pos === 'left') return { x: x - d, y }
  if (pos === 'right') return { x: x + d, y }
  if (pos === 'top') return { x, y: y - d }
  return { x, y: y + d }
}

const cubicAt = (p1, c1, c2, p2, t) => {
  const u = 1 - t
  const a = u * u * u, b = 3 * u * u * t, c = 3 * u * t * t, d = t * t * t
  return {
    x: a * p1.x + b * c1.x + c * c2.x + d * p2.x,
    y: a * p1.y + b * c1.y + c * c2.y + d * p2.y,
  }
}
const cubicMid = (p1, c1, c2, p2) => cubicAt(p1, c1, c2, p2, 0.5)

/**
 * 점들을 부드럽게 잇는다. path 와 함께 <각 구간의 한가운데>도 돌려준다.
 *
 * Catmull-Rom 을 3차 베지어로 바꾼다 — 점을 <정확히 지나면서> 휘는 곡선이다.
 * 그냥 베지어로 하면 점이 당기는 손잡이가 되어 선이 점을 비껴간다.
 *
 * 가운데를 눈대중(두 점의 평균)으로 잡지 않는 까닭: 휜 선에서는 그 자리가 선 위가 아니다.
 * 점이 선에서 떠 있으면 <무엇을 잡는 것인지> 가 흐려진다. t=0.5 를 그대로 셈한다.
 */
function smooth(ps) {
  const mids = []
  let head = null
  if (ps.length < 2) return { d: '', mids, head }
  let d = `M ${ps[0].x},${ps[0].y}`
  for (let i = 0; i < ps.length - 1; i++) {
    const p0 = ps[i - 1] ?? ps[i]
    const p1 = ps[i]
    const p2 = ps[i + 1]
    const p3 = ps[i + 2] ?? p2
    const c1 = { x: p1.x + (p2.x - p0.x) / 6, y: p1.y + (p2.y - p0.y) / 6 }
    const c2 = { x: p2.x - (p3.x - p1.x) / 6, y: p2.y - (p3.y - p1.y) / 6 }
    d += ` C ${c1.x},${c1.y} ${c2.x},${c2.y} ${p2.x},${p2.y}`
    mids.push(cubicMid(p1, c1, c2, p2))
    // 순번표는 <출발 쪽>에 붙인다 — 선을 눈으로 좇을 때 번호를 먼저 보고 따라가게 된다.
    // 가운데는 글귀가 쓰고 있어서 겹친다.
    if (i === 0) head = cubicAt(p1, c1, c2, p2, 0.28)
  }
  return { d, mids, head }
}

/** Vue Flow 의 기본 베지어와 같은 공식 — 경유점이 없을 때 쓴다 */
function plainBezier() {
  const a = { x: props.sourceX, y: props.sourceY }
  const b = { x: props.targetX, y: props.targetY }
  const k = Math.max(25, Math.min(150, (Math.abs(b.x - a.x) + Math.abs(b.y - a.y)) / 2))
  const c1 = lead(props.sourcePosition, a.x, a.y, k)
  const c2 = lead(props.targetPosition, b.x, b.y, k)
  return {
    d: `M ${a.x},${a.y} C ${c1.x},${c1.y} ${c2.x},${c2.y} ${b.x},${b.y}`,
    mids: [cubicMid(a, c1, c2, b)],
    head: cubicAt(a, c1, c2, b, 0.28),
  }
}

const shape = computed(() => {
  if (!pts.value.length) return plainBezier()
  // 경유점이 있으면 <출발 → 경유점들 → 도착> 을 그대로 지난다.
  // 끝에서 억지로 빼 주던 보조점은 두지 않는다 — 그것까지 구간이 되면
  // 첫 점이 칸 코앞에 돋아 잡기 어렵다. 방향은 사람이 점으로 잡는다.
  return smooth([
    { x: props.sourceX, y: props.sourceY },
    ...pts.value,
    { x: props.targetX, y: props.targetY },
  ])
})

const path = computed(() => shape.value.d)
/** 아직 경유점이 아닌 <돋아난 점>. 끌면 그 자리에 경유점이 생긴다 */
const ghosts = computed(() => shape.value.mids)

/** 이름표 자리 — 선의 한가운데 구간 */
const mid = computed(() => {
  const m = ghosts.value
  return m.length ? m[Math.floor((m.length - 1) / 2)] : { x: props.sourceX, y: props.sourceY }
})

// ---------- 끌기 ----------
//
// 두 가지를 같은 길로 다룬다 — 이미 있는 경유점을 옮기는 것과, 돋아난 점을 끌어
// 새 경유점을 만드는 것. 뒤쪽은 <처음 움직인 순간> 점을 끼워 넣고 그 뒤로는 같다.
function startDrag(e, idx, isGhost) {
  if (!way) return
  e.preventDefault()
  e.stopPropagation()     // 선을 고르는 것이 아니라 점을 잡는 것이다

  let i = idx
  let born = !isGhost     // 실제 경유점이 되었는가
  dragging.value = isGhost ? -2 : idx

  const move = (ev) => {
    const p = project({ x: ev.clientX, y: ev.clientY })
    const at = { x: Math.round(p.x), y: Math.round(p.y) }
    if (!born) {
      // 돋아난 점을 처음 움직였다 — 여기서 진짜 경유점이 된다.
      // 누르자마자 만들지 않는 까닭: 잘못 눌렀을 때 점만 남는다.
      way.insert(props.id, i, at)
      born = true
      dragging.value = i
    } else {
      way.move(props.id, i, at)
    }
  }
  const up = () => {
    dragging.value = -1
    window.removeEventListener('pointermove', move)
    window.removeEventListener('pointerup', up)
    window.removeEventListener('pointercancel', up)
    if (born) way.done(props.id)
  }
  // ⚠️ window 에 단다 — 점은 10px 짜리라 손이 금방 벗어난다. 요소에 달면 끌다가 끊긴다.
  window.addEventListener('pointermove', move)
  window.addEventListener('pointerup', up)
  window.addEventListener('pointercancel', up)
}

/** 경유점을 두 번 누르면 없어진다 — 선을 원래대로 펴는 길이다 */
function dropPt(e, i) {
  if (!way) return
  e.preventDefault()
  e.stopPropagation()
  way.remove(props.id, i)
}
</script>

<template>
  <BaseEdge :id="id" :path="path" :marker-end="markerEnd" :style="style" />

  <!-- 잡기 쉬우라고 깔아 두는 투명한 굵은 선. 보이는 선은 1~3px 이라 이것이 없으면
       손을 올려도 점이 돋지 않는다. -->
  <path
    :d="path" fill="none" stroke="transparent" stroke-width="18"
    style="pointer-events: stroke"
    @pointerenter="hover = true"
    @pointerleave="hover = false"
  />

  <!-- 흐름 순번 — 작은 네모에 숫자. 갈래마다 빛깔이 다르다.
       각지게 둔다(이 화면의 규칙). 흐린 선에서는 숫자도 함께 흐려야 하므로
       선의 투명도를 그대로 물려받는다. -->
  <g v-if="seq" class="seq" :transform="`translate(${shape.head?.x ?? 0}, ${shape.head?.y ?? 0})`">
    <rect x="-7" y="-7" width="14" height="14" :fill="seqColor" />
    <text x="0" y="0.5" text-anchor="middle" dominant-baseline="middle">{{ seq }}</text>
  </g>

  <g v-if="showPts" class="wpts">
    <!-- 돋아난 점 — 아직 경유점이 아니다. 끌면 그 자리에 생긴다. -->
    <circle
      v-for="(p, i) in ghosts" :key="'g' + i"
      class="wpt ghost" :cx="p.x" :cy="p.y" r="4.5"
      @pointerdown="startDrag($event, i, true)"
    >
      <title>끌면 여기에 경유점이 생기고 선이 그쪽으로 휩니다</title>
    </circle>

    <!-- 자리 잡은 경유점 -->
    <circle
      v-for="(p, i) in pts" :key="'p' + i"
      class="wpt" :class="{ hot: dragging === i }"
      :cx="p.x" :cy="p.y" r="5"
      @pointerdown="startDrag($event, i, false)"
      @dblclick="dropPt($event, i)"
    >
      <title>끌어서 선을 돌립니다 · 두 번 누르면 이 점을 없앱니다</title>
    </circle>
  </g>

  <EdgeLabelRenderer v-if="label">
    <div
      class="wlabel"
      :style="{ transform: `translate(-50%, -50%) translate(${mid.x}px, ${mid.y}px)`, ...labelStyle }"
    >{{ label }}</div>
  </EdgeLabelRenderer>
</template>

<style scoped>
.wpt {
  fill: var(--panel, #fff);
  stroke: var(--accent, #2f6fd0);
  stroke-width: 1.5;
  cursor: grab;
  pointer-events: all;
}
/* 돋아난 점은 흐리게 — <아직 없는 것> 이라 자리 잡은 점과 같은 무게로 보이면 안 된다 */
.wpt.ghost { opacity: 0.45; stroke-dasharray: 2 2; }
.wpt.ghost:hover { opacity: 1; stroke-dasharray: none; }
.wpt.hot { fill: var(--accent, #2f6fd0); cursor: grabbing; }
.seq { pointer-events: none; }
.seq rect { stroke: var(--panel, #fff); stroke-width: 1.5; }
.seq text { font-size: 9px; font-weight: 700; fill: #fff; }
.wlabel {
  position: absolute;
  padding: 1px 3px;
  background: var(--panel, #fff);
  pointer-events: none;
  white-space: nowrap;
}
</style>
