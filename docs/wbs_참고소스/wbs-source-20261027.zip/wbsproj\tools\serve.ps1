﻿<#
  WBS 대시보드 기동 / 중지 — start.cmd · stop.cmd 가 부른다.

  창을 띄우지 않는다. 예전에는 `start "wbs-api" cmd /k ...` 로 CMD 창 두 개를 열어 두었는데,
  그 창이 화면을 차지하고 실수로 닫으면 서버가 같이 내려갔다. 지금은 숨겨서 띄우고
  화면에 나오던 것은 logs\ 아래 파일로 남긴다.

  창이 없으니 <무엇을 내릴지> 를 따로 적어 두어야 한다. 기동할 때 PID 를 logs\<이름>.pid 에
  적고, 중지할 때 그 PID 의 트리를 잡는다. 기록이 없거나 남이 그 포트를 물고 있을 수도 있어
  포트로 한 번 더 훑는다 — 예전 start.cmd 의 :freeport 가 하던 일이다.

  ⚠️ PMM 개발서버(8200+N / 3200+N)는 여기서 손대지 않는다. 그쪽은 대시보드와 일부러
     떼어 놓은 것이라(api/DevRun.cs 참고) 대시보드를 내려도 계속 돈다. 내리려면
     대시보드 화면의 [로컬 개발서버] 또는 각 PC 의 dev-ui 콘솔에서 내린다.
#>
param(
    [ValidateSet('start', 'stop', 'status')]
    [string] $Action = 'start',

    # 창을 띄워 눈으로 보고 싶을 때 (기동 실패를 따라갈 때 쓴다)
    [switch] $Foreground,

    # 프론트 번들을 다시 굽지 않는다 (5080 이 옛 화면을 그대로 서비스한다)
    [switch] $NoBuild
)

$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $PSScriptRoot
$LogDir = Join-Path $Root 'logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

# File/Args 를 따로 두는 까닭 — 경로에 한글이 있어(D:\수빅자재) 배치 파일을 만들어 넘기면
# 코드페이지에 걸린다. PowerShell 이 직접 넘기면 그 문제가 없다.
$Services = @(
    # ⚠️ `dotnet run` 으로 띄우지 않는다. 빌드된 exe 를 직접 띄운다.
    #
    #    `dotnet run` 은 자기가 띄운 앱을 <작업 개체(job object)> 에 묶어 두고,
    #    자기가 죽으면 그 job 안의 것을 전부 함께 죽인다. job 소속은 자손에게
    #    그대로 물려지므로, 대시보드가 띄운 로컬 개발서버(gradle·node)까지 딸려 간다.
    #    부모 사슬을 끊어도(고아로 만들어도, WMI 로 남이 만들게 해도) 벗어나지 못한다 —
    #    job 은 부모·자식 관계가 아니기 때문이다.
    #
    #    실제로 확인했다. `dotnet run` 으로 띄우면 PPD001 BE(8101)가 대시보드와 함께 죽고,
    #    exe 를 직접 띄우면 대시보드만 죽고 8101 은 살아남는다.
    #
    #    --contentRoot 를 주는 까닭: exe 는 bin\Release\net9.0 에 있는데 wwwroot·appsettings
    #    는 api\ 아래에 있다. 이것이 없으면 화면이 404 가 된다.
    [pscustomobject]@{
        Name  = 'api'
        Label = 'API + 화면'
        Dir   = (Join-Path $Root 'api')
        File  = (Join-Path $Root 'api\bin\Release\net9.0\WbsApi.exe')
        Args  = @('--contentRoot', (Join-Path $Root 'api'))
        Port  = 5080
    }
    [pscustomobject]@{
        Name  = 'web'
        Label = 'Vite 개발서버 (이 PC 전용)'
        Dir   = (Join-Path $Root 'web')
        File  = 'cmd.exe'
        Args  = @('/d', '/s', '/c', 'npm run dev')
        Port  = 5173
    }
)

function Get-Listener {
    param([int] $Port)
    # ⚠️ `netstat -ano -p TCP` 로 훑으면 IPv4 만 나온다. vite 는 [::1] 에만 붙는 일이 있어
    #    그러면 멀쩡히 뜬 것을 못 본다. 필터 없이 받아서 LISTENING 줄만 고른다.
    foreach ($line in (netstat -ano)) {
        if ($line -match "^\s*TCP\s+\S+:$Port\s+\S+\s+LISTENING\s+(\d+)") {
            $owner = [int]$Matches[1]
            if ($owner -gt 4) { return $owner }
        }
    }
    return $null
}

# ⚠️ /T (트리째 종료) 를 쓰지 않는다.
#
#    로컬 개발서버는 대시보드에서 떼어 내 띄운다(api/DevRun.cs). 떼어 내는 방법이
#    <부모를 먼저 끝내 고아로 만드는 것> 이라, 그 프로세스의 ParentProcessId 는
#    이미 죽은 PID 를 계속 가리킨다. 윈도우가 그 PID 를 재사용해 우리 트리 안의
#    새 프로세스에 붙이면, taskkill /T 가 그 사슬을 타고 들어가 <남의 개발서버> 까지
#    잡아 버린다. 실제로 그렇게 죽는 것을 봤고, 재현이 들쭉날쭉한 것도 이 때문이다.
#
#    우리는 무엇을 내릴지 이미 안다 — 적어 둔 PID 와 그 포트의 주인. 그 둘만 잡는다.
function Stop-One {
    param([int] $ProcessId, [string] $Why)
    if ($ProcessId -le 4) { return }
    Write-Host ("    {0} : PID {1} 종료" -f $Why, $ProcessId)
    & taskkill /F /PID $ProcessId 2>&1 | Out-Null
}

function Stop-All {
    Write-Host '  내리는 중 ...'

    # ⓪ 예전 start.cmd 가 `start "wbs-api" cmd /k` 로 열어 두던 창 — 포트로 프로세스를 잡아
    #    내려도 껍데기 창이 남는다. 제목으로 한 번 닫아 준다.
    #
    # ⚠️ IMAGENAME 을 반드시 같이 건다. Windows Terminal 로 열린 창은 제목이 같아도
    #    프로세스가 WindowsTerminal.exe 이고, 그것을 잡으면 그 창의 <다른 탭까지> 같이
    #    닫힌다. 남의 작업을 날리는 것이라 고전 콘솔(cmd.exe)만 닫는다.
    foreach ($title in @('wbs-api', 'wbs-web')) {
        & taskkill /F /FI "WINDOWTITLE eq $title*" /FI "IMAGENAME eq cmd.exe" 2>&1 | Out-Null
    }

    # ① 기동할 때 적어 둔 PID
    foreach ($svc in $Services) {
        $pidFile = Join-Path $LogDir "$($svc.Name).pid"
        if (-not (Test-Path $pidFile)) { continue }
        $raw = (Get-Content $pidFile -Raw).Trim()
        if ($raw -match '^\d+$' -and (Get-Process -Id ([int]$raw) -ErrorAction SilentlyContinue)) {
            Stop-One -ProcessId ([int]$raw) -Why $svc.Name
        }
        Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
    }

    # ② 기록이 없거나(직접 띄웠거나 serve.cmd) 남은 것이 있으면 포트로 잡는다.
    #    /T 를 안 쓰므로 껍데기(npm → node → vite)가 한 겹씩 남을 수 있다 —
    #    포트가 빌 때까지 주인을 거듭 잡는다.
    foreach ($svc in $Services) {
        for ($i = 0; $i -lt 10; $i++) {
            $owner = Get-Listener -Port $svc.Port
            if (-not $owner) { break }
            Stop-One -ProcessId $owner -Why ("port {0}" -f $svc.Port)
            Start-Sleep -Milliseconds 400
        }
        if (Get-Listener -Port $svc.Port) {
            Write-Warning ("포트 {0} 가 아직 열려 있습니다 — 새로 기동하면 실패할 수 있습니다." -f $svc.Port)
        }
    }
}

function Build-Api {
    Write-Host '  API 빌드 중 ...'
    Push-Location (Join-Path $Root 'api')
    try {
        & dotnet build -c Release --nologo -v quiet
        if ($LASTEXITCODE -ne 0) {
            Write-Warning 'API 빌드 실패 — 직전에 빌드된 실행 파일로 띄웁니다. 위 메시지를 보세요.'
        }
    }
    finally { Pop-Location }
}

function Build-Front {
    Write-Host '  프론트 번들 굽는 중 (5080 이 서비스할 화면) ...'
    Push-Location (Join-Path $Root 'web')
    try {
        & npm run build
        if ($LASTEXITCODE -ne 0) {
            Write-Warning '프론트 빌드 실패 — 5080 은 옛 화면을 그대로 서비스합니다. 위 메시지를 보세요.'
        }
    }
    finally { Pop-Location }
}

function Start-One {
    param($Svc)

    $log = Join-Path $LogDir "$($Svc.Name).log"
    $err = Join-Path $LogDir "$($Svc.Name).err.log"
    $pidFile = Join-Path $LogDir "$($Svc.Name).pid"

    if ($Foreground) {
        # 눈으로 따라갈 때 — 창을 띄우고 로그도 그 창에 그대로 둔다
        $p = Start-Process -FilePath $Svc.File -ArgumentList $Svc.Args `
            -WorkingDirectory $Svc.Dir -PassThru
    }
    else {
        # 숨겨서 띄운다. 화면에 나오던 것은 파일로 간다.
        # PowerShell 이 끝나면 이 프로세스는 고아가 되어 <이 창>과 무관하게 계속 돈다 —
        # 그래서 내릴 때 쓰라고 PID 를 적어 둔다.
        $p = Start-Process -FilePath $Svc.File -ArgumentList $Svc.Args `
            -WorkingDirectory $Svc.Dir -WindowStyle Hidden -PassThru `
            -RedirectStandardOutput $log -RedirectStandardError $err
    }

    Set-Content -Path $pidFile -Value $p.Id -Encoding ASCII
    Write-Host ("    {0,-3} PID {1}" -f $Svc.Name, $p.Id)
    return $p
}

function Wait-Port {
    param($Svc, [int] $Seconds = 90)
    for ($i = 0; $i -lt ($Seconds * 2); $i++) {
        if (Get-Listener -Port $Svc.Port) { return $true }
        Start-Sleep -Milliseconds 500
    }
    return $false
}

function Show-Tail {
    param($Svc, [int] $Lines = 25)
    foreach ($f in @("$($Svc.Name).log", "$($Svc.Name).err.log")) {
        $p = Join-Path $LogDir $f
        if (-not (Test-Path $p)) { continue }
        # dotnet 은 출력이 파일로 가면 UTF-8 로 쓴다. PS 5.1 의 기본값(ANSI)으로 읽으면 깨진다.
        $tail = Get-Content $p -Tail $Lines -Encoding UTF8 -ErrorAction SilentlyContinue
        if (-not $tail) { continue }
        Write-Host ''
        Write-Host ("  --- {0} (마지막 {1}줄) ---" -f $f, $Lines) -ForegroundColor Yellow
        $tail | ForEach-Object { Write-Host "  $_" }
    }
}

function Show-Status {
    Write-Host ''
    foreach ($svc in $Services) {
        $owner = Get-Listener -Port $svc.Port
        $mark = if ($owner) { "실행중 (PID $owner)" } else { '내려감' }
        Write-Host ("  {0,-3} {1,-28} {2,-5} {3}" -f $svc.Name, $svc.Label, $svc.Port, $mark)
    }
    Write-Host ''
    Write-Host ("  로그 : {0}" -f $LogDir)
}

# ---------------------------------------------------------------- 실행
switch ($Action) {

    'stop' {
        Stop-All
        Show-Status
        Write-Host ''
        Write-Host '  PMM 개발서버(8200+N / 3200+N)는 그대로 돕니다 — 대시보드와 따로 도는 것들입니다.'
        Write-Host '  내리려면 대시보드의 [로컬 개발서버] 화면이나 각 PC 의 dev-ui 콘솔에서 내리세요.'
    }

    'status' {
        Show-Status
    }

    'start' {
        Stop-All
        if (-not $NoBuild) {
            Build-Api
            Build-Front
        }

        $exe = ($Services | Where-Object { $_.Name -eq 'api' }).File
        if (-not (Test-Path $exe)) {
            Write-Warning "API 실행 파일이 없습니다: $exe"
            Write-Host '  nobuild 없이 start.cmd 를 한 번 돌려 빌드하세요.'
            exit 1
        }

        Write-Host '  띄우는 중 ...'
        foreach ($svc in $Services) { Start-One -Svc $svc | Out-Null }

        $bad = @()
        foreach ($svc in $Services) {
            if (-not (Wait-Port -Svc $svc)) { $bad += $svc }
        }

        Show-Status

        if ($bad.Count -gt 0) {
            foreach ($svc in $bad) {
                Write-Host ''
                Write-Warning ("{0} 가 포트 {1} 을 물지 못했습니다. 로그를 봅니다." -f $svc.Name, $svc.Port)
                Show-Tail -Svc $svc
            }
            Write-Host ''
            Write-Host '  창을 띄워 눈으로 따라가려면 :  start.cmd fg'
            exit 1
        }

        # 이 PC 가 가진 주소를 모두 적는다. 하나만 골라 적으면 랜카드가 여럿일 때
        # 남이 못 여는 주소를 안내하게 된다.
        $lans = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
            Where-Object {
                $_.AddressState -eq 'Preferred' -and
                $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*'
            } | Select-Object -ExpandProperty IPAddress)
        if ($lans.Count -eq 0) { $lans = @('127.0.0.1') }

        Write-Host ''
        Write-Host '  [이 PC]  https://localhost:5443  ·  http://localhost:5080  ·  http://localhost:5173 (vite)'
        foreach ($ip in $lans) {
            Write-Host ("  [공유 ]  http://{0}:5080" -f $ip)
        }
        Write-Host ''
        # https 는 인증서에 적힌 주소에서만 경고 없이 열린다 (지금은 localhost / 127.0.0.1).
        Write-Host '  https 5443 은 localhost · 127.0.0.1 에서만 경고 없이 열립니다.'
        Write-Host '  사내 IP 로도 https 를 쓰려면 tools\make-cert.ps1 로 인증서를 다시 만드세요.'
        Write-Host ''
        Write-Host '  창은 뜨지 않습니다. 내릴 때는 stop.cmd 를 쓰세요.'
    }
}
