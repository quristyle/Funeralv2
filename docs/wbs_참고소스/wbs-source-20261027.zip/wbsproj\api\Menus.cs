using System.Text.Json;

namespace WbsApi;

/// <summary>
/// 메뉴 권한 — 개발자별로 쓸 수 있는 화면을 지정한다.
///
/// 정책은 <b>행이 없으면 허용</b>이다. 막을 것만 `allow_yn='N'` 으로 한 줄 남긴다.
///  - 지금 쓰는 사람이 갑자기 잠기지 않는다 (아무 행도 없으면 전원 전체 허용)
///  - 메뉴를 새로 만들어도 저절로 숨지 않는다
///
/// 이것은 <b>화면을 가리는</b> 장치다. API 자체를 막지는 않는다 —
/// 한 화면이 여러 API 를 나눠 쓰고 있어, 지금 구조에서 API 단위로 막으면
/// 드릴다운 같은 곳이 조용히 깨진다. 진짜 차단이 필요하면 IP 게이트(dev_user.block_yn)를 쓴다.
/// </summary>
public static class Menus
{
    /// <summary>부르는 쪽을 한 줄로 — 브라우저인지 스크립트인지만 가리면 된다.</summary>
    private static string Agent(HttpContext ctx)
    {
        var ua = ctx.Request.Headers.UserAgent.ToString();
        if (string.IsNullOrWhiteSpace(ua)) return "(없음)";
        if (ua.Contains("Mozilla", StringComparison.Ordinal)) return "브라우저";
        return ua.Length > 40 ? ua[..40] : ua;
    }

    /// <summary>
    /// 메뉴 한 칸을 제자리에 놓는다 (폴더 · 순서).
    ///
    /// <b>insert … on conflict</b> 인 까닭 — 코드에는 있는데 <c>dev_menu</c> 에는 아직 없는
    /// 메뉴가 있을 수 있다(새로 만들고 [메뉴 권한] 화면을 아직 안 연 상태). 그때
    /// update 만 하면 그 칸만 조용히 안 움직이고, 끌어다 놓은 사람은 까닭을 알 수 없다.
    /// </summary>
    private static Task<int> Place(PgConn c, string key, int? folderId, int sortOrder) =>
        c.ExecuteAsync("""
            insert into public.dev_menu (menu_key, menu_nm, folder_id, sort_order)
            values ($1::text, $1::text, $2::int, $3::int)
            on conflict (menu_key) do update
               set folder_id  = excluded.folder_id
                 , sort_order = excluded.sort_order
                 , updated_at = now()
            """, [key, folderId, sortOrder]);

    /// <summary>막을 수 없는 메뉴 — 여기까지 막으면 로그인 후 갈 곳이 없어진다.</summary>
    private static readonly HashSet<string> AlwaysOn =
        new(["summary"], StringComparer.OrdinalIgnoreCase);

    /// <summary>한 사람이 못 쓰는 메뉴 키 목록.</summary>
    public static async Task<List<string>> DeniedAsync(PgPool db, string? bpId)
    {
        if (string.IsNullOrWhiteSpace(bpId)) return [];
        var rows = await db.QueryAsync("""
            select menu_key
              from public.dev_user_menu
             where bp_id = $1::text
               and upper(coalesce(allow_yn, 'Y')) = 'N'
            """, [bpId]);
        return [.. rows.Select(r => r["menu_key"]?.ToString() ?? "")
                       .Where(k => k.Length > 0 && !AlwaysOn.Contains(k))];
    }

    /// <summary>
    /// 사이드바의 짜임새 — 폴더와 순서. 누구에게나 같은 값이다(개인 설정이 아니다).
    ///
    /// 화면이 쓰기 좋게 <b>납작하게</b> 준다. 트리로 만들어 주지 않는 까닭은, 화면이 어차피
    /// 코드에 있는 메뉴 목록(<c>menuList.js</c>)과 겹쳐 봐야 하기 때문이다 — DB 에 아직 없는
    /// 메뉴(새로 만들고 아직 sync 안 된 것)도 자리를 잡아 줘야 한다.
    /// </summary>
    public static async Task<object> TreeAsync(PgPool db)
    {
        var folders = await db.QueryAsync("""
            select folder_id, folder_nm, sort_order
              from public.dev_menu_folder
             order by sort_order, folder_id
            """);
        var menus = await db.QueryAsync("""
            select menu_key, folder_id, sort_order
              from public.dev_menu
             order by sort_order, menu_key
            """);
        return new
        {
            folders = folders.Select(r => new
            {
                id = r["folder_id"],
                nm = r["folder_nm"],
                so = r["sort_order"],
            }),
            // { menu_key: { f: 폴더번호|null, so: 순서 } }
            place = menus.ToDictionary(
                r => r["menu_key"]?.ToString() ?? "",
                r => (object)new { f = r["folder_id"], so = r["sort_order"] }),
        };
    }

    /// <param name="isSuper">
    /// 사이드바를 <b>고치는</b> 것은 Super 뿐이다. 판정 기준을 통째로 받아 와
    /// whoami 가 보여 주는 것(<c>super</c>)과 서버가 막는 것이 어긋나지 않게 한다
    /// (<see cref="RowFiles"/> 와 같은 방식).
    /// </param>
    public static void Map(WebApplication app, Func<IpGate.Result, bool> isSuper)
    {
        // 쓰기 경로마다 되풀이되는 판정을 한 곳에 모은다.
        // 화면이 버튼을 감추는 것과 별개로 <서버도> 막아야 한다 — 주소를 직접 치면 그만이다.
        async Task<IResult?> DenyAsync(IpGate g, HttpContext ctx)
        {
            var me = await g.CheckAsync(ctx);
            return isSuper(me) ? null
                : Results.Json(new { error = "사이드바 구성은 Super 만 바꿀 수 있습니다." }, statusCode: 403);
        }

        // ---------- 사이드바 짜임새 (폴더 · 순서) ----------
        app.MapGet("/api/menus/tree", async (PgPool db) => Results.Ok(await TreeAsync(db)));

        // 폴더 만들기 — 맨 아래에 붙는다. 자리는 끌어다 옮긴다.
        app.MapPost("/api/menus/folders", async (PgPool db, IpGate g, HttpContext ctx, JsonElement body) =>
        {
            if (await DenyAsync(g, ctx) is { } no) return no;
            var nm = body.TryGetProperty("name", out var v) ? v.GetString()?.Trim() : null;
            if (string.IsNullOrWhiteSpace(nm)) return Results.BadRequest(new { error = "폴더 이름이 필요합니다." });
            if (nm.Length > 60) nm = nm[..60];

            var me = await g.CheckAsync(ctx);
            var rows = await db.QueryAsync("""
                insert into public.dev_menu_folder (folder_nm, sort_order, updated_by)
                select $1::text
                     , greatest(
                         coalesce((select max(sort_order) from public.dev_menu_folder), 0),
                         coalesce((select max(sort_order) from public.dev_menu where folder_id is null), 0)
                       ) + 10
                     , $2::text
                returning folder_id, folder_nm, sort_order
                """, [nm, me.BpId ?? "dashboard"]);
            return Results.Ok(rows.Count > 0 ? rows[0] : new Dictionary<string, object?>());
        });

        app.MapPut("/api/menus/folders/{id:int}", async (PgPool db, IpGate g, HttpContext ctx, int id, JsonElement body) =>
        {
            if (await DenyAsync(g, ctx) is { } no) return no;
            var nm = body.TryGetProperty("name", out var v) ? v.GetString()?.Trim() : null;
            if (string.IsNullOrWhiteSpace(nm)) return Results.BadRequest(new { error = "폴더 이름이 필요합니다." });
            if (nm.Length > 60) nm = nm[..60];

            var me = await g.CheckAsync(ctx);
            var n = await db.ExecuteAsync("""
                update public.dev_menu_folder
                   set folder_nm = $1::text, updated_at = now(), updated_by = $2::text
                 where folder_id = $3::int
                """, [nm, me.BpId ?? "dashboard", id]);
            return n > 0 ? Results.Ok(new { folder_id = id, folder_nm = nm })
                         : Results.NotFound(new { error = "그런 폴더가 없습니다." });
        });

        // 폴더를 지워도 <그 안의 메뉴는 남는다> — 최상위로 돌아간다.
        // 외래키의 on delete set null 이 그 일을 한다 (db/dev_menu_folder.sql).
        // 메뉴가 폴더와 함께 사라지면 그 화면으로 갈 길이 없어진다.
        app.MapDelete("/api/menus/folders/{id:int}", async (PgPool db, IpGate g, HttpContext ctx, int id) =>
        {
            if (await DenyAsync(g, ctx) is { } no) return no;
            // 꺼낸 메뉴는 폴더가 있던 자리 근처에 둔다. 0 으로 두면 전부 맨 위로 튀어 오른다.
            await db.ExecuteAsync("""
                update public.dev_menu
                   set sort_order = coalesce(
                         (select sort_order from public.dev_menu_folder where folder_id = $1::int), 0)
                       + sort_order
                 where folder_id = $1::int
                """, [id]);
            var n = await db.ExecuteAsync("delete from public.dev_menu_folder where folder_id = $1::int", [id]);
            return n > 0 ? Results.Ok(new { deleted = id })
                         : Results.NotFound(new { error = "그런 폴더가 없습니다." });
        });

        // 짜임새를 통째로 저장한다 — 한 칸씩 보내지 않는 까닭은 [메뉴 권한] 저장과 같다.
        // 끌어다 놓은 결과가 그대로 남아야지, 중간에 끊겨 반쯤 뒤섞이면 안 된다.
        //
        // 받는 모양: { tree: [ {type:'menu', key}, {type:'folder', id, children:[key…]} … ] }
        // 최상위는 폴더와 메뉴가 <한 줄에 섞여> 있으므로 번호 공간을 함께 쓴다.
        app.MapPut("/api/menus/tree", async (PgPool db, IpGate g, HttpContext ctx, JsonElement body) =>
        {
            if (await DenyAsync(g, ctx) is { } no) return no;
            if (!body.TryGetProperty("tree", out var tree) || tree.ValueKind != JsonValueKind.Array)
                return Results.BadRequest(new { error = "tree 배열이 필요합니다." });
            var meTree = await g.CheckAsync(ctx);
            var who = meTree.Name ?? meTree.BpId ?? meTree.Ip;

            return await db.UseAsync<IResult>(async c =>
            {
                await c.QueryAsync("begin");
                try
                {
                    var top = 0;
                    var moved = 0;
                    foreach (var node in tree.EnumerateArray())
                    {
                        top += 10;
                        var type = node.TryGetProperty("type", out var t) ? t.GetString() : null;

                        if (type == "folder")
                        {
                            if (!node.TryGetProperty("id", out var idv) || !idv.TryGetInt32(out var fid)) continue;
                            await c.QueryAsync(
                                "update public.dev_menu_folder set sort_order = $1::int, updated_at = now() where folder_id = $2::int",
                                [top, fid]);

                            var inner = 0;
                            if (node.TryGetProperty("children", out var ch) && ch.ValueKind == JsonValueKind.Array)
                                foreach (var k in ch.EnumerateArray())
                                {
                                    var key = k.GetString()?.Trim();
                                    if (string.IsNullOrWhiteSpace(key)) continue;
                                    inner += 10;
                                    moved += await Place(c, key, fid, inner);
                                }
                        }
                        else
                        {
                            var key = node.TryGetProperty("key", out var kv) ? kv.GetString()?.Trim() : null;
                            if (string.IsNullOrWhiteSpace(key)) continue;
                            moved += await Place(c, key, null, top);
                        }
                    }
                    await c.QueryAsync("commit");
                    // 사이드바는 <모두가 함께 보는> 값이다. 누가 언제 어떻게 바꿨는지 남겨 둔다 —
                    // 어느 날 배치가 달라져 있을 때, 기록이 없으면 원인을 영영 못 찾는다(실제로 겪었다).
                    var shape = string.Join(" ", tree.EnumerateArray().Select(n =>
                        (n.TryGetProperty("type", out var ty) ? ty.GetString() : null) == "folder"
                            ? "[" + (n.TryGetProperty("id", out var fi) ? fi.ToString() : "?") + "]"
                            : (n.TryGetProperty("key", out var kk) ? kk.GetString() : "?")));
                    Console.WriteLine($"[menus/tree] {DateTime.Now:HH:mm:ss} by={who} placed={moved} ua={Agent(ctx)} top={shape}");
                    return Results.Ok(new { placed = moved });
                }
                catch
                {
                    await c.QueryAsync("rollback");
                    throw;
                }
            });
        });

        // ---------- 메뉴 목록 ----------
        // ⚠️ <c>sort_order</c> 하나로 줄을 세우면 안 된다. 폴더가 생긴 뒤로 이 값은
        // <b>같은 자리 안에서의 순서</b>다 — 폴더마다 10, 20, 30 … 으로 다시 시작한다.
        // 그대로 정렬하면 서로 다른 폴더의 10번들이 한데 섞여
        // <c>mflow · orakill · pvsync · rows · summary …</c> 처럼 뒤죽박죽이 된다(실제로 그랬다).
        // 사이드바와 같은 차례로 보이려면 <b>폴더 자리 → 폴더 안 자리</b> 순으로 세워야 한다.
        app.MapGet("/api/menus", async (PgPool db) =>
            Results.Ok(await db.QueryAsync("""
                select m.menu_key, m.menu_nm, m.sort_order, m.use_yn
                     , m.folder_id, f.folder_nm
                  from public.dev_menu m
                  left join public.dev_menu_folder f on f.folder_id = m.folder_id
                 where coalesce(m.use_yn, 'Y') <> 'N'
                 order by coalesce(f.sort_order, m.sort_order)   -- 최상위에서의 자리
                        , m.sort_order                           -- 폴더 안에서의 자리
                        , m.menu_key
                """)));

        // 화면이 가진 메뉴 목록을 올려 DB 와 맞춘다.
        // 메뉴를 새로 만들었을 때 sql 을 따로 돌리지 않아도 권한 화면에 나타나게 하려는 것이다.
        //
        // ⚠️ <b>이미 있는 줄의 sort_order 는 건드리지 않는다.</b> 예전에는 화면이 보낸 번호로
        // 덮어썼는데, 그러면 Super 가 사이드바에서 맞춰 둔 순서가 <누군가 [메뉴 권한] 화면을
        // 열기만 해도> 코드 순서로 되돌아간다. 아무 오류도 나지 않아 한참 모른다.
        // 새로 들어오는 줄은 <맨 뒤>에 붙인다 — 끼어들어 순서를 흔들지 않게.
        app.MapPost("/api/menus/sync", async (PgPool db, JsonElement body) =>
        {
            if (!body.TryGetProperty("menus", out var arr) || arr.ValueKind != JsonValueKind.Array)
                return Results.BadRequest(new { error = "menus 배열이 필요합니다." });

            var n = 0;
            foreach (var m in arr.EnumerateArray())
            {
                var key = m.TryGetProperty("menu_key", out var k) ? k.GetString()?.Trim() : null;
                if (string.IsNullOrWhiteSpace(key)) continue;
                var nm = m.TryGetProperty("menu_nm", out var v) ? v.GetString() : null;
                n += await db.ExecuteAsync("""
                    insert into public.dev_menu (menu_key, menu_nm, sort_order)
                    select $1::text, $2::text
                         , coalesce((select max(sort_order) from public.dev_menu), 0) + 10
                    on conflict (menu_key) do update
                       set menu_nm    = coalesce(excluded.menu_nm, dev_menu.menu_nm)
                         , updated_at = now()
                    """, [key, nm]);
            }
            return Results.Ok(new { synced = n });
        });

        // ---------- 권한 ----------
        // 격자 한 판을 그리기 위한 것 — 막힌 것만 돌려준다 (행이 없으면 허용이므로)
        app.MapGet("/api/menu-perms", async (PgPool db) =>
            Results.Ok(await db.QueryAsync("""
                select bp_id, menu_key
                  from public.dev_user_menu
                 where upper(coalesce(allow_yn, 'N')) = 'N'
                 order by bp_id, menu_key
                """)));

        // 한 사람의 권한을 통째로 바꾼다. denied 에 없는 것은 모두 허용으로 돌아간다.
        // 한 칸씩 보내지 않는 까닭 — 격자를 통째로 저장해야 <끄고 켠 결과> 가 그대로 남는다.
        app.MapPut("/api/menu-perms/{bpId}", async (PgPool db, string bpId, JsonElement body) =>
        {
            var denied = new List<string>();
            if (body.TryGetProperty("denied", out var arr) && arr.ValueKind == JsonValueKind.Array)
                foreach (var x in arr.EnumerateArray())
                {
                    var k = x.GetString()?.Trim();
                    // 항상 열어 두는 메뉴는 받아도 버린다 (화면이 잘못 보내도 잠기지 않게)
                    if (!string.IsNullOrWhiteSpace(k) && !AlwaysOn.Contains(k)) denied.Add(k);
                }

            var who = body.TryGetProperty("updated_by", out var w) ? w.GetString() : "dashboard";

            return await db.UseAsync<IResult>(async c =>
            {
                await c.QueryAsync("begin");
                try
                {
                    await c.QueryAsync("delete from public.dev_user_menu where bp_id = $1::text", [bpId]);
                    foreach (var k in denied.Distinct(StringComparer.OrdinalIgnoreCase))
                        await c.QueryAsync("""
                            insert into public.dev_user_menu (bp_id, menu_key, allow_yn, updated_by)
                            values ($1::text, $2::text, 'N', $3::text)
                            """, [bpId, k, who]);
                    await c.QueryAsync("commit");
                    return Results.Ok(new { bp_id = bpId, denied = denied.Count });
                }
                catch
                {
                    await c.QueryAsync("rollback");
                    throw;
                }
            });
        });
    }
}
