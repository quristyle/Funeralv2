// 메뉴 목록(menuList.js)에 <무엇으로 그릴지>를 붙인다.
// 화면 컴포넌트는 여기서만 부른다 — 목록만 필요한 쪽(권한 화면)이 컴포넌트를 끌고 오지 않도록.
import { MENU_META } from './menuList'
import Summary from './views/Summary.vue'
import Period from './views/Period.vue'
import Users from './views/Users.vue'
import Modules from './views/Modules.vue'
import Rows from './views/Rows.vue'
import Docs from './views/Docs.vue'
import DevUsers from './views/DevUsers.vue'
import Delay from './views/Delay.vue'
import Progress from './views/Progress.vue'
import Ci from './views/Ci.vue'
import GlMonitor from './views/GlMonitor.vue'
import DevUi from './views/DevUi.vue'
import Interfaces from './views/Interfaces.vue'
import Libs from './views/Libs.vue'
import MFlow from './views/MFlow.vue'
import OraKill from './views/OraKill.vue'
import LocPor from './views/LocPor.vue'
import TestFail from './views/TestFail.vue'
import LshipChange from './views/LshipChange.vue'
import Tables2 from './views/Tables2.vue'
import HtmlDoc from './components/HtmlDoc.vue'
import PvSync from './views/PvSync.vue'
import PvFlow from './views/PvFlow.vue'
import Perms from './views/Perms.vue'
import Files from './views/Files.vue'

const COMP = {
  summary: Summary,
  period: Period,
  users: Users,
  modules: Modules,
  progress: Progress,
  delay: Delay,
  rows: Rows,
  ci: Ci,
  glmon: GlMonitor,
  devui: DevUi,
  libs: Libs,
  mflow: MFlow,
  locpor: LocPor,
  orakill: OraKill,
  testfail: TestFail,
  lshipchg: LshipChange,
  tables2: Tables2,
  iface: Interfaces,
  pvsync: PvSync,
  pvflow: PvFlow,
  flow: HtmlDoc,
  tables: HtmlDoc,
  pdflow: HtmlDoc,
  docs: Docs,
  files: Files,
  devusers: DevUsers,
  perms: Perms,
}

// 그릴 컴포넌트가 없는 항목은 빼 둔다 — 목록에만 남은 키로 빈 화면을 띄우지 않는다
export const MENU = MENU_META.filter((m) => COMP[m.key]).map((m) => ({ ...m, comp: COMP[m.key] }))

export { ALWAYS_ON } from './menuList'
