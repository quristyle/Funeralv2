<script setup>
import { computed, onMounted, ref } from 'vue'
import { api } from '../api'
import { state, useViewRefresh, screenUrls } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'
import { useColResize } from '../colresize'

// 단위테스트 FAIL 목록.
//
// 원본은 DRM 이 감싼 엑셀이라 서버가 매번 읽을 수 없다 — 한 번 떠서 표에 넣어 두었다
// (api/TestFail.cs · db/hhip_test_fail.sql). 여기서는 그 표를 보여 주고 H 열만 받는다.
//
// 고치는 칸이 하나뿐이라 <수정 창>을 따로 두지 않았다. 줄 안에서 바로 적고 칸을 벗어나면
// 저장한다 — 62줄을 훑으며 답을 다는 일이라, 한 줄 고칠 때마다 창이 뜨면 일이 안 된다.
// 컬럼 너비 — 머리글 오른쪽 끝을 끌어 조절한다. 두 번 누르면 그 칸만 기본으로.
// 차례가 곧 colgroup 의 차례다 (표의 th 차례와 같아야 한다).
const cw = useColResize('testfail.cols', [
  { k: 'seq', w: 38, min: 30 },
  { k: 'program', w: 200 },
  { k: 'dev', w: 96 },
  { k: 'category', w: 92 },
  { k: 'step', w: 140 },
  { k: 'input_data', w: 150 },
  { k: 'expect', w: 200 },
  { k: 'result', w: 54, min: 44 },
  { k: 'note', w: 230 },
  { k: 'verdict', w: 240, min: 150 },
])

const rows = ref([])
const head = ref('')
const label = ref('판단')
const choices = ref([])
// 값마다 무슨 뜻인지. 서버가 고를 값과 <같은 차례>로 준다 (api/TestFail.cs).
const legend = ref([])
/** 값 → 뜻. 단추·칩·드롭다운의 title 이 전부 이것을 본다 */
const descOf = computed(() => Object.fromEntries(legend.value.map((l) => [l.key, l.desc])))
const showLegend = ref(false)
const total = ref(0)
const loading = ref(false)

// 적은 것은 화면에서 센다 — 서버가 준 숫자를 들고 있으면 한 칸 고칠 때마다
// 목록을 다시 받아야 한다. 62줄짜리라 세는 값이 싸다.
const answered = computed(() => rows.value.filter((r) => (r.verdict ?? '').trim()).length)

/**
 * 판단별 건수. 고를 수 있는 값 순서대로 세고, 그 밖의 말로 적은 것은 <기타> 로 모은다.
 * 안 적은 것까지 한 줄에 둔다 — 합이 전체와 맞아야 숫자를 믿을 수 있다.
 */
const tally = computed(() => {
  const t = new Map(choices.value.map((c) => [c, 0]))
  let other = 0
  for (const r of rows.value) {
    const v = String(r.verdict ?? '').trim()
    if (!v) continue
    if (t.has(v)) t.set(v, t.get(v) + 1)
    else other++
  }
  const out = [...t].map(([k, n]) => ({ key: k, label: k, n }))
  if (other) out.push({ key: '__other', label: '기타', n: other })
  out.push({ key: '__todo', label: '안 적음', n: total.value - answered.value })
  return out
})

// 지금 적고 있는 줄. 한 번에 하나만 열어 둔다 —
// 여러 칸을 열어 두면 어느 것이 저장됐는지 사람이 셀 수 없다.
const editing = ref(null)   // fail_id
const draft = ref('')
const saving = ref(null)    // fail_id
const savedAt = ref({})     // fail_id → 방금 저장했다는 표시(잠깐 보여 준다)
let savedTimer = null

// ---------- 필터 ----------
//
// 두 가지를 같이 쓴다. 머리의 <판단 집계>는 한 번 눌러 크게 갈라 보는 것이고,
// 머리글 아래 칸은 컬럼마다 좁혀 들어가는 것이다. 둘은 and 로 겹친다.
const q = ref('')
/** null 이면 전체. 그 밖에는 판단 값 · '__other' · '__todo' */
const pick0 = ref(null)
/** 컬럼별 필터. 키는 아래 COLF 의 키와 같다. */
const colf = ref({})

// 어느 칸을 무엇으로 거르는지 — 화면(머리글 아래 칸)과 거르는 일이 한 곳을 본다.
// 따로 두면 컬럼을 하나 늘릴 때 한쪽만 고치게 된다.
const COLF = [
  { k: 'program', of: (r) => r.program },
  { k: 'dev', of: (r) => `${r.user_real_nm ?? ''} ${r.user_real_id ?? ''}` },
  { k: 'category', of: (r) => r.category },
  { k: 'step', of: (r) => r.step },
  { k: 'input_data', of: (r) => r.input_data },
  { k: 'expect', of: (r) => r.expect },
  { k: 'result', of: (r) => r.result },
  { k: 'note', of: (r) => r.note },
  // 판단은 여기 없다 — 글자 일부가 아니라 <값 하나>를 고르는 칸이고,
  // 머리의 집계 칩과 <같은 것>을 거른다. 둘 다 pick0 하나를 본다.
]
const hasColf = computed(() => COLF.some((c) => String(colf.value[c.k] ?? '').trim()))
function clearFilters() {
  colf.value = {}
  q.value = ''
  pick0.value = null
}

const view = computed(() => {
  const kw = q.value.trim().toLowerCase()
  const p = pick0.value
  const act = COLF
    .map((c) => [c, String(colf.value[c.k] ?? '').trim().toLowerCase()])
    .filter(([, v]) => v)

  return rows.value.filter((r) => {
    const v = String(r.verdict ?? '').trim()
    if (p === '__todo' && v) return false
    if (p === '__other' && (!v || choices.value.includes(v))) return false
    if (p && p !== '__todo' && p !== '__other' && v !== p) return false

    for (const [c, needle] of act) {
      if (!String(c.of(r) ?? '').toLowerCase().includes(needle)) return false
    }
    if (!kw) return true
    return [r.program, r.user_real_nm, r.category, r.step, r.input_data, r.expect, r.note, r.verdict]
      .some((x) => String(x ?? '').toLowerCase().includes(kw))
  })
})

/**
 * 판단 드롭다운에 깔 값. 집계(tally)와 <같은 순서 · 같은 키>를 쓴다 —
 * 둘이 다른 목록을 들고 있으면 칩에서 고른 것이 드롭다운에 안 보이는 일이 난다.
 */
const verdictOpts = computed(() =>
  tally.value.map((t) => ({ key: t.key, label: `${t.label} (${t.n})` })))

/** 프로그램 칸을 누르면 열 운영 화면 주소. 원장에 없는 화면이면 null 이라 글자로만 보인다. */
const opsOf = (r) =>
  r.systemcode && r.menu_nm ? (screenUrls({ menu_nm: r.menu_nm, systemcode: r.systemcode })?.ops ?? null) : null

async function load() {
  loading.value = true
  try {
    const d = await api.testFail()
    rows.value = d.rows
    head.value = d.verdict_head
    label.value = d.verdict_label ?? '판단'
    choices.value = d.choices
    legend.value = d.legend ?? []
    total.value = d.total
    state.error = ''
  } catch (e) {
    state.error = `FAIL 목록을 읽지 못했습니다: ${e.message}`
  } finally {
    loading.value = false
  }
}
onMounted(load)
useViewRefresh(load)

function startEdit(r) {
  editing.value = r.fail_id
  draft.value = r.verdict ?? ''
}

/** 적은 것을 보낸다. 값이 그대로면 보내지 않는다 — 훑기만 해도 updated_at 이 바뀌면 안 된다. */
async function save(r, text) {
  const next = String(text ?? '').trim()
  editing.value = null
  if (next === String(r.verdict ?? '').trim()) return

  saving.value = r.fail_id
  try {
    const got = await api.testFailSet(r.fail_id, next)
    r.verdict = got.verdict
    r.updated_by = got.updated_by
    r.updated_at = got.updated_at
    // 머리의 집계(answered · tally)는 computed 라 r.verdict 를 바꾼 것만으로 따라온다
    savedAt.value = { ...savedAt.value, [r.fail_id]: true }
    clearTimeout(savedTimer)
    savedTimer = setTimeout(() => (savedAt.value = {}), 2500)
    state.error = ''
  } catch (e) {
    state.error = `저장 실패 (${r.program} · ${r.category}): ${e.message}`
  } finally {
    saving.value = null
  }
}

/** 단추로 고른 값. 이미 같은 값이면 지운다 — 잘못 누른 것을 되돌릴 길이 있어야 한다. */
function pick(r, c) {
  save(r, String(r.verdict ?? '').trim() === c ? '' : c)
}
</script>

<template>
  <section class="panel">
    <h2>
      단위테스트 FAIL
      <span class="hint">{{ total }}건 · 적은 것 {{ answered }}건 · 남은 것 {{ total - answered }}건</span>
      <span class="spacer"></span>
      <RefreshBtn :busy="loading" @click="load" />
    </h2>


    <!-- 판단 집계. 세어서 보여 주기만 하지 않고 <눌러서 거르게> 둔다 —
         "먼소리 7건" 을 보고 나면 다음에 하고 싶은 일은 그 7건을 보는 것이다. -->
    <div class="tally">
      <button class="tl all" :class="{ on: pick0 === null }" @click="pick0 = null">
        전체 <b>{{ total }}</b>
      </button>
      <button
        v-for="t in tally"
        :key="t.key"
        class="tl"
        :class="{ on: pick0 === t.key, zero: !t.n, todo: t.key === '__todo' }"
        :title="descOf[t.key] ? `${t.label} — ${descOf[t.key]}` : t.label"
        @click="pick0 = pick0 === t.key ? null : t.key"
      >{{ t.label }} <b>{{ t.n }}</b></button>
    </div>

    <!-- 범례. 평소에는 접어 둔다 — 다섯 줄이 늘 펼쳐져 있으면 정작 봐야 할 목록을 밀어낸다.
         뜻은 단추·칩·드롭다운의 title 에도 들어 있어, 여기를 펴지 않아도 올려놓으면 보인다. -->
    <p class="legbar">
      <button class="legtoggle" @click="showLegend = !showLegend">
        {{ showLegend ? '▾' : '▸' }} 범례
      </button>
      <span v-if="!showLegend" class="muted lgone">
        <template v-for="(l, i) in legend" :key="l.key">
          <span v-if="i" class="sep">·</span>{{ l.key }}
        </template>
      </span>
    </p>
    <dl v-if="showLegend" class="legend">
      <template v-for="l in legend" :key="l.key">
        <dt>{{ l.key }}</dt>
        <dd>{{ l.desc }}</dd>
      </template>
    </dl>

    <div class="topbar">
      <input v-model="q" type="search" placeholder="전체 검색 (프로그램 · 개발자 · 스텝 · 비고 · 판단)" />
      <button v-if="q || pick0 || hasColf" class="clr" @click="clearFilters">필터 지우기</button>
      <button v-if="cw.touched.value" class="clr" title="컬럼 너비를 모두 기본값으로" @click="cw.resetAll()">너비 되돌리기</button>
      <span class="spacer"></span>
      <span class="hint">{{ view.length }}건 표시 / {{ total }}건</span>
    </div>

    <div class="scroll" :class="{ sizing: cw.sizing.value }">
      <table :style="cw.tableStyle.value">
        <!-- 폭은 여기서만 정한다. table-layout:fixed 가 아니면 브라우저가 내용 길이를 보고
             다시 나눠, 한 칸을 넓혔을 때 옆 칸이 제멋대로 줄어든다. -->
        <colgroup><col v-for="c in cw.cols" :key="c.k" :style="cw.colStyle(c.k)" /></colgroup>
        <thead>
          <tr>
            <th class="num">#<span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값" @pointerdown="cw.start($event, 'seq')" @dblclick="cw.reset('seq')"></span></th>
            <th>프로그램<span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값" @pointerdown="cw.start($event, 'program')" @dblclick="cw.reset('program')"></span></th>
            <th>개발자<span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값" @pointerdown="cw.start($event, 'dev')" @dblclick="cw.reset('dev')"></span></th>
            <th>구분<span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값" @pointerdown="cw.start($event, 'category')" @dblclick="cw.reset('category')"></span></th>
            <th>테스트 스텝<span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값" @pointerdown="cw.start($event, 'step')" @dblclick="cw.reset('step')"></span></th>
            <th>입력 데이터<span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값" @pointerdown="cw.start($event, 'input_data')" @dblclick="cw.reset('input_data')"></span></th>
            <th>예상 결과<span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값" @pointerdown="cw.start($event, 'expect')" @dblclick="cw.reset('expect')"></span></th>
            <th class="ctr">결과<span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값" @pointerdown="cw.start($event, 'result')" @dblclick="cw.reset('result')"></span></th>
            <th>비고<span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값" @pointerdown="cw.start($event, 'note')" @dblclick="cw.reset('note')"></span></th>
            <th :title="head">{{ label }}<span class="cgrip" title="끌어서 너비 조절 · 두 번 누르면 기본값" @pointerdown="cw.start($event, 'verdict')" @dblclick="cw.reset('verdict')"></span></th>
          </tr>
          <!-- 컬럼별 필터. 머리글 바로 아래에 둔다 — 거르는 칸과 걸러지는 칸이
               같은 세로줄에 있어야 무엇을 거르는지 묻지 않아도 안다. -->
          <tr class="filt">
            <th class="num"></th>
            <th><input v-model="colf.program" type="text" placeholder="프로그램" /></th>
            <th><input v-model="colf.dev" type="text" placeholder="개발자" /></th>
            <th><input v-model="colf.category" type="text" placeholder="구분" /></th>
            <th><input v-model="colf.step" type="text" placeholder="스텝" /></th>
            <th><input v-model="colf.input_data" type="text" placeholder="입력" /></th>
            <th><input v-model="colf.expect" type="text" placeholder="예상" /></th>
            <th class="ctr"><input v-model="colf.result" type="text" placeholder="결과" /></th>
            <th><input v-model="colf.note" type="text" placeholder="비고" /></th>
            <!-- 판단은 고를 수 있는 값이 정해져 있다 — 글자를 치게 하면 '접수' 와 '접수 '
                 가 다른 것이 되고, 무엇을 칠 수 있는지도 알 수 없다.
                 머리의 집계 칩과 pick0 를 함께 쓴다: 한쪽에서 고르면 다른 쪽도 따라 움직인다. -->
            <th>
              <select v-model="pick0" :title="head">
                <option :value="null">{{ label }} 전체 ({{ total }})</option>
                <option v-for="o in verdictOpts" :key="o.key" :value="o.key">{{ o.label }}</option>
              </select>
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in view" :key="r.fail_id" :class="{ done: (r.verdict ?? '').trim() }">
            <td class="num muted">{{ r.seq }}</td>
            <!-- 프로그램을 누르면 운영 화면이 열린다. 주소는 원장(wrk2)의 모듈코드와
                 메뉴명 앞머리의 화면코드로 만든다 (store.js 의 screenUrls — 상세 목록과 같은 길).
                 원장에 없는 화면이면 주소가 없어 그냥 글자로 둔다. -->
            <td class="nowrap prog">
              <a
                v-if="opsOf(r)"
                class="oplink"
                :href="opsOf(r)"
                target="_blank"
                rel="noopener noreferrer"
                :title="`운영 화면 열기 — ${r.systemcode} · ${r.menu_nm}`"
              >{{ r.program }}</a>
              <span v-else :title="'원장(상세 목록)에서 이 화면을 찾지 못했습니다 — 주소를 만들 수 없습니다'">
                {{ r.program }}
              </span>
            </td>
            <td class="nowrap dev">
              <template v-if="r.user_real_nm || r.user_real_id">
                <span class="nm">{{ r.user_real_nm || '—' }}</span>
                <span class="uid">{{ r.user_real_id }}</span>
              </template>
              <span v-else class="muted">—</span>
            </td>
            <td class="nowrap">{{ r.category }}</td>
            <td class="small">{{ r.step }}</td>
            <td class="small muted">{{ r.input_data }}</td>
            <td class="small muted">{{ r.expect }}</td>
            <td class="ctr"><span class="tag fail">{{ r.result }}</span></td>
            <td class="small">{{ r.note }}</td>

            <!-- H 열 — 여기만 고친다 -->
            <td class="ved">
              <textarea
                v-if="editing === r.fail_id"
                v-model="draft"
                class="vin"
                rows="2"
                spellcheck="false"
                autofocus
                @blur="save(r, draft)"
                @keydown.esc.prevent="editing = null"
                @keydown.enter.exact.prevent="save(r, draft)"
              ></textarea>
              <button
                v-else
                class="vtext"
                :class="{ empty: !(r.verdict ?? '').trim() }"
                :title="r.updated_by ? `${r.updated_by} · ${r.updated_at}` : '눌러서 적습니다'"
                @click="startEdit(r)"
              >{{ (r.verdict ?? '').trim() || '적기' }}</button>

              <!-- 자주 쓰는 말은 단추로. 자유 입력을 막지는 않는다 — 다시 누르면 지워진다. -->
              <div class="picks">
                <button
                  v-for="c in choices"
                  :key="c"
                  class="pk"
                  :class="{ on: String(r.verdict ?? '').trim() === c }"
                  :disabled="saving === r.fail_id"
                  :title="descOf[c] ? `${c} — ${descOf[c]}` : c"
                  @click="pick(r, c)"
                >{{ c }}</button>
              </div>

              <span v-if="saving === r.fail_id" class="st">저장 중…</span>
              <span v-else-if="savedAt[r.fail_id]" class="st ok">저장됨</span>
              <span v-else-if="r.updated_by" class="st who">{{ r.updated_by }} · {{ r.updated_at }}</span>
            </td>
          </tr>
          <tr v-if="!view.length && !loading">
            <td colspan="10" class="empty">보여 줄 것이 없습니다.</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>

<style scoped>
h2 { display: flex; align-items: center; gap: 8px; }
.spacer { flex: 1; }
.hint { font-size: 12px; font-weight: 400; color: var(--muted); }
.note { margin: 0 0 10px; font-size: 11.5px; line-height: 1.7; }

/* 범례 */
.legbar { display: flex; align-items: baseline; gap: 8px; margin: 0 0 8px; flex-wrap: wrap; }
.legtoggle { font-size: 11px; padding: 2px 8px; color: var(--muted); border-color: var(--line); background: none; }
.legtoggle:hover { color: var(--accent); border-color: var(--accent); }
.lgone { font-size: 11px; }
.lgone .sep { margin: 0 5px; color: var(--muted-3); }
.legend {
  display: grid; grid-template-columns: max-content 1fr; gap: 3px 12px;
  margin: 0 0 10px; padding: 9px 12px; font-size: 11.5px; line-height: 1.7;
  background: var(--bg); border: 1px solid var(--line); border-radius: 8px;
}
.legend dt { font-weight: 600; white-space: nowrap; }
.legend dd { margin: 0; color: var(--muted); }

/* 판단 집계 — 숫자이면서 단추다 */
.tally { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 8px; }
.tl {
  font-size: 11.5px; padding: 3px 10px; border-radius: 12px;
  color: var(--muted); border-color: var(--line); background: var(--panel);
  max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.tl b { color: var(--text); font-variant-numeric: tabular-nums; margin-left: 2px; }
.tl:hover:not(:disabled) { border-color: var(--accent); color: var(--accent); }
.tl.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
.tl.on b { color: var(--on-accent); }
/* 0건은 눈에 덜 띄게 — 지워 버리면 <그 값이 있다> 는 것조차 안 보인다 */
.tl.zero { opacity: 0.45; }
.tl.todo b { color: var(--warn); }
.tl.todo.on b { color: var(--on-accent); }
.tl.all { font-weight: 600; }

.topbar { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; flex-wrap: wrap; }
.clr { font-size: 11.5px; padding: 3px 9px; }
.topbar input[type='search'] { min-width: 230px; }
.btns { display: flex; gap: 4px; }
.btns button { font-size: 11.5px; padding: 3px 9px; }
.btns button.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }

.scroll { overflow: auto; max-height: calc(100vh - 290px); }
table { border-collapse: collapse; width: 100%; font-size: 12px; }
th, td { border-bottom: 1px solid var(--line); padding: 5px 8px; text-align: left; vertical-align: top; }
/* fixed 레이아웃에서는 긴 낱말이 칸을 밀지 못하고 삐져나간다 — 접어서 담는다 */
td { overflow-wrap: anywhere; }
th { position: relative; }   /* 손잡이(.cgrip)가 머리글 오른쪽 끝에 붙는다 */
th {
  position: sticky; top: 0; z-index: 1;
  background: var(--panel); color: var(--muted); font-weight: 600; font-size: 11.5px;
  border-bottom: 1px solid var(--line);
}
td.num, th.num { text-align: right; font-variant-numeric: tabular-nums; }
/* 너비 조절 손잡이 — 머리글 오른쪽 끝의 좁은 띠. 보이지 않지만 커서가 알려 준다. */
.cgrip {
  position: absolute; top: 0; right: -3px; width: 7px; height: 100%;
  cursor: col-resize; user-select: none; touch-action: none; z-index: 2;
}
.cgrip:hover { background: var(--accent); opacity: 0.35; }
/* 끌는 동안에는 글자가 잡히지 않게 — 드래그가 <선택>으로 새면 폭이 안 따라온다 */
.scroll.sizing { user-select: none; cursor: col-resize; }
td.ctr, th.ctr { text-align: center; }
.nowrap { white-space: nowrap; }
/* 머리글 아래 필터 줄. 머리글과 함께 붙어 따라온다 (top 은 머리글 높이만큼) */
thead tr.filt th { position: sticky; top: 27px; z-index: 1; padding: 3px 5px; background: var(--panel); }
thead tr.filt input,
thead tr.filt select {
  width: 100%; min-width: 0; font-size: 11px; padding: 2px 5px; font-weight: 400;
}
/* 고른 것이 있으면 그 칸이 켜져 있다는 티를 낸다 — 걸러 둔 것을 잊고 "왜 안 나오지" 하게 된다 */
thead tr.filt select { cursor: pointer; }

.nm { font-size: 11.5px; }
.uid { color: var(--muted); font-size: 10.5px; margin-left: 4px; font-variant-numeric: tabular-nums; }
a.oplink { color: inherit; text-decoration: none; }
a.oplink:hover { color: var(--accent); text-decoration: underline; }
.small { font-size: 11.5px; line-height: 1.6; }
.prog { font-weight: 600; }
tbody tr:hover { background: var(--hover); }
/* 적어 둔 줄은 한눈에 — 62줄을 훑으며 남은 것을 찾는 화면이다 */
tbody tr.done { background: var(--done-soft); }
tbody tr.done:hover { background: var(--done-soft); }
.empty { text-align: center; color: var(--muted); padding: 24px; }

.tag { font-size: 10.5px; border-radius: 8px; padding: 1px 7px; white-space: nowrap; }
.tag.fail { color: var(--danger-text); background: var(--danger-soft); border: 1px solid var(--danger-line); }


.ved { display: flex; flex-direction: column; gap: 4px; }
.vin { width: 100%; font-size: 11.5px; line-height: 1.5; resize: vertical; }
.vtext {
  width: 100%; text-align: left; font-size: 11.5px; line-height: 1.5;
  padding: 4px 7px; min-height: 26px; white-space: pre-wrap; word-break: break-word;
  border-color: transparent; background: none;
}
tbody tr:hover .vtext { border-color: var(--line); }
.vtext:hover { border-color: var(--accent); }
.vtext.empty { color: var(--muted-3); }

/* 지름길 단추는 줄에 손이 갈 때만 보인다. 자리는 미리 비워 둔다(visibility) —
   나타날 때 줄 높이가 출렁이면 누르려던 곳이 달아난다.
   그래서 <한 줄에 들어가는 것>이 중요하다: 줄바꿈을 막고 긴 말은 잘라 둔다.
   ('ASIS랑같은데ASIS봤냐?' 하나 때문에 세 줄이 되어 62줄이 모두 그만큼 높아졌다.
    잘린 말은 title 로 온전히 읽을 수 있고, 누르면 온전한 값이 저장된다.) */
.picks { display: flex; flex-wrap: nowrap; gap: 3px; visibility: hidden; }
tbody tr:hover .picks,
.ved:focus-within .picks { visibility: visible; }
.pk {
  font-size: 10px; padding: 1px 6px; border-radius: 8px;
  color: var(--muted); border-color: var(--line); background: none;
  flex: 0 1 auto; min-width: 0; max-width: 74px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.pk:hover:not(:disabled) { color: var(--accent); border-color: var(--accent); }
.pk.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }

.st { font-size: 10.5px; color: var(--muted); }
.st.ok { color: var(--done); }
.st.who { color: var(--muted-3); }
</style>
