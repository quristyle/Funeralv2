<script setup>
import { computed, ref } from 'vue'
import { api } from '../api'
import { state, useViewRefresh } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'

// 보관 파일 — 대시보드가 디스크에 쌓아 두는 것들을 한자리에서 본다 (api/FileStore.cs).
//
// 왜 필요한가: 파일이 여러 군데에 따로 쌓인다. 붙여넣은 이미지는 본문에서 지워도 파일은
// 남고, 첨부는 폴더 이름(= 대상 ID)으로만 주인을 알 수 있다. 어디에 무엇이 얼마나
// 있는지 볼 데가 없으면 용량이 새는 것도, 주인 없는 파일도 아무도 모른다.
//
// 이 화면은 <읽기만> 한다. 지우는 것은 각 보관소의 제 화면에서 한다 —
// 지우는 규칙(누가 지울 수 있는지, 무엇이 함께 사라지는지)이 보관소마다 다르기 때문이다.
const stores = ref([])
const sel = ref('')
const detail = ref(null)
const loading = ref(false)
const q = ref('')

// 용량이 이 화면의 요점이라 작은 값을 올려치지 않는다 —
// 빈 폴더가 '1 KB' 로 보이면 <0 건인데 1 KB> 라는 앞뒤가 안 맞는 줄이 된다.
const mb = (n) => {
  if (n == null) return ''
  if (n >= 1024 * 1024 * 1024) return (n / 1024 / 1024 / 1024).toFixed(2) + ' GB'
  if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB'
  if (n >= 1024) return Math.round(n / 1024) + ' KB'
  return n + ' B'
}

async function load() {
  loading.value = true
  try {
    stores.value = await api.fileStores()
    // 처음 열 때는 <파일이 가장 많은 보관소>를 보여 준다. 빈 화면으로 시작하면
    // 무엇을 눌러야 하는지 알 수 없다.
    if (!sel.value) sel.value = [...stores.value].sort((a, b) => b.cnt - a.cnt)[0]?.key ?? ''
    if (sel.value) await open(sel.value)
  } catch (e) {
    state.error = e.message
  } finally {
    loading.value = false
  }
}

async function open(key) {
  sel.value = key
  detail.value = null
  q.value = ''
  try {
    detail.value = await api.fileList(key)
  } catch (e) {
    state.error = e.message
  }
}

const rows = computed(() => {
  const s = q.value.trim().toLowerCase()
  const list = detail.value?.files ?? []
  if (!s) return list
  return list.filter((f) =>
    [f.name, f.owner, f.owner_title].some((v) => String(v ?? '').toLowerCase().includes(s))
  )
})

const total = computed(() => ({
  cnt: stores.value.reduce((a, s) => a + s.cnt, 0),
  bytes: stores.value.reduce((a, s) => a + s.bytes, 0),
}))

// 대상(폴더)이 있는 보관소는 <대상별로 묶어> 보여 준다.
//
// 화면설계 문서는 한 화면에 여러 장이 붙는 것이 보통이다. 파일을 한 줄씩 늘어놓으면
// 대상 이름이 줄마다 되풀이될 뿐, <이 화면에 몇 장이 붙어 있는가> 가 한눈에 안 들어온다.
// 그래서 대상을 머리줄로 세우고 그 아래 파일을 붙인다 (인터페이스 첨부도 같은 모양이다).
const grouped = computed(() => {
  if (!rows.value.some((f) => f.owner)) return null
  const m = new Map()
  for (const f of rows.value) {
    const k = f.owner ?? ''
    if (!m.has(k)) m.set(k, { owner: k, title: f.owner_title, files: [], bytes: 0 })
    const g = m.get(k)
    g.files.push(f)
    g.bytes += f.size
  }
  // 많이 붙은 대상이 위로 — 용량을 살필 때 보통 그쪽부터 본다
  return [...m.values()].sort((a, b) => b.files.length - a.files.length || b.bytes - a.bytes)
})

/** 쓰이지 않는 붙여넣기 이미지 — 본문에서 지워도 파일은 남는다 */
const orphans = computed(() => rows.value.filter((f) => f.used === false).length)

useViewRefresh(load)
load()
</script>

<template>
  <section class="panel">
    <h2>
      보관 파일
      <span class="hint">
        {{ stores.length }}곳 · {{ total.cnt }}건 · {{ mb(total.bytes) }}
        {{ loading ? ' · 조회 중…' : '' }}
      </span>
      <span class="spacer"></span>
      <RefreshBtn :fn="load" label="" title="다시 조회" />
    </h2>

    <p class="muted note">
      대시보드가 파일을 쌓아 두는 곳입니다. <strong>읽기 전용</strong>이며, 지우는 것은 각 보관소의
      제 화면에서 합니다 — 지우는 규칙이 보관소마다 달라서입니다.
    </p>

    <div class="cards">
      <button
        v-for="s in stores"
        :key="s.key"
        class="card"
        :class="{ on: s.key === sel, none: !s.exists }"
        :title="s.dir"
        @click="open(s.key)"
      >
        <div class="k">{{ s.label }}</div>
        <div class="v">
          {{ s.cnt }}<small>건</small>
          <template v-if="s.owners != null"> · {{ s.owners }}<small>대상</small></template>
        </div>
        <div class="b">{{ mb(s.bytes) }}<template v-if="s.newest"> · {{ s.newest }}</template></div>
        <div v-if="!s.exists" class="warn">폴더 없음</div>
      </button>
    </div>
  </section>

  <section v-if="detail" class="panel list">
    <h2>
      {{ detail.label }}
      <span class="hint">{{ rows.length }}건<template v-if="q"> / 전체 {{ detail.files.length }}</template></span>
      <span v-if="orphans" class="orph" :title="`본문 어디에서도 쓰이지 않는 이미지 ${orphans}건`">
        안 쓰임 {{ orphans }}
      </span>
      <span class="spacer"></span>
      <input v-model="q" type="text" placeholder="파일명 · 대상 검색" />
    </h2>

    <p class="path" :title="detail.dir">
      <code>{{ detail.dir }}</code>
      <span class="what">{{ detail.what }}</span>
    </p>

    <div class="scroll">
      <!-- 대상이 있는 보관소 — 대상을 머리줄로 세우고 그 아래에 파일을 붙인다 -->
      <table v-if="grouped" class="grp">
        <thead>
          <tr>
            <th>파일명</th>
            <th class="num">크기</th>
            <th class="nowrap">수정</th>
          </tr>
        </thead>
        <tbody v-for="g in grouped" :key="g.owner">
          <tr class="ghd">
            <td colspan="3">
              <span class="cnt" :title="`이 대상에 붙어 있는 파일 ${g.files.length}건`">{{ g.files.length }}</span>
              <b v-if="g.title" :title="g.title">{{ g.title }}</b>
              <!-- 폴더는 있는데 DB 에 그 대상이 없다 = 지워진 대상의 파일이 남은 것이다 -->
              <b v-else class="gone" title="이 번호의 대상을 찾지 못했습니다 — 지워진 대상의 파일일 수 있습니다">
                주인 없음
              </b>
              <span class="uid">#{{ g.owner }}</span>
              <span class="spacer"></span>
              <span class="sz">{{ mb(g.bytes) }}</span>
            </td>
          </tr>
          <tr v-for="f in g.files" :key="f.raw" class="gf">
            <td class="nm">
              <!-- 새 창으로 연다 — 목록을 떠나지 않고 파일만 보기 위해서다.
                   첨부는 내려받기로 내려오므로 그 창은 스스로 닫힌다. -->
              <a v-if="f.url" :href="f.url" target="_blank" rel="noopener noreferrer" :title="f.name">{{ f.name }}</a>
              <span v-else :title="f.name">{{ f.name }}</span>
            </td>
            <td class="num muted nowrap">{{ mb(f.size) }}</td>
            <td class="muted nowrap">{{ f.modified }}</td>
          </tr>
        </tbody>
      </table>

      <!-- 대상이 없는 보관소 (이미지·로그·엑셀) — 그냥 파일 목록이다 -->
      <table v-else>
        <thead>
          <tr>
            <th>파일명</th>
            <th class="num">크기</th>
            <th class="nowrap">수정</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="f in rows" :key="f.raw">
            <td class="nm">
              <a v-if="f.url" :href="f.url" target="_blank" rel="noopener noreferrer" :title="f.name">{{ f.name }}</a>
              <span v-else :title="f.name">{{ f.name }}</span>
            </td>
            <td class="num muted nowrap">{{ mb(f.size) }}</td>
            <td class="muted nowrap">{{ f.modified }}</td>
            <td class="nowrap">
              <span v-if="f.used === false" class="tag orph" title="개발자 정보·일감 본문 어디에서도 참조하지 않습니다">안 쓰임</span>
              <span v-else-if="f.used === true" class="tag use" title="본문에서 참조하고 있습니다">쓰임</span>
            </td>
          </tr>
        </tbody>
      </table>

      <p v-if="!rows.length" class="muted empty">
        {{ detail.exists ? '파일이 없습니다.' : '폴더가 아직 없습니다 — 처음 저장될 때 만들어집니다.' }}
      </p>
    </div>
  </section>
</template>

<style scoped>
.note { margin: -2px 0 10px; font-size: 11.5px; }
h2 .spacer { flex: 1; }
h2 { display: flex; align-items: center; gap: 8px; }
h2 input { width: 180px; }

.cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(165px, 1fr)); gap: 10px; }
.card {
  text-align: left;
  border: 1px solid var(--line);
  border-radius: var(--radius);
  background: var(--panel);
  padding: 9px 11px;
  cursor: pointer;
}
.card:hover { border-color: var(--accent); }
/* 전역 button.on 이 color 를 on-accent 로 덮는다 — 옅은 바탕이라 글자색을 되돌려 놓는다 */
.card.on { border-color: var(--accent); background: var(--accent-soft); color: var(--text); }
.card.none { opacity: 0.55; }
.card .k { color: var(--muted); font-size: 11.5px; }
.card .v { font-size: 17px; font-weight: 600; margin-top: 1px; }
.card .v small { font-size: 11px; font-weight: 400; color: var(--muted); margin-left: 1px; }
.card .b { font-size: 11px; color: var(--muted); margin-top: 2px; }
.card .warn { font-size: 11px; color: var(--warn); margin-top: 2px; }

.list { margin-top: 12px; }
/* 경로는 이 화면의 답(<어디에 보관하나>)이라 눈에 띄는 자리에 그대로 적어 둔다 */
.path { margin: -2px 0 8px; font-size: 11.5px; display: flex; gap: 10px; align-items: baseline; flex-wrap: wrap; }
.path code {
  background: var(--fill); border-radius: 3px; padding: 2px 6px;
  font-family: Consolas, 'Courier New', monospace; font-size: 11.5px;
}
.path .what { color: var(--muted); }

.scroll { max-height: calc(100vh - 360px); overflow: auto; }
table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
thead th { position: sticky; top: 0; background: var(--panel); z-index: 1; }
.num { text-align: right; }
.nowrap { white-space: nowrap; }
.nm a { color: var(--accent); word-break: break-all; }

/* 대상별 묶음 — 머리줄이 <어느 화면에 몇 장> 인지를 말한다 */
table.grp tbody + tbody { border-top: 6px solid transparent; }
.ghd td {
  background: var(--bg);
  border-bottom: 1px solid var(--line);
  padding: 5px 8px;
}
.ghd td { display: flex; align-items: baseline; gap: 7px; }
.ghd .cnt {
  flex: none;
  background: var(--accent-soft); color: var(--accent);
  border-radius: 999px; padding: 0 7px;
  font-size: 11px; font-weight: 700; font-variant-numeric: tabular-nums;
}
.ghd b { font-size: 12.5px; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ghd b.gone { color: var(--warn); }
.ghd .uid { font-size: 10.5px; color: var(--muted-2); font-variant-numeric: tabular-nums; }
.ghd .spacer { flex: 1; }
.ghd .sz { font-size: 11px; color: var(--muted); flex: none; }
/* 파일은 대상 아래에 딸린 것으로 보이게 한 칸 들인다 */
.gf .nm { padding-left: 24px; position: relative; }
.gf .nm::before { content: '·'; position: absolute; left: 12px; color: var(--muted-3); }
.tag { font-size: 10.5px; border-radius: 3px; padding: 1px 6px; }
.tag.use { color: var(--done); background: var(--done-soft); }
.tag.orph { color: var(--warn); background: var(--warn-soft); }
h2 .orph { font-size: 11px; color: var(--warn); background: var(--warn-soft); border-radius: 3px; padding: 1px 6px; }
.empty { text-align: center; padding: 18px 0; font-size: 12.5px; }
</style>
