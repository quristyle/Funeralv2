<script setup>
import { computed, onMounted, ref } from 'vue'
import { api } from '../api'
import { state, loadDevUsers, useViewRefresh } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'
import { downloadXlsx } from '../xlsx'

// 컬럼 정의 — group 은 표 구분용
const COLS = [
  { key: 'bp_id', label: 'BP ID', w: 92, key0: true },
  { key: 'name', label: '성명', w: 78 },
  // 차단·Super 는 이름 옆에 둔다 — 사람 단위 판정이라 장비/계정 항목들과 성격이 다르다
  { key: 'block_yn', label: '차단', w: 56, tag: 'flag', danger: true },
  { key: 'super_yn', label: 'Super', w: 62, tag: 'flag', power: true },
  { key: 'position_nm', label: '직급', w: 72 },
  { key: 'birth_dt', label: '생년월일', w: 128, tag: 'date' },
  { key: 'email', label: '이메일', w: 170 },
  { key: 'tel_no', label: '전화번호', w: 118, tag: 'tel' },
  { key: 'emerg_tel_no', label: '비상연락처', w: 118, tag: 'tel' },
  { key: 'use_ip', label: '사용 IP', w: 120, tag: 'ip' },
  { key: 'mac_addr', label: 'MAC 주소', w: 140, tag: 'mac' },
  { key: 'notebook_no', label: '노트북 장비번호', w: 120, tag: 'code' },
  { key: 'notebook_chk_no', label: '노트북 확인번호', w: 120, tag: 'code' },
  { key: 'monitor1_no', label: '모니터1 장비번호', w: 120, tag: 'code' },
  { key: 'monitor1_chk_no', label: '모니터1 확인번호', w: 120, tag: 'code' },
  { key: 'monitor2_no', label: '모니터2 장비번호', w: 120, tag: 'code' },
  { key: 'monitor2_chk_no', label: '모니터2 확인번호', w: 120, tag: 'code' },
  { key: 'monitor3_no', label: '모니터3 장비번호', w: 120, tag: 'code' },
  { key: 'monitor3_chk_no', label: '모니터3 확인번호', w: 120, tag: 'code' },
  { key: 'summer_size', label: '하복', w: 62, tag: 'size' },
  { key: 'winter_size', label: '동복', w: 62, tag: 'size' },
  { key: 'git', label: 'Git', w: 48, tag: 'flag' },
  { key: 'startkit', label: 'StartKit', w: 62, tag: 'flag' },
  { key: 'dxb', label: 'DXB', w: 48, tag: 'flag' },
  { key: 'vm_conn', label: 'VM접속', w: 58, tag: 'flag' },
  { key: 'aipro', label: 'AI Pro', w: 54, tag: 'flag' },
  { key: 'claudecode', label: 'Claude', w: 58, tag: 'flag' },
  { key: 'dev_db', label: '개발DB', w: 58, tag: 'flag' },
  { key: 'wiki', label: 'Wiki', w: 48, tag: 'flag' },
  { key: 'projectview', label: 'PrjView', w: 60, tag: 'flag' },
  // ProjectView 워크플로의 담당자를 이름 대신 이 id 로 지정한다 (동명이인·개명에 흔들리지 않는다)
  { key: 'pv_user_id', label: 'PrjView ID', w: 150, tag: 'code' },
  { key: 'svn', label: 'SVN', w: 48, tag: 'flag' },
  { key: 'notebook', label: '노트북', w: 56, tag: 'flag' },
  { key: 'hub_hdmi', label: '허브/HDMI', w: 68, tag: 'flag' },
]
const FLAG_OPTS = ['', 'O', 'X', 'o', 'x']

/** 켜진 것으로 치는 값 — 서버(IpGate.IsOn)와 같은 규칙으로 본다 */
const isOn = (v) => /^[oy]/i.test(String(v ?? '').trim())

// 입력 힌트 (tag 별 placeholder)
const PH = {
  size: '예: 100',
  ip: '10.133.172.1',
  mac: '00-1A-2B-3C-4D-5E',
  tel: '010-0000-0000',
  code: '',
}

const rows = ref([])
const origin = ref({}) // bp_id → 원본 스냅샷 (변경 감지용)
const loading = ref(false)
const saving = ref(null)
const adding = ref(null) // 새 행 (bp_id 미확정)

async function load() {
  loading.value = true
  try {
    rows.value = await api.devUsers()
    origin.value = Object.fromEntries(rows.value.map((r) => [r.bp_id, JSON.stringify(r)]))
  } catch (e) {
    state.error = e.message
  } finally {
    loading.value = false
  }
}

const dirty = (r) => origin.value[r.bp_id] !== JSON.stringify(r)

// 칸을 떠나는 즉시 저장한다 (select 는 고르는 즉시).
// 글자마다 보내지 않는 까닭 — change 는 <다 쓰고 칸을 떠날 때> 한 번만 나므로
// 한 번 고친 것이 한 번의 저장이 된다. input 에 걸면 글자 수만큼 요청이 나간다.
const saved = ref({}) // bp_id → 방금 저장됨 (잠깐 ✓ 를 보여 준다)
const failed = ref({}) // bp_id → 실패 사유. 남아 있으면 [저장] 단추로 다시 시도한다
const lastSave = new Map() // bp_id → 진행 중인 저장. 같은 행의 저장을 줄 세운다

async function save(r) {
  saving.value = r.bp_id
  try {
    const body = {}
    for (const c of COLS) if (!c.key0) body[c.key] = r[c.key] ?? ''
    // 보낸 그 순간의 모습을 기억해 둔다 — 저장을 기다리는 사이에 사용자가 또 고칠 수 있어,
    // 응답이 온 뒤의 r 로 기준을 잡으면 그 새 수정이 <이미 저장됨> 으로 묻힌다.
    const sent = JSON.stringify(r)
    await api.devUserUpdate(r.bp_id, body)
    origin.value[r.bp_id] = sent
    delete failed.value[r.bp_id]
    saved.value[r.bp_id] = Date.now()
    setTimeout(() => {
      if (Date.now() - (saved.value[r.bp_id] ?? 0) >= 1900) delete saved.value[r.bp_id]
    }, 2000)
    await loadDevUsers() // 상세 목록의 담당자/개발자 셀렉트도 갱신
  } catch (e) {
    failed.value[r.bp_id] = e.message
    state.error = `저장 실패: ${r.name || r.bp_id} — ${e.message}`
  } finally {
    saving.value = null
  }
}

/** 한 행의 저장은 순서대로 — 여러 칸을 빠르게 옮겨 다녀도 마지막 값이 이긴다 */
function autoSave(r) {
  // 서버와 같아졌으면 보낼 것이 없다. 앞서 실패한 표시도 함께 지운다 —
  // 실패한 뒤 값을 원래대로 되돌린 경우가 여기다. 안 지우면 표시가 영영 남는다.
  if (!dirty(r)) {
    delete failed.value[r.bp_id]
    return
  }
  const prev = lastSave.get(r.bp_id) ?? Promise.resolve()
  const next = prev.then(() => (dirty(r) ? save(r) : undefined)).catch(() => {})
  lastSave.set(r.bp_id, next)
  return next
}

function startAdd() {
  adding.value = Object.fromEntries(COLS.map((c) => [c.key, '']))
}
async function commitAdd() {
  if (!adding.value.bp_id?.trim()) {
    state.error = 'BP ID 는 필수입니다.'
    return
  }
  try {
    await api.devUserCreate(adding.value)
    adding.value = null
    await load()
    await loadDevUsers()
  } catch (e) {
    state.error = `추가 실패: ${e.message}`
  }
}

async function remove(r) {
  if (!confirm(`${r.name || ''} (${r.bp_id}) 를 삭제할까요?`)) return
  try {
    await api.devUserDelete(r.bp_id)
    await load()
    await loadDevUsers()
  } catch (e) {
    state.error = `삭제 실패: ${e.message}`
  }
}

const dirtyCount = computed(() => rows.value.filter(dirty).length)

/** 엑셀로 내려받는다 — 화면의 컬럼 순서·이름 그대로, 보이는 행 전부 */
function exportXlsx() {
  const headers = COLS.map((c) => ({ label: c.label, width: c.w }))
  // 저장 안 된 값도 <화면에 보이는 그대로> 담는다. 지금 보고 있는 표를 옮기는 것이 목적이다.
  const body = rows.value.map((r) => COLS.map((c) => r[c.key] ?? ''))
  return downloadXlsx('개발자관리', '개발자 관리', headers, body)
}

useViewRefresh(load)
onMounted(load)
</script>

<template>
  <section class="panel">
    <h2>
      개발자 관리
      <span class="hint">
        {{ rows.length }}명{{ dirtyCount ? ` · 저장 안 된 행 ${dirtyCount}` : '' }}{{ loading ? ' · 불러오는 중…' : '' }}
      </span>
      <span class="spacer"></span>
      <button
        title="엑셀 내려받기 — 화면의 컬럼과 행을 그대로 담습니다"
        :disabled="!rows.length"
        @click="exportXlsx"
      >⤓ 엑셀</button>
      <button v-if="!adding" @click="startAdd">+ 개발자 추가</button>
      <RefreshBtn :fn="load" />
    </h2>

    <div class="scroll">
      <table>
        <thead>
          <tr>
            <th v-for="c in COLS" :key="c.key" :style="{ minWidth: c.w + 'px' }">{{ c.label }}</th>
            <th style="min-width: 96px">작업</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="adding" class="new">
            <td v-for="c in COLS" :key="c.key">
              <select v-if="c.tag === 'flag'" v-model="adding[c.key]">
                <option v-for="o in FLAG_OPTS" :key="o" :value="o">{{ o || '—' }}</option>
              </select>
              <input
                v-else
                v-model="adding[c.key]"
                :type="c.tag === 'date' ? 'date' : 'text'"
                :placeholder="c.label"
              />
            </td>
            <td class="acts">
              <button @click="commitAdd">추가</button>
              <button @click="adding = null">취소</button>
            </td>
          </tr>

          <tr v-for="r in rows" :key="r.bp_id" :class="{ dirty: dirty(r), blocked: isOn(r.block_yn) }">
            <td v-for="c in COLS" :key="c.key">
              <span v-if="c.key0" class="key">{{ r.bp_id }}</span>
              <select
                v-else-if="c.tag === 'flag'"
                v-model="r[c.key]"
                :class="{ danger: c.danger && isOn(r[c.key]), power: c.power && isOn(r[c.key]) }"
                :title="c.danger
                  ? '차단 — 사용 IP 가 등록돼 있어도 막습니다 (서버 장비의 localhost 접속은 예외)'
                  : c.power
                    ? 'Super 권한 — 관리자 전용 도구가 보이고, 메뉴 권한과 무관하게 전체 메뉴를 씁니다'
                    : ''"
                @change="autoSave(r)"
              >
                <option v-for="o in FLAG_OPTS" :key="o" :value="o">{{ o || '—' }}</option>
              </select>
              <input
                v-else
                v-model="r[c.key]"
                :type="c.tag === 'date' ? 'date' : 'text'"
                :class="{ mono: ['ip', 'mac', 'code', 'tel'].includes(c.tag) }"
                :placeholder="PH[c.tag] || ''"
                @change="autoSave(r)"
              />
            </td>
            <!-- 칸을 떠나면 바로 저장되므로 [저장] 단추는 평소에 없다.
                 실패했을 때만 다시 시도할 자리로 나타난다. -->
            <td class="acts">
              <span v-if="saving === r.bp_id" class="st busy">저장 중…</span>
              <button
                v-else-if="failed[r.bp_id] || dirty(r)"
                class="retry"
                :title="failed[r.bp_id] || '아직 저장되지 않았습니다'"
                @click="autoSave(r)"
              >저장</button>
              <span v-else-if="saved[r.bp_id]" class="st ok">✓ 저장됨</span>
              <span v-else class="st"></span>
              <button class="del" @click="remove(r)">삭제</button>
            </td>
          </tr>

          <tr v-if="!rows.length && !loading && !adding">
            <td :colspan="COLS.length + 1" class="muted" style="text-align: center; padding: 20px">
              등록된 개발자가 없습니다.
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <p class="muted note">
      값을 고치고 <strong>칸을 떠나면 바로 저장</strong>됩니다 (선택 항목은 고르는 즉시).
      <code>✓ 저장됨</code> 이 잠깐 표시되고, 실패하면 그 자리에 <strong>저장</strong> 버튼이 남아
      다시 시도할 수 있습니다.
      <code>BP ID</code> 는 키라서 수정할 수 없습니다 (변경이 필요하면 추가 후 삭제).
      성명 변경은 상세 목록의 담당자·개발자 표기에도 바로 반영됩니다.
    </p>
    <p class="muted note">
      <strong>Super</strong> 를 켜면 최고 관리자가 됩니다 — 상세 목록의 관리자 전용 아이콘
      (<code>⛁</code> ProjectView 데이터 수집, <code>✔</code> 단위테스트 상태 변경)과
      <code>메뉴 권한</code> 화면이 보이고, 메뉴 권한 설정과 무관하게 전체 메뉴를 씁니다.
      <code>appsettings</code> 의 <code>Admin:BpIds</code> 에 적힌 사람은 이 값을 꺼도 계속
      관리자입니다 — <strong>아무도 관리자가 아닌 상태</strong>가 되면 되돌릴 화면조차 들어갈 수 없어
      바닥으로 남겨 둔 것입니다.
    </p>
    <p class="muted note">
      <strong>차단</strong> 을 켜면 그 사람은 사용 IP 가 등록돼 있어도 막히고,
      흔한 서버 오류처럼 보이는 화면을 받습니다.
      서버 장비에서 <code>localhost</code> 로 접속할 때는 <strong>막지 않습니다</strong>
      (스스로를 잠그면 풀 방법이 남지 않기 때문입니다).
      그래서 이 화면은 여기서 실제로 볼 수 없습니다 —
      <a href="/blocked-preview" target="_blank" rel="noopener">차단 화면 미리보기</a>
      ·
      <a href="/denied-preview" target="_blank" rel="noopener">미등록 화면 미리보기</a>
    </p>
  </section>
</template>

<style scoped>
h2 .spacer { flex: 1; }
.scroll { overflow: auto; max-height: calc(100vh - 220px); }
thead th { position: sticky; top: 0; z-index: 2; background: var(--panel); box-shadow: inset 0 -1px 0 var(--line); }
td { padding: 3px 5px; }
td input, td select { width: 100%; padding: 3px 5px; }
td input { border: 1px solid transparent; border-radius: 4px; background: transparent; }
td input:hover { border-color: var(--line); background: var(--panel); }
td input:focus { border-color: var(--accent); background: var(--panel); outline: none; }
td select { border: 1px solid transparent; background: transparent; border-radius: 4px; }
td select:hover { border-color: var(--line); background: var(--panel); }
.key { font-weight: 600; font-variant-numeric: tabular-nums; padding-left: 3px; }
/* IP · MAC · 장비번호는 고정폭으로 자릿수 맞춰 보이게 */
td input.mono { font-family: Consolas, 'Courier New', monospace; font-variant-numeric: tabular-nums; }
/* 저장 상태 — 자리를 늘 차지해 두어 줄이 흔들리지 않게 한다 */
.acts .st {
  display: inline-block;
  min-width: 52px;
  font-size: 11px;
  color: var(--muted);
  white-space: nowrap;
}
.acts .st.ok { color: var(--done); }
.acts .st.busy { color: var(--accent); }
.acts .retry { min-width: 52px; border-color: var(--warn); color: var(--warn); }

tr.dirty { background: var(--warn-soft); }
tr.dirty td:first-child { box-shadow: inset 3px 0 0 var(--warn); }

/* 차단된 사람은 줄 전체를 흐리게 — 목록에서 한눈에 가려낸다 */
tr.blocked td .key,
tr.blocked td input,
tr.blocked td select { opacity: 0.55; }
tr.blocked td select.danger { opacity: 1; }
select.danger {
  border-color: var(--danger-2);
  background: var(--danger-soft);
  color: var(--danger-text);
  font-weight: 600;
}
/* Super 는 막는 것이 아니라 <주는> 것이라 차단과 색을 달리한다 */
select.power {
  border-color: var(--accent);
  background: var(--accent-soft);
  color: var(--accent);
  font-weight: 600;
}
tr.blocked td select.power { opacity: 1; }
tr.new { background: var(--accent-soft); }
.acts { white-space: nowrap; display: flex; gap: 4px; }
.acts button { padding: 2px 8px; }
.del:hover { border-color: var(--danger-2); color: var(--danger-2); }
.note { margin: 8px 0 0; }
</style>
