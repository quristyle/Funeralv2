<script setup>
import { onMounted, ref } from 'vue'
import { copyText } from '../pvScript'

// ProjectView 전송 스크립트를 보여 주는 창.
// HTTP(비보안 컨텍스트)에서는 clipboard API 가 막히므로 내용을 전체 선택해 두고
// Ctrl+C 로도 복사할 수 있게 한다. 진척률·실적시작일 두 화면이 함께 쓴다.
const props = defineProps({
  script: { type: String, required: true },
  title: { type: String, default: 'ProjectView 전송 스크립트' },
  meta: { type: String, default: '' },   // 예: '12건 · 계획진척률'
  sends: { type: String, default: '' },  // 실제로 바뀌는 값 설명
  // 읽기 전용 스크립트(수집)는 pvSend() 단계가 없으므로 안내를 바꿔 끼운다
  steps: { type: Array, default: null },
})
const emit = defineEmits(['close'])

const area = ref(null)
const msg = ref('')

async function doCopy() {
  area.value?.select()
  msg.value = (await copyText(props.script))
    ? '복사했습니다. ProjectView 탭의 F12 → Console 에 붙여넣으세요.'
    : '자동 복사가 차단되었습니다. 아래 내용이 전체 선택된 상태이니 Ctrl+C 로 복사하세요.'
}

// 열리자마자 전체 선택 → Ctrl+C 로 바로 복사 가능
onMounted(() => setTimeout(() => area.value?.select(), 50))
</script>

<template>
  <div class="mask" @click.self="emit('close')">
    <div class="dlg">
      <header>
        <strong>{{ title }}</strong>
        <span class="hint">{{ meta }}</span>
        <span class="spacer"></span>
        <button @click="doCopy">복사</button>
        <button @click="emit('close')">닫기</button>
      </header>

      <ol v-if="steps" class="steps">
        <li v-for="(s, i) in steps" :key="i" v-html="s"></li>
      </ol>
      <ol v-else class="steps">
        <li>아래 스크립트를 복사합니다 (자동 복사가 막히면 <code>Ctrl+C</code>).</li>
        <li><strong>ProjectView 로그인 탭</strong>에서 <code>F12 → Console</code> 에 붙여넣고 Enter
          → <strong>확인만</strong> 하고 전송하지 않습니다 (DRY RUN).</li>
        <li>출력된 대상·값이 맞으면 콘솔에 <code>pvSend()</code> 를 입력하고 Enter → <strong>실제 전송</strong>.</li>
        <li>전송 후 ProjectView 화면을 <strong>새로고침(F5)</strong> 하면 반영된 값이 보입니다.
          실패한 건이 있으면 <strong>같은 스크립트를 한 번 더</strong> 돌리면 됩니다 —
          이미 맞는 값은 건너뜁니다.</li>
      </ol>

      <p v-if="sends" class="sends">{{ sends }}</p>
      <p v-if="msg" class="pvmsg">{{ msg }}</p>

      <textarea ref="area" class="code" readonly :value="script" spellcheck="false"></textarea>
    </div>
  </div>
</template>

<style scoped>
.mask {
  position: fixed;
  inset: 0;
  background: var(--overlay);
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 50px 20px;
  z-index: 100;
}
.dlg {
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 10px;
  width: min(940px, 100%);
  max-height: calc(100vh - 100px);
  display: flex;
  flex-direction: column;
  box-shadow: 0 8px 28px var(--shadow);
}
.dlg header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 14px;
  border-bottom: 1px solid var(--line);
}
.dlg header .hint { font-size: 11.5px; color: var(--muted); }
.dlg header .spacer { flex: 1; }
.steps { margin: 12px 14px; padding-left: 20px; font-size: 12px; color: var(--muted); line-height: 1.8; }
.steps strong { color: var(--text); }
.sends {
  margin: 0 14px 8px;
  background: var(--warn-soft);
  border: 1px solid var(--warn-line);
  color: var(--warn);
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 12px;
}
.pvmsg {
  margin: 0 14px 8px;
  background: var(--accent-soft);
  border: 1px solid var(--accent);
  color: var(--accent);
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 12px;
}
.code {
  margin: 0 14px 14px;
  flex: 1;
  min-height: 260px;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 11.5px;
  line-height: 1.5;
  border: 1px solid var(--line);
  border-radius: 6px;
  padding: 10px;
  background: var(--surface);
  resize: vertical;
  white-space: pre;
  overflow: auto;
}
</style>
