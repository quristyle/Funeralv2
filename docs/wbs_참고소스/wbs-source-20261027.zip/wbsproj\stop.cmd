@echo off
rem ============================================================
rem  stop.cmd - take the WBS dashboard down
rem
rem    stop.cmd           stop API (5080 / 5443) and Vite (5173)
rem    stop.cmd status    only report what is currently up
rem
rem  start.cmd hides the windows, so there is nothing to close by
rem  hand any more - this is the way down.  It kills the PIDs that
rem  start.cmd wrote to logs\*.pid, then sweeps the two ports in
rem  case something else is holding them (serve.cmd, a manual
rem  dotnet run, an orphan from a previous session).
rem
rem  PMM dev servers (8200+N / 3200+N) are NOT touched.  They are
rem  deliberately detached from the dashboard (api\DevRun.cs) and
rem  keep running.  Stop them from the dashboard's [local dev
rem  server] screen, or from the dev-ui console on your own PC.
rem
rem  Messages are ASCII only on purpose - see the note in start.cmd.
rem ============================================================
setlocal

set "ACT=stop"
if /i "%~1"=="status" set "ACT=status"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\serve.ps1" -Action %ACT%
exit /b %ERRORLEVEL%
