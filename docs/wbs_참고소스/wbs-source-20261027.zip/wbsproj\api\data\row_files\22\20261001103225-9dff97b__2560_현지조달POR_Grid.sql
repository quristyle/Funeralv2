--------------------------------------------------------------------------------
-- [2560] 현지 조달 POR 관리 (구 MM2510)
-- 대상 스키마 예시: M20 (대형선). 중형선(M10/NEW05/SST01) 조회 시에는
-- 아래 M20. 접두어만 해당 스키마로 교체해서 사용 (스키마 라우팅 규칙은
-- 호선번호 -> 선박 크기 매핑 기준으로 애플리케이션 단에서 결정, 미확정).
-- 용어: 화면 표기는 "한국전환"으로 통일 (DB 컬럼명/코멘트 원문, 기존 등록된 사유 텍스트는 "국내전환" 표현 그대로 유지)
-- 작성일 2026.09.18 (v0.7) - 필드정의(PPT 4p)를 그리드 표시 순서와 1:1로 맞춤, T30B_1130 처리 UPDATE로 변경
--------------------------------------------------------------------------------

-- ① Grid 조회 (그리드 표시 컬럼 순서와 동일 + 참고용 미표시 컬럼 포함)
-- ※ BNFPO(품목번호) 출처 확인됨: T30B_1120에는 없고, SST02.MTB_POR_OLN.BNFPO(CHAR5)가 원본.
--   같은 인터페이스 테이블의 BANFN(CHAR10, 구매요청번호)도 함께 존재 - 필요 시 참고.
--   조인키: SHIP_NO / POR_NO / LINE_NO(=POR_SEQ) / REV_NO(=POR_REV_NO)
SELECT
    H.SHIP_NO                              AS 호선번호,
    DECODE(T.ZTRANSPOR,'X','전환','미전환') AS 한국전환여부,
    H.POR_NO                               AS POR번호,
    D.POR_SEQ                              AS 순번,
    D.POR_REV_NO                           AS 수정번호,
    H.POR_STAT                             AS POR상태_CD,      -- 코드값. 코드테이블 조인 시 텍스트("Sent to A/Section" 등)로 변환 필요
    D.MATL_CD                              AS 자재코드,
    D.QUALITY || '/' || D.SHAPE            AS 자재규격,        -- ※조합규칙 추정치(THK/WIDTH/LENGTH 포함 여부 등 확인 필요)
    D.REQ_QTY                              AS 요청수량,
    D.MATL_UNIT                            AS 단위,
    D.EST_AMT                              AS "예상금액(USD)",
    D.REQ_DLY_DTE                          AS 요청납기일,
    D.RECV_DTE                             AS POR접수일,       -- ※H.RGST_DTE와 구분 확인 필요
    D.PO_COM                               AS 발주회사,
    D.PUBLISH_DIV                          AS 발행구분,
    D.RGST_EMP                             AS 등록자,
    T.ZTRANSDAT                            AS 전환일자,        -- CHAR(8), 'YYYYMMDD'
    T.ZTRANSRSN                            AS 전환사유,
    O.BNFPO                                AS 품목번호,        -- 화면엔 미표시, 한국전환 등록 시 :BNFPO로 그대로 전달용
    -- 이하는 그리드 미표시, 참고/상세팝업용
    D.QUALITY, D.SHAPE,                                        -- 재질/형상(개별)
    D.THK1 || 'x' || D.WIDTH1 || 'x' || D.LENGTH AS 규격,
    D.UNIT_PRICE                           AS 단가,
    D.UNIT_WGT                             AS 단중,
    D.EMERGENT_YN                          AS 긴급여부,
    H.FILE_PATH, H.ATT_FILE_NAME, H.SUP_ATT_FILE_NAME         -- 첨부파일
FROM M20.T30B_1110 H
JOIN M20.T30B_1120 D
    ON D.SHIP_NO = H.SHIP_NO
   AND D.POR_NO  = H.POR_NO
LEFT JOIN SST02.MTB_POR_OLN O
    ON O.SHIP_NO = H.SHIP_NO
   AND O.POR_NO  = D.POR_NO
   AND O.LINE_NO = D.POR_SEQ
   AND O.REV_NO  = D.POR_REV_NO
   -- ※ O.SHIP_NO는 CHAR(24)로 T30B_1120.SHIP_NO(CHAR6)와 길이가 다르나 CHAR 비교는 자동 블랭크패딩되어 값 비교엔 문제 없음
LEFT JOIN M20.IF_MTB_POR_TRANS T
    ON T.PSPID     = H.SHIP_NO
   AND T.ZPORNO    = D.POR_NO
   AND T.ZPORSEQNO = D.POR_SEQ
   AND T.ZREVNO    = D.POR_REV_NO
   AND T.BNFPO     = O.BNFPO
WHERE H.SHIP_NO = :호선번호
  AND (:POR_NO IS NULL OR H.POR_NO = :POR_NO)
ORDER BY H.POR_NO, D.POR_SEQ;


--------------------------------------------------------------------------------
-- ② "한국전환" 버튼 → 사유입력 팝업 "확인" 클릭 시 처리 - 3단계로 처리
-- ※ 아래 :BNFPO는 사용자가 Grid에서 선택한 행의 값(①에서 O.BNFPO로 조회된 값)을 그대로
--   전달받아 쓰면 됨 - 이 단계에서 별도로 다시 조회할 필요 없음.
--------------------------------------------------------------------------------

-- 2-1) T30B_1130 한국전환 현재상태 flag 갱신 (UPDATE) -- 행은 인터페이스로 이미 적재돼 있다고 보고 UPDATE로 처리 (MERGE 미사용)
UPDATE M20.T30B_1130
   SET DOM_CVT_YN = 'Y', REV_EMP = :사용자사번, REV_DTE = SYSDATE
 WHERE SHIP_NO = :SHIP_NO AND POR_NO = :POR_NO AND POR_SEQ = :POR_SEQ AND POR_REV_NO = :POR_REV_NO;
-- ※ 대상 행이 없으면(0 rows updated) 인터페이스 미수신 등 이상 상황이므로 애플리케이션에서 오류 처리 필요

-- 2-2) T30B_1131 한국전환 이력 적재 (시도할 때마다 매번 INSERT, EAI 성격 아님 - batch_id 등 불필요)
-- ※ HIST_SEQ는 스칼라 서브쿼리로 "다음 번호"를 계산해 VALUES에 바로 꽂는 형태(테스트/예시용).
--   해당 키로 첫 등록이면 서브쿼리 결과가 NULL이라 NVL(...,0)+1 = 1이 됨(기존 데이터 없어도 정상 동작 - 검증 완료).
-- ★ 채번 방식 관련 전제: 이 MAX+1 서브쿼리 방식은 예시일 뿐이며, 동시성/이중화(WAS 다중 서버, DB
--   이중화) 환경에서는 안전하지 않음(동시 요청 시 같은 값 충돌 가능). 프로젝트에 기존 채번
--   컨벤션(공통 시퀀스/공통 모듈 등)이 있으면 이 예시 대신 그 방식을 따를 것. 없다면 SEQUENCE
--   기반 채번 + 화면 표시용 ROW_NUMBER() 조합을 검토할 것.
INSERT INTO M20.T30B_1131
    (SHIP_NO, POR_NO, POR_SEQ, POR_REV_NO, BNFPO, HIST_SEQ,
     PROC_RSLT, PROC_MSG, TRANS_DTE, TRANS_RSN, RGST_EMP, RGST_DTE)
VALUES
    (:SHIP_NO, :POR_NO, :POR_SEQ, :POR_REV_NO, :BNFPO,
     (SELECT NVL(MAX(HIST_SEQ), 0) + 1
        FROM M20.T30B_1131
       WHERE SHIP_NO = :SHIP_NO AND POR_NO = :POR_NO AND POR_SEQ = :POR_SEQ AND POR_REV_NO = :POR_REV_NO),
     'S', '전환 요청 등록 완료', TO_CHAR(SYSDATE,'YYYYMMDD'), :전환사유, :사용자사번, SYSDATE);
-- ※ 동시성 주의: 동일 건 중복 클릭 시 HIST_SEQ 충돌 가능 - 애플리케이션 레벨 락 또는 SELECT ... FOR UPDATE 권장

-- 2-3) M20.IF_MTB_POR_TRANS 전송 등록 (순수 INSERT. UPDATE 없음 - PK에 ZREVNO 포함되어 리비전마다 새 행)
INSERT INTO M20.IF_MTB_POR_TRANS
    (PSPID, ZPORNO, ZPORSEQNO, BNFPO, ZREVNO,
     ZTRANSPOR, ZTRANSDAT, ZTRANSRSN, MMUSEID,
     RAW_IFSEQ, RAW_PSPID, RAW_ZPORNO, RAW_ZPORSEQNO, RAW_ZREVNO,
     PROC_SCRN_ID, REG_EMPNO, REG_DT)
VALUES
    (:SHIP_NO, :POR_NO, :POR_SEQ, :BNFPO, :POR_REV_NO,
     'X', TO_CHAR(SYSDATE,'YYYYMMDD'), :전환사유, :사용자사번,
     'NOSRC-' || RTRIM(:SHIP_NO) || :POR_NO || :POR_SEQ || :POR_REV_NO,
     :SHIP_NO, :POR_NO, :POR_SEQ, :POR_REV_NO,
     '2560', :사용자사번, SYSDATE);
-- ※ PROC_SCRN_ID '2560'은 신규 화면ID. 과거 실운영 데이터는 구 화면ID '2510'으로 등록되어 있음(참고용, 변경 불필요).
