-- 개발자 정보 섹션의 iframe — <올린 파일> 말고 <주소(URL)> 로도 걸 수 있게 한다.
--
-- 한 줄은 둘 중 하나다. 파일이면 file 이 차고, 주소면 url 이 찬다. 둘 다 차 있거나
-- 둘 다 비어 있는 줄은 만들지 않는다(ck_dev_doc_files_one) — <무엇을 보여 줄 것인가> 를
-- 화면이 그때그때 짐작하게 두면, 비어 있는 iframe 이 떠도 까닭을 알 수 없다.
--
-- 주소로 건 것은 우리 서버를 거치지 않는다. 화면이 그 주소를 iframe 에 그대로 건다.
-- 받아다 중계(proxy)하지 않는 까닭:
--   · 중계하면 그 사이트의 쿠키·로그인이 끊겨 <사내 다른 화면> 이 거의 다 안 열린다
--   · 남의 사이트를 우리 주소로 내보내는 꼴이 되어, 그쪽 CSP 를 우리가 어기게 된다
-- 대신 상대가 X-Frame-Options 로 막아 두었으면 빈 칸으로 보인다 — 화면이 그 사정을
-- 적어 두고 [새 탭으로 열기] 를 함께 준다.

alter table public.dev_doc_files alter column file drop not null;
alter table public.dev_doc_files add column if not exists url text;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'ck_dev_doc_files_one') then
    alter table public.dev_doc_files
      add constraint ck_dev_doc_files_one
      check ((file is not null) <> (url is not null));
  end if;
end $$;

comment on column public.dev_doc_files.url  is '주소로 건 경우의 주소. file 과 둘 중 하나만 찬다';
comment on column public.dev_doc_files.file is '올린 파일 이름 — api/data/doc_files/{doc_id}/ 안. url 과 둘 중 하나만 찬다';
comment on column public.dev_doc_files.name is '화면에 적을 이름 (파일이면 원래 파일 이름, 주소면 붙인 이름)';
