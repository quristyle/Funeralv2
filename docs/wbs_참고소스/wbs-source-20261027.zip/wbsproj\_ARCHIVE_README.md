# WBS 대시보드 — 소스 보관본

`D:\수빅자재\wbsproj` 를 그대로 뜬 것이다. 받아 올 수 있는 것과 빌드 산출물만 뺐다.

짝이 되는 DB 보관본은 **`wbs-db-*.zip`** 이다. 둘 다 있어야 화면이 다 찬다.

## 뺀 것 (다시 만들어진다)

| 뺀 것 | 어떻게 되살리나 |
|---|---|
| `web/node_modules/` (136 MB) | `cd web && npm ci` |
| `api/wwwroot/` (7.3 MB) | `cd web && npm run build` — Vite 가 여기에 굽는다 |
| `api/bin/` · `api/obj/` | `dotnet build` |
| `logs/` | 돌리면 생긴다 |

`api/data/` 는 **빼지 않았다.** 빌드 산출물이 아니라 앱이 읽고 쓰는 실제 자료다
(도면·올린 파일·첨부·로그). 22.6 MB 중 대부분이 이것이다.

## 세우는 법

필요한 것: **.NET 9 SDK** · **Node 18 이상** · **PostgreSQL** (DB 보관본 참조).

```bash
# 1) DB 를 먼저 세운다 — wbs-db-*.zip 의 README.md 대로
# 2) 접속 문자열을 그 DB 로 맞춘다 — api/appsettings.json 의 ConnectionStrings:Wbs
# 3) 프런트
cd web && npm ci && npm run build        # api/wwwroot 로 구워진다
# 4) API
cd ../api && dotnet build -c Release
```

Windows 라면 위를 다 하는 대신 뿌리의 `start.cmd` 하나면 된다
(프런트·API 둘 다 빌드하고 분리 기동한다 — API 5080 / https 5443, Vite 5173).
돌고 있는 것이 있으면 `stop.cmd` 를 **먼저** — `WbsApi.exe` 가 떠 있으면
`bin\Release` 가 잠겨 빌드가 깨진다.

콘솔 창은 안 뜬다. 로그는 `logs\api.log` · `logs\web.log` 로 간다.
빌드까지 몇 분 걸리니 5080 이 응답하는지로 끝났는지 확인한다.

### ⚠ 고친 것이 안 보일 때

재기동해도 브라우저가 **옛 번들**을 준다 — `index.html` 이 캐시돼서 바뀐 해시의 js 를 안 읽는다.
쿼리를 붙여 캐시를 깬다: `https://localhost:5443/?cb=1#/devui`

## ⚠ 이 압축에 비밀이 들어 있다

외부로 옮기기 전에 반드시 추려 낼 것.

| 어디 | 무엇 |
|---|---|
| `api/appsettings.json` | GitLab 개인 토큰 (`Gitlab:Token`) |
| `api/appsettings.json` | postgres 비밀번호 (`ConnectionStrings:Wbs`) |
| `api/appsettings.json` | Oracle 계정·비밀번호 (`OraSession:User`/`Password`) — 사내 10.103.13.10 |
| `api/appsettings.json` | 사내 주소 — `code.hd.com` · `10.100.45.110` · `repo-hiway.hhigroup.kr` |
| `api/cert/wbs.pfx` | TLS 개인키 (localhost 자체서명) — `tools/make-cert.ps1` 로 새로 만들면 된다 |

`api/data/` 안에도 업무자료가 들어 있다 — 올린 문서(`doc_files`) · 첨부(`if_files`·`row_files`) ·
지운 행의 되살림 사본(`deleted_rows`).

## 알아 둘 것

- **`api/data/vueflow/` 는 DB 가 아니다.** `#/tables2` 의 도면과 업무항목이 전부 이 JSON 파일에 있다.
  API 가 요청마다 파일을 다시 읽으므로 고쳐도 재기동할 필요가 없다.
- **`api/data/orasession/ojdbc8.jar` (4.1 MB) 를 담았다.** 저장소에서는 제외되는 것인데,
  없으면 Oracle 세션 화면이 안 돈다. Java 가 있어야 쓴다(`OraSession:Java`/`Javac`).
- `tools/serve.ps1` 이 `--contentRoot api` 를 준다 — 그래서 **정본은 `api/data/`** 이고
  `api/bin/.../data/` 쪽은 빌드가 복사해 둔 산출물이다. 거기를 고쳐도 소용없다.
- `db/install/wbs_install.sql` 은 **외부 배포용 설치본**이다(표 17개, 개인정보·업무자료 뺌).
  지금 상태를 그대로 옮길 것이면 DB 보관본 쪽을 써라.
