@echo off
rem WBS 대시보드(api/DevRun.cs)가 만든 기동 스크립트 — 기동할 때마다 덮어쓴다.
rem 손으로 실행해도 된다. 그때는 대시보드에 <외부> 로 보인다.
chcp 65001>nul
cd /d "C:\projs\G6X0\XU62\Production Management\PPP001\ppp001-be"
set "TEMP=C:\devtmp"
set "TMP=C:\devtmp"
set "PORT="
call .\gradlew.bat local --console=plain >> "D:\수빅자재\wbsproj\api\data\devlogs\ppp001-be.log" 2>&1
echo [dev-exit] %ERRORLEVEL%>> "D:\수빅자재\wbsproj\api\data\devlogs\ppp001-be.log"
