﻿# ProjectView 에서 내려받은 엑셀(export-excel)을 CSV 로 바꾼다.
#
# 엑셀 파일은 HHI DRM 으로 암호화되어 있어 프로그램이 직접 열 수 없다.
# Excel 은 로그인한 사용자 권한으로 DRM 을 풀어 주므로, Excel COM 으로 값을 읽어
# UTF-8 CSV 로 다시 쓴다. 대시보드의 [ProjectView 동기화] 화면은 이 CSV 를 읽는다.
#
# 사용법:  powershell -ExecutionPolicy Bypass -File tools\export2csv.ps1
#          (변환할 폴더를 바꾸려면 -Dir 인자)

param(
  [string]$Dir = 'D:\수빅자재\projectview_exports',
  [switch]$All          # 지정하면 폴더의 모든 xlsx 를 변환 (기본은 최신 1개)
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $Dir)) { Write-Error "폴더가 없습니다: $Dir"; exit 1 }

$files = Get-ChildItem -Path $Dir -Filter *.xls* -File | Sort-Object LastWriteTime -Descending
if (-not $files) { Write-Error "변환할 엑셀 파일이 없습니다: $Dir"; exit 1 }
if (-not $All) { $files = @($files[0]) }

$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

try {
  foreach ($f in $files) {
    Write-Host "여는 중: $($f.Name)"
    $wb = $excel.Workbooks.Open($f.FullName, 0, $true)   # ReadOnly
    try {
      $ws = $wb.Worksheets.Item(1)
      $used = $ws.UsedRange
      $vals = $used.Value2                                # 2차원 배열 (1-based)
      $rows = $used.Rows.Count
      $cols = $used.Columns.Count

      $sb = New-Object System.Text.StringBuilder
      for ($r = 1; $r -le $rows; $r++) {
        $line = New-Object System.Collections.Generic.List[string]
        for ($c = 1; $c -le $cols; $c++) {
          $v = if ($rows -eq 1 -and $cols -eq 1) { $vals } else { $vals[$r, $c] }
          if ($null -eq $v) {
            $line.Add('')
            continue
          }
          # 날짜는 엑셀 내부에서 일련번호(double)로 들어온다. 날짜 형식이 걸린 칸만 날짜로 본다.
          if ($v -is [double]) {
            $fmt = [string]$ws.Cells.Item($r + $used.Row - 1, $c + $used.Column - 1).NumberFormat
            if ($fmt -match 'y+' -and $fmt -match '[md]') {
              $line.Add([DateTime]::FromOADate($v).ToString('yyyy-MM-dd'))
              continue
            }
            $line.Add([string]$v)
            continue
          }
          $s = [string]$v
          # CSV 이스케이프: 큰따옴표 · 쉼표 · 줄바꿈이 있으면 감싼다
          if ($s.Contains('"') -or $s.Contains(',') -or $s.Contains("`n") -or $s.Contains("`r")) {
            $s = '"' + $s.Replace('"', '""') + '"'
          }
          $line.Add($s)
        }
        [void]$sb.AppendLine([string]::Join(',', $line))
      }

      $out = [System.IO.Path]::ChangeExtension($f.FullName, '.csv')
      [System.IO.File]::WriteAllText($out, $sb.ToString(), (New-Object System.Text.UTF8Encoding $true))
      Write-Host "  -> $([System.IO.Path]::GetFileName($out))  ($rows 행 x $cols 열)"
    }
    finally {
      $wb.Close($false)
      [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($wb)
    }
  }
}
finally {
  $excel.Quit()
  [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
  [GC]::Collect()
}

Write-Host '완료'
