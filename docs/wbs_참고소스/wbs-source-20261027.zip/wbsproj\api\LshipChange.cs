using System.Text.Json;

namespace WbsApi;

/// <summary>
/// 대형선 업무설계 <b>변경이력</b> — [대형선 설계 변경이력] 화면(#/lshipchg).
///
/// 설계가 바뀔 때마다 <b>무엇을 · 언제부터 · 누가</b> 를 한 줄씩 남긴다
/// (<c>db/hhip_lship_change.sql</c>).
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>원장(hhip_wbs_wrk2)과 잇지 않는다.</b> 아직 원장에 없는 화면의 변경도 적어야 하고
/// (설계가 먼저 바뀐다), 원장의 줄을 지워도 이력은 남아야 한다. 그래서 화면명을
/// <b>글자로</b> 들고 있다 — 이어 두면 <적을 수 없는 변경>이 생긴다.
///
/// <b>지우는 대신 폐기로 남긴다.</b> <c>drop_yn='Y'</c> 가 본 경로다. 이력표에서 줄을
/// 없애 버리면 <b>무엇이 있었다가 없어졌는지</b>를 알 길이 없다. 진짜 삭제는 잘못 적은 줄을
/// 치우는 용도라 <b>Super 만</b> 할 수 있다.
///
/// <b>적는 것은 누구나.</b> 자기 설계 변경을 남기는 자리다. 대신 누가 언제 남기고 고쳤는지는
/// 반드시 적는다(<c>created_by</c> · <c>updated_by</c>) — 이력을 적는 표라 이력 자체에도
/// 주인이 있어야 한다.
/// </summary>
public static class LshipChange
{
    /// <summary>화면이 보내도 되는 칸. 여기 없는 이름은 조용히 버린다.</summary>
    private static readonly HashSet<string> Editable =
        ["screen_nm", "screen_desc", "req_sdt", "drop_yn", "owner_nm", "note"];

    /// <summary>날짜로 넣어야 하는 칸 — 빈 문자열을 그냥 넣으면 date 변환에서 터진다.</summary>
    private static readonly HashSet<string> DateCols = ["req_sdt"];

    private static async Task<string> WhoAsync(IpGate g, HttpContext ctx)
    {
        var me = await g.CheckAsync(ctx);
        return me.Name ?? me.BpId ?? "미상";
    }

    /// <summary>본문에서 한 칸을 꺼낸다. 빈 문자열은 <b>비웠다</b>는 뜻이라 null 로 바꾼다.</summary>
    private static object? Val(JsonElement body, string col)
    {
        if (!body.TryGetProperty(col, out var v)) return null;
        var s = v.ValueKind switch
        {
            JsonValueKind.Null => null,
            JsonValueKind.True => "Y",
            JsonValueKind.False => "N",
            JsonValueKind.Number => v.ToString(),
            _ => v.GetString(),
        };
        s = s?.Trim();
        return string.IsNullOrEmpty(s) ? null : s;
    }

    public static void Map(WebApplication app, Func<IpGate.Result, bool> isSuper)
    {
        // 목록 — 이력표라 통째로 준다. 수천 줄이 되면 그때 나눈다.
        // 담당자 이름이 개발자 목록에 있으면 사번을 함께 준다(화면에서 흐리게 덧붙인다).
        app.MapGet("/api/lshipchg", async (PgPool db) =>
        {
            var rows = await db.QueryAsync("""
                select c.chg_id, c.screen_nm, c.screen_desc
                     , c.req_sdt::text as req_sdt
                     , c.drop_yn, c.owner_nm, c.note
                     , c.created_by
                     , to_char(c.created_at, 'YYYY-MM-DD HH24:MI') as created_at
                     , c.updated_by
                     , to_char(c.updated_at, 'YYYY-MM-DD HH24:MI') as updated_at
                     , u.bp_id as owner_bp
                  from public.hhip_lship_change c
                  left join public.dev_user u on u.name = c.owner_nm
                 order by c.req_sdt desc nulls last, c.chg_id desc
                """);

            // 담당자 고르는 목록 — 개발자 관리(dev_user)에 있는 사람들.
            // 그 밖의 이름도 적을 수 있다(협력사·타 팀). 그래서 목록은 <지름길>일 뿐이다.
            var devs = await db.QueryAsync("""
                select name from public.dev_user
                 where coalesce(name,'') <> '' and coalesce(block_yn,'N') <> 'Y'
                 order by name
                """);

            return Results.Ok(new
            {
                rows,
                owners = devs.Select(d => d["name"]),
                total = rows.Count,
                live = rows.Count(r => (string?)r["drop_yn"] != "Y"),
                dropped = rows.Count(r => (string?)r["drop_yn"] == "Y"),
            });
        });

        // 새 줄 — 필수는 화면명 하나다. 나머지는 나중에 채운다
        // (설계가 바뀐 순간 적어 두는 것이 중요하지, 다 적고 나서 적는 것이 아니다).
        app.MapPost("/api/lshipchg", async (PgPool db, IpGate g, HttpContext ctx, JsonElement body) =>
        {
            var who = await WhoAsync(g, ctx);
            var nm = Val(body, "screen_nm") as string;
            if (nm is null) return Results.BadRequest(new { error = "화면명은 비울 수 없습니다." });

            var drop = (Val(body, "drop_yn") as string) == "Y" ? "Y" : "N";
            var made = await db.QueryAsync("""
                insert into public.hhip_lship_change
                       (screen_nm, screen_desc, req_sdt, drop_yn, owner_nm, note, created_by)
                values ($1::text, $2::text, $3::date, $4::char(1), $5::text, $6::text, $7::text)
                returning chg_id
                """,
                [nm, Val(body, "screen_desc"), Val(body, "req_sdt"), drop,
                 Val(body, "owner_nm"), Val(body, "note"), who]);

            Console.WriteLine($"[lshipchg/new] {DateTime.Now:HH:mm:ss} id={made[0]["chg_id"]} \"{nm}\" by={who}");
            return Results.Ok(new { created = 1, chg_id = made[0]["chg_id"] });
        });

        // 한 칸씩 고친다 — 화면이 칸을 벗어날 때마다 보낸다.
        // 보낸 칸만 건드린다(빠진 칸은 그대로) — 통째로 덮으면 두 사람이 다른 칸을
        // 고쳤을 때 나중 사람이 앞사람 것을 지운다.
        app.MapPut("/api/lshipchg/{chgId:long}", async (PgPool db, IpGate g, HttpContext ctx, long chgId, JsonElement body) =>
        {
            var who = await WhoAsync(g, ctx);

            var sets = new List<string>();
            var args = new List<object?>();
            foreach (var pr in body.EnumerateObject())
            {
                var col = pr.Name.ToLowerInvariant();
                if (!Editable.Contains(col)) continue;
                if (sets.Any(x => x.StartsWith(col + " ="))) continue;

                var v = Val(body, col);
                // 화면명은 비울 수 없다 — 비면 그 줄이 무엇에 대한 것인지 사라진다
                if (col == "screen_nm" && v is null)
                    return Results.BadRequest(new { error = "화면명은 비울 수 없습니다." });
                if (col == "drop_yn") v = (v as string) == "Y" ? "Y" : "N";

                args.Add(v);
                sets.Add($"{col} = ${args.Count}{(DateCols.Contains(col) ? "::date" : "::text")}");
            }
            if (sets.Count == 0) return Results.BadRequest(new { error = "고칠 칸이 없습니다." });

            args.Add(who);
            sets.Add($"updated_by = ${args.Count}::text");
            sets.Add("updated_at = now()");

            args.Add(chgId);
            var n = await db.ExecuteAsync(
                $"update public.hhip_lship_change set {string.Join(", ", sets)} where chg_id = ${args.Count}::bigint",
                [.. args]);
            if (n == 0) return Results.NotFound(new { error = "그 줄을 찾지 못했습니다.", chg_id = chgId });

            // 서버가 다듬은 값(앞뒤 공백 · 빈 문자열 → 비움)을 그대로 돌려준다.
            // 화면이 제 손으로 꾸며 내면 화면에만 다르게 남는다.
            var got = await db.QueryAsync("""
                select chg_id, screen_nm, screen_desc, req_sdt::text as req_sdt, drop_yn, owner_nm, note
                     , updated_by, to_char(updated_at, 'YYYY-MM-DD HH24:MI') as updated_at
                  from public.hhip_lship_change where chg_id = $1::bigint
                """, [chgId]);
            return Results.Ok(got[0]);
        });

        // 진짜 삭제 — 잘못 적은 줄을 치우는 용도다. 평소에는 <폐기>(drop_yn='Y')를 쓴다.
        // 되돌릴 수 없으므로 Super 만, 그리고 무엇을 지웠는지 남긴다.
        app.MapDelete("/api/lshipchg/{chgId:long}", async (PgPool db, IpGate g, HttpContext ctx, long chgId) =>
        {
            var me = await g.CheckAsync(ctx);
            if (!isSuper(me))
                return Results.Json(new { error = "이력 삭제는 Super 권한만 할 수 있습니다. (폐기는 누구나 할 수 있습니다)" },
                                    statusCode: 403);

            var found = await db.QueryAsync(
                "select screen_nm, owner_nm from public.hhip_lship_change where chg_id = $1::bigint", [chgId]);
            if (found.Count == 0) return Results.NotFound(new { error = "지울 줄을 찾지 못했습니다.", chg_id = chgId });

            var n = await db.ExecuteAsync("delete from public.hhip_lship_change where chg_id = $1::bigint", [chgId]);
            Console.WriteLine($"[lshipchg/del] {DateTime.Now:HH:mm:ss} id={chgId} \"{found[0]["screen_nm"]}\""
                            + $" by={me.Name ?? me.BpId}");
            return Results.Ok(new { deleted = n, chg_id = chgId, screen_nm = found[0]["screen_nm"] });
        });
    }
}
