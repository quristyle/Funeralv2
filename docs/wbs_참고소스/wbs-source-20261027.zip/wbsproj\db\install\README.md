# 외부 구축용 DB 설치

`wbs_install.sql` 하나면 WBS 대시보드가 쓰는 DB 를 통째로 세울 수 있다.
사내 개발 PC 의 실제 스키마를 `pg_dump --schema-only` 로 뜬 것이라 손으로 적은 DDL 이 아니다.

```bash
createdb -h <host> -U postgres wbs
psql -h <host> -U postgres -d wbs -f wbs_install.sql
```

그다음 `api/appsettings.json` 의 접속 문자열을 그 DB 로 맞춘다.

```
ConnectionStrings:Wbs = Host=...;Port=5432;Database=wbs;Username=...;Password=...
```

## 담은 것

| | 개수 | 무엇 |
|---|---|---|
| 함수 | 1 | `fn_set_updated_at` — `if_*` 표의 `updated_at` 자동 갱신 |
| 표 | 17 | `dev_*` · `hhip_wbs_*` · `if_*` |
| 뷰 | 4 | `v_if_master` · `v_if_step` · `v_if_attr` · `v_if_flow` |
| 인덱스 | 13 | |
| 제약 | 29 | PK · UNIQUE |
| 트리거 | 7 | `if_*` 표의 `updated_at` |
| 코드성 데이터 | 4표 | `if_system` 3 · `if_code` 43 · `if_attr_def` 3 · `dev_menu` 18 |

**코드성 데이터를 함께 담은 까닭** — 없으면 인터페이스 화면의 선택목록(방향·상태·단계유형 등)이
전부 비고, 추가 관리항목도 뜨지 않는다. 표만 있어서는 화면이 돌지 않는다.

## 담지 않은 것 (일부러)

- **개인정보** — `dev_user`(성명·전화·비상연락처·IP·MAC·장비번호). 외부로 옮기기 전에 반드시 검토할 것.
- **업무자료** — `hhip_wbs_wrk2`(WBS 원장) · `hhip_wbs_task`(일감) · `hhip_wbs_pv*`(ProjectView 캐시) ·
  `if_master`/`if_step`/`if_note`/`if_attr`(인터페이스 내용) · `dev_docs` ·
  `dev_user_menu`(권한) · `dev_user_pref`(화면설정)
- **안 쓰는 옛 표** — `hhip_wbs` · `hhip_wbs_wrk` (앱이 어디서도 참조하지 않는다)
- **작업용 백업표** — `hhip_wbs_wrk2_bak_*` 12개

자료가 필요하면 표별로 따로 뽑아 옮긴다.

```bash
pg_dump -h localhost -U postgres -d postgres --data-only --column-inserts \
        -t public.hhip_wbs_wrk2 > wrk2_data.sql
```

## 세운 뒤

1. **사용자 등록** — `dev_user` 에 넣고 `use_ip` 에 접속 IP 를 적는다. `IpGate` 가 이 표를 본다.
   등록이 **0건이면 전체 허용**이라 처음부터 잠기지는 않는다.
2. **최고 관리자** — `dev_user.super_yn='o'` 로 주거나 `appsettings` 의 `Admin:BpIds` 에 적는다.
   `localhost` 접속은 언제나 전부 열린다(되돌릴 길을 남겨 둔 장치다).
3. **메뉴 권한** — `행이 없으면 허용` 이다. 막을 것만 넣으면 된다.
   메뉴 목록(`dev_menu`)은 [메뉴 권한] 화면을 한 번 열면 화면이 스스로 맞춘다.

## 이 파일이 맞는지 확인한 방법

빈 DB(`wbs_install_test`)를 새로 만들어 이 스크립트를 돌리고, **앱을 그 DB 에 붙여**
실제로 읽고 썼다(2026-09-23).

```
표 17 · 뷰 4 · 함수 1 · 트리거 7 · 인덱스 34 · 코드데이터 4표 전부 일치
GET  /api/health · /api/if/codes(43) · /api/if/systems(3) · /api/menus(18)
     /api/rows(0) · /api/stats/summary · /api/dev-users(0)   ← 비어 있는 것이 정상
POST /api/dev-users · /api/if · /api/if/{id}/steps           ← 등록됨
     뷰 v_if_flow 가 "1. T_TEST" 를 돌려주고, 트리거가 updated_at 을 채웠다
PUT  /api/menu-perms/{bpId}                                   ← 저장됨
```

확인이 끝난 뒤 시험 DB 는 지웠다.

## 다시 뜨려면

스키마가 바뀌면 이 파일을 다시 만든다.

```powershell
pg_dump -h localhost -U postgres -d postgres --schema-only --no-owner --no-privileges `
        -t public.dev_docs -t public.dev_menu -t public.dev_user ... > schema.sql
```

`-t` 로 표를 고르면 **함수는 딸려 오지 않는다.** `fn_set_updated_at` 은 전체 덤프에서 따로 꺼내
앞에 붙여야 한다(트리거가 그것을 부른다). 이 파일도 그렇게 엮었다.
