// PWA 아이콘(PNG) 생성기 — 외부 라이브러리 없이 PNG 를 직접 만든다.
//
//   node tools/make-icons.mjs
//
// 만들어지는 파일 (web/public/):
//   icon-192.png           일반 아이콘 (둥근 사각형)
//   icon-512.png           일반 아이콘 (둥근 사각형)
//   icon-maskable-512.png  마스커블 — 배경을 꽉 채우고 그림은 안쪽 80% 안에만 둔다
//   wbs.ico                윈도우 바로가기용 (16~256 묶음)
//
// 그림: 검정 바탕에 회색 막대그래프 3개 (진척률 대시보드).
import fs from 'fs'
import path from 'path'
import zlib from 'zlib'
import { fileURLToPath } from 'url'

const OUT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'web', 'public')

// 회색톤 + 블랙 조합
const BG = [0x16, 0x18, 0x1b] // 거의 검정 (바탕)
const FG = [0xe8, 0xea, 0xed] // 밝은 회색 (막대)
const LN = [0x9a, 0xa0, 0xa6] // 중간 회색 (바닥선)

// ---------------------------------------------------------------- PNG 인코더
const CRC = (() => {
  const t = new Int32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    t[n] = c
  }
  return t
})()

function crc32(buf) {
  let c = -1
  for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 0xff] ^ (c >>> 8)
  return (c ^ -1) >>> 0
}

function chunk(type, data) {
  const len = Buffer.alloc(4)
  len.writeUInt32BE(data.length)
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data])
  const crc = Buffer.alloc(4)
  crc.writeUInt32BE(crc32(body))
  return Buffer.concat([len, body, crc])
}

/** RGBA 픽셀 버퍼(size*size*4)를 PNG 로 인코딩한다. */
function png(size, rgba) {
  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(size, 0)
  ihdr.writeUInt32BE(size, 4)
  ihdr[8] = 8 // bit depth
  ihdr[9] = 6 // color type: RGBA
  // 10,11,12 = compression/filter/interlace = 0

  // 각 행 앞에 필터 바이트(0)를 붙인다
  const raw = Buffer.alloc(size * (size * 4 + 1))
  for (let y = 0; y < size; y++) {
    const o = y * (size * 4 + 1)
    raw[o] = 0
    rgba.copy(raw, o + 1, y * size * 4, (y + 1) * size * 4)
  }

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ])
}

// ---------------------------------------------------------------- 그리기
function make(size, maskable) {
  const buf = Buffer.alloc(size * size * 4) // 전부 투명으로 시작
  const put = (x, y, c) => {
    if (x < 0 || y < 0 || x >= size || y >= size) return
    const o = (y * size + x) * 4
    buf[o] = c[0]
    buf[o + 1] = c[1]
    buf[o + 2] = c[2]
    buf[o + 3] = 255
  }
  const rect = (x0, y0, w, h, c) => {
    for (let y = Math.round(y0); y < Math.round(y0 + h); y++)
      for (let x = Math.round(x0); x < Math.round(x0 + w); x++) put(x, y, c)
  }

  // 배경 — 마스커블은 꽉 채우고, 일반 아이콘은 모서리를 둥글린다
  if (maskable) {
    rect(0, 0, size, size, BG)
  } else {
    const r = size * 0.22
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = x < r ? r - x : x > size - r ? x - (size - r) : 0
        const dy = y < r ? r - y : y > size - r ? y - (size - r) : 0
        if (dx * dx + dy * dy <= r * r) put(x, y, BG)
      }
    }
  }

  // 그림 영역 — 마스커블은 안쪽 80% 안에만 (safe zone)
  const inset = maskable ? size * 0.2 : size * 0.24
  const w = size - inset * 2
  const base = size - inset // 막대가 서 있는 바닥선

  // 막대 3개 (높이 40% / 65% / 92%) + 바닥선
  const bw = w * 0.2
  const gap = (w - bw * 3) / 2
  const hs = [0.4, 0.65, 0.92]
  for (let i = 0; i < 3; i++) {
    const h = w * hs[i]
    rect(inset + i * (bw + gap), base - h, bw, h, FG)
  }
  rect(inset, base + w * 0.06, w, Math.max(2, size * 0.035), LN)

  return png(size, buf)
}

// ---------------------------------------------------------------- ICO (윈도우 바로가기용)
// Vista 이상은 ICO 안에 PNG 를 그대로 넣을 수 있다. 크기별 PNG 를 묶기만 하면 된다.
function ico(sizes) {
  const imgs = sizes.map((n) => ({ n, data: make(n, false) }))
  const head = Buffer.alloc(6)
  head.writeUInt16LE(0, 0)          // reserved
  head.writeUInt16LE(1, 2)          // type: icon
  head.writeUInt16LE(imgs.length, 4)

  const dir = Buffer.alloc(16 * imgs.length)
  let offset = 6 + dir.length
  imgs.forEach((im, i) => {
    const o = i * 16
    dir[o] = im.n >= 256 ? 0 : im.n // 0 은 256 을 뜻한다
    dir[o + 1] = im.n >= 256 ? 0 : im.n
    dir[o + 2] = 0                  // 팔레트 없음
    dir[o + 3] = 0
    dir.writeUInt16LE(1, o + 4)     // planes
    dir.writeUInt16LE(32, o + 6)    // bpp
    dir.writeUInt32LE(im.data.length, o + 8)
    dir.writeUInt32LE(offset, o + 12)
    offset += im.data.length
  })

  return Buffer.concat([head, dir, ...imgs.map((i) => i.data)])
}

fs.mkdirSync(OUT, { recursive: true })
const files = [
  ['icon-192.png', make(192, false)],
  ['icon-512.png', make(512, false)],
  ['icon-maskable-512.png', make(512, true)],
  ['wbs.ico', ico([16, 32, 48, 64, 128, 256])],
]
for (const [name, data] of files) {
  fs.writeFileSync(path.join(OUT, name), data)
  console.log(name, data.length.toLocaleString(), 'bytes')
}
