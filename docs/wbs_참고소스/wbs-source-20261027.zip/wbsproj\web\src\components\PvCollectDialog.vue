<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { api } from '../api'
import { state } from '../store'
import { useDragMove } from '../dragmove'
import { buildPvCacheScript, buildPvPushScript, copyText, FULL_AT, FULL_RATE } from '../pvScript'

// ProjectView 데이터 수집을 한 창에서 끝낸다.
//
// 왜 두 단계인가 — ProjectView 는 HTTPS 이고 이 대시보드는 HTTP 라서
// 대시보드가 ProjectView API 를 직접 부를 수 없다(mixed content 차단).
// 그래서 <스크립트를 만들어 ProjectView 탭에서 실행하고, 결과를 되붙여> 넣는다.
// ProjectView 는 조회만 하고 고치지 않는다 (GET 만 쓴다).
//
// 걷어 온 값은 늘 <지금 ProjectView 의 값>으로 통째로 덮어쓴다.
// 그래서 이력을 남길 것도, 캐시를 비울 일도 없다 — 다시 걷으면 최신이 된다.
//
// 저장은 두 곳으로 나뉜다. 성질이 다르므로 한 번에 묶지 않는다.
//   1) 캐시(hhip_wbs_pv)   — 바로 저장. 언제 지워도 되는 값이다.
//   2) 원장(hhip_wbs_wrk2) — <미리보기 → 확인> 을 거친다. 우리 원장을 고치는 일이다.
// 원장 반영은 [ProjectView 동기화] 화면이 쓰는 것과 <같은> preview/apply 경로를 그대로 부른다.
const emit = defineEmits(['close', 'saved'])

// 머리말을 잡아 창을 옮긴다. 이 창만 빠져 있었다 — 아래에 표가 길게 붙어
// 뒤에 가린 목록을 보려고 옮기고 싶어지는 일이 가장 잦은 창인데도 그랬다.
const drag = useDragMove()

// 원장에 반영할 날짜 4개 (PvSync 의 MapCols 와 같은 이름)
const SYNC_FIELDS = ['plan_sdt', 'plan_edt', 'plan_sdt_c', 'plan_edt_c']
// ProjectView 가 빈 값이면 원장도 비운다 — 날짜의 기준이 ProjectView 라서 그렇게 정했다
const CLEAR_EMPTY = true

const info = ref(null)
const codes = ref([])
const script = ref('')
const raw = ref('')
const err = ref('')
const msg = ref('')
const busy = ref(false)
const step = ref(1)
const area = ref(null)

async function load() {
  err.value = ''
  try {
    // 수집 대상은 <걸린 필터와 무관하게> 대시보드가 관리하는 전체다.
    // 일부만 걷으면 workId 가 하나라도 비어 전송 스크립트가 느린 경로로 돌기 때문이다.
    const [c, rows] = await Promise.all([api.pvCache(state.scope), api.pvCacheRows(state.scope)])
    info.value = c
    codes.value = rows.map((r) => r.activity_id).filter(Boolean)
    script.value = buildPvCacheScript(codes.value, new Date().toLocaleString('ko-KR'))
  } catch (e) {
    err.value = e.message
  }
}
onMounted(load)

const w = computed(() => info.value?.works ?? {})
const t = computed(() => info.value?.tasks ?? {})
const n = (v) => (v === null || v === undefined ? 0 : Number(v))
const lastAt = computed(() => (w.value.last_snapshot || '').slice(0, 16))

/** 마지막 수집이 하루를 넘겼는지 */
const staleDays = computed(() => {
  const s = w.value.last_snapshot
  if (!s) return null
  const days = (Date.now() - new Date(s.replace(' ', 'T')).getTime()) / 86400000
  return days > 1 ? Math.floor(days) : null
})

async function doCopy() {
  area.value?.select()
  msg.value = (await copyText(script.value))
    ? '복사했습니다. ProjectView 탭의 F12 → Console 에 붙여넣으세요.'
    : '자동 복사가 막혔습니다. 내용이 전체 선택된 상태이니 Ctrl+C 로 복사하세요.'
  step.value = 2
}

/** 붙여넣은 텍스트에서 JSON 을 꺼낸다 (콘솔 출력을 통째로 붙여넣어도 받아 준다) */
function parsePasted() {
  const s = raw.value.trim()
  if (!s) throw new Error('붙여넣은 내용이 없습니다.')
  const a = s.indexOf('{')
  const b = s.lastIndexOf('}')
  if (a < 0 || b < a) throw new Error('JSON 을 찾지 못했습니다.')
  try {
    return JSON.parse(s.slice(a, b + 1))
  } catch (x) {
    throw new Error('JSON 을 읽지 못했습니다: ' + x.message)
  }
}

// ---------------------------------------------------------------- 원장 반영
// 수집한 날짜를 원장(plan_sdt/plan_edt/plan_sdt_c/plan_edt_c)에 넣을지 보여 주고 확인받는다.
// works[] 한 건의 모양이 PvSync 의 JSON 입력과 같아서(code + 날짜 4개) 그대로 넘길 수 있다.
const works = ref(null)      // 방금 저장한 수집 결과 (원장 반영에 다시 쓴다)
const sync = ref(null)       // preview 결과
const syncing = ref(false)
const syncMsg = ref('')

const syncPayload = () => ({
  source: 'json',
  items: works.value,
  fields: SYNC_FIELDS,
  clearEmpty: CLEAR_EMPTY,
})

async function previewLedger() {
  if (!works.value) return
  syncing.value = true
  sync.value = null
  syncMsg.value = ''
  try {
    sync.value = await api.pvSyncPreview(syncPayload())
  } catch (e) {
    err.value = '원장 미리보기 실패: ' + e.message
  } finally {
    syncing.value = false
  }
}

async function applyLedger() {
  if (!works.value) return
  syncing.value = true
  try {
    const r = await api.pvSyncApply(syncPayload())
    syncMsg.value = `원장에 반영했습니다 — ${r.applied}건 (행 ${r.affected}개)`
    sync.value = await api.pvSyncPreview(syncPayload())   // 남은 차이 재확인
    emit('saved')
    await loadPush()   // 갱신된 날짜로 전송값을 다시 계산한다
  } catch (e) {
    err.value = '원장 반영 실패: ' + e.message
  } finally {
    syncing.value = false
  }
}

// ------------------------------------------------- ProjectView 로 되돌려 보내기
// [진척률 현황]·[지연 현황] 이 각각 하던 전송을 여기서 하나로 합친다.
//
// 왜 <읽기>가 끝난 뒤에 값을 만드는가 — 보낼 값이 우리 원장에서 나오기 때문이다.
//   · 진척률   = 계획진척률. plan_sdt/plan_edt 로 계산한다 (3단계에서 방금 갱신한 값).
//   · 실적시작일 = 착수지연 건의 plan_sdt.
// 그래서 원장 반영 뒤에 대상을 다시 뽑는다. 그 전에 뽑으면 옛 날짜로 계산한 값이 나간다.
//
// 스크립트는 하나다. 같은 activity_id 에 둘 다 걸려도 조회 1번 · 저장 1번으로 끝난다.
const push = ref(null)       // { rate: [...], date: [...], script }
const pushing = ref(false)
const pushMsg = ref('')

/** 전송 대상을 지금 원장에서 다시 뽑는다 */
async function loadPush() {
  pushing.value = true
  pushMsg.value = ''
  try {
    // 지연 목록은 kind='all' 로 한 번만 받는다 — 착수지연·종료지연을 따로 부르면
    // 두 요청 사이에 날이 바뀌어 한쪽만 current_date 가 넘어가는 일이 생긴다.
    const [prog, late, cached] = await Promise.all([
      api.progressRows(state.scope),
      api.delayRows(state.scope, 'all'),
      api.pvCacheRows(state.scope),
    ])

    // 방금 걷어 온 ProjectView 값 — 이미 맞는 건은 보낼 이유가 없다
    const ids = {}
    const curRate = {}
    const curSdt = {}
    const curEdt = {}
    let projectId = ''
    for (const r of cached) {
      if (r.pv_work_id) ids[r.activity_id] = r.pv_work_id
      if (r.pv_finish_rate !== null && r.pv_finish_rate !== undefined) {
        curRate[r.activity_id] = Number(r.pv_finish_rate)
      }
      if (r.pv_actual_sdt) curSdt[r.activity_id] = r.pv_actual_sdt
      if (r.pv_actual_edt) curEdt[r.activity_id] = r.pv_actual_edt
      if (!projectId && r.pv_project_id) projectId = r.pv_project_id
    }
    const toSend = (v) => (Number(v) >= FULL_AT ? FULL_RATE : Number(v))

    // 진척률 — [진척률 현황] 의 기본값과 같은 대상: 착수(도래) & 미완료
    const rate = prog
      .filter((r) => r.activity_id && r.plan_rate != null)
      .filter((r) => (r.plan_rate ?? 0) > 0 && r.complate_yn !== 'o')
      .filter((r) => curRate[r.activity_id] !== toSend(r.plan_rate))
      .map((r) => ({
        activity_id: r.activity_id, menu_nm: r.menu_nm,
        rate: r.plan_rate, send: toSend(r.plan_rate),
        from: curRate[r.activity_id],
      }))

    // 실적시작일 — [지연 현황] 과 같은 대상: 착수지연(계획시작일 도래 · 실적시작일 없음).
    // ProjectView 에 이미 값이 있으면 스크립트가 어차피 건너뛰므로 여기서 뺀다.
    const date = late
      .filter((r) => r.activity_id && r.plan_sdt && !r.plan_sdt_c)
      .filter((r) => !curSdt[r.activity_id])
      .map((r) => ({ activity_id: r.activity_id, menu_nm: r.menu_nm, date: r.plan_sdt }))

    // 실적종료일 — 시작일과 같은 규칙: 계획종료일이 도래했는데 실적종료일이 없는 건에
    // 그 계획종료일을 넣는다(= [지연 현황] 의 종료지연과 같은 대상).
    //
    // ⚠️ 시작일과 무게가 다르다. ProjectView 에 실적종료일이 찍히면 <그날 끝났다> 는 뜻인데,
    //    이 대상은 정의상 <끝났다고 기록되지 않은> 건이다. 그래서 목록에서 걸러내지 않고
    //    완료·개발자완료 표시를 그대로 실어 보내 사람이 보고 판단하게 한다.
    const edate = late
      .filter((r) => r.activity_id && r.plan_edt && !r.plan_edt_c)
      .filter((r) => !curEdt[r.activity_id])
      .map((r) => ({
        activity_id: r.activity_id, menu_nm: r.menu_nm, edate: r.plan_edt,
        done: r.complate_yn === 'o', devDone: r.complate_real_yn === 'o',
      }))

    // 현재상태 — 계획진척률이 100% 로 나갈 건의 <일감 현재상태> 를 완료 단계로 옮긴다.
    //
    // ⚠️⚠️ **rate 목록에서 뽑으면 안 된다.** rate 는 <ProjectView 와 값이 달라 새로 써야
    //    하는 건>만 남긴 것이라, 이미 100% 인 건은 거기서 빠진다 — 그런데 «100% 인데
    //    현재상태는 AI설계검토» 로 남은 그 건이야말로 이 기능이 메우려던 구멍이다.
    //    실제로 처음에 rate 에서 뽑았다가 이 일을 밟았다: 211건 중 100% 대상 119건이
    //    **전부** ProjectView 에서 이미 100% 라, 보낸 10건은 25%·72.7% 뿐이고
    //    현재상태는 한 건도 안 바뀌었다. 그래서 rate 와 <따로> 뽑는다.
    //
    // 기준은 rate 와 같되(착수 도래 · 미완료) <값이 다른 것만> 만 뺀다.
    const status = prog
      .filter((r) => r.activity_id && r.plan_rate != null)
      .filter((r) => (r.plan_rate ?? 0) > 0 && r.complate_yn !== 'o')
      .filter((r) => toSend(r.plan_rate) === FULL_RATE)
      .map((r) => ({
        activity_id: r.activity_id, menu_nm: r.menu_nm, setDone: true,
        from: curRate[r.activity_id],
        devDone: r.complate_real_yn === 'o',
      }))

    const script = buildPvPushScript(
      [...rate, ...date, ...edate, ...status],
      new Date().toLocaleString('ko-KR'),
      { ids, projectId },
    )
    const rateIds = new Set(rate.map((r) => r.activity_id))
    push.value = {
      rate, date, edate, status, script,
      // 미리보기 표에 두 번 적지 않는다 — 진척률 줄에는 이미 「현재상태 → 완료」가 붙는다
      statusOnly: status.filter((r) => !rateIds.has(r.activity_id)),
      full: rate.filter((r) => r.send === FULL_RATE).length,
      // 완료 표시가 하나도 없는 건 — 이것만은 눈에 띄게 알려야 한다
      unfinished: edate.filter((r) => !r.done && !r.devDone).length,
      // 현재상태를 완료로 옮기는데 개발자완료 표시조차 없는 건. 계획진척률 100% 는
      // <계획종료일이 지났다> 는 뜻이지 <끝났다> 는 뜻이 아니라, 세어서 보여 줘야 한다.
      statusOpen: status.filter((r) => !r.devDone).length,
    }
  } catch (e) {
    err.value = '전송 대상 확인 실패: ' + e.message
  } finally {
    pushing.value = false
  }
}

const pushArea = ref(null)
async function copyPush() {
  pushArea.value?.select()
  pushMsg.value = (await copyText(push.value.script))
    ? '복사했습니다. ProjectView 탭 콘솔에 붙여넣고, 확인 후 pvSend() 로 전송하세요.'
    : '자동 복사가 막혔습니다. 내용이 전체 선택된 상태이니 Ctrl+C 로 복사하세요.'
}

async function save() {
  err.value = ''
  msg.value = ''
  syncMsg.value = ''
  push.value = null
  busy.value = true
  try {
    const j = parsePasted()
    if (!Array.isArray(j.works)) {
      throw new Error('수집 결과가 아닙니다 — works 배열을 찾지 못했습니다.')
    }
    const r = await api.pvIngest(j)
    msg.value =
      `캐시에 저장했습니다 — 액티비티 ${r.works}건 · 일감 ${r.tasks}건` +
      (r.nodes ? ` · 워크플로 단계 ${r.nodes}개` : '') +
      (r.unknown_count ? ` · 원장에 없는 코드 ${r.unknown_count}건` : '')
    works.value = j.works
    raw.value = ''
    await load()
    emit('saved')          // 상세 목록을 다시 읽어 PV 컬럼을 채운다
    await previewLedger()  // 이어서 원장에서 무엇이 바뀔지 보여 준다
    // 원장에 바꿀 것이 없으면 곧바로 전송 대상을 뽑는다.
    // 바꿀 것이 있으면 반영을 누른 뒤에 뽑아야 새 날짜로 계산된다.
    if (sync.value && !sync.value.changed) await loadPush()
  } catch (e) {
    err.value = e.message
  } finally {
    busy.value = false
  }
}

// 바깥을 눌러 닫는 길을 막았으므로 Esc 는 살아 있어야 한다 — 닫는 길이 하나뿐이면
// 단추가 가려지거나 창이 화면 밖으로 밀렸을 때 빠져나올 수 없다.
function onKey(e) { if (e.key === 'Escape') emit('close') }
onMounted(() => window.addEventListener('keydown', onKey))
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <div class="mask">
    <div class="dlg" :class="{ moving: drag.moving.value }" :style="drag.style.value">
      <header class="grab" @pointerdown="drag.start($event)">
        <span class="hgrip" title="여기를 잡아 창을 옮깁니다">⠿</span>
        <strong>ProjectView 데이터 수집</strong>
        <span class="hint">진척률 · 실적시작일 · 실적종료일 · 일감(완료일 · 담당자 · 빈 단계)</span>
        <span class="spacer"></span>
        <button v-if="drag.moved()" title="창을 원래 자리로" @click="drag.reset()">⌖</button>
        <button class="x" title="닫기 (Esc)" @click="emit('close')">✕</button>
      </header>

      <!-- 머리말·꼬리말은 제자리에 두고 <가운데만> 구른다.
           전에는 감싸는 칸이 없어, 4단계의 표가 길어지면 창 아래로 삐져나가 잘렸다. -->
      <div class="body">

      <p v-if="err" class="err">{{ err }}</p>
      <p v-if="msg" class="ok">{{ msg }}</p>

      <!-- 지금 캐시 상태 -->
      <div class="stat">
        <span><b>{{ n(w.targets) }}</b> 건 대상</span>
        <span :class="{ warn: n(w.identified) < n(w.targets) }">
          workId <b>{{ n(w.identified) }}</b>
        </span>
        <span>일감 <b>{{ n(t.tasks) }}</b></span>
        <span :class="{ warn: !n(t.nodes_cached) }">단계 <b>{{ n(t.nodes_cached) }}</b></span>
        <span class="spacer"></span>
        <span class="muted">마지막 수집 {{ lastAt || '없음' }}</span>
      </div>

      <p v-if="staleDays" class="note warn">
        마지막 수집이 <strong>{{ staleDays }}일</strong> 전입니다. 그 사이 ProjectView 에서 값이 바뀌었을 수 있습니다.
      </p>
      <p v-else-if="!lastAt" class="note">
        아직 수집한 적이 없습니다. 한 번 걷으면 상세 목록의 <strong>PV</strong> 컬럼이 채워집니다.
      </p>

      <ol class="steps">
        <li :class="{ now: step === 1 }">
          아래 스크립트를 <strong>[복사]</strong> 합니다 (자동 복사가 막히면 <code>Ctrl+C</code>).
        </li>
        <li :class="{ now: step === 2 }">
          <strong>ProjectView 로그인 탭</strong>에서 <code>F12 → Console</code> 에 붙여넣고 Enter.
          <span class="muted">조회만 합니다 — ProjectView 를 고치지 않습니다.</span>
        </li>
        <li>끝나면 결과가 클립보드에 복사됩니다. 아래 칸에 붙여넣고 <strong>[저장]</strong>.</li>
        <li>이어서 <strong>원장에 넣을 날짜</strong>가 표로 나옵니다. 확인하고 <strong>[원장에 반영]</strong>.</li>
        <li>
          마지막으로 <strong>진척률 · 실적시작일 · 실적종료일</strong>을 ProjectView 로 되돌려 보내는 스크립트가 나옵니다.
          <span class="muted">진척률이 {{ FULL_RATE }}% 로 나가는 건은 일감의 <strong>현재상태</strong>도 완료로 함께 옮깁니다.</span>
          <span class="muted">이것만 ProjectView 를 고칩니다 — 콘솔에서 <code>pvSend()</code> 를 쳐야 전송됩니다.</span>
        </li>
      </ol>

      <!-- 1·2 는 짝이다 — 스크립트를 들고 나갔다가 결과를 들고 돌아오는 한 왕복이다.
           세로로 쌓으면 둘이 창 높이의 절반을 먹어 3·4 단계가 접힌 자리 아래로 밀려난다.
           가로로 두면 <나간 것>과 <돌아온 것>이 나란히 보이기도 한다. -->
      <div class="pair">
        <div class="col">
          <div class="row">
            <label>1 · 수집 스크립트 <span class="muted">{{ codes.length }}건 대상</span></label>
            <span class="spacer"></span>
            <button class="go" @click="doCopy">복사</button>
          </div>
          <textarea ref="area" class="code" readonly :value="script" spellcheck="false"></textarea>
        </div>

        <div class="col">
          <div class="row">
            <label>2 · 결과 붙여넣기</label>
            <span class="spacer"></span>
            <button class="go" :disabled="busy || !raw.trim()" @click="save">저장</button>
          </div>
          <textarea
            v-model="raw"
            class="paste"
            spellcheck="false"
            placeholder="ProjectView 콘솔이 복사해 준 JSON 을 붙여넣으세요 ( { &quot;projectId&quot;: ..., &quot;works&quot;: [ ... ] } )"
          ></textarea>
        </div>
      </div>

      <!-- 3 · 원장 반영. 캐시와 달리 우리 원장을 고치는 일이라 반드시 확인을 받는다. -->
      <template v-if="works">
        <div class="row">
          <label>3 · 원장 반영 <span class="muted">계획/실적 날짜 4개</span></label>
          <span class="spacer"></span>
          <button :disabled="syncing" @click="previewLedger">다시 확인</button>
          <button
            class="go warn"
            :disabled="syncing || !sync || !sync.changed"
            :title="sync && sync.changed
              ? `원장 ${sync.changed}건의 날짜를 ProjectView 값으로 바꿉니다`
              : '바꿀 것이 없습니다'"
            @click="applyLedger"
          >원장에 반영</button>
        </div>

        <p v-if="syncMsg" class="ok">{{ syncMsg }}</p>

        <div v-if="syncing" class="note">확인 중…</div>
        <template v-else-if="sync">
          <p v-if="!sync.changed" class="note">
            원장과 ProjectView 의 날짜가 <strong>모두 같습니다</strong> — 반영할 것이 없습니다.
          </p>
          <template v-else>
            <p class="note warn">
              원장(<code>hhip_wbs_wrk2</code>)의 날짜 <strong>{{ sync.changed }}건</strong>이 바뀝니다.
              ProjectView 가 빈 값인 자리는 <strong>원장도 비웁니다</strong>.
              <span class="muted">대조 {{ sync.matched }}건 · 같아서 그대로 {{ sync.same }}건<template
                v-if="sync.unknown_count"> · 원장에 없는 코드 {{ sync.unknown_count }}건</template></span>
            </p>
            <div class="diff">
              <table>
                <thead>
                  <tr><th>Activity ID</th><th>화면</th><th>바뀌는 값</th></tr>
                </thead>
                <tbody>
                  <tr v-for="r in sync.rows" :key="r.activity_id">
                    <td class="mono">{{ r.activity_id }}</td>
                    <td class="ell">{{ r.menu_nm }}</td>
                    <td>
                      <span v-for="c in r.changes" :key="c.col" class="chg">
                        {{ c.label }}
                        <b>{{ c.from || '(없음)' }}</b> → <b class="to">{{ c.to || '(비움)' }}</b>
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </template>
        </template>
      </template>

      <!-- 4 · ProjectView 로 되돌려 보내기. 여기만 ProjectView 를 고친다. -->
      <template v-if="works">
        <div class="row">
          <label>4 · ProjectView 전송 <span class="muted">진척률 · 실적시작일 · 실적종료일 · 현재상태</span></label>
          <span class="spacer"></span>
          <button :disabled="pushing" @click="loadPush">{{ push ? '다시 뽑기' : '대상 확인' }}</button>
          <button
            v-if="push && (push.rate.length || push.date.length || push.edate.length || push.status.length)"
            class="go"
            @click="copyPush"
          >전송 스크립트 복사</button>
        </div>

        <p v-if="pushMsg" class="ok">{{ pushMsg }}</p>
        <div v-if="pushing" class="note">대상 확인 중…</div>

        <p v-else-if="sync && sync.changed && !push" class="note warn">
          먼저 <strong>[원장에 반영]</strong> 을 눌러 주세요. 보낼 진척률은 원장의 계획일자로 계산하므로,
          반영 전에 뽑으면 <strong>옛 날짜로 계산된 값</strong>이 나갑니다.
        </p>

        <template v-else-if="push">
          <p v-if="!push.rate.length && !push.date.length && !push.edate.length && !push.status.length" class="note">
            ProjectView 와 <strong>이미 모두 같습니다</strong> — 보낼 것이 없습니다.
          </p>
          <template v-else>
            <p class="note warn">
              ProjectView 의 <strong>{{ push.rate.length + push.date.length + push.edate.length + push.status.length }}건</strong>이 바뀝니다 —
              진척률 <strong>{{ push.rate.length }}</strong>건 ·
              실적시작일 <strong>{{ push.date.length }}</strong>건 ·
              실적종료일 <strong>{{ push.edate.length }}</strong>건 ·
              현재상태 <strong>{{ push.status.length }}</strong>건.
              <template v-if="push.full">
                진척률 가운데 <strong>{{ push.full }}건</strong>은 {{ FULL_RATE }}% 로 나갑니다.
              </template>
              <span class="muted">
                진척률은 [진척률 현황] 과 같은 기준(착수 도래 · 미완료),
                실적시작일·실적종료일은 [지연 현황] 과 같은 기준(착수지연 · 종료지연),
                현재상태는 <strong>계획진척률이 {{ FULL_RATE }}% 로 나갈 건 전부</strong>입니다 —
                진척률을 새로 쓰지 않아도(ProjectView 가 이미 {{ FULL_RATE }}% 여도) 현재상태는 옮깁니다.
              </span>
            </p>
            <!-- 계획진척률 100% 는 <계획종료일이 지났다> 는 뜻이지 <끝났다> 는 뜻이 아니다.
                 실적종료일과 같은 무게라 같은 방식으로 세어서 보여 준다. -->
            <p v-if="push.statusOpen" class="note bad">
              <strong>현재상태 {{ push.statusOpen }}건은 개발자완료 표시가 없습니다.</strong>
              계획진척률 {{ FULL_RATE }}% 는 <strong>계획종료일이 지났다</strong>는 뜻이지
              <strong>끝났다</strong>는 뜻이 아닙니다 — 아직 끝나지 않은 건이라면 보내기 전에
              스크립트의 <code>DATA</code> 에서 그 줄의 <code>done: true</code> 를 지우세요.
            </p>
            <p v-if="push.unfinished" class="note bad">
              <strong>실적종료일 {{ push.unfinished }}건은 완료 표시가 하나도 없습니다.</strong>
              ProjectView 에 실적종료일이 찍히면 <strong>그날 끝났다</strong>는 뜻입니다 —
              아직 끝나지 않은 건이라면 보내기 전에 아래 표에서 빼야 할 대상인지 확인하세요
              (스크립트의 <code>DATA</code> 에서 그 줄을 지우면 됩니다).
            </p>
            <div class="diff">
              <table>
                <thead>
                  <tr><th>Activity ID</th><th>화면</th><th>보낼 값</th></tr>
                </thead>
                <tbody>
                  <tr v-for="r in push.rate" :key="'r' + r.activity_id">
                    <td class="mono">{{ r.activity_id }}</td>
                    <td class="ell">{{ r.menu_nm }}</td>
                    <td>
                      <span class="chg">진척률
                        <b>{{ r.from ?? '-' }}</b> → <b class="to">{{ r.send }}</b>
                        <em v-if="r.send !== r.rate" class="muted">(계산 {{ r.rate }})</em>
                      </span>
                      <!-- 100% 로 나가는 줄에는 <현재상태도 함께 바뀐다> 를 적는다.
                           윗줄 요약의 수만으로는 어느 줄인지 알 수가 없다. -->
                      <span v-if="r.send === FULL_RATE" class="flag ok">현재상태 → 완료</span>
                    </td>
                  </tr>
                  <tr v-for="r in push.date" :key="'d' + r.activity_id">
                    <td class="mono">{{ r.activity_id }}</td>
                    <td class="ell">{{ r.menu_nm }}</td>
                    <td>
                      <span class="chg">실적시작일
                        <b>(비어 있음)</b> → <b class="to">{{ r.date }}</b>
                      </span>
                    </td>
                  </tr>
                  <!-- 실적종료일 — 완료 표시를 함께 보여 준다. 끝났다고 적는 값이라
                       무엇이 근거인지 보이지 않으면 판단할 수가 없다. -->
                  <tr v-for="r in push.edate" :key="'e' + r.activity_id">
                    <td class="mono">{{ r.activity_id }}</td>
                    <td class="ell">{{ r.menu_nm }}</td>
                    <td>
                      <span class="chg">실적종료일
                        <b>(비어 있음)</b> → <b class="to">{{ r.edate }}</b>
                      </span>
                      <span v-if="r.done" class="flag ok">완료</span>
                      <span v-else-if="r.devDone" class="flag">개발자완료</span>
                      <span v-else class="flag bad">완료 표시 없음</span>
                    </td>
                  </tr>
                  <!-- 현재상태만 바뀌는 줄 — 진척률 줄에는 이미 배지가 붙어 있어 거기 섞지 않는다.
                       이 줄들이 수의 대부분이다(진척률은 쓸 것이 없고 상태만 남은 건). -->
                  <tr v-for="r in push.statusOnly" :key="'s' + r.activity_id">
                    <td class="mono">{{ r.activity_id }}</td>
                    <td class="ell">{{ r.menu_nm }}</td>
                    <td>
                      <span class="chg">현재상태
                        <b>(지금 단계)</b> → <b class="to">완료</b>
                      </span>
                      <em class="muted">진척률 {{ r.from ?? '-' }} — 그대로</em>
                      <span v-if="r.devDone" class="flag">개발자완료</span>
                      <span v-else class="flag bad">완료 표시 없음</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <textarea
              ref="pushArea" class="code push" readonly :value="push.script" spellcheck="false"
            ></textarea>
          </template>
        </template>
      </template>
      </div>

      <footer>
        <span class="muted">
          워크플로까지 걷으면 일감마다 조회가 한 번씩 더 붙어 몇십 초 걸립니다.
          필요 없으면 스크립트 위쪽 <code>WITH_FLOW</code> 를 <code>false</code> 로 두세요.
        </span>
      </footer>
    </div>
  </div>
</template>

<style scoped>
.mask {
  position: fixed;
  inset: 0;
  background: var(--overlay);
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 40px 20px;
  z-index: 100;
}
.dlg {
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 10px;
  width: min(900px, 100%);
  max-height: calc(100vh - 80px);
  display: flex;
  flex-direction: column;
  box-shadow: 0 8px 28px var(--shadow);
  overflow: hidden;              /* 둥근 모서리 밖으로 내용이 삐져나가지 않게 */
}
.dlg.moving { user-select: none; }
/* min-height:0 이 없으면 flex 자식이 내용만큼 늘어나 max-height 를 그냥 넘긴다 —
   스크롤이 생기지 않고 창 밖으로 삐져나가던 까닭이 이것이다. */
.body { flex: 1; min-height: 0; overflow: auto; padding-bottom: 12px; }
.dlg header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 11px 14px;
  border-bottom: 1px solid var(--line);
  flex: none;
}
.dlg header.grab { cursor: move; user-select: none; touch-action: none; }
.dlg header .hint { font-size: 11.5px; color: var(--muted); }
.hgrip { color: var(--muted-3); font-size: 12px; letter-spacing: -2px; }
.spacer { flex: 1; }

.err, .ok, .note { margin: 10px 14px 0; padding: 6px 10px; border-radius: 6px; font-size: 12px; }
.err { background: var(--danger-soft); border: 1px solid var(--danger-line); color: var(--danger-text); }
.ok { background: var(--done-soft); border: 1px solid var(--done); color: var(--done); }
.note { background: var(--accent-soft); border: 1px solid var(--accent); color: var(--accent); }
.note.warn { background: var(--warn-soft); border-color: var(--warn-line); color: var(--warn); }

.stat {
  display: flex;
  align-items: center;
  gap: 14px;
  margin: 10px 14px 0;
  padding: 7px 10px;
  background: var(--bg);
  border: 1px solid var(--line);
  border-radius: 6px;
  font-size: 11.5px;
  color: var(--muted);
  flex-wrap: wrap;
}
.stat b { color: var(--text); font-size: 13px; }
.stat .warn, .stat .warn b { color: var(--warn); }

.steps { margin: 10px 14px 4px; padding-left: 20px; font-size: 12px; color: var(--muted); line-height: 1.8; }
.steps strong { color: var(--text); }
.steps li.now { color: var(--accent); }
.steps .muted { font-size: 11px; }

.row { display: flex; align-items: center; gap: 8px; margin: 8px 14px 4px; flex: none; }
.row label { font-size: 12px; font-weight: 600; }
.row .muted { font-weight: 400; font-size: 11px; }
button.go { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
button.go:hover { color: var(--on-accent); }
button.go:disabled { opacity: 0.5; cursor: default; }

.code, .paste {
  margin: 0 14px;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 11.5px;
  line-height: 1.5;
  border: 1px solid var(--line);
  border-radius: 6px;
  padding: 8px;
  background: var(--surface);
  resize: vertical;
  overflow: auto;
}
.code { flex: 1 1 auto; min-height: 150px; white-space: pre; }
.paste { flex: none; min-height: 90px; }

/* 1 · 2 를 나란히. 세로 공간을 벌려고 가로로 둔 것이라 두 칸의 높이를 <같게> 맞춘다 —
   한쪽만 길면 짝으로 안 보이고, 아낀 높이도 긴 쪽에 도로 먹힌다. */
.pair { display: grid; grid-template-columns: 1fr 1fr; gap: 0 12px; margin: 0 14px; align-items: start; }
.pair .col { display: flex; flex-direction: column; min-width: 0; }
.pair .row { margin: 8px 0 4px; }        /* 바깥 여백은 .pair 가 들고 있다 */
.pair .code,
.pair .paste { margin: 0; height: 170px; min-height: 110px; flex: none; }
/* 창이 좁아지면 도로 세로로 — 가로 두 칸이 되면 스크립트가 글자 몇 개씩 접힌다 */
@media (max-width: 760px) { .pair { grid-template-columns: 1fr; } }
/* 전송 스크립트는 확인용이라 낮게 둔다 — 위쪽 수집 스크립트가 주인공이다 */
.code.push { flex: none; min-height: 110px; margin-top: 6px; }
.diff .chg em { font-style: normal; margin-left: 4px; font-size: 10.5px; }

/* 원장 반영 미리보기 — 바뀔 것만 보여 준다 */
.diff {
  margin: 0 14px;
  max-height: 190px;
  overflow: auto;
  border: 1px solid var(--line);
  border-radius: 6px;
  flex: none;
}
.diff table { border-collapse: collapse; width: 100%; font-size: 11.5px; }
.diff th, .diff td { border-bottom: 1px solid var(--line); padding: 4px 8px; text-align: left; }
.diff th { position: sticky; top: 0; background: var(--panel); color: var(--muted); font-weight: 600; }
.diff .mono { font-variant-numeric: tabular-nums; white-space: nowrap; }
.diff .ell { max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.diff .chg { display: inline-block; margin-right: 10px; white-space: nowrap; color: var(--muted); }
.diff .chg b { color: var(--text); font-weight: 600; }
.diff .chg b.to { color: var(--warn); }
button.go.warn { background: var(--warn); border-color: var(--warn); }

.dlg footer { padding: 10px 14px; flex: none; }
.dlg footer .muted { font-size: 11px; line-height: 1.5; }
header .x { border: 0; background: transparent; font-size: 14px; color: var(--muted); padding: 2px 6px; }
header .x:hover { color: var(--text); }

/* 실적종료일 줄의 근거 표시 — 완료 / 개발자완료 / 없음 */
.flag { margin-left: 6px; font-size: 10.5px; border-radius: 8px; padding: 1px 6px; border: 1px solid var(--line); color: var(--muted); }
.flag.ok { color: var(--done); border-color: var(--done-line); background: var(--done-soft); }
.flag.bad { color: var(--danger-text); border-color: var(--danger-line); background: var(--danger-soft); }
.note.bad { color: var(--danger-text); border-color: var(--danger-line); background: var(--danger-soft); }
</style>
