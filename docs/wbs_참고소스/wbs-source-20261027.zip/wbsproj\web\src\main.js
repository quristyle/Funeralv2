import { createApp } from 'vue'
// 기본 글꼴 Play — 구글 글꼴이지만 <우리가 서비스한다>.
// 사내망에서는 fonts.googleapis.com 에 닿지 않아 CDN 으로 걸면 열 때마다 끊긴 요청을
// 기다리게 된다. 그래서 파일을 저장소에 받아 두고(@fontsource/play) 번들에 싣는다.
// 400(보통)·700(굵게) 두 벌만 쓴다 — Play 에는 이 둘뿐이다.
import '@fontsource/play/latin-400.css'
import '@fontsource/play/latin-700.css'
// 한글은 Pretendard 가 받친다 — Play 에는 한글이 없다.
// <경량(subset)> 판을 쓴다: 흔히 쓰는 한글(KS X 1001 2,350자)+영문만 담아 굵기당 ~267KB 다.
// 전체 판은 굵기당 ~766KB 라 세 배가 되는데, 업무 화면에 쓰는 글자는 경량 판 안에 다 있다.
// 아홉 굵기가 선언되지만 브라우저는 <실제로 쓰는 400·700 만> 받아 간다.
import 'pretendard/dist/web/static/pretendard-subset.css'
import App from './App.vue'
import './style.css'

createApp(App).mount('#app')

// ---------------------------------------------------------------- PWA
// 서비스 워커는 <https 로 접속했을 때만> 등록한다.
// 크롬 주소창의 설치 아이콘은 보안 출처 + 서비스 워커가 모두 있어야 뜨기 때문이다.
//
// http(5080)로 들어오면 등록하지 않고, 예전에 등록된 것이 남아 있으면 지운다.
// chrome://flags 로 http 출처를 보안 출처인 척 만든 PC 에서 브라우저가 멈추는 문제가
// 있었기 때문이다. sw.js 자체도 https 가 아니면 스스로 물러나도록 되어 있다(이중 안전장치).
const HTTPS = location.protocol === 'https:'

if ('serviceWorker' in navigator) {
  if (HTTPS) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch((e) => {
        console.warn('서비스 워커 등록 실패:', e.message)
      })
    })
  } else {
    navigator.serviceWorker
      .getRegistrations()
      .then((rs) => rs.forEach((r) => r.unregister()))
      .catch(() => {})
    if (window.caches) {
      caches
        .keys()
        .then((ks) => ks.filter((k) => k.startsWith('wbs-')).forEach((k) => caches.delete(k)))
        .catch(() => {})
    }
  }
}
