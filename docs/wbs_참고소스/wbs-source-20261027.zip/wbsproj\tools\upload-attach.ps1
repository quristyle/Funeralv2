﻿# 인터페이스 첨부파일 업로드 (파일명이 한글이어도 UTF-8 로 정확히 전달한다).
# curl 은 Windows 에서 파일명을 ANSI 로 읽어 한글이 깨지므로 multipart 를 직접 만든다.
#
# 사용법: powershell -ExecutionPolicy Bypass -File tools\upload-attach.ps1 -IfId 5 -Path "<파일>"

param(
  [Parameter(Mandatory = $true)][int]$IfId,
  [Parameter(Mandatory = $true)][string]$Path,
  [string]$Base = 'http://127.0.0.1:5080'
)

$ErrorActionPreference = 'Stop'
$file = Get-Item -LiteralPath $Path
$bytes = [System.IO.File]::ReadAllBytes($file.FullName)

$boundary = 'wbs' + [Guid]::NewGuid().ToString('N')
$utf8 = New-Object System.Text.UTF8Encoding $false
$ms = New-Object System.IO.MemoryStream

function Add-Text([string]$s) {
  $b = $utf8.GetBytes($s)
  $ms.Write($b, 0, $b.Length)
}

Add-Text "--$boundary`r`n"
Add-Text "Content-Disposition: form-data; name=`"files`"; filename=`"$($file.Name)`"`r`n"
Add-Text "Content-Type: application/octet-stream`r`n`r`n"
$ms.Write($bytes, 0, $bytes.Length)
Add-Text "`r`n--$boundary--`r`n"

$body = $ms.ToArray()
$ms.Dispose()

$res = Invoke-WebRequest -Uri "$Base/api/if/$IfId/files" -Method Post `
  -ContentType "multipart/form-data; boundary=$boundary" -Body $body -UseBasicParsing

Write-Host "if_id=$IfId  $($file.Name)  ($([Math]::Round($file.Length/1KB)) KB) -> $($res.StatusCode)"
Write-Host $res.Content
