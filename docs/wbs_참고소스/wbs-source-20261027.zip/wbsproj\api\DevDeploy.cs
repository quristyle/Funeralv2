using System.Collections.Concurrent;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace WbsApi;

/// <summary>
/// 배포 상태 — [로컬 개발서버] 화면의 카드마다 BE·FE 한 줄씩, <b>세 칸</b>으로 붙는다.
/// 왼쪽부터 <b>이미지 → 도커 → 로컬</b> 이고, 흐름이 그 순서다(굽는다 → 올린다 → 내 PC 에서 돈다).
///
///  ① <b>이미지</b>  GitLab 의 마지막 성공 <c>build:image</c> 잡. 그 안에서 docker build 와 push 가
///                   끝나므로 <b>이미지가 생긴 시각</b>이다. 커밋·브랜치도 함께 안다.
///  ② <b>도커</b>    개발 서버 컨테이너를 직접 두드린 결과. 시각은 아래 <관측> 참고.
///  ③ <b>로컬</b>    DevRun.cs 가 띄우고 내리는 것. 대상이 아예 다르다.
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>⚠️ 공개 URL 로는 ②를 판정할 수 없다 — 이것이 이 파일이 있는 까닭이다.</b>
/// <c>https://dev-isos-hhip.hd.com/mfe/pmm001/remoteEntry.js</c> 는 미인증이면 <b>무조건 302</b>
/// (mod_auth_openidc → Keycloak <c>realms/bff</c>). 배포된 모듈도, 있지도 않은 <c>pmm099</c> 도,
/// <c>/zzz/nope.js</c> 도 똑같이 302 다(2026-10-01 셋 다 직접 확인). 그 응답코드를 상태로 쓰면
/// 무엇이 내려가 있든 <b>언제나 초록</b>인 거짓 표시가 된다. 그래서 판정은 <b>컨테이너 포트로 직접</b>
/// 하고, 공개 URL 은 <b>사람이 눌러 열 링크</b>로만 쓴다. 둘을 합치지 말 것.
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>⚠️ <도커에 반영된 시각> 은 컨테이너에게 물어볼 수 없다.</b> 2026-10-01 에 길을 다 두드려 봤다:
///   · Docker API(2375 · 2376 · 9000) — 전부 닫힘
///   · Spring actuator — <c>health</c> 만 열려 있다. <c>info · metrics · env · startup</c> 모두 404
///   · Apache <c>mod_status</c> — 없다. <c>/server-status</c> 가 200 인 것은 SPA fallback 이
///     index.html 을 돌려준 것이다(<b>오탐 주의</b> — 본문을 봐야 안다)
///   · <c>remoteEntry.js</c> 의 Last-Modified 는 <b>이미지 안 파일의 mtime</b> 이다.
///     즉 ①에 속하는 값이지 반영 시각이 아니다(잡 완료와 7초 차이인 것이 그 증거).
///
/// 그래서 <b>관측해서 기록</b>한다. 지문(FE 는 <c>remoteEntry.js</c> 의 ETag, BE 는 살아 있는지
/// 여부)을 매번 읽어 두고, <b>바뀐 순간</b>을 <c>data/deploy-seen.json</c> 에 적는다.
/// 처음 본 값은 언제부터 그랬는지 알 수 없으므로 <b>시각을 주지 않는다</b>(confirmed=false).
/// BE 는 지문이 없어 <끊겼다 돌아온 것>만 잡으므로, 폴링 사이에 교체가 끝나면 놓친다.
///
/// <b>더 좋은 길이 하나 열려 있다 — Harbor.</b> <c>10.100.45.109:5000</c> 이 살아 있고
/// <c>/api/v2.0/health</c> 가 200 이다(<c>.gitlab-ci.yml</c> 머리말의 DEV_HARBOR_REGISTRY).
/// 아티팩트의 <c>pull_time</c> 이 곧 <b>배포 호스트가 이미지를 당긴 시각</b>이라 반영 시각 그 자체다.
/// 막는 것은 계정뿐이다(CI 변수 DEV_HARBOR_USERNAME/PASSWORD). 읽기 전용 계정을 받으면
/// <c>ReflectedAtAsync</c> 한 군데만 갈아 끼우면 된다 — 나머지는 손댈 것이 없다.
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>대상은 화면이 아는 모든 프로젝트다</b>(<c>DevRun.DeployTargets()</c>). 모듈 번호를 세지 않는다.
///   · GitLab 경로 — 그 폴더의 <c>.git/config</c> 에 적힌 remote 에서 읽는다. 짐작하지 않는다.
///   · FE 배포 포트 — 그 저장소 <c>.gitlab-ci.yml</c> 의 <c>--build-arg APP_PORT=NNNN</c>.
///   · BE 배포 포트 — <b>저장소에 없다</b>. CI 변수(<c>TPL_APP_PORT</c>)로 주입되기 때문이다.
///     그래서 <b>FE 포트의 3→8 규칙으로 추정</b>한다(3201→8201 · 3101→8101 … 넷을 맞춰 보았다).
///     추정이라는 사실을 화면이 그대로 밝힌다. <c>Deploy:Ports</c> 로 못을 박을 수 있다.
///
/// <b>부르는 쪽이 기다리지 않는다</b> — <c>/api/dev/state</c> 는 화면이 2초마다 부른다.
/// <c>Touch()</c> 는 묵었을 때만 뒤에서 한 바퀴를 시작하고 즉시 돌아간다.
/// </summary>
public static class DevDeploy
{
    // 리다이렉트를 따라가지 않는다 — 따라가면 Keycloak 로그인 페이지의 200 을 <정상>으로 읽는다.
    // 프록시도 끈다 — 사내 프록시가 끼면 컨테이너 포트가 엉뚱한 응답으로 가려진다.
    private static readonly HttpClient Http =
        new(new HttpClientHandler { AllowAutoRedirect = false, UseProxy = false })
        {
            Timeout = TimeSpan.FromSeconds(30), // 실제 제한은 요청마다 건다(_timeoutMs)
        };

    private static bool _on;
    private static string _host = "";
    private static string _pub = "";
    private static int _ttl, _timeoutMs, _probeWide;
    private static Dictionary<string, string> _groupHost = new(StringComparer.OrdinalIgnoreCase);
    private static Dictionary<string, int> _portFix = new(StringComparer.OrdinalIgnoreCase);
    private static Dictionary<string, string> _pubPath = new(StringComparer.OrdinalIgnoreCase);

    private static Dictionary<string, object> _items = [];
    private static DateTimeOffset _at = DateTimeOffset.MinValue;
    private static volatile bool _busy;
    private static readonly SemaphoreSlim Gate = new(1, 1);

    // ---------- GitLab ----------
    private static readonly HttpClient Gl = new() { Timeout = TimeSpan.FromSeconds(20) };
    private static string _glBase = "";
    private static string _glToken = "";
    private static string _glJob = "";
    private static int _imgTtl, _driftMin;
    private static Dictionary<string, Dictionary<string, object?>?> _img = [];
    private static DateTimeOffset _imgAt = DateTimeOffset.MinValue;

    // ---------- 관측 기록 ----------
    private static string _seenFile = "";
    private static readonly ConcurrentDictionary<string, Seen> SeenMap = new();

    private sealed class Seen
    {
        /// <summary>
        /// 어디를 두드려서 얻은 지문인가. <b>보는 곳이 바뀌면 지문 비교는 뜻이 없다</b> —
        /// 포트를 고치거나 배정이 바뀐 것을 <재배포> 로 적어 버린다(pmm016 에서 실제로 겪었다:
        /// 포트를 3000 에서 3216 으로 바로잡자 "방금 반영됨" 으로 찍혔다).
        /// </summary>
        public string Url { get; set; } = "";
        /// <summary>지금 서비스되는 것의 지문. FE 는 ETag, BE 는 살아 있는지 여부뿐이다.</summary>
        public string Fp { get; set; } = "";
        /// <summary>그 지문이 된 시각 — 바뀌는 것을 <b>본</b> 때다.</summary>
        public long At { get; set; }
        /// <summary>바뀌는 것을 실제로 보았는가. 처음 본 값은 false — 언제부터인지 모른다.</summary>
        public bool Confirmed { get; set; }
    }

    public static void Init(IConfiguration cfg, string contentRoot)
    {
        _on = !string.Equals(cfg["Deploy:Enabled"], "false", StringComparison.OrdinalIgnoreCase);
        _host = (cfg["Deploy:Host"] ?? "10.100.45.110").Trim();
        _pub = (cfg["Deploy:Public"] ?? "https://dev-isos-hhip.hd.com").TrimEnd('/');
        _ttl = cfg.GetValue("Deploy:CacheSeconds", 60);
        // 컨테이너가 식어 있으면 actuator 첫 응답이 늦다 — 2초로 끊으면 떠 있는 것을 꺼졌다고 적는다.
        _timeoutMs = cfg.GetValue("Deploy:TimeoutMs", 6000);
        // 대상이 70칸이 넘는다. 안 뜬 것은 제한시간을 다 쓰므로 한 번에 여럿 보낸다.
        _probeWide = cfg.GetValue("Deploy:Concurrency", 16);

        _groupHost = ReadMap(cfg, "Deploy:Hosts");            // 작업공간 → 호스트
        _pubPath = ReadMap(cfg, "Deploy:PublicPaths");        // "<id>:<tier>" → 공개 경로
        _portFix = ReadMap(cfg, "Deploy:Ports")               // "<id>:<tier>" → 배포 포트(못 박기)
            .Where(kv => int.TryParse(kv.Value, out _))
            .ToDictionary(kv => kv.Key, kv => int.Parse(kv.Value), StringComparer.OrdinalIgnoreCase);

        // GitLab 설정은 [빌드 상태] 화면 것을 그대로 빌려 쓴다 — 같은 저장소를 본다.
        // 토큰을 두 군데 적어 두면 한쪽만 갈아 끼우고 왜 안 되는지 찾게 된다.
        _glBase = (cfg["Gitlab:BaseUrl"] ?? "https://code.hd.com").TrimEnd('/');
        _glToken = cfg["Gitlab:Token"] ?? Environment.GetEnvironmentVariable("GITLAB_TOKEN") ?? "";
        _glJob = cfg["Deploy:ImageJob"] ?? "build:image";
        _imgTtl = cfg.GetValue("Deploy:ImageCacheSeconds", 300);
        // 이미지를 구운 시각과 지금 서비스되는 파일의 시각이 이만큼 벌어지면 <안 올라갔다> 로 본다.
        _driftMin = cfg.GetValue("Deploy:DriftMinutes", 30);

        _seenFile = Path.Combine(contentRoot, "data", "deploy-seen.json");
        LoadSeen();

        if (_on) _ = SweepAsync();
    }

    private static Dictionary<string, string> ReadMap(IConfiguration cfg, string key)
    {
        var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var c in cfg.GetSection(key).GetChildren())
            if (c.Value is not null) d[c.Key] = c.Value;
        return d;
    }

    // ============================================================================
    // 대상 표 — 화면이 아는 모든 be/fe 폴더에서 <어디를 두드릴지> 를 끌어낸다.
    // ============================================================================
    private sealed record Target(
        string Id, string Label, string Group, string Tier, string Dir,
        string? GitPath, string Host, int Port, string PortSrc, string? Pub);

    // 포트를 어디서 알아냈는가. 작은 숫자가 더 믿을 만하다 —
    // <겹쳤을 때 누가 그 포트의 주인인가> 를 이것으로 가린다.
    private const int SrcFix = 0;   // appsettings 의 Deploy:Ports
    private const int SrcVm = 1;    // 작업공간의 vm_port정보.txt (배정 정본)
    private const int SrcCi = 2;    // 저장소의 .gitlab-ci.yml APP_PORT
    private const int SrcRule = 3;  // FE 포트의 3→8 규칙 (추정)
    private static readonly string[] SrcName = ["설정", "vm_port정보.txt", ".gitlab-ci.yml", "추정 (FE 포트 3→8)"];
    private static int SrcRank(string s) => Array.IndexOf(SrcName, s) is var i && i >= 0 ? i : 99;

    // 폴더당 한 번만 읽으면 되는 것들. 폴더가 바뀌는 일(= 새로 받아 옴)은 [다시 훑기] 가 알려 준다.
    private static readonly ConcurrentDictionary<string, string?> GitPathCache = new();
    private static readonly ConcurrentDictionary<string, int> CiPortCache = new();

    /// <summary>[다시 훑기] 를 눌렀을 때 — 폴더가 바뀌었으니 읽어 둔 것을 버린다.</summary>
    public static void Reset()
    {
        GitPathCache.Clear();
        CiPortCache.Clear();
        _at = DateTimeOffset.MinValue;
        _imgAt = DateTimeOffset.MinValue;
    }

    private static List<Target> BuildTargets()
    {
        var raw = DevRun.DeployTargets();

        // FE 의 CI 포트를 먼저 모은다 — BE 포트를 그 값에서 끌어내기 때문이다.
        var feCi = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        foreach (var t in raw)
            if (t.Tier == "fe")
            {
                var p = CiPortCache.GetOrAdd(t.Dir, CiAppPort);
                if (p > 0) feCi[t.Id] = p;
            }

        var list = new List<Target>(raw.Count);
        foreach (var t in raw)
        {
            var key = $"{t.Id}:{t.Tier}";
            var host = _groupHost.GetValueOrDefault(t.Group, _host);
            int port;
            string src;

            if (_portFix.TryGetValue(key, out var fix))
            {
                (port, src) = (fix, SrcName[SrcFix]);
            }
            else if (VmPortOf(t.Dir, t.Id, t.Tier) is (string vmHost, int vmPort))
            {
                // 배정 정본이 있으면 그것이 이긴다 — 저장소의 CI 값이 낡은 경우가 실제로 있다
                // (pmm016 은 CI 에 3000 이라 적혀 있지만 실제 배포는 3216 이다).
                (host, port, src) = (vmHost, vmPort, SrcName[SrcVm]);
            }
            else if (t.Tier == "fe")
            {
                (port, src) = (feCi.GetValueOrDefault(t.Id), SrcName[SrcCi]);
            }
            else
            {
                // BE 포트는 저장소에 없다(CI 변수 TPL_APP_PORT 로 주입된다). 3→8 규칙으로 <추정>한다.
                var f = feCi.GetValueOrDefault(t.Id);
                port = f is >= 3000 and < 4000 ? 8000 + (f - 3000) : 0;
                src = SrcName[SrcRule];
            }

            list.Add(new Target(
                t.Id, t.Label, t.Group, t.Tier, t.Dir,
                GitPathCache.GetOrAdd(t.Dir, GitPath),
                host, port, src, PubOf(t.Id, t.Tier)));
        }

        return Dedupe(list);
    }

    /// <summary>
    /// 같은 <c>host:port</c> 를 둘 이상이 가리키면 <b>아무도 판정하지 않는다</b>.
    ///
    /// 틀린 포트가 실제로 있다 — 템플릿 기본값 <c>APP_PORT=3000</c> 을 안 고친 저장소가 여럿이고
    /// (ppp006 · pps001 · pqm001 … 전부 3000), <c>ppd006-fe</c> 는 <c>3201</c> 이라 <c>pmm001</c> 과 겹친다.
    /// 그대로 두면 <b>남의 컨테이너를 보고 "배포됨"</b> 이라고 적는다 — 가장 나쁜 종류의 거짓말이다.
    /// 출처가 더 믿을 만한 쪽이 하나뿐이면 그쪽만 살려 둔다(배정 정본 &gt; CI &gt; 추정).
    /// </summary>
    private static List<Target> Dedupe(List<Target> list)
    {
        foreach (var g in list.Where(x => x.Port > 0).GroupBy(x => $"{x.Host}:{x.Port}"))
        {
            var members = g.ToList();
            if (members.Count < 2) continue;

            var best = members.Min(m => SrcRank(m.PortSrc));
            var winners = members.Where(m => SrcRank(m.PortSrc) == best).ToList();
            foreach (var m in members)
            {
                if (winners.Count == 1 && ReferenceEquals(m, winners[0])) continue;
                list[list.IndexOf(m)] = m with { Port = 0, PortSrc = $"겹침:{g.Key}" };
            }
        }
        return list;
    }

    // ---------- 배정 정본 (vm_port정보.txt) ----------
    // 작업공간 루트에 있는 포트 배정표. "pmm001 → 10.100.45.110:3201" · "api/pmm001 → …:8201".
    // 폴더에서 세 칸까지 거슬러 올라가며 찾는다 — 짝을 이룬 것과 홀로 선 것의 깊이가 다르다.
    private static readonly ConcurrentDictionary<string, Dictionary<string, (string Host, int Port)>> VmCache = new();

    private static (string, int)? VmPortOf(string dir, string id, string tier)
    {
        var table = VmTableFor(dir);
        if (table is null) return null;
        var key = tier == "be" ? $"api/{id}" : id;
        return table.TryGetValue(key, out var v) ? v : null;
    }

    private static Dictionary<string, (string, int)>? VmTableFor(string dir)
    {
        var cur = dir;
        for (var up = 0; up < 4 && !string.IsNullOrEmpty(cur); up++)
        {
            var path = Path.Combine(cur, "vm_port정보.txt");
            if (File.Exists(path))
                return VmCache.GetOrAdd(path, ReadVmTable);
            cur = Path.GetDirectoryName(cur);
        }
        return null;
    }

    private static Dictionary<string, (string Host, int Port)> ReadVmTable(string path)
    {
        var d = new Dictionary<string, (string, int)>(StringComparer.OrdinalIgnoreCase);
        try
        {
            foreach (var line in File.ReadLines(path))
            {
                var m = Regex.Match(line, @"^\s*(\S+)\s+(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5})\s*$");
                if (m.Success) d[m.Groups[1].Value] = (m.Groups[2].Value, int.Parse(m.Groups[3].Value));
            }
        }
        catch { /* 못 읽으면 CI 값으로 내려간다 */ }
        return d;
    }

    /// <summary>공개 주소 — 모르는 것은 null 이다. 짐작해서 적으면 눌렀을 때 엉뚱한 곳으로 간다.</summary>
    private static string? PubOf(string id, string tier)
    {
        if (_pubPath.TryGetValue($"{id}:{tier}", out var p))
            return p.StartsWith("http", StringComparison.OrdinalIgnoreCase) ? p : $"{_pub}/{p.TrimStart('/')}";
        // 자재관리(pmmNNN)만 게이트웨이 경로가 정해져 있다 — /mfe/<id>, /api/<id>.
        if (!Regex.IsMatch(id, @"^pmm\d{3}$", RegexOptions.IgnoreCase)) return null;
        return tier == "fe" ? $"{_pub}/mfe/{id}/remoteEntry.js" : $"{_pub}/api/{id}";
    }

    /// <summary>그 폴더의 GitLab 경로 — <c>.git/config</c> 의 remote 에서 읽는다.</summary>
    private static string? GitPath(string dir)
    {
        try
        {
            var cfgPath = Path.Combine(dir, ".git", "config");
            if (!File.Exists(cfgPath)) return null;
            foreach (var line in File.ReadLines(cfgPath))
            {
                var m = Regex.Match(line, @"^\s*url\s*=\s*(\S+)");
                if (!m.Success) continue;
                var url = m.Groups[1].Value;
                // https://code.hd.com/g6x0/xu62/…/pmm001-fe.git · git@code.hd.com:g6x0/… 둘 다 받는다
                var i = url.IndexOf("code.hd.com", StringComparison.OrdinalIgnoreCase);
                if (i < 0) continue;
                var path = url[(i + "code.hd.com".Length)..].TrimStart(':', '/');
                if (path.EndsWith(".git", StringComparison.OrdinalIgnoreCase)) path = path[..^4];
                return path.Trim('/');
            }
        }
        catch { /* 못 읽으면 이미지 칸이 <모름> 으로 남는다 — 화면이 죽지는 않는다 */ }
        return null;
    }

    /// <summary><c>.gitlab-ci.yml</c> 의 <c>--build-arg APP_PORT=NNNN</c>. 없으면 0.</summary>
    private static int CiAppPort(string dir)
    {
        try
        {
            var p = Path.Combine(dir, ".gitlab-ci.yml");
            if (!File.Exists(p)) return 0;
            var m = Regex.Match(File.ReadAllText(p), @"APP_PORT[=:]\s*""?(\d{2,5})");
            return m.Success ? int.Parse(m.Groups[1].Value) : 0;
        }
        catch { return 0; }
    }

    // ============================================================================
    // 한 바퀴
    // ============================================================================
    public static object Json() => new
    {
        enabled = _on,
        host = _host,
        pub = _pub,
        busy = _busy,
        at = Ms(_at),
        imgAt = Ms(_imgAt),
        imgOn = !string.IsNullOrWhiteSpace(_glToken),
        // 화면이 <무엇이 얼마마다 갱신되는지> 를 그대로 적어 보여 줄 수 있게 함께 준다.
        // 화면의 폴링 주기를 아무리 줄여도 이 두 값보다 빨라지지 않는다.
        ttl = _ttl,
        imgTtl = _imgTtl,
        items = _items,
    };

    private static long? Ms(DateTimeOffset d) =>
        d == DateTimeOffset.MinValue ? null : d.ToUnixTimeMilliseconds();

    public static void Touch()
    {
        if (!_on || _busy) return;
        if (DateTimeOffset.UtcNow - _at < TimeSpan.FromSeconds(_ttl)) return;
        _ = SweepAsync();
    }

    public static async Task SweepAsync(bool force = false)
    {
        if (!_on) return;
        if (!force && DateTimeOffset.UtcNow - _at < TimeSpan.FromSeconds(_ttl)) return;

        // ⚠️ 저절로 도는 쪽(force=false)만 비켜 준다. 사람이 ⟳ 를 누른 쪽은 <기다린다> —
        //    비켜 버리면 첫 한 바퀴가 도는 동안 누른 ⟳ 가 빈 결과를 돌려준다.
        if (force) await Gate.WaitAsync();
        else if (!await Gate.WaitAsync(0)) return;
        _busy = true;
        try
        {
            if (!force && DateTimeOffset.UtcNow - _at < TimeSpan.FromSeconds(_ttl)) return;

            var targets = BuildTargets();

            // 이미지 시각은 따로 묵힌다 — 사내 GitLab 으로 나가는 호출이라 훨씬 드물게 본다.
            var imgTask = force || DateTimeOffset.UtcNow - _imgAt >= TimeSpan.FromSeconds(_imgTtl)
                ? RefreshImagesAsync(targets)
                : Task.CompletedTask;

            var docker = await ProbeAllAsync(targets);
            await imgTask;

            var map = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            foreach (var t in targets)
            {
                var key = $"{t.Id}:{t.Tier}";
                if (!map.TryGetValue(t.Id, out var row))
                {
                    row = new Dictionary<string, object?>();
                    map[t.Id] = row;
                }
                var img = _img.GetValueOrDefault(key);
                var dk = docker.GetValueOrDefault(key);
                ((Dictionary<string, object?>)row)[t.Tier] = new
                {
                    gitPath = t.GitPath,
                    img,
                    docker = dk,
                    // 구운 이미지가 서비스되는 파일보다 한참 새것이면 <올리지 않은 것> 이다.
                    // FE 만 가릴 수 있다 — BE 는 비교할 짝(serveAt)이 없다.
                    stale = IsStale(img, dk),
                };
            }

            _items = map;
            _at = DateTimeOffset.UtcNow;
            SaveSeen();
        }
        finally
        {
            _busy = false;
            Gate.Release();
        }
    }

    /// <summary>이미지는 새것인데 서비스되는 파일은 옛것인가 — 빌드는 됐는데 안 올라간 상태다.</summary>
    private static bool IsStale(Dictionary<string, object?>? img, object? docker)
    {
        if (img is null || docker is null) return false;
        if (img.GetValueOrDefault("at") is not long built) return false;
        // 익명 형식이라 속성을 이름으로 꺼낸다 — 이 한 군데뿐이라 그대로 둔다.
        var serve = docker.GetType().GetProperty("serveAt")?.GetValue(docker) as long?;
        return serve is long live && built - live > (long)_driftMin * 60_000;
    }

    private static async Task<Dictionary<string, object>> ProbeAllAsync(List<Target> targets)
    {
        var done = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        using var gate = new SemaphoreSlim(_probeWide, _probeWide);
        var pairs = new (string Key, object Val)[targets.Count];

        await Task.WhenAll(targets.Select(async (t, i) =>
        {
            await gate.WaitAsync();
            try { pairs[i] = ($"{t.Id}:{t.Tier}", await ProbeAsync(t)); }
            finally { gate.Release(); }
        }));

        foreach (var (k, v) in pairs) done[k] = v;
        return done;
    }

    // ---------- 컨테이너 두드리기 ----------
    private static async Task<object> ProbeAsync(Target t)
    {
        if (t.Port <= 0)
        {
            // 주소를 모르는 것과 <안 떠 있는 것> 은 전혀 다르다. 섞으면 멀쩡한 것을 장애로 읽고,
            // 반대로 남의 포트를 보고 멀쩡하다고 적게 된다.
            var dup = t.PortSrc.StartsWith("겹침:", StringComparison.Ordinal);
            return new
            {
                state = "unknown",
                label = dup ? "포트 겹침" : "주소 모름",
                why = dup
                    ? $"{t.PortSrc[3..]} 를 다른 프로젝트도 가리킵니다 — 어느 컨테이너인지 가릴 수 없어 "
                      + "판정하지 않습니다. appsettings 의 Deploy:Ports 로 못을 박으세요."
                    : t.Tier == "fe"
                        ? "배정표(vm_port정보.txt)에도 .gitlab-ci.yml 의 APP_PORT 에도 없습니다 "
                          + "(배포하지 않는 저장소일 수 있습니다)"
                        : "BE 배포 포트를 알 수 없습니다 — 배정표가 없으면 같은 프로젝트 FE 포트에서 추정합니다",
                host = t.Host, port = 0, portSrc = t.PortSrc, portGuessed = false,
                url = (string?)null, pub = t.Pub, serveAt = (long?)null,
                at = (long?)null, since = (long?)null, confirmed = false,
            };
        }

        var url = t.Tier == "fe"
            ? $"http://{t.Host}:{t.Port}/remoteEntry.js"
            : $"http://{t.Host}:{t.Port}/actuator/health";

        using var cts = new CancellationTokenSource(_timeoutMs);
        try
        {
            string state, label, fp;
            int code;
            long? serveAt = null;

            if (t.Tier == "fe")
            {
                using var req = new HttpRequestMessage(HttpMethod.Head, url);
                using var res = await Http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, cts.Token);
                code = (int)res.StatusCode;
                serveAt = res.Content.Headers.LastModified?.ToUnixTimeMilliseconds();
                state = code == 200 ? "up" : "bad";
                // 포트는 열렸는데 파일이 없다 = 컨테이너는 떴지만 빌드 결과가 안 들어간 것이다.
                label = code switch { 200 => "배포됨", 404 => "파일 없음", _ => $"HTTP {code}" };
                // 지문 — 이미지가 바뀌면 ETag 도 바뀐다. 없으면 파일 시각으로 대신한다.
                fp = res.Headers.ETag?.Tag ?? serveAt?.ToString() ?? code.ToString();
            }
            else
            {
                using var res = await Http.GetAsync(url, HttpCompletionOption.ResponseContentRead, cts.Token);
                code = (int)res.StatusCode;
                // ⚠️ 본문은 200 이 아닐 때도 읽는다. actuator 는 health 가 DOWN 이면
                //    503 + {"status":"DOWN"} 으로 답한다 — 코드만 보고 "HTTP 503" 이라 적으면
                //    <무슨 일인지 모르겠다> 가 되지만, 본문을 읽으면 <기동 중이거나 의존이 끊겼다> 가 된다.
                var status = await HealthStatusAsync(res, cts.Token);
                if (status.Length > 0)
                {
                    var ok = string.Equals(status, "UP", StringComparison.OrdinalIgnoreCase);
                    state = ok ? "up" : "bad";
                    label = ok ? "배포됨" : status; // DOWN · OUT_OF_SERVICE …
                }
                else
                {
                    // 404 는 꺼진 것이 아니다 — 포트가 응답했다는 것 자체가 컨테이너가 떠 있다는 뜻이다
                    // (actuator 를 안 연 모듈이 있다). 5xx 만 성치 않은 것으로 본다.
                    state = code >= 500 ? "bad" : "up";
                    label = code >= 500 ? $"HTTP {code}" : $"떠 있음 (actuator 없음 · {code})";
                }
                // BE 는 판가름할 지문이 없다 — 살아 있는지만 적어 둔다(머리말의 한계 참고).
                fp = "up";
            }

            var seen = Note($"{t.Id}:{t.Tier}", fp, url);
            return new
            {
                state, label, code,
                host = t.Host, port = t.Port, portSrc = t.PortSrc,
                portGuessed = SrcRank(t.PortSrc) >= SrcRule,
                url, pub = t.Pub,
                // 이 컨테이너가 서비스하는 파일의 시각 — <이미지 안의 mtime> 이다(FE 만).
                serveAt,
                // 도커에 반영된 시각 — 우리가 <바뀌는 것을 본> 때만 준다.
                at = seen.Confirmed ? seen.At : (long?)null,
                since = seen.At,
                confirmed = seen.Confirmed,
            };
        }
        catch (Exception e)
        {
            Note($"{t.Id}:{t.Tier}", "down", url);
            return new
            {
                state = "down", label = "안 떠 있음", code = 0,
                host = t.Host, port = t.Port, portSrc = t.PortSrc,
                portGuessed = SrcRank(t.PortSrc) >= SrcRule,
                url, pub = t.Pub, serveAt = (long?)null,
                at = (long?)null, since = (long?)null, confirmed = false,
                why = Why(e),
            };
        }
    }

    /// <summary>
    /// 지문을 적어 둔다. <b>바뀌는 것을 본</b> 때만 시각이 뜻을 갖는다 —
    /// 처음 본 값은 언제부터 그랬는지 알 수 없으므로 confirmed=false 로 둔다.
    /// </summary>
    private static Seen Note(string key, string fp, string url)
    {
        var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        return SeenMap.AddOrUpdate(
            key,
            _ => new Seen { Url = url, Fp = fp, At = now, Confirmed = false },
            (_, old) =>
            {
                // 두드리는 곳이 바뀌었으면 처음부터 다시 본다 — 비교할 짝이 아니다.
                if (old.Url != url) return new Seen { Url = url, Fp = fp, At = now, Confirmed = false };
                if (old.Fp == fp) return old;
                // 지문이 바뀌었다 = 다른 이미지가 올라왔다. down → up 도 <무언가 올라왔다> 로 본다.
                return new Seen { Url = url, Fp = fp, At = now, Confirmed = true };
            });
    }

    private static async Task<string> HealthStatusAsync(HttpResponseMessage res, CancellationToken ct)
    {
        try
        {
            await using var s = await res.Content.ReadAsStreamAsync(ct);
            using var doc = await JsonDocument.ParseAsync(s, cancellationToken: ct);
            return doc.RootElement.TryGetProperty("status", out var v) && v.ValueKind == JsonValueKind.String
                ? v.GetString() ?? ""
                : "";
        }
        catch { return ""; }
    }

    /// <summary>풍선말에 한 줄로 붙일 사유 — 예외 메시지는 길고 겹겹이 싸여 있다.</summary>
    private static string Why(Exception e) => e switch
    {
        TaskCanceledException or OperationCanceledException => $"{_timeoutMs}ms 안에 응답이 없습니다",
        HttpRequestException h => h.InnerException?.Message ?? h.Message,
        _ => e.Message,
    };

    // ---------- 관측 기록 보관 ----------
    // 대시보드를 내렸다 올려도 <언제 바뀌었는지> 를 잃지 않는다. 잃으면 그 칸이 다시
    // <처음 본 값> 으로 돌아가 시각을 못 주고, 다음 배포 때까지 비어 있게 된다.
    private static void LoadSeen()
    {
        try
        {
            if (!File.Exists(_seenFile)) return;
            var d = JsonSerializer.Deserialize<Dictionary<string, Seen>>(File.ReadAllText(_seenFile));
            if (d is null) return;
            foreach (var (k, v) in d) SeenMap[k] = v;
        }
        catch { /* 깨졌으면 새로 쌓는다 */ }
    }

    private static string _seenSaved = "";
    private static void SaveSeen()
    {
        try
        {
            var json = JsonSerializer.Serialize(SeenMap.ToDictionary(k => k.Key, v => v.Value));
            if (json == _seenSaved) return; // 안 바뀌었으면 1분마다 디스크를 긁지 않는다
            Directory.CreateDirectory(Path.GetDirectoryName(_seenFile)!);
            File.WriteAllText(_seenFile, json);
            _seenSaved = json;
        }
        catch { /* 못 적어도 이번 세션 동안은 메모리에 남는다 */ }
    }

    // ============================================================================
    // 이미지를 구운 시각 (GitLab)
    // ============================================================================
    private static async Task RefreshImagesAsync(List<Target> targets)
    {
        if (string.IsNullOrWhiteSpace(_glToken))
        {
            _img = [];
            _imgAt = DateTimeOffset.UtcNow; // 토큰이 없으면 다시 물어도 같다 — 매번 치지 않는다
            return;
        }

        using var gate = new SemaphoreSlim(8, 8); // [빌드 상태] 화면과 같은 폭으로 보낸다
        var got = new (string Key, Dictionary<string, object?>? Val)[targets.Count];

        await Task.WhenAll(targets.Select(async (t, i) =>
        {
            if (t.GitPath is null) { got[i] = ($"{t.Id}:{t.Tier}", null); return; }
            await gate.WaitAsync();
            try { got[i] = ($"{t.Id}:{t.Tier}", await ImageOfAsync(t.GitPath)); }
            finally { gate.Release(); }
        }));

        var map = new Dictionary<string, Dictionary<string, object?>?>(StringComparer.OrdinalIgnoreCase);
        foreach (var (key, val) in got) map[key] = val;
        _img = map;
        _imgAt = DateTimeOffset.UtcNow;
    }

    private static async Task<Dictionary<string, object?>?> ImageOfAsync(string gitPath)
    {
        var enc = Uri.EscapeDataString(gitPath);
        // 넉넉히 받아 이름으로 고른다 — 잡이 늘어도 엉뚱한 것을 집지 않는다.
        var url = $"{_glBase}/api/v4/projects/{enc}/jobs?per_page=20";
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, url);
            req.Headers.Add("PRIVATE-TOKEN", _glToken);
            using var res = await Gl.SendAsync(req);
            if (!res.IsSuccessStatusCode)
                return new Dictionary<string, object?>
                {
                    ["state"] = "unknown",
                    ["label"] = (int)res.StatusCode switch
                    {
                        401 => "인증 실패",
                        403 => "권한 없음",
                        404 => "저장소 없음",
                        _ => $"HTTP {(int)res.StatusCode}",
                    },
                };

            using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
            if (doc.RootElement.ValueKind != JsonValueKind.Array) return null;

            // 이미지를 굽는 잡 중 <가장 최근 것> 과 <가장 최근 성공한 것> 을 함께 본다.
            // 마지막 빌드가 깨졌는데 초록으로 보이면 안 되고, 그렇다고 지금 떠 있는 이미지가
            // 어느 것인지도 알아야 한다 — 그 둘은 다른 질문이다.
            // 잡 이름이 저장소마다 다르다 — XU62 는 build:image 지만 CX90 은 "dev client deploy" 다.
            // ① 정확히 그 이름 → ② 이름에 image/build/deploy 가 든 것 순으로 양보한다.
            // 어느 잡에서 나온 시각인지는 그대로 돌려줘서 풍선말이 밝히게 한다 — 짐작했다는 사실을
            // 감추면 <이미지 생성 시각> 이라는 말이 거짓이 된다.
            JsonElement? latest = null, ok = null;
            for (var pass = 0; pass < 2 && latest is null && ok is null; pass++)
            {
                foreach (var j in doc.RootElement.EnumerateArray())
                {
                    var name = j.TryGetProperty("name", out var nm) ? nm.GetString() ?? "" : "";
                    var hit = pass == 0
                        ? string.Equals(name, _glJob, StringComparison.OrdinalIgnoreCase)
                        : Regex.IsMatch(name, "image|build|deploy", RegexOptions.IgnoreCase);
                    if (!hit) continue;
                    latest ??= j;
                    var st = j.TryGetProperty("status", out var s) ? s.GetString() : null;
                    if (ok is null && string.Equals(st, "success", StringComparison.OrdinalIgnoreCase)) ok = j;
                    if (latest is not null && ok is not null) break;
                }
            }
            if (latest is null && ok is null)
                return new Dictionary<string, object?>
                {
                    ["state"] = "none",
                    ["label"] = doc.RootElement.GetArrayLength() == 0 ? "빌드 없음" : "이미지 잡 없음",
                };

            var use = ok ?? latest!.Value;          // 시각·커밋은 <실제로 구워진 것> 기준이다
            var head = latest ?? use;               // 상태는 <마지막 시도> 기준이다

            string? S(JsonElement e, string k) =>
                e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

            var headStatus = S(head, "status") ?? "";
            var at = DateTimeOffset.TryParse(S(use, "finished_at"), out var dt)
                ? dt.ToUnixTimeMilliseconds() : (long?)null;

            string? sha = null, title = null;
            if (use.TryGetProperty("commit", out var c) && c.ValueKind == JsonValueKind.Object)
            {
                sha = c.TryGetProperty("short_id", out var si) ? si.GetString() : null;
                title = c.TryGetProperty("title", out var ti) ? ti.GetString() : null;
            }

            // ⚠️ <도는 중> 을 <실패> 와 같이 묶지 말 것. 사내 CI 가 한 번 돌면 열 몇 개가
            //    동시에 running/pending 이 되는데, 그때마다 작업공간 머리줄에 <빌드 실패 11> 이
            //    뜨면 아무도 그 표시를 안 믿게 된다.
            var good = string.Equals(headStatus, "success", StringComparison.OrdinalIgnoreCase);
            var busy = headStatus is "running" or "pending" or "created" or "waiting_for_resource" or "preparing";
            return new Dictionary<string, object?>
            {
                ["state"] = good ? "up" : busy ? "busy" : ok is not null ? "bad" : "down",
                ["label"] = good ? "성공" : headStatus switch
                {
                    "failed" => "빌드 실패",
                    "canceled" => "취소됨",
                    "running" => "빌드 중",
                    "pending" => "대기 중",
                    "created" => "대기 중",
                    "preparing" => "준비 중",
                    "waiting_for_resource" => "대기 중",
                    _ => headStatus.Length > 0 ? headStatus : "알 수 없음",
                },
                ["at"] = at,
                ["job"] = S(use, "name"),
                ["sha"] = sha,
                ["title"] = title,
                ["url"] = S(head, "web_url"),
                ["ref"] = S(use, "ref"),
                ["headStatus"] = headStatus,
            };
        }
        catch { return null; }
    }

    // ---------- 라우팅 ----------
    // GET 으로 둔다 — 두드려 보기만 하는 조회다. POST /api/dev/{action} 쪽에 끼우면
    // 거기 걸린 <기동·중지 권한> 에 묶여, 보기만 하는 사람은 새로고침도 못 하게 된다.
    public static void Map(WebApplication app)
    {
        app.MapGet("/api/dev/deploy", async (bool? force) =>
        {
            if (force == true) await SweepAsync(true);
            else Touch();
            return Results.Ok(Json());
        });
    }
}
