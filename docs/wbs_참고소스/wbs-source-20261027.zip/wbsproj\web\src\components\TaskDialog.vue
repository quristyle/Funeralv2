<script setup>
import { computed, onMounted, ref } from 'vue'
import { useDragMove } from '../dragmove'
import { api } from '../api'
import RichEditor from './RichEditor.vue'

// 한 화면(activity_id)의 일감 목록 관리 — 추가 / 수정 / 완료 / 삭제
const props = defineProps({
  row: { type: Object, required: true }, // { activity_id, systemcode, system_nm, menu_nm }
  // 특정 상황에서 열 때 입력을 미리 채워 준다 — 예: 재확인요청 체크 시 { div:'확인', reason:'…' }
  prefill: { type: Object, default: null },
})
const emit = defineEmits(['close', 'changed'])

// 머리글을 잡아 창을 옮긴다 (표의 값을 확인하려고 잠깐 치워 둘 때 쓴다)
const drag = useDragMove()

const DIVS = ['개발', '확인', '문의', '버그', '기타']
const memoEd = ref(null)   // 추가용 에디터

// 메모는 HTML 로 보관한다 — 태그만 남은 경우도 빈 값으로 본다 (이미지는 내용으로 인정)
function isBlank(html) {
  if (!html) return true
  if (/<img/i.test(html)) return false
  return !html.replace(/<[^>]*>/g, '').replace(/&nbsp;/gi, ' ').trim()
}

const list = ref([])
const loading = ref(false)
const err = ref('')
const busy = ref(null) // 처리 중인 task_id

const newDiv = ref('개발')
const newMemo = ref('')
const adding = ref(false)

const editId = ref(null)
const draft = ref({ task_div: '', memo: '' })

const doneCnt = computed(() => list.value.filter((t) => t.done_yn === 'o').length)

// ---------- 정렬 / 필터 ----------
// 기본은 수정일 내림차순 — 방금 손댄 일감이 맨 위로 온다.
const COLS = [
  { key: 'done_yn', label: '완료', w: '46px' },
  { key: 'task_div', label: '구분', w: '84px' },
  { key: 'memo', label: '메모', w: '' },
  { key: 'updated_at', label: '수정일', w: '116px' },
]
const sortKey = ref('updated_at')
const sortDir = ref('desc')
// 창을 열면 <미완료만> 보인다 — 일감 창을 여는 까닭은 대개 남은 일을 보려는 것이다.
// 완료된 것까지 보려면 완료 필터를 '전체' 로 바꾸거나 필터 해제를 누른다.
const NO_FILTER = { done_yn: '', task_div: '', memo: '', updated_at: '' }
const f = ref({ ...NO_FILTER, done_yn: 'x' })

/** 메모는 HTML 이므로 검색·정렬에는 태그를 벗긴 글자만 쓴다 */
const plain = (h) =>
  (h ?? '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/\s+/g, ' ')
    .trim()

function toggleSort(key) {
  if (sortKey.value === key) {
    sortDir.value = sortDir.value === 'asc' ? 'desc' : 'asc'
  } else {
    sortKey.value = key
    // 날짜는 최신부터, 나머지는 오름차순이 자연스럽다
    sortDir.value = key === 'updated_at' ? 'desc' : 'asc'
  }
}

const divOptions = computed(() => [...new Set(list.value.map((t) => t.task_div || ''))].sort())
const hasFilter = computed(() => Object.values(f.value).some((v) => v !== ''))
function clearFilters() {
  f.value = { ...NO_FILTER }
}

function cellVal(t, key) {
  if (key === 'done_yn') return t.done_yn === 'o' ? 1 : 0
  if (key === 'memo') return plain(t.memo).toLowerCase()
  return (t[key] ?? '').toString().toLowerCase()
}

const viewList = computed(() => {
  const q = f.value
  const rows = list.value.filter((t) => {
    if (q.done_yn === 'o' && t.done_yn !== 'o') return false
    if (q.done_yn === 'x' && t.done_yn === 'o') return false
    if (q.task_div === '__none__' && (t.task_div ?? '') !== '') return false
    if (q.task_div && q.task_div !== '__none__' && (t.task_div ?? '') !== q.task_div) return false
    if (q.memo && !plain(t.memo).toLowerCase().includes(q.memo.trim().toLowerCase())) return false
    if (q.updated_at && !(t.updated_at ?? '').includes(q.updated_at.trim())) return false
    return true
  })
  const k = sortKey.value
  const dir = sortDir.value === 'asc' ? 1 : -1
  // 같은 값이면 원래 순서를 유지 (안정 정렬)
  return rows
    .map((t, i) => [t, i])
    .sort((a, b) => {
      const x = cellVal(a[0], k)
      const y = cellVal(b[0], k)
      if (x < y) return -dir
      if (x > y) return dir
      return a[1] - b[1]
    })
    .map((p) => p[0])
})

async function load() {
  loading.value = true
  err.value = ''
  try {
    list.value = await api.tasks(props.row.activity_id)
  } catch (e) {
    err.value = e.message
  } finally {
    loading.value = false
  }
}

async function add() {
  if (isBlank(newMemo.value)) {
    err.value = '메모를 입력하세요.'
    return
  }
  adding.value = true
  try {
    await api.taskCreate({
      activity_id: props.row.activity_id,
      task_div: newDiv.value,
      memo: newMemo.value,
    })
    newMemo.value = ''
    await load()
    emit('changed')
  } catch (e) {
    err.value = e.message
  } finally {
    adding.value = false
  }
}

async function toggleDone(t) {
  busy.value = t.task_id
  try {
    await api.taskUpdate(t.task_id, { done_yn: t.done_yn === 'o' ? '' : 'o' })
    await load()
    emit('changed')
  } catch (e) {
    err.value = e.message
  } finally {
    busy.value = null
  }
}

function startEdit(t) {
  editId.value = t.task_id
  draft.value = { task_div: t.task_div ?? '', memo: t.memo ?? '' }
}
async function saveEdit(t) {
  if (isBlank(draft.value.memo)) {
    err.value = '메모를 입력하세요.'
    return
  }
  busy.value = t.task_id
  try {
    await api.taskUpdate(t.task_id, { task_div: draft.value.task_div, memo: draft.value.memo })
    editId.value = null
    await load()
    emit('changed')
  } catch (e) {
    err.value = e.message
  } finally {
    busy.value = null
  }
}

async function remove(t) {
  if (!confirm(`일감을 삭제할까요?\n\n${t.task_div ? '[' + t.task_div + '] ' : ''}${t.memo ?? ''}`)) return
  busy.value = t.task_id
  try {
    await api.taskDelete(t.task_id)
    await load()
    emit('changed')
  } catch (e) {
    err.value = e.message
  } finally {
    busy.value = null
  }
}

/** 메모 안의 이미지를 클릭하면 원본을 새 탭으로 연다 */
function onMemoClick(e) {
  if (e.target.tagName === 'IMG' && e.target.src) window.open(e.target.src, '_blank', 'noopener')
}

onMounted(async () => {
  if (props.prefill) {
    newDiv.value = props.prefill.div ?? '개발'
    newMemo.value = props.prefill.memo ?? ''
  }
  await load()
  // 사유를 바로 적을 수 있게 입력칸에 커서를 둔다
  if (props.prefill) setTimeout(() => memoEd.value?.focus(), 60)
})
</script>

<template>
  <!-- 배경 클릭 / Esc 로 닫기 -->
  <div class="mask" @keydown.esc="emit('close')" tabindex="-1">
    <div class="dlg" :class="{ moving: drag.moving.value }" :style="drag.style.value">
      <!-- 머리글을 잡으면 창이 따라온다. 버튼을 누른 것은 끌기로 보지 않는다. -->
      <header class="grab" @pointerdown="drag.start($event)">
        <span class="hgrip" title="여기를 잡아 창을 옮깁니다">⠿</span>
        <div class="ttl">
          <strong>일감</strong>
          <span class="menu">{{ row.systemcode }} · {{ row.menu_nm }}</span>
          <span class="aid">{{ row.activity_id }}</span>
        </div>
        <span class="cnt">
          {{ doneCnt }} / {{ list.length }} 완료<span v-if="hasFilter" class="fon">표시 {{ viewList.length }}건</span>
        </span>
        <button v-if="drag.moved()" title="창을 원래 자리로" @click="drag.reset()">⌖</button>
        <button class="x" title="닫기 (Esc)" @click="emit('close')">✕</button>
      </header>

      <p v-if="err" class="err">{{ err }}</p>
      <p v-if="prefill?.reason" class="why">{{ prefill.reason }}</p>

      <!-- 추가 -->
      <div class="addbox">
        <div class="addhead">
          <select v-model="newDiv" title="구분">
            <option v-for="d in DIVS" :key="d" :value="d">{{ d }}</option>
          </select>
          <span class="tip">
            서식 · 링크 사용 가능 · 이미지는 <b>Ctrl+V</b> 로 붙여넣기 · <b>Ctrl+Enter</b> 로 추가
          </span>
          <button :disabled="adding" @click="add">{{ adding ? '추가 중…' : '+ 추가' }}</button>
        </div>
        <RichEditor
          ref="memoEd"
          v-model="newMemo"
          compact
          :placeholder="prefill?.placeholder ?? '일감 내용을 입력하세요'"
          @submit="add"
        />
      </div>

      <!-- 목록 -->
      <div class="listbox">
        <table>
          <thead>
            <tr>
              <th
                v-for="c in COLS" :key="c.key"
                class="sortable" :class="{ on: sortKey === c.key }"
                :style="c.w ? { width: c.w } : null"
                :title="`${c.label} 정렬`"
                @click="toggleSort(c.key)"
              >
                {{ c.label }}<span class="arw">{{ sortKey === c.key ? (sortDir === 'asc' ? '▲' : '▼') : '' }}</span>
              </th>
              <th style="width: 96px">작업</th>
            </tr>
            <tr class="frow">
              <th>
                <select v-model="f.done_yn" title="완료 여부">
                  <option value="">전체</option>
                  <option value="o">완료</option>
                  <option value="x">미완료</option>
                </select>
              </th>
              <th>
                <select v-model="f.task_div" title="구분">
                  <option value="">전체</option>
                  <option v-for="d in divOptions" :key="d || '__none__'" :value="d || '__none__'">
                    {{ d || '(없음)' }}
                  </option>
                </select>
              </th>
              <th><input v-model="f.memo" type="search" placeholder="내용 검색" /></th>
              <th><input v-model="f.updated_at" type="search" placeholder="2026-08" /></th>
              <th class="ctr">
                <button v-if="hasFilter" class="clr" title="필터 해제" @click="clearFilters">해제</button>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="t in viewList" :key="t.task_id" :class="{ done: t.done_yn === 'o', busy: busy === t.task_id }">
              <td class="ctr">
                <input type="checkbox" :checked="t.done_yn === 'o'" title="완료 처리" @change="toggleDone(t)" />
              </td>

              <template v-if="editId === t.task_id">
                <td>
                  <select v-model="draft.task_div">
                    <option value="">(없음)</option>
                    <option v-for="d in DIVS" :key="d" :value="d">{{ d }}</option>
                  </select>
                </td>
                <td>
                  <RichEditor v-model="draft.memo" compact placeholder="내용을 입력하세요" @submit="saveEdit(t)" />
                </td>
                <td class="muted">{{ t.updated_at }}</td>
                <td class="acts">
                  <button @click="saveEdit(t)">저장</button>
                  <button @click="editId = null">취소</button>
                </td>
              </template>

              <template v-else>
                <td><span v-if="t.task_div" class="div">{{ t.task_div }}</span></td>
                <td class="memo" @click="onMemoClick" v-html="t.memo"></td>
                <td class="muted">{{ t.updated_at }}</td>
                <td class="acts">
                  <button @click="startEdit(t)">수정</button>
                  <button class="del" @click="remove(t)">삭제</button>
                </td>
              </template>
            </tr>

            <tr v-if="!viewList.length && !loading">
              <td colspan="5" class="muted ctr" style="padding: 22px">
                <template v-if="list.length">
                  필터에 맞는 일감이 없습니다.
                  <button class="clr" @click="clearFilters">필터 해제</button>
                </template>
                <template v-else>등록된 일감이 없습니다. 위에서 추가하세요.</template>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<style scoped>
.mask {
  position: fixed;
  inset: 0;
  background: var(--overlay);
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 60px 20px;
  z-index: 100;
}
.dlg {
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 10px;
  width: min(1020px, 100%);
  max-height: calc(100vh - 120px);
  display: flex;
  flex-direction: column;
  box-shadow: 0 8px 28px var(--shadow);
}

header {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 14px;
  border-bottom: 1px solid var(--line);
}
/* 머리글은 창을 옮기는 손잡이다 */
header.grab { cursor: move; user-select: none; touch-action: none; }
.dlg.moving { box-shadow: 0 14px 40px var(--shadow-2); }
.hgrip { color: var(--muted-3); font-size: 13px; flex: none; }
header .ttl { display: flex; align-items: baseline; gap: 8px; flex: 1; min-width: 0; }
header .menu { font-size: 12.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
header .aid { font-size: 11px; color: var(--muted); font-variant-numeric: tabular-nums; }
header .cnt { font-size: 11.5px; color: var(--done); font-weight: 600; white-space: nowrap; }
header .x { border: 0; background: transparent; font-size: 14px; color: var(--muted); padding: 2px 6px; }
header .x:hover { color: var(--text); }

/* 왜 이 창이 열렸는지 알려주는 안내 (재확인요청 등) */
.why {
  margin: 10px 14px 0;
  background: var(--warn-soft);
  border: 1px solid var(--warn-line);
  color: var(--warn);
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 12px;
}

.err {
  margin: 10px 14px 0;
  background: var(--danger-soft);
  border: 1px solid var(--danger-line);
  color: var(--danger-text);
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 12px;
}

.addbox { padding: 12px 14px; border-bottom: 1px solid var(--line); }
.addhead { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.addhead select { width: 88px; }
.addhead .tip { flex: 1; font-size: 11px; color: var(--muted); }
.addhead .tip b { color: var(--text); }
/* 작성 영역은 넉넉하게 — 아래 모서리를 끌어 더 키울 수 있다 */
.addbox :deep(.body) { min-height: 170px; max-height: 46vh; resize: vertical; overflow: auto; }
/* 목록에서 수정할 때도 여러 줄을 편하게 */
.listbox :deep(.body) { min-height: 120px; max-height: 40vh; resize: vertical; overflow: auto; }
.addbox :deep(.src) { min-height: 170px; }

.listbox { overflow: auto; padding: 0 14px 14px; }
.listbox table { width: 100%; }
.listbox thead th { position: sticky; background: var(--panel); z-index: 1; }
.listbox thead tr:first-child th { top: 0; height: 28px; box-shadow: inset 0 -1px 0 var(--line); }
.listbox thead tr.frow th { top: 28px; box-shadow: inset 0 -1px 0 var(--line); padding: 3px 6px; }
.listbox thead tr.frow select, .listbox thead tr.frow input { width: 100%; font-size: 11.5px; padding: 1px 4px; }
.listbox th.sortable { cursor: pointer; user-select: none; white-space: nowrap; }
.listbox th.sortable:hover { color: var(--accent); }
.listbox th.on { color: var(--accent); }
.listbox th .arw { font-size: 9px; margin-left: 3px; }
.clr { padding: 1px 6px; font-size: 11px; }
header .fon {
  margin-left: 6px;
  background: var(--accent-soft);
  color: var(--accent);
  border-radius: 9px;
  padding: 1px 7px;
  font-weight: 600;
}

.listbox td { padding: 5px 8px; vertical-align: top; }
.listbox td.ctr, .listbox td.muted, .listbox td.acts { padding-top: 8px; }
.listbox td input[type='text'], .listbox td select { width: 100%; }
.ctr { text-align: center; }
.memo { word-break: break-word; white-space: pre-wrap; }
.memo :deep(img) {
  max-width: 100%;
  max-height: 180px;
  border: 1px solid var(--line);
  border-radius: 4px;
  margin: 3px 0;
  display: block;
  cursor: zoom-in;
}
.memo :deep(p) { margin: 3px 0; }
.memo :deep(ul), .memo :deep(ol) { margin: 3px 0; padding-left: 20px; }
.memo :deep(a) { color: var(--accent); }
.memo :deep(pre) {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 4px;
  padding: 6px 8px;
  overflow-x: auto;
  font-family: Consolas, 'Courier New', monospace;
  font-size: 12px;
}
.div {
  background: var(--accent-soft);
  color: var(--accent);
  border-radius: 9px;
  padding: 1px 7px;
  font-size: 11px;
  font-weight: 600;
  white-space: nowrap;
}
tr.done .memo { color: var(--muted); text-decoration: line-through; }
tr.done .div { background: var(--done-soft); color: var(--done); }
tr.busy { opacity: 0.45; }
.acts { white-space: nowrap; display: flex; gap: 4px; }
.acts button { padding: 2px 8px; }
.del:hover { border-color: var(--danger-2); color: var(--danger-2); }
input[type='checkbox'] { cursor: pointer; accent-color: var(--done); }
</style>
