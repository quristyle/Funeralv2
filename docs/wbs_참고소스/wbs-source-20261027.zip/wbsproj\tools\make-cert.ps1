﻿# WBS 대시보드 HTTPS 인증서 만들기 (서버 PC 에서 1회, 관리자 권한)
#
#   powershell -ExecutionPolicy Bypass -File tools\make-cert.ps1
#
# 왜 필요한가:
#   크롬은 <보안 출처>(https)에서만 주소창에 설치 아이콘을 띄운다.
#   도메인이 없어도 IP 를 SAN 에 넣은 자체서명 인증서면 된다.
#   각 PC 는 이 인증서를 <신뢰할 수 있는 루트>에 넣어야 경고 없이 열린다
#   (web/public/install-cert.cmd 가 그 일을 한다).
#
# 만들어지는 것:
#   api/cert/wbs.pfx    서버가 쓰는 인증서 + 개인키  ← 서버 밖으로 내보내지 말 것
#   api/cert/wbs.cer    PC 에 신뢰 등록할 공개 인증서 (배포용)
param(
  [string]$IpAddress = '10.13.45.51',
  [string]$Password  = 'wbs',
  [int]   $Years     = 5
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$out  = Join-Path $root 'api\cert'
New-Item -ItemType Directory -Force -Path $out | Out-Null

$pfx = Join-Path $out 'wbs.pfx'
$cer = Join-Path $out 'wbs.cer'

Write-Host ''
Write-Host "  IP        : $IpAddress"
Write-Host "  유효기간  : $Years 년"
Write-Host "  내보낼 곳 : $out"
Write-Host ''

# SAN 에 IP 와 localhost 를 모두 넣는다. 크롬은 CN 을 보지 않고 SAN 만 본다.
$san = "2.5.29.17={text}IPAddress=$IpAddress&IPAddress=127.0.0.1&DNS=localhost"

$cert = New-SelfSignedCertificate `
  -Subject "CN=WBS Dashboard ($IpAddress)" `
  -Type SSLServerAuthentication `
  -TextExtension @($san) `
  -KeyAlgorithm RSA -KeyLength 2048 `
  -HashAlgorithm SHA256 `
  -NotAfter (Get-Date).AddYears($Years) `
  -CertStoreLocation 'Cert:\LocalMachine\My' `
  -FriendlyName 'WBS Dashboard'

Write-Host "  지문(thumbprint) : $($cert.Thumbprint)"

$pw = ConvertTo-SecureString -String $Password -Force -AsPlainText
Export-PfxCertificate -Cert $cert -FilePath $pfx -Password $pw | Out-Null
Export-Certificate    -Cert $cert -FilePath $cer -Type CERT    | Out-Null

# 배포용 공개 인증서는 화면과 함께 내려받을 수 있도록 wwwroot 에도 둔다
$pub = Join-Path $root 'web\public\wbs.cer'
Copy-Item $cer $pub -Force
$www = Join-Path $root 'api\wwwroot\wbs.cer'
if (Test-Path (Split-Path $www)) { Copy-Item $cer $www -Force }

# 서버 PC 자신도 신뢰하도록 등록해 둔다 (여기서 바로 확인할 수 있게)
Import-Certificate -FilePath $cer -CertStoreLocation 'Cert:\LocalMachine\Root' | Out-Null

Write-Host ''
Write-Host '  만들었습니다:'
Write-Host "    $pfx  (서버용 · 밖으로 내보내지 말 것)"
Write-Host "    $cer  (PC 배포용)"
Write-Host ''
Write-Host '  다음 순서:'
Write-Host '    1) API 를 다시 띄운다 (start.cmd 또는 serve.cmd)'
Write-Host '       api/cert/wbs.pfx 가 있으면 https 5443 을 함께 연다'
Write-Host '    2) 방화벽에 5443 을 연다 (관리자 PowerShell):'
Write-Host '       netsh advfirewall firewall add rule name="wbsproj-5443" dir=in action=allow protocol=TCP localport=5443 profile=domain,private'
Write-Host '    3) 각 PC 에서 install-cert.cmd 를 관리자 권한으로 실행한다'
Write-Host ('       http://' + $IpAddress + ':5080/install-cert.cmd')
Write-Host ''
