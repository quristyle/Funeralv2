@echo off
rem WBS 대시보드(api/DevRun.cs)가 만든 기동 스크립트 — 기동할 때마다 덮어쓴다.
rem 손으로 실행해도 된다. 그때는 대시보드에 <외부> 로 보인다.
chcp 65001>nul
cd /d "C:\projs\G6X0\XU62\Material Management\PMM005\pmm005-fe"
set "TEMP=C:\devtmp"
set "TMP=C:\devtmp"
set "PORT=3205"
call pnpm dev >> "D:\수빅자재\wbsproj\api\data\devlogs\pmm005-fe.log" 2>&1
echo [dev-exit] %ERRORLEVEL%>> "D:\수빅자재\wbsproj\api\data\devlogs\pmm005-fe.log"
