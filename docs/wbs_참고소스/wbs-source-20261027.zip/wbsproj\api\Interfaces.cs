using System.Text.Json;

namespace WbsApi;

/// <summary>
/// EAI 인터페이스 카탈로그 API.
/// 조회는 뷰(v_if_*), 편집은 원본 테이블(if_*)을 쓴다.
/// updated_at 은 DB 트리거가 갱신하므로 API 에서 보내지 않는다.
/// </summary>
public static class Interfaces
{
    // 수정 허용 컬럼 (식별자는 바인딩 불가라 화이트리스트로 처리)
    private static readonly string[] MasterCols =
    [
        "if_cd", "if_nm", "if_desc", "direction_cd", "src_system_id", "tgt_system_id",
        "domain_cd", "trigger_cd", "cycle_cd", "status_cd", "owner_nm", "owner_bp_id",
        "plan_sdt", "plan_edt", "open_dt", "remark", "ext", "sort_order", "use_yn",
    ];
    private static readonly string[] StepCols =
    [
        "step_no", "step_nm", "step_type_cd", "system_id", "object_owner", "object_nm",
        "object_type", "step_desc", "params", "ext", "use_yn",
    ];
    private static readonly string[] NoteCols =
    [
        "step_id", "note_type_cd", "title", "content", "writer_nm", "note_dt",
        "done_yn", "sort_order", "ext",
    ];

    // 컬럼별 캐스팅 — 숫자/날짜/jsonb 는 text 로 넘기면 안 된다
    private static string Cast(string col) => col switch
    {
        "if_id" or "src_system_id" or "tgt_system_id" or "system_id" or "step_id"
            or "attr_def_id" or "step_no" or "sort_order" => "::int",
        "plan_sdt" or "plan_edt" or "open_dt" or "note_dt" => "::date",
        "params" or "ext" => "::jsonb",
        _ => "::text",
    };

    /// <summary>JSON 본문에서 허용 컬럼만 뽑아 (컬럼, 값) 목록으로</summary>
    private static List<(string Col, object? Val)> Pick(JsonElement body, string[] allow)
    {
        var set = new HashSet<string>(allow, StringComparer.OrdinalIgnoreCase);
        var list = new List<(string, object?)>();
        foreach (var p in body.EnumerateObject())
        {
            if (!set.Contains(p.Name)) continue;
            object? v = p.Value.ValueKind switch
            {
                JsonValueKind.Null => null,
                JsonValueKind.True => "Y",
                JsonValueKind.False => "N",
                JsonValueKind.Number => p.Value.GetRawText(),
                JsonValueKind.Object or JsonValueKind.Array => p.Value.GetRawText(),
                _ => p.Value.GetString(),
            };
            if (v is string s && string.IsNullOrWhiteSpace(s)) v = null;
            list.Add((p.Name.ToLowerInvariant(), v));
        }
        return list;
    }

    public static void Map(WebApplication app)
    {
        // ---------- 공통코드 · 시스템 ----------
        app.MapGet("/api/if/codes", async (PgPool db, string? grp) =>
            Results.Ok(await db.QueryAsync("""
                select code_grp, code, code_nm, code_desc, sort_order
                  from public.if_code
                 where use_yn = 'Y'
                   and ($1::text is null or code_grp = $1)
                 order by code_grp, sort_order, code
                """, [string.IsNullOrWhiteSpace(grp) ? null : grp])));

        app.MapGet("/api/if/systems", async (PgPool db) =>
            Results.Ok(await db.QueryAsync("""
                select system_id, system_cd, system_nm, system_kind, host, port,
                       db_nm, schema_nm, system_desc, sort_order
                  from public.if_system
                 where use_yn = 'Y'
                 order by sort_order, system_cd
                """)));

        // ---------- 목록 ----------
        app.MapGet("/api/if", async (PgPool db, string? status, string? domain, string? q, string? useYn) =>
            Results.Ok(await db.QueryAsync("""
                select m.*, f.flow
                  from public.v_if_master m
                  left join public.v_if_flow f on f.if_id = m.if_id
                 where ($1::text is null or m.status_cd = $1)
                   and ($2::text is null or m.domain_cd = $2)
                   and ($3::text is null or m.if_cd ilike '%' || $3 || '%' or m.if_nm ilike '%' || $3 || '%')
                   and ($4::text is null or m.use_yn = $4)
                 order by m.sort_order, m.if_cd
                """, [Nz(status), Nz(domain), Nz(q), Nz(useYn)])));

        // ---------- 상세 (원본 + 단계 + 추가항목 + 메모) ----------
        app.MapGet("/api/if/{ifId:int}", async (PgPool db, int ifId) =>
        {
            var master = await db.QueryAsync("""
                select m.*, m.plan_sdt::text as plan_sdt, m.plan_edt::text as plan_edt,
                       m.open_dt::text as open_dt,
                       to_char(m.updated_at,'YYYY-MM-DD HH24:MI') as updated_at_txt
                  from public.if_master m where m.if_id = $1::int
                """, [ifId]);
            if (master.Count == 0) return Results.NotFound(new { error = "대상 없음", ifId });

            return Results.Ok(new
            {
                master = master[0],
                steps = await StepsAsync(db, ifId),
                attrs = await AttrsAsync(db, ifId),
                notes = await NotesAsync(db, ifId),
                flow = (await db.QueryAsync("select flow from public.v_if_flow where if_id = $1::int", [ifId]))
                       .FirstOrDefault()?["flow"],
            });
        });

        // ---------- 마스터 CRUD ----------
        app.MapPost("/api/if", async (PgPool db, JsonElement body) =>
        {
            var vals = Pick(body, MasterCols);
            var cd = vals.FirstOrDefault(v => v.Col == "if_cd").Val as string;
            var nm = vals.FirstOrDefault(v => v.Col == "if_nm").Val as string;
            if (string.IsNullOrWhiteSpace(cd) || string.IsNullOrWhiteSpace(nm))
                return Results.BadRequest(new { error = "if_cd 와 if_nm 은 필수입니다." });

            vals.Add(("created_by", Who(body)));
            vals.Add(("updated_by", Who(body)));
            var cols = string.Join(", ", vals.Select(v => v.Col));
            var ph = string.Join(", ", vals.Select((v, i) => $"${i + 1}{Cast(v.Col)}"));
            try
            {
                var r = await db.QueryAsync(
                    $"insert into public.if_master ({cols}) values ({ph}) returning if_id",
                    [.. vals.Select(v => v.Val)]);
                return Results.Ok(new { if_id = r[0]["if_id"] });
            }
            catch (PgException e) when (e.Message.Contains("uq_if_master_cd") || e.Message.Contains("중복"))
            {
                return Results.BadRequest(new { error = $"이미 있는 인터페이스 코드입니다: {cd}" });
            }
        });

        app.MapPut("/api/if/{ifId:int}", async (PgPool db, int ifId, JsonElement body) =>
        {
            var vals = Pick(body, MasterCols);
            if (vals.Count == 0) return Results.BadRequest(new { error = "수정할 항목이 없습니다." });
            vals.Add(("updated_by", Who(body)));

            var sets = string.Join(", ", vals.Select((v, i) => $"{v.Col} = ${i + 1}{Cast(v.Col)}"));
            var args = vals.Select(v => v.Val).Append((object?)ifId).ToArray();
            var n = await db.ExecuteAsync(
                $"update public.if_master set {sets} where if_id = ${args.Length}::int", args);
            return n > 0 ? Results.Ok(new { updated = n }) : Results.NotFound(new { error = "대상 없음", ifId });
        });

        app.MapDelete("/api/if/{ifId:int}", async (PgPool db, int ifId) =>
        {
            var n = await db.ExecuteAsync("delete from public.if_master where if_id = $1::int", [ifId]);
            return n > 0 ? Results.Ok(new { deleted = n }) : Results.NotFound(new { error = "대상 없음", ifId });
        });

        // ---------- 처리 단계 ----------
        app.MapGet("/api/if/{ifId:int}/steps", async (PgPool db, int ifId) =>
            Results.Ok(await StepsAsync(db, ifId)));

        app.MapPost("/api/if/{ifId:int}/steps", async (PgPool db, int ifId, JsonElement body) =>
        {
            var vals = Pick(body, StepCols);
            if (!vals.Any(v => v.Col == "step_no"))
                vals.Add(("step_no",
                    (await db.QueryAsync(
                        "select coalesce(max(step_no),0) + 1 as n from public.if_step where if_id = $1::int",
                        [ifId]))[0]["n"]?.ToString()));
            vals.Insert(0, ("if_id", ifId.ToString()));
            vals.Add(("created_by", Who(body)));
            vals.Add(("updated_by", Who(body)));

            var cols = string.Join(", ", vals.Select(v => v.Col));
            var ph = string.Join(", ", vals.Select((v, i) => $"${i + 1}{Cast(v.Col)}"));
            var r = await db.QueryAsync(
                $"insert into public.if_step ({cols}) values ({ph}) returning step_id",
                [.. vals.Select(v => v.Val)]);
            return Results.Ok(new { step_id = r[0]["step_id"] });
        });

        app.MapPut("/api/if/steps/{stepId:int}", async (PgPool db, int stepId, JsonElement body) =>
        {
            var vals = Pick(body, StepCols);
            if (vals.Count == 0) return Results.BadRequest(new { error = "수정할 항목이 없습니다." });
            vals.Add(("updated_by", Who(body)));
            var sets = string.Join(", ", vals.Select((v, i) => $"{v.Col} = ${i + 1}{Cast(v.Col)}"));
            var args = vals.Select(v => v.Val).Append((object?)stepId).ToArray();
            var n = await db.ExecuteAsync(
                $"update public.if_step set {sets} where step_id = ${args.Length}::int", args);
            return n > 0 ? Results.Ok(new { updated = n }) : Results.NotFound(new { error = "대상 없음", stepId });
        });

        app.MapDelete("/api/if/steps/{stepId:int}", async (PgPool db, int stepId) =>
        {
            var n = await db.ExecuteAsync("delete from public.if_step where step_id = $1::int", [stepId]);
            return n > 0 ? Results.Ok(new { deleted = n }) : Results.NotFound(new { error = "대상 없음", stepId });
        });

        // step_no 일괄 재배치 — UNIQUE(if_id, step_no) 충돌을 피해 음수로 옮겼다가 되돌린다
        app.MapPut("/api/if/{ifId:int}/steps/reorder", async (PgPool db, int ifId, JsonElement body) =>
        {
            if (!body.TryGetProperty("order", out var arr) || arr.ValueKind != JsonValueKind.Array)
                return Results.BadRequest(new { error = "order 배열이 필요합니다. 예: {\"order\":[12,10,11]}" });

            var ids = arr.EnumerateArray()
                .Where(x => x.ValueKind == JsonValueKind.Number)
                .Select(x => x.GetInt32())
                .ToList();
            if (ids.Count == 0) return Results.BadRequest(new { error = "order 가 비어 있습니다." });

            return await db.UseAsync<IResult>(async c =>
            {
                await c.QueryAsync("begin");
                try
                {
                    // 1단계: 전부 음수로 대피
                    await c.QueryAsync(
                        "update public.if_step set step_no = -step_no where if_id = $1::int", [ifId]);
                    // 2단계: 넘겨받은 순서대로 1..N 부여
                    for (var i = 0; i < ids.Count; i++)
                        await c.QueryAsync(
                            "update public.if_step set step_no = $1::int where step_id = $2::int and if_id = $3::int",
                            [i + 1, ids[i], ifId]);
                    // 3단계: 목록에 없던 단계는 뒤로 밀어 정리
                    await c.QueryAsync("""
                        update public.if_step s set step_no = t.rn
                          from (select step_id, $2::int + row_number() over (order by -step_no) as rn
                                  from public.if_step where if_id = $1::int and step_no < 0) t
                         where s.step_id = t.step_id
                        """, [ifId, ids.Count]);
                    await c.QueryAsync("commit");
                    return Results.Ok(new { reordered = ids.Count });
                }
                catch
                {
                    await c.QueryAsync("rollback");
                    throw;
                }
            });
        });

        // ---------- 메모 / 이슈 ----------
        app.MapGet("/api/if/{ifId:int}/notes", async (PgPool db, int ifId) =>
            Results.Ok(await NotesAsync(db, ifId)));

        app.MapPost("/api/if/{ifId:int}/notes", async (PgPool db, int ifId, JsonElement body) =>
        {
            var vals = Pick(body, NoteCols);
            vals.Insert(0, ("if_id", ifId.ToString()));
            vals.Add(("created_by", Who(body)));
            vals.Add(("updated_by", Who(body)));
            var cols = string.Join(", ", vals.Select(v => v.Col));
            var ph = string.Join(", ", vals.Select((v, i) => $"${i + 1}{Cast(v.Col)}"));
            var r = await db.QueryAsync(
                $"insert into public.if_note ({cols}) values ({ph}) returning note_id",
                [.. vals.Select(v => v.Val)]);
            return Results.Ok(new { note_id = r[0]["note_id"] });
        });

        app.MapPut("/api/if/notes/{noteId:int}", async (PgPool db, int noteId, JsonElement body) =>
        {
            var vals = Pick(body, NoteCols);
            if (vals.Count == 0) return Results.BadRequest(new { error = "수정할 항목이 없습니다." });
            vals.Add(("updated_by", Who(body)));
            var sets = string.Join(", ", vals.Select((v, i) => $"{v.Col} = ${i + 1}{Cast(v.Col)}"));
            var args = vals.Select(v => v.Val).Append((object?)noteId).ToArray();
            var n = await db.ExecuteAsync(
                $"update public.if_note set {sets} where note_id = ${args.Length}::int", args);
            return n > 0 ? Results.Ok(new { updated = n }) : Results.NotFound(new { error = "대상 없음", noteId });
        });

        app.MapDelete("/api/if/notes/{noteId:int}", async (PgPool db, int noteId) =>
        {
            var n = await db.ExecuteAsync("delete from public.if_note where note_id = $1::int", [noteId]);
            return n > 0 ? Results.Ok(new { deleted = n }) : Results.NotFound(new { error = "대상 없음", noteId });
        });

        // ---------- 추가 관리항목 ----------
        app.MapGet("/api/if/{ifId:int}/attrs", async (PgPool db, int ifId) =>
            Results.Ok(await AttrsAsync(db, ifId)));

        app.MapPut("/api/if/{ifId:int}/attrs", async (PgPool db, int ifId, JsonElement body) =>
        {
            if (!body.TryGetProperty("values", out var vals) || vals.ValueKind != JsonValueKind.Object)
                return Results.BadRequest(new { error = "values 객체가 필요합니다. 예: {\"values\":{\"12\":\"abc\"}}" });

            var who = Who(body);
            var n = 0;
            foreach (var p in vals.EnumerateObject())
            {
                if (!int.TryParse(p.Name, out var defId)) continue;
                var v = p.Value.ValueKind switch
                {
                    JsonValueKind.Null => null,
                    JsonValueKind.True => "Y",
                    JsonValueKind.False => "N",
                    JsonValueKind.Number => p.Value.GetRawText(),
                    JsonValueKind.Object or JsonValueKind.Array => p.Value.GetRawText(),
                    _ => p.Value.GetString(),
                };
                n += await db.ExecuteAsync("""
                    insert into public.if_attr (if_id, attr_def_id, attr_val, created_by, updated_by)
                    values ($1::int, $2::int, $3::text, $4::text, $4::text)
                    on conflict (if_id, attr_def_id)
                    do update set attr_val = excluded.attr_val, updated_by = excluded.updated_by
                    """, [ifId, defId, v, who]);
            }
            return Results.Ok(new { saved = n });
        });
    }

    // ---------- 조회 도우미 ----------

    private static Task<List<Dictionary<string, object?>>> StepsAsync(PgPool db, int ifId) =>
        db.QueryAsync("""
            select step_id, if_id, step_no, step_nm, step_type_cd, step_type_nm, system_nm,
                   object_owner, object_nm, object_full_nm, object_type, step_desc,
                   params::text as params, ext::text as ext, use_yn,
                   to_char(updated_at,'YYYY-MM-DD HH24:MI') as updated_at_txt
              from public.v_if_step
             where if_id = $1::int
             order by step_no
            """, [ifId]);

    private static Task<List<Dictionary<string, object?>>> AttrsAsync(PgPool db, int ifId) =>
        db.QueryAsync("""
            select attr_def_id, attr_cd, attr_nm, attr_type, code_grp, required_yn,
                   attr_val, sort_order,
                   to_char(updated_at,'YYYY-MM-DD HH24:MI') as updated_at_txt, updated_by
              from public.v_if_attr
             where if_id = $1::int
             order by sort_order, attr_cd
            """, [ifId]);

    private static Task<List<Dictionary<string, object?>>> NotesAsync(PgPool db, int ifId) =>
        db.QueryAsync("""
            select n.note_id, n.if_id, n.step_id, s.step_nm, n.note_type_cd,
                   c.code_nm as note_type_nm, n.title, n.content, n.writer_nm,
                   n.note_dt::text as note_dt, n.done_yn, n.sort_order,
                   to_char(n.updated_at,'YYYY-MM-DD HH24:MI') as updated_at_txt
              from public.if_note n
              left join public.if_step s on s.step_id = n.step_id
              left join public.if_code c on c.code_grp = 'NOTE_TYPE' and c.code = n.note_type_cd
             where n.if_id = $1::int
             order by coalesce(n.done_yn,'N'), n.sort_order, n.note_id desc
            """, [ifId]);

    private static string? Who(JsonElement body) =>
        body.TryGetProperty("updated_by", out var v) && v.ValueKind == JsonValueKind.String
            ? v.GetString() : "dashboard";

    private static string? Nz(string? s) => string.IsNullOrWhiteSpace(s) ? null : s;
}
