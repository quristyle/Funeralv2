using System.Globalization;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace WbsApi;

/// <summary>
/// dev_user.use_ip 에 등록된 IP 만 접근을 허용한다.
/// 스스로를 잠그지 않도록 다음은 항상 허용한다.
///  - 루프백(127.0.0.1 / ::1)
///  - 서버 장비 자신의 IP
///  - 등록된 IP 가 하나도 없는 상태(부트스트랩) — 최초 등록 전 잠김 방지
///
/// 루프백은 표기가 갈린다(127.0.0.1 · ::1 · localhost). 셋 중 하나로 등록해 두면
/// 나머지로 접속해도 그 사람으로 가려낸다 — 그래야 서버 장비에서 열어도 관리자 판정이 선다.
/// </summary>
public sealed class IpGate(PgPool db, IConfiguration cfg)
{
    private static readonly TimeSpan CacheTtl = TimeSpan.FromSeconds(5);

    // 서버 장비 자신의 IP 를 무조건 허용할지. 엄격 운영을 원하면 appsettings 에서 false 로.
    private readonly bool _trustSelf = cfg.GetValue("IpGate:TrustSelf", true);
    private readonly HashSet<string> _selfIps = LocalIps();
    private Dictionary<string, Who> _allow = new();
    private DateTimeOffset _loadedAt = DateTimeOffset.MinValue;
    private readonly SemaphoreSlim _lock = new(1, 1);

    public static string ClientIp(HttpContext ctx)
    {
        var ip = ctx.Connection.RemoteIpAddress ?? IPAddress.None;
        if (ip.IsIPv4MappedToIPv6) ip = ip.MapToIPv4();

        // 로컬 프록시(개발서버 등)를 거친 요청이면 X-Forwarded-For 의 원래 IP 로 판정한다.
        // 루프백은 어차피 전면 허용이므로, 이 처리는 게이트를 느슨하게 만들지 않고 조이는 방향이다.
        if (IPAddress.IsLoopback(ip))
        {
            var xff = ctx.Request.Headers["X-Forwarded-For"].ToString();
            var first = xff.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                           .FirstOrDefault();
            if (!string.IsNullOrEmpty(first) && IPAddress.TryParse(first, out var fwd))
            {
                if (fwd.IsIPv4MappedToIPv6) fwd = fwd.MapToIPv4();
                return fwd.ToString();
            }
        }
        return ip.ToString();
    }

    // 루프백은 표기가 여러 가지다 — 브라우저가 localhost 를 무엇으로 푸느냐에 따라
    // ::1 로도 127.0.0.1 로도 들어온다. 어느 하나로 등록해 두면 나머지로 접속해도
    // 같은 사람으로 보이도록, 조회할 때 이 표기들을 서로 같은 것으로 친다.
    private static readonly string[] LoopbackForms = ["127.0.0.1", "::1", "localhost"];

    private static bool IsLoopbackText(string s) =>
        LoopbackForms.Contains(s, StringComparer.OrdinalIgnoreCase)
        || (IPAddress.TryParse(s, out var a) && IPAddress.IsLoopback(a));

    private static HashSet<string> LocalIps()
    {
        var set = new HashSet<string> { "127.0.0.1", "::1" };
        try
        {
            foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                foreach (var a in ni.GetIPProperties().UnicastAddresses)
                    if (a.Address.AddressFamily is AddressFamily.InterNetwork or AddressFamily.InterNetworkV6)
                        set.Add(a.Address.ToString());
        }
        catch { /* 조회 실패 시 루프백만 허용 */ }
        return set;
    }

    /// <summary>
    /// 등록된 사람 하나.
    /// Blocked 는 개발자 관리의 <차단여부>, Super 는 <Super 권한>.
    /// </summary>
    private sealed record Who(string BpId, string Name, bool Blocked, bool Super);

    /// <summary>켜진 것으로 치는 값 — 화면은 O/X 로 쓰지만 손으로 넣은 값도 받아 준다.</summary>
    private static bool IsOn(string? v) =>
        v is not null && v.Trim() is var s && s.Length > 0 && "oy".Contains(char.ToLowerInvariant(s[0]));

    /// <summary>dev_user.use_ip 목록을 5초간 캐시한다 (정적 파일 요청마다 DB 조회하지 않도록).</summary>
    private async Task<Dictionary<string, Who>> AllowListAsync()
    {
        if (DateTimeOffset.UtcNow - _loadedAt < CacheTtl) return _allow;
        await _lock.WaitAsync();
        try
        {
            if (DateTimeOffset.UtcNow - _loadedAt < CacheTtl) return _allow;

            var rows = await db.QueryAsync("""
                select bp_id, coalesce(name, bp_id) as name, use_ip, block_yn, super_yn
                  from public.dev_user
                 where coalesce(trim(use_ip), '') <> ''
                """);
            var map = new Dictionary<string, Who>();
            foreach (var r in rows)
            {
                var bp = r["bp_id"]?.ToString() ?? "";
                var nm = r["name"]?.ToString() ?? bp;
                var blocked = IsOn(r["block_yn"]?.ToString());
                var sup = IsOn(r["super_yn"]?.ToString());
                // 한 사람이 여러 IP 를 쓸 수 있으므로 쉼표/세미콜론/공백 구분 모두 허용
                foreach (var raw in (r["use_ip"]?.ToString() ?? "").Split([',', ';', ' ', '\t', '\n'],
                             StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                    map[raw] = new Who(bp, nm, blocked, sup);
            }
            _allow = map;
            _loadedAt = DateTimeOffset.UtcNow;
            return _allow;
        }
        finally { _lock.Release(); }
    }

    /// <summary>
    /// Super 는 dev_user.super_yn, Loopback 은 서버 장비에서 연 것인지 —
    /// whoami 가 <무엇을 보여 줄지> 를 이 둘로 정한다.
    /// </summary>
    public sealed record Result(
        string Ip, bool Allowed, string? BpId, string? Name, string Reason, int Registered,
        bool Super = false, bool Loopback = false);

    public async Task<Result> CheckAsync(HttpContext ctx)
    {
        // 연결 IP 가 아니라 ClientIp(=프록시 고려) 로 판정한다
        var ip = ClientIp(ctx);
        var allow = await AllowListAsync();

        // 루프백은 서버 장비에서 연 것이다 — 최고 권한이라 <차단여부> 를 보지 않는다.
        // 스스로를 잠그면 풀 방법이 화면에 남지 않기 때문이다.
        // 프록시를 거친 요청은 ClientIp 가 이미 원래 IP 로 바꿔 놓으므로 여기 걸리지 않는다.
        var loop = IsLoopbackText(ip);

        Result Seen(Who e) =>
            !loop && e.Blocked
                ? new Result(ip, false, e.BpId, e.Name, "blocked", allow.Count, e.Super, loop)
                : new Result(ip, true, e.BpId, e.Name, "registered", allow.Count, e.Super, loop);

        if (allow.TryGetValue(ip, out var hit)) return Seen(hit);

        // 루프백으로 들어왔는데 그 표기로는 등록이 없으면 다른 표기로도 찾아 본다.
        // (localhost 로 열면 ::1, 127.0.0.1 로 열면 127.0.0.1 이 되는 탓에
        //  등록해 둔 사람이 <서버 로컬> 로 떨어져 관리자 판정을 못 받던 문제)
        if (loop)
            foreach (var form in LoopbackForms)
                if (allow.TryGetValue(form, out var lo))
                    return Seen(lo);

        // 등록되지 않은 루프백도 서버 장비에서 연 것이라 Loopback 을 그대로 실어 보낸다 —
        // 누구인지 몰라도 전체를 열어 주어야 한다(그래야 처음 설정할 때 막히지 않는다).
        if (_trustSelf && _selfIps.Contains(ip))
            return new Result(ip, true, null, "서버 로컬", "self", allow.Count, false, loop);
        if (IPAddress.TryParse(ip, out var parsed) && IPAddress.IsLoopback(parsed))
            return new Result(ip, true, null, "서버 로컬", "self", allow.Count, false, true);
        if (allow.Count == 0)
            return new Result(ip, true, null, null, "bootstrap", allow.Count, false, loop);

        return new Result(ip, false, null, null, "denied", allow.Count, false, loop);
    }

    /// <summary>
    /// 차단된 사용자에게 보이는 화면. 흔한 서버 오류처럼 보이게 둔다 —
    /// <당신은 차단되었습니다> 라고 알리지 않는 것이 이 기능의 목적이다.
    /// 그래서 안내도, 문의 경로도, 우리 쪽 표시도 넣지 않는다.
    /// </summary>
    public static string BlockedHtml(HttpContext ctx)
    {
        var host = ctx.Request.Host.Host;
        var port = ctx.Request.Host.Port ?? (ctx.Request.IsHttps ? 443 : 80);
        var client = ClientIp(ctx);
        var cport = ctx.Connection.RemotePort;

        // 아파치 error_log 의 시각 표기 — [Mon Sep 15 09:12:33.481920 2026].
        // 영문 요일/월이라야 그 형식이 되므로 로캘을 고정한다.
        var now = DateTime.Now;
        var stamp = now.ToString("ddd MMM dd HH:mm:ss", CultureInfo.InvariantCulture)
                    + "." + (now.Ticks % 10_000_000 / 10).ToString("D6", CultureInfo.InvariantCulture)
                    + " " + now.Year;

        // pid/tid 는 아파치 로그에 늘 붙는 값이다. 새로고침마다 달라지면 어색해서 하루 단위로 고정한다.
        var pid = 2000 + now.DayOfYear % 6000;
        var tid = 139_600_000_000_000L + now.DayOfYear * 977L;
        var head = $"[{stamp}] ";
        var who = $"[pid {pid}:tid {tid}]";

        // 보안장비를 지나지 못했다는 내용으로 남긴다.
        // (113)No route to host · AH00957 · AH00959 · AH01114 는 mod_proxy 가 실제로 함께 내는 조합이다.
        var log = string.Join("\n", [
            head + $"[proxy:error] {who} (113)No route to host: "
                 + "AH00957: HTTP: attempt to connect to 10.133.160.11:8443 (secure-gw) failed",
            head + $"[proxy:error] {who} "
                 + "AH00959: ap_proxy_connect_backend disabling worker for (secure-gw) for 60s",
            head + $"[proxy_http:error] {who} [client {client}:{cport}] "
                 + "AH01114: HTTP: failed to make connection to backend: secure-gw",
        ]);

        return $"""
            <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
            <html><head>
            <title>500 Internal Server Error</title>
            </head><body>
            <h1>Internal Server Error</h1>
            <p>The server encountered an internal error or
            misconfiguration and was unable to complete
            your request.</p>
            <p>Please contact the server administrator to inform them of the time this
            error occurred, and the actions you performed just before this error.</p>
            <p>More information about this error may be available
            in the server error log.</p>
            <pre>{log}</pre>
            <hr>
            <address>Apache/2.4.58 Server at {host} Port {port}</address>
            </body></html>

            """;
    }

    /// <summary>차단 안내 화면. 접근 IP 를 크게 보여주고 관리자 등록을 요청하게 한다.</summary>
    public static string DeniedHtml(string ip) => $$"""
        <!doctype html>
        <html lang="ko"><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>접근 권한 없음 · WBS 대시보드</title>
        <style>
          :root{color-scheme:light}
          body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
               background:#f6f7f9;color:#1c2024;
               font:14px/1.7 'Malgun Gothic',-apple-system,'Segoe UI',sans-serif}
          .box{background:#fff;border:1px solid #e3e6ea;border-radius:10px;padding:30px 34px;
               max-width:520px;box-shadow:0 1px 3px rgba(0,0,0,.04)}
          h1{font-size:17px;margin:0 0 6px}
          .sub{color:#6b7480;font-size:12.5px;margin-bottom:20px}
          .ipbox{background:#f5f6f8;border:1px solid #e3e6ea;border-radius:8px;
                 padding:14px 16px;text-align:center;margin:18px 0}
          .iplab{font-size:11.5px;color:#6b7480}
          .ip{font-family:Consolas,'Courier New',monospace;font-size:24px;font-weight:700;
              color:#2f6fd0;letter-spacing:.5px;margin-top:4px;user-select:all}
          ol{margin:14px 0 0;padding-left:20px}
          li{margin:5px 0}
          .foot{margin-top:20px;padding-top:14px;border-top:1px solid #e3e6ea;
                color:#6b7480;font-size:11.5px}
          code{background:#eef1f4;border-radius:3px;padding:1px 5px;font-size:12px}
        </style></head>
        <body><div class="box">
          <h1>접근 권한이 없습니다</h1>
          <div class="sub">WBS 대시보드는 등록된 IP 에서만 사용할 수 있습니다.</div>

          <div class="ipbox">
            <div class="iplab">접속하신 IP</div>
            <div class="ip">{{ip}}</div>
          </div>

          <strong>사용을 원하시면</strong>
          <ol>
            <li>위 IP 주소를 그대로 복사해 주세요.</li>
            <li>관리자에게 <strong>IP 등록</strong>을 요청해 주세요.</li>
            <li>등록 후 이 페이지를 새로고침하면 바로 사용할 수 있습니다.</li>
          </ol>

          <div class="foot">
            관리자는 <code>개발자 관리</code> 화면에서 해당 사용자의 <code>사용 IP</code> 항목에
            위 주소를 입력해 저장하면 됩니다.
          </div>
        </div></body></html>
        """;
}
