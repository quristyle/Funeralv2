using System.Text;
using System.Text.Json;

namespace WbsApi;

/// <summary>
/// ProjectView 캐시 — 신원(workId) 과 현재값 스냅샷.
///
/// 왜 필요한가:
///  - 지금까지는 전송할 때마다 work 목록을 통째로 다시 받아 code→workId 를 만들었다.
///    workId 를 보관하면 그 단계가 통째로 사라진다.
///  - ProjectView 의 현재 진척률을 몰라서 늘 전체 건을 다시 보냈다.
///    스냅샷을 보관하면 <값이 달라진 건만> 보낼 수 있다. 이게 가장 큰 이득이다.
///
/// 이 테이블은 어디까지나 <캐시>다. 통째로 지워도 대시보드는 그대로 동작하고,
/// 예전처럼 매번 다시 조회하는 느린 경로로 돌아갈 뿐이다.
/// 원장(hhip_wbs_wrk2)은 이 파일에서 절대 수정하지 않는다.
/// </summary>
public static class PvCache
{
    // 조회 범위. Program.cs 의 DevWhere 와 같은 규칙이다(그쪽은 지역 함수라 공유가 안 된다).
    private static string DevWhere(string? scope) =>
        scope?.ToLowerInvariant() == "all" ? "true" : "new_dev2 = 'o'";

    /// <summary>
    /// 액티비티별 일감 요약. Rows 화면과 캐시 화면이 함께 쓴다.
    /// 일감 수 · 워크플로 노드 수 · 아직 비어 있는 노드 수 · 마지막 완료일 · 담당자 · 현재단계.
    /// </summary>
    public const string TaskRollup = """
        (select t.activity_id
              , count(*)                          as task_cnt
              , sum(coalesce(t.pv_node_cnt, 0))   as node_cnt
              , sum(coalesce(t.pv_node_empty, 0)) as node_empty
              , max(t.pv_plan_edt)                as task_edt
              -- 현재단계. 액티비티에 일감이 여러 개면 <가장 나중에 바뀐 것>을 대표로 삼는다.
              , (array_agg(t.pv_status order by t.pv_status_at desc nulls last)
                   filter (where t.pv_status is not null))[1] as status
              -- 그 단계를 가진 일감의 코드 (ProjectView 일감 상세로 링크할 때 쓴다)
              , (array_agg(t.pv_task_code order by t.pv_status_at desc nulls last)
                   filter (where t.pv_task_code is not null))[1] as task_code
              , max(t.pv_status_at)               as status_at
              , count(distinct t.pv_status)       as status_cnt
              , (select string_agg(distinct n.worker_nm, ', ')
                   from public.hhip_wbs_pv_node n
                   join public.hhip_wbs_pv_task t2 on t2.pv_task_id = n.pv_task_id
                  where t2.activity_id = t.activity_id and n.worker_nm is not null) as workers
           from public.hhip_wbs_pv_task t
          group by t.activity_id)
        """;

    // ---------------------------------------------------------------- 값 정리

    /// <summary>'2026-08-31T00:00:00' → '2026-08-31'. 빈 값·형식 오류는 null.</summary>
    private static string? Day(JsonElement el)
    {
        if (el.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) return null;
        var s = (el.ValueKind == JsonValueKind.String ? el.GetString() : el.ToString())?.Trim();
        if (string.IsNullOrWhiteSpace(s)) return null;
        if (s.Length > 10) s = s[..10];
        return DateOnly.TryParse(s, out var d) ? d.ToString("yyyy-MM-dd") : null;
    }

    private static decimal? Num(JsonElement el)
    {
        if (el.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) return null;
        if (el.ValueKind == JsonValueKind.Number) return el.TryGetDecimal(out var d) ? d : null;
        var s = el.ValueKind == JsonValueKind.String ? el.GetString() : el.ToString();
        return decimal.TryParse(s, System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var v) ? v : null;
    }

    private static string? Txt(JsonElement el)
    {
        if (el.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) return null;
        var s = el.ValueKind == JsonValueKind.String ? el.GetString() : el.ToString();
        return string.IsNullOrWhiteSpace(s) ? null : s.Trim();
    }

    private static JsonElement? Prop(JsonElement o, params string[] names)
    {
        if (o.ValueKind != JsonValueKind.Object) return null;
        foreach (var n in names)
            if (o.TryGetProperty(n, out var v)) return v;
        return null;
    }

    private static string? Str(JsonElement o, params string[] names)
    { var v = Prop(o, names); return v is null ? null : Txt(v.Value); }

    private static string? Date(JsonElement o, params string[] names)
    { var v = Prop(o, names); return v is null ? null : Day(v.Value); }

    private static decimal? Dec(JsonElement o, params string[] names)
    { var v = Prop(o, names); return v is null ? null : Num(v.Value); }

    private static int? Int(JsonElement o, params string[] names)
    { var d = Dec(o, names); return d is null ? null : (int)d.Value; }

    // ---------------------------------------------------------------- 묶음 INSERT

    /// <summary>
    /// 값을 100행씩 끊어 한 문장으로 넣는다. 211건을 211번 왕복하지 않기 위한 것이다.
    /// casts 는 컬럼별 형변환('::text' 등) — 이 드라이버는 모든 값을 텍스트로 보내므로 필수다.
    /// literals 는 파라미터가 아닌 그대로 들어갈 값(now() 등)으로, 각 행 끝에 붙는다.
    /// </summary>
    private static async Task<int> BulkAsync(
        PgPool db, string head, string tail, string[] casts, List<object?[]> rows,
        string? literals = null, int chunk = 100)
    {
        var total = 0;
        for (var at = 0; at < rows.Count; at += chunk)
        {
            var part = rows.GetRange(at, Math.Min(chunk, rows.Count - at));
            var sb = new StringBuilder(head).Append(" values ");
            var args = new List<object?>();
            for (var i = 0; i < part.Count; i++)
            {
                if (i > 0) sb.Append(", ");
                sb.Append('(');
                for (var c = 0; c < casts.Length; c++)
                {
                    if (c > 0) sb.Append(", ");
                    args.Add(part[i][c]);
                    sb.Append('$').Append(args.Count).Append(casts[c]);
                }
                if (!string.IsNullOrEmpty(literals)) sb.Append(", ").Append(literals);
                sb.Append(')');
            }
            sb.Append(' ').Append(tail);
            total += await db.ExecuteAsync(sb.ToString(), [.. args]);
        }
        return total;
    }

    // ---------------------------------------------------------------- 라우팅

    public static void Map(WebApplication app)
    {
        // ---------- 캐시 현황 ----------
        app.MapGet("/api/pv/cache", async (PgPool db, string? scope) =>
        {
            var where = DevWhere(scope);
            var sum = await db.QueryAsync($"""
                select count(*)                                             as targets
                     , count(p.pv_work_id)                                  as identified
                     , count(p.pv_snapshot_at)                              as snapshot
                     , max(p.pv_seen_at)::text                              as last_seen
                     , max(p.pv_snapshot_at)::text                          as last_snapshot
                     , max(p.pv_project_id)                                 as project_id
                  from public.hhip_wbs_wrk2 w
                  left join public.hhip_wbs_pv p on p.activity_id = w.activity_id
                 where {where} and w.activity_id is not null
                """);

            var tasks = await db.QueryAsync("""
                select count(*)                as tasks
                     , sum(coalesce(pv_node_cnt, 0))   as nodes
                     , sum(coalesce(pv_node_empty, 0)) as nodes_empty
                     , count(pv_charger_id)    as charged
                     , count(pv_status)        as staged
                     , max(pv_seen_at)::text   as last_seen
                     , (select count(*) from public.hhip_wbs_pv_node) as nodes_cached
                  from public.hhip_wbs_pv_task
                """);

            // 원장에 없는데 캐시에만 있는 것 (프로젝트에서 빠졌거나 코드가 바뀐 건)
            var orphan = await db.QueryAsync("""
                select count(*) as n
                  from public.hhip_wbs_pv p
                 where not exists (select 1 from public.hhip_wbs_wrk2 w
                                    where w.activity_id = p.activity_id)
                """);

            return Results.Ok(new
            {
                scope = scope ?? "dev",
                works = sum.Count > 0 ? sum[0] : null,
                tasks = tasks.Count > 0 ? tasks[0] : null,
                orphan = orphan.Count > 0 ? orphan[0]["n"] : 0,
            });
        });

        // ---------- 액티비티별 캐시 (원장과 조인) ----------
        // 화면이 '보낼 필요가 있는 건'을 직접 계산할 수 있도록 원장 값과 나란히 준다.
        app.MapGet("/api/pv/rows", async (PgPool db, string? scope) =>
        {
            var where = DevWhere(scope);
            return Results.Ok(await db.QueryAsync($"""
                select w.activity_id
                     , w.systemcode, w.menu_nm, w.user_bp_id
                     , w.plan_sdt::text   as plan_sdt
                     , w.plan_edt::text   as plan_edt
                     , w.plan_sdt_c::text as plan_sdt_c
                     , p.pv_work_id, p.pv_work_title, p.pv_project_id
                     , p.pv_seen_at::text     as pv_seen_at
                     , p.pv_finish_rate, p.pv_actual_rate
                     , p.pv_plan_sdt::text    as pv_plan_sdt
                     , p.pv_plan_edt::text    as pv_plan_edt
                     , p.pv_actual_sdt::text  as pv_actual_sdt
                     , p.pv_actual_edt::text  as pv_actual_edt
                     , p.pv_snapshot_at::text as pv_snapshot_at
                     , t.task_cnt, t.node_cnt, t.node_empty
                     , t.task_edt::text as pv_task_edt
                     , t.workers        as pv_workers
                     , t.status         as pv_status
                     , t.status_at::text as pv_status_at
                     , t.status_cnt     as pv_status_cnt
                     , t.task_code      as pv_task_code
                  from public.hhip_wbs_wrk2 w
                  left join {TaskRollup} t on t.activity_id = w.activity_id
                  left join public.hhip_wbs_pv p on p.activity_id = w.activity_id
                 where {where} and w.activity_id is not null
                 order by w.activity_id
                """));
        });

        // ---------- 워크플로 일감 캐시 ----------
        app.MapGet("/api/pv/tasks", async (PgPool db, string? activityId) =>
        {
            var sql = """
                select pv_task_id, activity_id, pv_work_id, pv_task_code, pv_task_title
                     , pv_plan_sdt::text as pv_plan_sdt
                     , pv_plan_edt::text as pv_plan_edt
                     , pv_node_cnt, pv_node_empty
                     , pv_charger_id, pv_charger_nm, pv_status
                     , pv_status_at::text as pv_status_at
                     , pv_seen_at::text   as pv_seen_at
                  from public.hhip_wbs_pv_task
                """;
            var tasks = string.IsNullOrWhiteSpace(activityId)
                ? await db.QueryAsync(sql + " order by activity_id, pv_task_code")
                : await db.QueryAsync(sql + " where activity_id = $1::text order by pv_task_code",
                                      [activityId.Trim()]);

            // 한 화면만 볼 때는 워크플로 노드까지 같이 준다 (Rows 화면의 펼침 보기용)
            if (string.IsNullOrWhiteSpace(activityId)) return Results.Ok(new { tasks, nodes = Array.Empty<object>() });

            var nodes = await db.QueryAsync("""
                select n.pv_task_id, n.node_no, n.stage_nm
                     , n.node_dt::text as node_dt
                     , n.worker_id, n.worker_nm
                  from public.hhip_wbs_pv_node n
                  join public.hhip_wbs_pv_task t on t.pv_task_id = n.pv_task_id
                 where t.activity_id = $1::text
                 order by n.pv_task_id, n.node_no
                """, [activityId.Trim()]);
            return Results.Ok(new { tasks, nodes });
        });

        // ---------- 수집 결과 저장 ----------
        // body: { projectId, works: [{ code, id, title, finishRate, actualRate,
        //                              planStartDate, planEndDate, actualStartDate, actualEndDate,
        //                              tasks: [{ id, code, title, planStartDate, planEndDate,
        //                                        nodeCnt, nodeEmpty }] }] }
        //
        // 걷어 온 값으로 통째로 덮어쓴다 — 캐시는 늘 <지금 ProjectView 의 값>이면 된다.
        app.MapPost("/api/pv/ingest", async (PgPool db, JsonElement body) =>
        {
            var projectId = Str(body, "projectId", "project_id");
            var listEl = Prop(body, "works", "items", "rows");
            if (listEl is null || listEl.Value.ValueKind != JsonValueKind.Array)
                return Results.BadRequest(new { error = "works 배열이 필요합니다." });

            var works = new List<object?[]>();
            var tasks = new List<object?[]>();
            var nodes = new List<object?[]>();
            var nodeTasks = new List<string>();   // 노드를 받은 일감 — 옛 노드를 지울 대상
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var dupes = new List<string>();
            var noCode = 0;

            foreach (var w in listEl.Value.EnumerateArray())
            {
                var code = Str(w, "code", "activity_id", "activityId");
                if (string.IsNullOrWhiteSpace(code)) { noCode++; continue; }
                if (!seen.Add(code)) { dupes.Add(code); continue; }   // 한 번만 넣는다(PK 충돌 방지)

                works.Add([
                    code,
                    projectId ?? Str(w, "projectId"),
                    Str(w, "id", "workId", "work_id"),
                    Str(w, "title", "workTitle"),
                    Dec(w, "finishRate", "finish_rate"),
                    Dec(w, "actualRate", "actualProgressRate", "actual_rate"),
                    Date(w, "planStartDate", "plan_sdt"),
                    Date(w, "planEndDate", "plan_edt"),
                    Date(w, "actualStartDate", "plan_sdt_c"),
                    Date(w, "actualEndDate", "plan_edt_c"),
                ]);

                var tl = Prop(w, "tasks", "taskList");
                if (tl is null || tl.Value.ValueKind != JsonValueKind.Array) continue;
                foreach (var t in tl.Value.EnumerateArray())
                {
                    var tid = Str(t, "id", "taskId", "pv_task_id");
                    if (string.IsNullOrWhiteSpace(tid)) continue;

                    // 노드를 함께 받았으면 개수는 우리가 센다 (보내 준 값보다 정확하다)
                    var nl = Prop(t, "nodes", "taskNodes");
                    var hasNodes = nl is not null && nl.Value.ValueKind == JsonValueKind.Array;
                    int? nodeCnt = Int(t, "nodeCnt", "node_cnt");
                    int? nodeEmpty = Int(t, "nodeEmpty", "empty", "node_empty");

                    if (hasNodes)
                    {
                        nodeTasks.Add(tid);
                        var no = 0;
                        var empty = 0;
                        foreach (var nd in nl!.Value.EnumerateArray())
                        {
                            var dt = Date(nd, "date", "node_dt", "endDate", "planEndDate");
                            var wid = Str(nd, "workerId", "worker_id", "chargerId");
                            if (dt is null || wid is null) empty++;
                            nodes.Add([
                                tid, no,
                                Str(nd, "id", "nodeId", "node_id"),
                                Str(nd, "stage", "stageNm", "stage_nm", "statusName"),
                                dt, wid,
                                Str(nd, "workerNm", "worker_nm", "workerName"),
                            ]);
                            no++;
                        }
                        nodeCnt = no;
                        nodeEmpty = empty;
                    }

                    tasks.Add([
                        tid,
                        code,
                        Str(w, "id", "workId", "work_id"),
                        Str(t, "code", "taskCode"),
                        Str(t, "title", "name"),
                        Date(t, "planStartDate"),
                        Date(t, "planEndDate", "endDate"),
                        nodeCnt,
                        nodeEmpty,
                        Str(t, "chargerId", "charger_id", "workerId"),
                        Str(t, "chargerNm", "charger_nm", "workerNm"),
                        Str(t, "status", "statusName", "stage"),
                        Date(t, "statusAt", "status_at"),
                    ]);
                }
            }

            var nWork = await BulkAsync(db,
                """
                insert into public.hhip_wbs_pv
                  (activity_id, pv_project_id, pv_work_id, pv_work_title,
                   pv_finish_rate, pv_actual_rate,
                   pv_plan_sdt, pv_plan_edt, pv_actual_sdt, pv_actual_edt,
                   pv_seen_at, pv_snapshot_at, updated_at)
                """,
                """
                on conflict (activity_id) do update set
                    pv_project_id  = coalesce(excluded.pv_project_id, hhip_wbs_pv.pv_project_id)
                  , pv_work_id     = coalesce(excluded.pv_work_id,    hhip_wbs_pv.pv_work_id)
                  , pv_work_title  = coalesce(excluded.pv_work_title, hhip_wbs_pv.pv_work_title)
                  , pv_finish_rate = excluded.pv_finish_rate
                  , pv_actual_rate = excluded.pv_actual_rate
                  , pv_plan_sdt    = excluded.pv_plan_sdt
                  , pv_plan_edt    = excluded.pv_plan_edt
                  , pv_actual_sdt  = excluded.pv_actual_sdt
                  , pv_actual_edt  = excluded.pv_actual_edt
                  , pv_seen_at     = now()
                  , pv_snapshot_at = now()
                  , updated_at     = now()
                """,
                ["::text", "::text", "::text", "::text",
                 "::numeric", "::numeric",
                 "::date", "::date", "::date", "::date"],
                works, "now(), now(), now()");

            var nTask = tasks.Count == 0 ? 0 : await BulkAsync(db,
                """
                insert into public.hhip_wbs_pv_task
                  (pv_task_id, activity_id, pv_work_id, pv_task_code, pv_task_title,
                   pv_plan_sdt, pv_plan_edt, pv_node_cnt, pv_node_empty,
                   pv_charger_id, pv_charger_nm, pv_status, pv_status_at,
                   pv_seen_at, updated_at)
                """,
                """
                on conflict (pv_task_id) do update set
                    activity_id   = excluded.activity_id
                  , pv_work_id    = coalesce(excluded.pv_work_id, hhip_wbs_pv_task.pv_work_id)
                  , pv_task_code  = coalesce(excluded.pv_task_code, hhip_wbs_pv_task.pv_task_code)
                  , pv_task_title = coalesce(excluded.pv_task_title, hhip_wbs_pv_task.pv_task_title)
                  , pv_plan_sdt   = excluded.pv_plan_sdt
                  , pv_plan_edt   = excluded.pv_plan_edt
                  , pv_node_cnt   = coalesce(excluded.pv_node_cnt, hhip_wbs_pv_task.pv_node_cnt)
                  , pv_node_empty = coalesce(excluded.pv_node_empty, hhip_wbs_pv_task.pv_node_empty)
                  , pv_charger_id = coalesce(excluded.pv_charger_id, hhip_wbs_pv_task.pv_charger_id)
                  , pv_charger_nm = coalesce(excluded.pv_charger_nm, hhip_wbs_pv_task.pv_charger_nm)
                  -- 현재단계는 걷어 왔으면 그 값이 이긴다 (되돌아가는 경우도 있으므로 coalesce 하지 않는다).
                  -- 이번에 못 걷었으면(null) 이전 값을 지키려고 coalesce 를 쓴다.
                  , pv_status     = coalesce(excluded.pv_status, hhip_wbs_pv_task.pv_status)
                  , pv_status_at  = coalesce(excluded.pv_status_at, hhip_wbs_pv_task.pv_status_at)
                  , pv_seen_at    = now()
                  , updated_at    = now()
                """,
                ["::text", "::text", "::text", "::text", "::text",
                 "::date", "::date", "::int", "::int",
                 "::text", "::text", "::text", "::date"],
                tasks, "now(), now()");

            // 노드는 일감 단위로 통째로 갈아 끼운다.
            // 노드가 줄어든 경우(단계 삭제)에 옛 행이 남지 않게 하려는 것이다.
            var nNode = 0;
            if (nodeTasks.Count > 0)
            {
                for (var at = 0; at < nodeTasks.Count; at += 200)
                {
                    var part = nodeTasks.GetRange(at, Math.Min(200, nodeTasks.Count - at));
                    var ph = string.Join(", ", part.Select((_, i) => $"${i + 1}::text"));
                    await db.ExecuteAsync(
                        $"delete from public.hhip_wbs_pv_node where pv_task_id in ({ph})",
                        [.. part.Cast<object?>()]);
                }
                nNode = await BulkAsync(db,
                    """
                    insert into public.hhip_wbs_pv_node
                      (pv_task_id, node_no, node_id, stage_nm, node_dt, worker_id, worker_nm, updated_at)
                    """,
                    "on conflict (pv_task_id, node_no) do nothing",
                    ["::text", "::int", "::text", "::text", "::date", "::text", "::text"],
                    nodes, "now()");
            }

            // 원장에 없는 코드 — 알려만 주고 지우지는 않는다
            var unknown = await db.QueryAsync("""
                select p.activity_id
                  from public.hhip_wbs_pv p
                 where not exists (select 1 from public.hhip_wbs_wrk2 w
                                    where w.activity_id = p.activity_id)
                 order by p.activity_id
                 limit 100
                """);

            return Results.Ok(new
            {
                works = nWork,
                tasks = nTask,
                nodes = nNode,
                skipped_no_code = noCode,
                duplicated = dupes.Count,
                duplicated_codes = dupes.Take(20),
                unknown_count = unknown.Count,
                unknown = unknown.Select(r => r["activity_id"]),
                project_id = projectId,
            });
        });

        // ---------- 캐시 비우기 ----------
        app.MapDelete("/api/pv/cache", async (PgPool db, string? what) =>
        {
            var w = (what ?? "all").ToLowerInvariant();
            var works = w is "all" or "works" ? await db.ExecuteAsync("delete from public.hhip_wbs_pv") : 0;
            // 노드는 일감에 매달린 것이라 일감을 지우면 함께 지운다
            var nodes = w is "all" or "tasks" ? await db.ExecuteAsync("delete from public.hhip_wbs_pv_node") : 0;
            var tasks = w is "all" or "tasks" ? await db.ExecuteAsync("delete from public.hhip_wbs_pv_task") : 0;
            return Results.Ok(new { works, tasks, nodes });
        });
    }
}
