<script setup>
import { onMounted, onUnmounted, ref } from 'vue'
import { api } from '../api'
import { isSuper } from '../store'
import { useDragMove } from '../dragmove'

// 상세 목록 한 줄에 붙이는 화면설계 문서.
//
// 보관은 파일시스템이다 (api/RowFiles.cs — 인터페이스 첨부와 같은 방식).
// 표를 만들지 않고 파일 이름 자체를 메타데이터로 쓴다.
//
// 폴더 이름이 row_uid 라 Activity ID 가 아직 없는 줄에도 붙는다. 그 값으로 삼지 않은
// 까닭은 나중에 확정되는 일이 있어서고, 모듈+메뉴명으로 삼지 않은 까닭은 그 둘이
// 사람이 고치는 값이라 고치는 순간 붙여 둔 것이 길을 잃기 때문이다.
const props = defineProps({ row: { type: Object, required: true } })
const emit = defineEmits(['close', 'changed'])

const drag = useDragMove()

const files = ref([])
const err = ref('')
const busy = ref('')        // 'up' | file_id
const dragOver = ref(false)
const fileInput = ref(null)
const loading = ref(true)

const kb = (n) => (n >= 1024 * 1024 ? (n / 1024 / 1024).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB')
const urlOf = (f) => api.rowFileUrl(props.row.row_uid, f.file_id)

async function load() {
  try {
    files.value = await api.rowFiles(props.row.row_uid)
  } catch (e) {
    err.value = e.message
  } finally {
    loading.value = false
  }
}

async function upload(list) {
  if (!list?.length) return
  busy.value = 'up'
  err.value = ''
  try {
    await api.rowFileUpload(props.row.row_uid, list)
    await load()
    emit('changed')          // 목록의 [첨부] 배지를 다시 센다
  } catch (e) {
    err.value = e.message
  } finally {
    busy.value = ''
    // 같은 파일을 다시 고를 수 있게 비워 둔다 (값이 같으면 change 가 안 난다)
    if (fileInput.value) fileInput.value.value = ''
  }
}

function onDrop(e) {
  dragOver.value = false
  upload(e.dataTransfer?.files)
}

async function removeFile(f) {
  if (!confirm(`"${f.name}" 을(를) 삭제합니다. 되돌릴 수 없습니다.`)) return
  busy.value = f.file_id
  err.value = ''
  try {
    await api.rowFileDelete(props.row.row_uid, f.file_id)
    await load()
    emit('changed')
  } catch (e) {
    err.value = e.message
  } finally {
    busy.value = ''
  }
}

function onKey(e) {
  if (e.key === 'Escape') emit('close')
}
onMounted(() => {
  window.addEventListener('keydown', onKey)
  load()
})
onUnmounted(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <div class="mask">
    <div class="dlg" :class="{ moving: drag.moving.value }" :style="drag.style.value">
      <header class="grab" @pointerdown="drag.start($event)">
        <span class="hgrip" title="여기를 잡아 창을 옮깁니다">⠿</span>
        <strong>화면설계 문서</strong>
        <span class="hint">{{ row.activity_id || 'ID 미정' }} · {{ row.menu_nm }}</span>
        <span class="spacer"></span>
        <button v-if="drag.moved()" title="창을 원래 자리로" @click="drag.reset()">⌖</button>
        <button class="x" title="닫기 (Esc)" @click="emit('close')">✕</button>
      </header>

      <div class="body">
        <p v-if="err" class="err">{{ err }}</p>

        <input ref="fileInput" type="file" multiple style="display: none" @change="upload($event.target.files)" />

        <div
          class="drop"
          :class="{ over: dragOver, busy: busy === 'up' }"
          @dragover.prevent="dragOver = true"
          @dragleave="dragOver = false"
          @drop.prevent="onDrop"
          @click="fileInput?.click()"
        >
          <template v-if="busy === 'up'">올리는 중…</template>
          <template v-else>
            여기로 파일을 끌어다 놓거나 눌러서 고르세요 — <b>여러 개</b> 한꺼번에 됩니다
            <em>파일당 25MB · 한 번에 20개까지</em>
          </template>
        </div>

        <table v-if="files.length">
          <thead>
            <tr><th>파일명</th><th class="num">크기</th><th class="nowrap">올린 시각</th><th></th></tr>
          </thead>
          <tbody>
            <tr v-for="f in files" :key="f.file_id" :class="{ dim: busy === f.file_id }">
              <td><a :href="urlOf(f)" class="dl" :title="f.name">{{ f.name }}</a></td>
              <td class="num muted nowrap">{{ kb(f.size) }}</td>
              <td class="muted nowrap">{{ f.modified }}</td>
              <td class="nowrap act">
                <a :href="urlOf(f)" class="btnlink">내려받기</a>
                <!-- 지우는 것은 되돌릴 수 없어 Super 만 — 서버도 같은 기준으로 막는다 -->
                <button v-if="isSuper" class="del" :disabled="busy === f.file_id" @click="removeFile(f)">삭제</button>
              </td>
            </tr>
          </tbody>
        </table>
        <p v-else-if="!loading" class="muted empty">아직 붙인 문서가 없습니다.</p>
      </div>

      <footer>
        <span class="hint">
          {{ files.length }}건
          <template v-if="!isSuper"> · 삭제는 Super 권한만 할 수 있습니다</template>
        </span>
        <span class="spacer"></span>
        <button @click="emit('close')">닫기</button>
      </footer>
    </div>
  </div>
</template>

<style scoped>
.mask {
  position: fixed;
  inset: 0;
  background: var(--overlay);
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 40px 20px;
  z-index: 100;
}
.dlg {
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 10px;
  width: min(720px, 100%);
  max-height: calc(100vh - 80px);
  display: flex;
  flex-direction: column;
  box-shadow: 0 8px 28px var(--shadow);
}
.dlg header,
.dlg footer { display: flex; align-items: center; gap: 8px; padding: 10px 14px; flex: none; }
.dlg header { border-bottom: 1px solid var(--line); }
.dlg footer { border-top: 1px solid var(--line); }
.dlg header.grab { cursor: move; user-select: none; touch-action: none; }
.dlg.moving { box-shadow: 0 14px 40px var(--shadow-2); }
.hgrip { color: var(--muted-3); font-size: 13px; }
.dlg header .hint,
.dlg footer .hint {
  font-size: 11.5px; color: var(--muted);
  min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.spacer { flex: 1; }

.body { flex: 1 1 auto; min-height: 0; overflow: auto; padding: 12px 14px 14px; }
.err { margin: 0 0 10px; font-size: 12px; color: var(--danger-2); }

/* 끌어다 놓는 자리 — 눌러도 열린다. 둘 다 되는 것이 한눈에 보여야 한다. */
.drop {
  border: 1px dashed var(--line);
  border-radius: 7px;
  padding: 16px 12px;
  text-align: center;
  font-size: 12.5px;
  color: var(--muted);
  cursor: pointer;
  background: var(--surface);
}
.drop em { display: block; font-style: normal; font-size: 11px; margin-top: 3px; color: var(--muted-2); }
.drop:hover { border-color: var(--accent); color: var(--accent); }
.drop.over { border-color: var(--accent); background: var(--accent-soft); color: var(--accent); }
.drop.busy { opacity: 0.6; cursor: default; }

table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 12.5px; }
th, td { border-bottom: 1px solid var(--line); padding: 5px 8px; text-align: left; }
th { color: var(--muted); font-weight: 600; font-size: 11.5px; white-space: nowrap; }
.num { text-align: right; }
.nowrap { white-space: nowrap; }
.muted { color: var(--muted); }
tr.dim { opacity: 0.5; }
td .dl { color: var(--accent); word-break: break-all; }
.act { text-align: right; }
.act .btnlink { font-size: 11px; margin-right: 6px; color: var(--accent); }
.act .del { padding: 1px 7px; font-size: 11px; }
.act .del:hover { border-color: var(--danger-2); color: var(--danger-2); }
.empty { font-size: 12.5px; margin: 14px 0 0; text-align: center; }
header .x { border: 0; background: transparent; font-size: 14px; color: var(--muted); padding: 2px 6px; }
header .x:hover { color: var(--text); }
</style>
