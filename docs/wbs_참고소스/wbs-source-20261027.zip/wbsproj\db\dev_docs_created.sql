-- ---------------------------------------------------------------------------
-- 개발자 정보(dev_docs) — 섹션을 <언제 누가 처음 썼는지> 남긴다.
--
-- 지금까지 남는 것은 마지막 수정(updated_at · updated_by) 뿐이었다. 섹션 머리글에
-- <작성 / 수정> 을 나란히 보여 주려면 최초 작성도 있어야 한다.
--
-- ⚠️ 이미 있는 섹션은 비워 둔다 — backfill 하지 않는다.
--    updated_at 으로 메우면 <마지막으로 고친 때> 가 <처음 쓴 때> 로 둔갑한다.
--    최초 작성 시각은 어디에도 남아 있지 않으므로, 모르는 것은 모르는 채로 두고
--    화면에서 '작성 —' 으로 보여 준다. 새로 만드는 섹션부터 채워진다.
--
--    그래도 대략의 값이라도 넣어 두고 싶으면 아래를 직접 실행한다. 권하지는 않는다.
--      update public.dev_docs set created_at = updated_at where created_at is null;
--
-- created_by 는 deleted_by · updated_by 와 같은 방식 — IpGate 가 가려 준 이름이다.
-- 사람이 안 가려지면 null 로 둔다. 빈 이름으로 채우면 <누군지 모른다> 와
-- <이름이 빈 사람> 을 구별할 수 없게 된다.
-- ---------------------------------------------------------------------------

alter table public.dev_docs add column if not exists created_at timestamptz;
alter table public.dev_docs add column if not exists created_by text;

-- 새로 만드는 섹션은 API 가 값을 빠뜨려도 시각만은 남게 둔다.
alter table public.dev_docs alter column created_at set default now();

comment on column public.dev_docs.created_at is
  '최초 작성 시각. 이 컬럼을 넣기 전에 만든 섹션은 null (모르는 값을 지어내지 않는다).';
comment on column public.dev_docs.created_by is
  '최초 작성자 (IpGate 가 가려 준 이름). 가려지지 않으면 null.';
