-- 사이드바 메뉴 — 폴더와 순서.
--
-- 두 가지를 더한다.
--   ① dev_menu_folder  : 사이드바에 두는 폴더(묶음)
--   ② dev_menu.folder_id : 그 메뉴가 어느 폴더에 들어 있는지 (null 이면 바깥, 곧 최상위)
--
-- 순서는 sort_order 하나로 센다. <같은 자리에 있는 것끼리> 만 견준다.
--   · 최상위 = 폴더 + folder_id 가 null 인 메뉴를 **한 줄로 섞어** sort_order 로 정렬한다.
--     그래서 폴더와 메뉴가 같은 번호 공간을 나눠 쓴다 — 화면이 트리 전체를 한 번에 보내고
--     서버가 10, 20, 30 … 으로 다시 매기므로 겹치지 않는다.
--   · 폴더 안 = 그 폴더의 메뉴끼리 sort_order 로 정렬한다.
--
-- 고치는 것은 Super 뿐이다 (서버가 막는다 — api/Menus.cs).
-- 아무 폴더도 없으면 예전과 똑같이 한 줄로 보인다. 기능이 조용히 낮아질 뿐 깨지지 않는다.

create table if not exists public.dev_menu_folder (
    folder_id  serial      primary key,
    folder_nm  varchar(60) not null,
    sort_order int         default 0,
    updated_at timestamptz default now(),
    updated_by varchar(40)
);

comment on table public.dev_menu_folder is '사이드바 메뉴 폴더 (Super 만 편집)';

alter table public.dev_menu
    add column if not exists folder_id int;

comment on column public.dev_menu.folder_id is
    '들어 있는 폴더 (dev_menu_folder.folder_id). null 이면 최상위';

-- 폴더를 지우면 그 안의 메뉴는 최상위로 돌아간다 — 메뉴가 같이 사라지면 안 된다.
do $$
begin
    if not exists (select 1 from pg_constraint where conname = 'fk_dev_menu_folder') then
        alter table public.dev_menu
            add constraint fk_dev_menu_folder
            foreign key (folder_id) references public.dev_menu_folder (folder_id)
            on delete set null;
    end if;
end $$;

create index if not exists ix_dev_menu_folder on public.dev_menu (folder_id);
