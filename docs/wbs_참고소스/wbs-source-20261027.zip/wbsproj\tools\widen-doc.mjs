// 올려 둔 HTML 문서가 iframe 안에서 가로를 다 쓰게 한다.
//
// 규칙을 열다섯 군데 고치는 대신 <마지막 </body> 앞에 덮어쓰기 한 덩이> 를 넣는다.
// 1~2MB 짜리 문서라 본문을 건드릴수록 깨질 자리가 늘고, 덮어쓰기는 지우면 그대로 돌아온다.
//
// 쓰기: node widen.mjs <파일> [<파일> ...]
import { readFileSync, writeFileSync, copyFileSync, existsSync } from 'node:fs'
import { basename } from 'node:path'

const MARK = 'wbs-widen'

const CSS = `
<style id="${MARK}">
/* ── iframe 에 꽉 차게: 가로 여백을 쓰지 않는다 ──────────────────────────────
   원래 글은 종이처럼 가운데로 모아 읽도록 폭을 묶어 두었다
   (.doc 920px · .wrap 1120~1240px · .bp-layout 1560px · 문단 760px).
   혼자 열어 볼 때는 그 편이 읽기 좋지만, iframe 안에서는 묶인 만큼이
   양옆의 빈 칸으로만 남는다.

   아래는 <폭을 묶은 것만> 푼다. 글자 크기·빛깔·사이 간격은 건드리지 않는다.
   되돌리려면 이 <style id="${MARK}"> 한 덩이를 지우면 된다. */
html, body { max-width: none; }
body { padding-left: 0; padding-right: 0; }
.doc { max-width: none; margin: 0; padding: 0 14px; }   /* 14px 은 글자가 테두리에 붙지 않을 만큼만 */
.hhip-bp { --prose: none; }                              /* 문단 760px 묶음을 푼다 */
.hhip-bp .wrap,
.hhip-bp .bp-layout,
.hhip-bp .bp-layout.sc3,
.hhip-bp .bp-layout > .wrap { max-width: none; margin-left: 0; margin-right: 0; }
.hhip-bp p, .hhip-bp .lead, .hhip-bp .howto { max-width: none; }
</style>
`

for (const f of process.argv.slice(2)) {
  if (!existsSync(f)) { console.log(`없음: ${f}`); continue }

  const before = readFileSync(f, 'utf8')
  if (before.includes(`id="${MARK}"`)) { console.log(`이미 적용됨: ${basename(f)}`); continue }

  const at = before.lastIndexOf('</body>')     // 안쪽 문서까지 통째로 붙은 파일이 있어 <마지막> 것을 쓴다
  if (at < 0) { console.log(`</body> 를 못 찾음: ${basename(f)}`); continue }

  copyFileSync(f, f + '.bak')
  const after = before.slice(0, at) + CSS + before.slice(at)
  writeFileSync(f, after, 'utf8')
  console.log(`${basename(f)} — ${before.length} → ${after.length} 자 (되돌릴 사본: .bak)`)
}
