<script setup>
import { nextTick, onActivated, onMounted, onUnmounted, ref } from 'vue'
import { api } from '../api'
import RefreshBtn from '../components/RefreshBtn.vue'
import TaskDialog from '../components/TaskDialog.vue'
import ColumnDialog from '../components/ColumnDialog.vue'
import PvCollectDialog from '../components/PvCollectDialog.vue'
import TestStatusDialog from '../components/TestStatusDialog.vue'
import RowFormDialog from '../components/RowFormDialog.vue'
import RowFilesDialog from '../components/RowFilesDialog.vue'
import SetIdDialog from '../components/SetIdDialog.vue'
import ScreenMenu from '../components/ScreenMenu.vue'
import PvMenu from '../components/PvMenu.vue'
import { computed } from 'vue'
import {
  state, sortedRows, COLS, hasFilter, toggleSort, colOptions, taskOf,
  onMonthPick, onWeekPick, clearFilter, clearColFilter, userName,
  loadStats, loadRows, loadUsers, loadTaskCounts,
  visibleCols, isColOn, colStore, pvStageText, pvTaskUrl, pvWorkUrl, isAdmin, isSuper,
  fileOf, loadFileCounts,
} from '../store'
import { downloadXlsx } from '../xlsx'

// 컬럼 표시 — 고른 값은 store 가 localStorage 에 남긴다
const show = (key) => isColOn(key)
const colPanel = ref(false)
const pvPanel = ref(false)   // ProjectView 데이터 수집 창
const testPanel = ref(false) // 단위테스트 상태 변경 창
const addPanel = ref(false)  // 대상(화면) 추가 창

// 방금 추가한 대상을 알려 준다 — 211건 가운데 어디에 끼었는지 눈으로 찾기 어렵다.
// Activity ID 없이도 만들 수 있으므로 <모듈 + 메뉴명> 까지 들고 있는다.
const added = ref(null) // { activity_id, systemcode, menu_nm }
let addedTimer = null
async function onAdded(r) {
  addPanel.value = false
  added.value = r
  clearTimeout(addedTimer)
  addedTimer = setTimeout(() => (added.value = null), 15000)
  await reload()
}
onUnmounted(() => clearTimeout(addedTimer))

/** 방금 추가한 것만 보이게 — 컬럼필터를 그 값으로 맞춘다 (ID 가 없으면 메뉴명으로) */
function findAdded() {
  if (added.value.activity_id) state.colFilter.activity_id = added.value.activity_id
  else state.colFilter.menu_nm = added.value.menu_nm
}

// ---------- 화면 열기 (운영 / 개발) ----------
// 메뉴명을 누른 자리에 작은 메뉴를 띄운다. 주소는 목록에 이미 있는 값으로 만든다
// (메뉴명의 [코드] + systemcode) — store.js 의 screenUrls 참고.
const screenMenu = ref(null) // { row, x, y }
function openScreen(e, r) {
  screenMenu.value = { row: r, x: e.clientX, y: e.clientY }
}

// ---------- ProjectView 열기 (작업 / 일감 / 단위테스트) ----------
// Activity ID 를 누른 자리에 뜬다. 예전에는 <작업 상세> 로 바로 가는 링크였는데,
// 한 화면을 두고 볼 곳이 셋이라 고르게 했다 — components/PvMenu.vue 참고.
const pvMenu = ref(null) // { row, x, y }
function openPv(e, r) {
  // Ctrl·Shift·Alt(맥은 ⌘)를 누른 채 누르는 것은 <새 탭에 바로> 라는 뜻이다. 가로채지 않고
  // 브라우저에 맡기면 예전처럼 작업 상세가 열린다. (가운데 버튼은 click 이 아니라
  // auxclick 이라 애초에 여기로 오지 않는다 — 그쪽도 그대로 열린다.)
  if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return
  e.preventDefault()
  pvMenu.value = { row: r, x: e.clientX, y: e.clientY }
}

// ---------- 대상 수정 ----------
// 목록에서 칸을 눌러 고치는 것은 몇 개뿐이다(담당자·완료 등). 나머지 30여 개는 고칠 데가
// 없어 DB 로 가야 했다. 추가 창과 같은 창을 수정 모드로 연다.
const editRow = ref(null)
async function onSaved(got) {
  editRow.value = null
  added.value = null          // 추가 안내 띠가 떠 있으면 치운다 (지금 이야기는 수정이다)
  await reload()
  state.error = ''
  saved.value = got.menu_nm
  clearTimeout(savedTimer)
  savedTimer = setTimeout(() => (saved.value = ''), 8000)
}
const saved = ref('')
let savedTimer = null
onUnmounted(() => clearTimeout(savedTimer))

// 지운 뒤 — 되돌릴 수 없는 일이라 안내 띠를 저장보다 오래(20초) 띄우고,
// 무엇이 함께 치워졌는지(일감·첨부·백업 파일 이름)까지 적어 둔다.
const gone = ref(null)
let goneTimer = null
async function onDeleted(got) {
  editRow.value = null
  added.value = null
  saved.value = ''
  await reload()
  state.error = ''
  gone.value = got
  clearTimeout(goneTimer)
  goneTimer = setTimeout(() => (gone.value = null), 20000)
}
onUnmounted(() => clearTimeout(goneTimer))

// ---------- 나중에 확정된 Activity ID 채우기 ----------
// 엑셀 WBS 에서 뒤늦게 정해지는 일이 있어 ID 없이도 줄을 세울 수 있게 했다.
// 그 줄은 ProjectView 캐시·일감이 붙지 않는다 — 그 둘이 activity_id 로 행을 찾기 때문이다.
// (수정과 첨부는 row_uid 를 쓰므로 ID 가 없어도 된다.)
// prompt() 로 받던 것을 창(SetIdDialog)으로 옮겼다 — 겹치는 ID 를 <보내기 전에> 알려 주고,
// 어느 줄을 채우는지 모듈·메뉴명으로 보여 주기 위해서다. 창 쪽 주석에 까닭을 적어 두었다.
const idRow = ref(null)
async function onIdSet(got) {
  const r = idRow.value
  idRow.value = null
  if (r) r.activity_id = got.activity_id
  await reload()
  state.error = ''
}

// 체크 컬럼의 필터 드롭다운 문구. 기본은 <완료/미완료> 지만 뜻이 다른 것이 섞여 있다 —
// 재확인요청은 <요청됨>, 화면 속성(도면조회·리포트)은 <쓴다/안 쓴다> 다.
// 전부 '완료' 로 적어 두면 켜져 있는 것이 무슨 뜻인지 거꾸로 읽히는 칸이 생긴다.
const CHECK_WORDS = {
  recheck_yn: ['✓ 요청됨', '요청 없음'],
  dwg_view_use: ['✓ 사용', '미사용'],
  report_use: ['✓ 사용', '미사용'],
}
const checkWord = (key, on) => (CHECK_WORDS[key] ?? ['✓ 완료', '미완료'])[on ? 0 : 1]

/** 엑셀로 내려받는다 — <지금 화면에 보이는 컬럼>과 <필터·정렬이 적용된 행>만 담는다 */
function exportXlsx() {
  const cols = visibleCols.value
  const headers = cols.map((c) => ({ label: c.label, width: c.w }))
  const rows = sortedRows.value.map((r) => cols.map((c) => cellValue(r, c.key)))
  const n = downloadXlsx('WBS_상세목록', '상세 목록', headers, rows)
  return n
}

/** 화면에 보이는 것과 같은 값으로 내보낸다 (체크는 O, 일감은 완료/전체) */
function cellValue(r, key) {
  switch (key) {
    case 'systemcode': return [r.systemcode, r.system_nm].filter(Boolean).join(' ')
    case 'user_bp_id': return r.user_nm ? `${r.user_nm} (${r.user_bp_id})` : ''
    case 'user_real_id': return r.user_real_nm ? `${r.user_real_nm} (${r.user_real_id})` : ''
    case 'complate_yn':
    case 'complate_real_yn':
    case 'recheck_yn':
    case 'complate_big_yn':
    case 'complate_real_big_yn':
    case 'recheck_big_yn':
    case 'db_ready_big_yn':
    case 'dwg_view_use':
    case 'report_use': return r[key] === 'o' ? 'O' : ''
    case 'task_cnt': {
      const t = taskOf(r)
      return t.cnt ? `${t.done}/${t.cnt}` : ''
    }
    case 'file_cnt': return fileOf(r) || ''
    case 'priority_order': {
      const n = Number(r.priority_order)
      return r.priority_order == null || r.priority_order === '' ? '' : isFinite(n) ? n : r.priority_order
    }
    // ProjectView 값은 숫자는 숫자로, 시각은 분까지만
    case 'pv_finish_rate':
    case 'pv_task_cnt':
    case 'pv_node_empty': return r[key] == null ? '' : Number(r[key])
    // 현재단계는 화면과 같은 '(90%) PI검토' 모양으로 내보낸다
    case 'pv_status': return pvStageText(r)
    case 'pv_snapshot_at': return (r.pv_snapshot_at || '').slice(0, 16)
    default: return r[key] ?? ''
  }
}

// ---------- ProjectView 캐시 ----------
/** WBS 의 실적시작일과 ProjectView 의 것이 어긋나는가 (둘 다 값이 있을 때만 본다) */
const sdtDiff = (r) => !!r.plan_sdt_c && !!r.pv_actual_sdt && r.plan_sdt_c !== r.pv_actual_sdt

/** 현재단계 툴팁 — 단계·시작일·갈린 경우 안내 */
function stageTip(r) {
  if (!r.pv_status) return r.pv_task_code ? '현재단계는 아직 수집되지 않았습니다' : 'ProjectView 캐시가 없습니다'
  return `현재단계 ${r.pv_status}` +
    (r.pv_status_at ? ` · ${r.pv_status_at} 부터` : '') +
    (r.pv_status_cnt > 1 ? ` · 일감이 ${r.pv_status_cnt}종 단계로 갈려 있어 가장 나중 것을 보여 줍니다` : '')
}

/** 현재단계 색 — 완료는 초록, 검토는 주황, 개발은 파랑, 등록/그 밖은 회색 */
function stageClass(v) {
  const s = String(v || '')
  if (s.includes('완료')) return 'done'
  if (s.includes('검토')) return 'review'
  if (s.includes('개발')) return 'dev'
  return 'todo'
}

const pvTip = (r) =>
  r.pv_snapshot_at
    ? `ProjectView 실적 진척률 · ${r.pv_snapshot_at.slice(0, 16)} 수집`
    : 'ProjectView 값이 없습니다 — ⛁ 로 수집하세요'

/** 지금 목록에 PV 값이 하나라도 있는지 (없으면 안내를 띄운다) */
const pvLoaded = computed(() => sortedRows.value.some((r) => r.pv_snapshot_at))
const pvShown = computed(() => visibleCols.value.some((c) => c.pv))

// 일감 다이얼로그 대상 행 (null 이면 닫힘)
const taskRow = ref(null)
const taskPrefill = ref(null)

function openTasks(r, prefill = null) {
  taskPrefill.value = prefill
  taskRow.value = r
}
function closeTasks() {
  taskRow.value = null
  taskPrefill.value = null
}

// 화면설계 문서 첨부 창의 대상 행 (null 이면 닫힘).
// 첨부는 row_uid 로 보관하므로 Activity ID 가 없는 줄에도 붙는다 (db/wrk2_row_uid.sql).
const fileRow = ref(null)
function openFiles(r) {
  fileRow.value = r
}

// 재확인요청을 켜면 사유를 남길 수 있게 일감 창을 '확인' 구분으로 바로 띄운다
// col: 일반은 recheck_yn, 대형은 recheck_big_yn
async function onRecheck(r, checked, col = 'recheck_yn') {
  await save(r, col, checked ? 'o' : '')
  if (checked && r.activity_id) {
    const big = col === 'recheck_big_yn' ? '대형 ' : ''
    openTasks(r, {
      div: '확인',
      reason: `${big}재확인요청을 켰습니다. 무엇을 다시 확인해야 하는지 일감으로 남겨 주세요.`,
      placeholder: '확인이 필요한 내용을 적어 주세요 (이미지 붙여넣기 가능)',
    })
  }
}

const colFilterCount = computed(() => Object.values(state.colFilter).filter((v) => v !== '' && v != null).length)

const reload = () =>
  Promise.all([loadRows(), loadUsers(), loadStats(), loadTaskCounts(), loadFileCounts()])

// 트리거 발화 여부: 없음 / 확인필요 / 실제 발화 로 구분해 색을 달리한다
function trgClass(v) {
  if (!v) return 'none'
  if (v.includes('없음') && !v.includes('배치')) return 'none'
  if (v.includes('미확인') || v.includes('확인필요')) return 'warn'
  return 'fire'
}

// 우선순위 선택 목록 — 조회 결과에 있는 값 + 기본값(1,2)
const PRIORITIES = computed(() => {
  const set = new Set(['1', '2'])
  for (const r of state.rows) if (r.priority_order) set.add(String(r.priority_order))
  return [...set].sort((a, b) => a.localeCompare(b, 'ko', { numeric: true }))
})

// ---------- 인라인 수정 ----------
// 담당자·개발자·우선순위: 클릭 → 셀렉트 / 완료·개발자완료: 체크박스 즉시 반영
// (일정·실적 일자는 엑셀 WBS 가 원본이라 읽기 전용)
const editing = ref(null) // { id, col }
const saving = ref(null) // 저장 중인 activity_id|col

async function save(r, col, val) {
  if ((r[col] ?? '') === (val ?? '')) return
  saving.value = `${r.activity_id}|${col}`
  try {
    await api.patch(r.activity_id, { [col]: val })
    r[col] = val || null
    // 담당자/개발자는 성명 표기도 함께 맞춘다
    if (col === 'user_bp_id') r.user_nm = nameOf(val)
    if (col === 'user_real_id') r.user_real_nm = nameOf(val)
    await loadStats()
  } catch (e) {
    state.error = `수정 실패: ${e.message}`
  } finally {
    saving.value = null
  }
}

// dev_user 에 있는 ID 만 성명을 가진다. 없으면 null → 화면에서 '미할당'(빈 셀)로 보인다.
const nameOf = (id) => (id ? state.devUsers.find((d) => d.bp_id === id)?.name ?? null : null)

function startEdit(r, col) {
  if (!r.activity_id) return
  editing.value = { id: r.activity_id, col }
}
function isEditing(r, col) {
  return editing.value && editing.value.id === r.activity_id && editing.value.col === col
}
const busy = (r, col) => saving.value === `${r.activity_id}|${col}`

const vFocus = {
  mounted(el) {
    el.focus()
    if (el.select) el.select()
  },
}

// ---------- 그리드 높이 ----------
// 예전에는 max-height: calc(100vh - 230px) 처럼 고정값을 썼는데,
// 필터줄이 줄바꿈되거나 창 크기가 바뀌면 어긋나 아래가 남거나 잘렸다.
// 패널의 실제 위치를 재서 화면 끝까지 채운다 — 표만 스크롤하고 머리글은 고정된 채로.
const panelEl = ref(null)
const panelH = ref('')
const GAP = 10 // 화면 맨 아래에 남길 여백

function fitPanel() {
  const el = panelEl.value
  if (!el) return
  const top = el.getBoundingClientRect().top
  panelH.value = Math.max(320, Math.round(window.innerHeight - top - GAP)) + 'px'
}

let ro = null
onMounted(() => {
  fitPanel()
  window.addEventListener('resize', fitPanel)
  // 필터줄이 한 줄 ↔ 두 줄로 바뀔 때도 다시 잰다 (컬럼을 늘리면 실제로 바뀐다)
  if (window.ResizeObserver && panelEl.value) {
    ro = new ResizeObserver(fitPanel)
    const bar = panelEl.value.querySelector('.bar')
    if (bar) ro.observe(bar)
  }
  scrollBox()?.addEventListener('scroll', rememberScroll, { passive: true })
})
onUnmounted(() => {
  window.removeEventListener('resize', fitPanel)
  ro?.disconnect()
  scrollBox()?.removeEventListener('scroll', rememberScroll)
})

// ---------- 탭 전환 ----------
// 탭을 오갈 때 <KeepAlive> 가 화면 상태(필터·정렬)는 살려 주지만
// 표의 스크롤 위치는 지켜 주지 않는다 — DOM 이 떼어졌다 붙으면 브라우저가 0 으로 되돌린다.
//
// onDeactivated 에서 읽으면 늦다: KeepAlive 는 <먼저 DOM 을 떼어내고> 훅을 부르기 때문에
// 그때 scrollTop 은 이미 0 이다. 그래서 <스크롤할 때마다> 적어 둔다.
let keptScroll = 0
const scrollBox = () => panelEl.value?.querySelector(':scope > .scroll')
const rememberScroll = (e) => { keptScroll = e.target.scrollTop }
onActivated(async () => {
  // 숨어 있는 동안 창 크기가 바뀌었을 수 있으니 높이를 다시 잰다
  fitPanel()
  if (!keptScroll) return
  // 되붙은 직후에는 표가 아직 <스크롤할 수 없는 상태>라 scrollTop 이 0 으로 잘린다.
  // 렌더 한 박자 + 한 프레임을 기다린 뒤 맞춘다.
  await nextTick()
  const set = () => {
    const box = scrollBox()
    if (box && box.scrollHeight > box.clientHeight) box.scrollTop = keptScroll
  }
  set()
  requestAnimationFrame(set)
})
</script>

<template>
  <section ref="panelEl" class="panel rows" :style="{ height: panelH }">
    <h2 class="bar">
      상세 목록
      <span class="hint">
        {{ sortedRows.length }}건<template v-if="colFilterCount"> / 전체 {{ state.rows.length }}</template>
        {{ state.rowsLoading ? ' · 조회 중…' : '' }}
      </span>
      <span class="spacer"></span>
      <select :value="state.sel.month" title="월 필터" @change="onMonthPick($event.target.value)">
        <option value="">월 전체</option>
        <option v-for="m in state.monthly" :key="m.bucket" :value="m.bucket">
          {{ m.bucket }} · {{ m.cnt }}건
        </option>
      </select>
      <select :value="state.sel.week" title="주 필터" @change="onWeekPick($event.target.value)">
        <option value="">주 전체</option>
        <option v-for="w in state.weekly" :key="w.bucket" :value="w.bucket">
          {{ w.bucket }} ({{ w.week_start.slice(5) }}~{{ w.week_end.slice(5) }}) · {{ w.cnt }}건
        </option>
      </select>
      <select v-model="state.sel.done" title="완료 여부 필터">
        <option value="">완료 전체</option>
        <option value="y">완료만</option>
        <option value="n">미완료만</option>
      </select>
      <!-- 진척률 현황 화면의 항목별 목록과 같은 기준 -->
      <select
        v-model="state.sel.status"
        class="late"
        :class="{ on: !!state.sel.status }"
        title="진행 상태 — 착수도래: 계획시작일이 지나 계획진척률이 0% 를 넘은 건"
      >
        <option value="">상태 전체</option>
        <option value="open">착수도래 · 미완료</option>
        <option value="notyet">미도래</option>
        <option value="done">완료</option>
      </select>
      <!-- 지연 현황 화면과 같은 기준 (기준일 = DB 의 오늘) -->
      <select
        v-model="state.sel.late"
        class="late"
        :class="{ on: !!state.sel.late }"
        title="지연 필터 — 착수지연: 계획시작일이 지났는데 실적시작일 없음 / 종료지연: 계획종료일이 지났는데 실적종료일 없음"
      >
        <option value="">지연 전체</option>
        <option value="any">지연만 (하나라도)</option>
        <option value="start">착수지연</option>
        <option value="finish">종료지연</option>
        <option value="both">착수+종료 지연</option>
        <option value="none">지연 없음</option>
      </select>
      <select v-model="state.sel.user" title="담당자 필터">
        <option value="">담당자 전체</option>
        <option v-for="u in state.users" :key="u.user_bp_id" :value="u.user_bp_id">
          {{ u.user_nm }} ({{ u.user_bp_id }}) · {{ u.cnt }}건
        </option>
        <!-- 월/주를 바꿔 해당 담당자가 목록에서 빠져도 선택값은 유지한다 -->
        <option
          v-if="state.sel.user && !state.users.some((u) => u.user_bp_id === state.sel.user)"
          :value="state.sel.user"
        >
          {{ userName(state.sel.user) }} ({{ state.sel.user }}) · 0건
        </option>
      </select>
      <!-- 필터가 많아 자리가 빠듯하다 — 뜻이 분명한 것들은 아이콘만 남긴다 (뜻은 title 로).
           해제 두 개는 범위가 달라 아이콘을 달리했다: ⌫ = 컬럼필터 줄만, ⊘ = 필터 전부 -->
      <button
        v-if="colFilterCount"
        class="ico warn"
        :title="`컬럼필터만 해제 (${colFilterCount}개) — 위쪽 월·완료·지연 선택은 그대로 둡니다`"
        @click="clearColFilter"
      >
        ⌫<sup>{{ colFilterCount }}</sup>
      </button>

      <!-- 새 대상(화면) 추가 — 목록에 한 줄을 세우는 동작이라 컬럼·내보내기 아이콘 앞에 둔다.
           원장(hhip_wbs_wrk2)에 직접 넣으므로 Super 에게만 보인다 (isAdmin 이 아니다 —
           거기에는 <서버 장비에서 연 것>이 섞여 있다). 서버도 같은 기준으로 막는다. -->
      <button
        v-if="isSuper"
        class="ico addrow"
        title="대상 추가 — 엑셀 WBS 에 아직 없는 화면을 목록에 직접 세웁니다"
        @click="addPanel = true"
      >＋ 대상추가</button>

      <!-- 보고 싶은 컬럼 고르기 (팝업). 고른 값은 사용자별로 서버에 남는다.
           일부만 보고 있을 때는 몇 개인지 위첨자로 알려 준다 — 빈 자리를 보고 헤매지 않게. -->
      <button
        class="ico"
        :class="{ on: colPanel }"
        :title="`보이는 컬럼 고르기 — ${visibleCols.length}/${COLS.length} 선택` +
          (colStore.server
            ? ` · ${colStore.who} 님 설정으로 서버에 보관됩니다`
            : ' · 이 브라우저에만 저장됩니다')"
        @click="colPanel = true"
      >
        ▦<sup v-if="visibleCols.length < COLS.length">{{ visibleCols.length }}</sup>
      </button>

      <!-- ProjectView 데이터 수집 — PV 컬럼을 채우는 동작이라 컬럼 버튼 곁에 둔다.
           아직 걷은 적이 없으면 눈에 띄게 표시한다 (빈 PV 칸을 보고 헤매지 않게). -->
      <button
        v-if="isAdmin"
        class="ico"
        :class="{ warn: !pvLoaded }"
        :title="pvLoaded
          ? 'ProjectView 데이터 수집 — 진척률 · 실적시작일 · 일감(완료일 · 담당자 · 빈 단계)'
          : 'ProjectView 데이터 수집 — 아직 걷은 적이 없어 PV 컬럼이 비어 있습니다'
        "
        @click="pvPanel = true"
      >⛁</button>

      <!-- 단위테스트 상태 변경 — ProjectView 를 고치는 동작이라 수집 아이콘 곁에 둔다 -->
      <button
        v-if="isAdmin"
        class="ico"
        title="단위테스트 상태 변경 — ProjectView 테스트 절차의 status 를 한꺼번에 바꿉니다"
        @click="testPanel = true"
      >✔</button>

      <button class="ico" title="엑셀 내려받기 — 지금 보이는 컬럼과 행만 담습니다" @click="exportXlsx">⤓</button>
      <button
        v-if="hasFilter"
        class="ico warn"
        title="필터 전부 해제 — 월·주·완료·상태·지연·담당자 선택과 컬럼필터를 모두 지웁니다"
        @click="clearFilter"
      >⊘</button>
      <RefreshBtn :fn="reload" label="" title="다시 조회 (목록 · 담당자 · 집계 · 일감 건수)" />

      <p v-if="hasFilter || state.sort.col" class="fdesc">
        필터:
        <template v-if="state.sel.month">월 {{ state.sel.month }} </template>
        <template v-if="state.sel.week">주 {{ state.sel.week }} </template>
        <template v-if="state.sel.user">담당자 {{ userName(state.sel.user) }} ({{ state.sel.user }}) </template>
        <template v-if="state.sel.realUser">개발자 {{ state.sel.realUser }} </template>
        <template v-if="state.sel.module">모듈 {{ state.sel.module }} </template>
        <template v-if="state.sel.done">{{ state.sel.done === 'y' ? '완료만' : '미완료만' }} </template>
        <template v-if="state.sort.col">
          · 정렬 {{ COLS.find((c) => c.key === state.sort.col)?.label }}
          {{ state.sort.dir === 'asc' ? '오름차순' : '내림차순' }}
        </template>
      </p>
    </h2>

    <!-- 방금 추가한 대상 — 211건 사이에 끼어 어디 있는지 보이지 않으므로 찾아갈 길을 준다 -->
    <p v-if="added" class="pvhint addedbar">
      <strong>{{ added.activity_id || added.menu_nm }}</strong> 을(를) 추가했습니다.
      <template v-if="added.activity_id">
        일정·담당자 같은 나머지 값은 목록에서 바로 고칠 수 있습니다.
      </template>
      <template v-else>
        <b>Activity ID 가 없어</b> 아직 ProjectView 캐시·일감이 붙지 않습니다
        (수정·첨부는 됩니다) — Activity ID 칸의 <b>＋ ID</b> 로 채우면 평범한 줄이 됩니다.
      </template>
      <button class="lk" @click="findAdded">이 건만 보기</button>
      <button class="lk" @click="added = null">닫기</button>
    </p>

    <p v-if="saved" class="pvhint addedbar">
      <strong>{{ saved }}</strong> 을(를) 고쳤습니다.
      <button class="lk" @click="saved = ''">닫기</button>
    </p>

    <!-- 지운 뒤 — 되돌릴 수 없으므로 <어디에 남겼는지> 까지 적는다 -->
    <p v-if="gone" class="pvhint gonebar">
      <strong>{{ gone.activity_id || gone.menu_nm }}</strong> 을(를) 지웠습니다.
      <template v-if="gone.tasks">일감 {{ gone.tasks }}건도 함께 지웠습니다. </template>
      <template v-if="gone.tasks_kept">
        일감 {{ gone.tasks_kept }}건은 <b>남겼습니다</b> (같은 Activity ID 를 쓰는 줄이 더 있습니다).
      </template>
      <template v-if="gone.files">첨부 {{ gone.files }}건은 옮겨 두었습니다. </template>
      되돌릴 자료는 <code>api/data/deleted_rows/{{ gone.backup }}</code> 에 있습니다.
      <button class="lk" @click="gone = null">닫기</button>
    </p>

    <!-- PV 컬럼을 켰는데 아직 수집한 적이 없으면 알려 준다 (빈 칸만 보고 헤매지 않게) -->
    <p v-if="pvShown && !pvLoaded" class="pvhint">
      <strong>PV</strong> 컬럼은 ProjectView 에서 걷어 온 값입니다. 아직 수집한 적이 없어 비어 있습니다.
      <template v-if="isAdmin">
        위의 <strong>⛁</strong> 로 한 번 수집하면 진척률 · 실적시작일 · 현재단계 ·
        일감(완료일 · 담당자 · 빈 단계)이 이 목록에 함께 보입니다.
      </template>
      <template v-else>수집은 관리자가 합니다.</template>
    </p>

    <div class="scroll">
      <table>
        <thead>
          <tr>
            <th
              v-for="c in visibleCols"
              :key="c.key"
              class="sortable"
              :class="{ on: state.sort.col === c.key }"
              :title="`${c.label} 정렬 (클릭: 오름차순 → 내림차순 → 해제)`"
              @click="toggleSort(c.key)"
            >
              {{ c.label }}
              <span class="arw">
                {{ state.sort.col === c.key ? (state.sort.dir === 'asc' ? '▲' : '▼') : '⇅' }}
              </span>
            </th>
          </tr>
          <!-- 컬럼별 검색 필터 -->
          <tr class="fltr">
            <th v-for="c in visibleCols" :key="c.key" :style="{ minWidth: c.w + 'px' }">
              <select
                v-if="c.ftype === 'check'"
                v-model="state.colFilter[c.key]"
                :class="{ on: state.colFilter[c.key] }"
                :title="`${c.label} 필터`"
              >
                <option value="">전체</option>
                <option value="y">{{ checkWord(c.key, true) }}</option>
                <option value="n">{{ checkWord(c.key, false) }}</option>
              </select>
              <!-- 일감: 유무·미완료 여부로 필터 -->
              <select
                v-else-if="c.ftype === 'task'"
                v-model="state.colFilter[c.key]"
                :class="{ on: state.colFilter[c.key] }"
                title="일감 필터"
              >
                <option value="">전체</option>
                <option value="open">미완료 있음</option>
                <option value="done">전부 완료</option>
                <option value="none">일감 없음</option>
              </select>
              <!-- 담당자 · 개발자: 조회 결과에 있는 인원 목록에서 선택 -->
              <select
                v-else-if="c.ftype === 'pick'"
                v-model="state.colFilter[c.key]"
                :class="{ on: state.colFilter[c.key] }"
                :title="`${c.label} 필터`"
              >
                <option value="">{{ c.label }} 전체</option>
                <option v-for="o in colOptions[c.key]" :key="o.value" :value="o.value">
                  {{ o.label }} · {{ o.cnt }}
                </option>
              </select>
              <input
                v-else
                v-model="state.colFilter[c.key]"
                type="text"
                :placeholder="c.label"
                :title="`${c.label} 검색 (부분일치)`"
                :class="{ on: state.colFilter[c.key] }"
              />
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in sortedRows" :key="(r.activity_id || '') + r.menu_nm">
            <!-- 셀은 <고른 순서>대로 그린다. 머리글(thead)도 같은 visibleCols 를 도니
                 팝업에서 순서를 바꾸면 머리글과 본문이 함께 따라온다. -->
            <template v-for="c in visibleCols" :key="c.key">
              <!-- Activity ID — 누르면 ProjectView 로 가는 작은 메뉴가 뜬다
                   (작업 상세 · 일감 상세 · 단위테스트 상세). 예전에는 작업 상세로 바로 가는
                   링크였는데, 한 화면을 두고 볼 곳이 셋이라 고르게 했다.
                   <a> 를 그대로 둔 까닭: 가운데 버튼·Ctrl+클릭으로 예전처럼 작업 상세를
                   새 탭에 바로 열 수 있고, 주소 복사도 된다. 왼쪽 클릭만 메뉴로 가로챈다. -->
              <td v-if="c.key === 'activity_id'">
                <a
                  v-if="r.activity_id"
                  class="pvlink"
                  :href="pvWorkUrl(r)"
                  target="_blank"
                  rel="noopener noreferrer"
                  :title="`ProjectView 열기 — 작업 · 일감 · 단위테스트 (${r.activity_id})`"
                  @click="openPv($event, r)"
                >{{ r.activity_id }}</a>
                <!-- ID 없이 만든 줄 — 채워야 수정·PV 캐시·일감이 붙는다. 채우는 것은 Super 만. -->
                <button
                  v-else-if="isSuper"
                  class="setid"
                  title="나중에 확정된 Activity ID 를 채웁니다 — 채워야 수정·ProjectView 캐시·일감이 붙습니다"
                  @click="idRow = r"
                >＋ ID</button>
                <span v-else class="muted" title="Activity ID 가 아직 정해지지 않은 줄입니다">—</span>
              </td>
              <td v-else-if="c.key === 'systemcode'" class="nowrap">{{ r.systemcode }} {{ r.system_nm }}</td>
              <!-- 메뉴명 — 이 줄의 이름이다. 그래서 <이 줄 전체를 고치는> 버튼을 여기 둔다.
                   컬럼을 따로 세우면 211줄 내내 한 칸을 버리게 된다. -->
              <td v-else-if="c.key === 'menu_nm'" class="menunm">
                <!-- 메뉴명을 누르면 그 화면을 운영/개발 어느 쪽으로든 여는 작은 메뉴가 뜬다.
                     곁의 ✎ 는 <줄을 고치는> 것이라 서로 눌리지 않게 따로 둔다. -->
                <button
                  class="t"
                  title="이 화면 열기 — 운영 / 개발"
                  @click="openScreen($event, r)"
                >{{ r.menu_nm }}</button>
                <button
                  v-if="isSuper"
                  class="editrow"
                  title="대상 수정 — 이 줄의 모든 항목을 고칩니다"
                  @click="editRow = r"
                >✎</button>
              </td>

              <!-- 계획/실적 일자는 엑셀 WBS 가 원본 — 읽기 전용 -->
              <td
                v-else-if="c.key === 'plan_sdt'"
                class="ro"
                :class="{ late: r.start_late }"
                :title="r.start_late
                  ? `착수지연 ${r.start_days}일 — 계획시작일이 지났는데 실적시작일이 비어 있습니다`
                  : '계획시작일 (엑셀 WBS 기준 · 수정 불가)'"
              >{{ r.plan_sdt || '—' }}<sup v-if="r.start_late">{{ r.start_days }}</sup></td>
              <td
                v-else-if="c.key === 'plan_edt'"
                class="ro"
                :class="{ late: r.finish_late }"
                :title="r.finish_late
                  ? `종료지연 ${r.finish_days}일 — 계획종료일이 지났는데 실적종료일이 비어 있습니다`
                  : '계획종료일 (엑셀 WBS 기준 · 수정 불가)'"
              >{{ r.plan_edt || '—' }}<sup v-if="r.finish_late">{{ r.finish_days }}</sup></td>
              <td v-else-if="c.key === 'plan_sdt_c'" class="ro act" title="실적시작일 (수정 불가)">{{ r.plan_sdt_c || '—' }}</td>
              <td v-else-if="c.key === 'plan_edt_c'" class="ro act" title="실적종료일 (수정 불가)">{{ r.plan_edt_c || '—' }}</td>

              <!-- 담당자 (user_bp_id) — dev_user 에 없는 값은 미할당으로 보고 빈 셀로 표시 -->
              <td
                v-else-if="c.key === 'user_bp_id'"
                class="pick"
                :class="{ busy: busy(r, 'user_bp_id'), none: !r.user_nm }"
                :title="!r.user_nm && r.user_bp_id ? `미할당 (저장된 값: ${r.user_bp_id})` : ''"
                @click="startEdit(r, 'user_bp_id')"
              >
                <select
                  v-if="isEditing(r, 'user_bp_id')"
                  :value="r.user_bp_id ?? ''"
                  v-focus
                  @change="editing = null; save(r, 'user_bp_id', $event.target.value)"
                  @blur="editing = null"
                >
                  <option value="">(미지정)</option>
                  <option v-for="d in state.devUsers" :key="d.bp_id" :value="d.bp_id">
                    {{ d.name }} ({{ d.bp_id }})
                  </option>
                </select>
                <template v-else-if="r.user_nm">
                  <span class="nm">{{ r.user_nm }}</span>
                  <span class="uid">{{ r.user_bp_id }}</span>
                </template>
                <span v-else class="blank"></span>
              </td>

              <!-- 완료 (complate_yn) -->
              <td v-else-if="c.key === 'complate_yn'" class="ctr" :class="{ busy: busy(r, 'complate_yn') }">
                <input
                  type="checkbox"
                  :checked="r.complate_yn === 'o'"
                  :disabled="!r.activity_id"
                  title="완료 표시"
                  @change="save(r, 'complate_yn', $event.target.checked ? 'o' : '')"
                />
              </td>

              <!-- 개발자 (user_real_id) — 위와 동일 -->
              <td
                v-else-if="c.key === 'user_real_id'"
                class="pick"
                :class="{ busy: busy(r, 'user_real_id'), none: !r.user_real_nm }"
                :title="!r.user_real_nm && r.user_real_id ? `미할당 (저장된 값: ${r.user_real_id})` : ''"
                @click="startEdit(r, 'user_real_id')"
              >
                <select
                  v-if="isEditing(r, 'user_real_id')"
                  :value="r.user_real_id ?? ''"
                  v-focus
                  @change="editing = null; save(r, 'user_real_id', $event.target.value)"
                  @blur="editing = null"
                >
                  <option value="">(미지정)</option>
                  <option v-for="d in state.devUsers" :key="d.bp_id" :value="d.bp_id">
                    {{ d.name }} ({{ d.bp_id }})
                  </option>
                </select>
                <template v-else-if="r.user_real_nm">
                  <span class="nm">{{ r.user_real_nm }}</span>
                  <span class="uid">{{ r.user_real_id }}</span>
                </template>
                <span v-else class="blank"></span>
              </td>

              <!-- 개발자완료 (complate_real_yn) -->
              <td v-else-if="c.key === 'complate_real_yn'" class="ctr" :class="{ busy: busy(r, 'complate_real_yn') }">
                <input
                  type="checkbox"
                  :checked="r.complate_real_yn === 'o'"
                  :disabled="!r.activity_id"
                  title="개발자 완료 표시"
                  @change="save(r, 'complate_real_yn', $event.target.checked ? 'o' : '')"
                />
              </td>

              <!-- 재확인요청 (recheck_yn) — 개발자에게 다시 확인해 달라는 표시 -->
              <td v-else-if="c.key === 'recheck_yn'" class="ctr recheck" :class="{ busy: busy(r, 'recheck_yn'), on: r.recheck_yn === 'o' }">
                <input
                  type="checkbox"
                  :checked="r.recheck_yn === 'o'"
                  :disabled="!r.activity_id"
                  title="개발자에게 재확인 요청 — 체크하면 사유를 남길 일감 창이 열립니다"
                  @change="onRecheck(r, $event.target.checked)"
                />
              </td>

              <!-- 대형 3종 — 위 세 개와 같은 방식으로 즉시 저장한다 -->
              <td
                v-else-if="c.key === 'complate_big_yn'"
                class="ctr"
                :class="{ busy: busy(r, 'complate_big_yn') }"
              >
                <input
                  type="checkbox"
                  :checked="r.complate_big_yn === 'o'"
                  :disabled="busy(r, 'complate_big_yn')"
                  title="대형 완료 표시"
                  @change="save(r, 'complate_big_yn', $event.target.checked ? 'o' : '')"
                />
              </td>
              <td
                v-else-if="c.key === 'complate_real_big_yn'"
                class="ctr"
                :class="{ busy: busy(r, 'complate_real_big_yn') }"
              >
                <input
                  type="checkbox"
                  :checked="r.complate_real_big_yn === 'o'"
                  :disabled="busy(r, 'complate_real_big_yn')"
                  title="대형 개발자 완료 표시"
                  @change="save(r, 'complate_real_big_yn', $event.target.checked ? 'o' : '')"
                />
              </td>
              <td
                v-else-if="c.key === 'recheck_big_yn'"
                class="ctr recheck"
                :class="{ busy: busy(r, 'recheck_big_yn'), on: r.recheck_big_yn === 'o' }"
              >
                <input
                  type="checkbox"
                  :checked="r.recheck_big_yn === 'o'"
                  :disabled="busy(r, 'recheck_big_yn')"
                  title="대형 재확인 요청 — 체크하면 사유를 남길 일감 창이 열립니다"
                  @change="onRecheck(r, $event.target.checked, 'recheck_big_yn')"
                />
              </td>

              <!-- 대형DB준비여부 — 다른 대형 항목과 같은 방식으로 바로 체크한다 -->
              <td
                v-else-if="c.key === 'db_ready_big_yn'"
                class="ctr dbready"
                :class="{ busy: busy(r, 'db_ready_big_yn'), on: r.db_ready_big_yn === 'o' }"
              >
                <input
                  type="checkbox"
                  :checked="r.db_ready_big_yn === 'o'"
                  :disabled="busy(r, 'db_ready_big_yn')"
                  title="대형 DB 준비여부"
                  @change="save(r, 'db_ready_big_yn', $event.target.checked ? 'o' : '')"
                />
              </td>

              <!-- 도면조회여부 — 다른 체크 컬럼과 같은 방식으로 바로 켜고 끈다.
                   Activity ID 가 없는 줄은 수정 경로가 그 값을 키로 쓰므로 막아 둔다. -->
              <td
                v-else-if="c.key === 'dwg_view_use'"
                class="ctr dwg"
                :class="{ busy: busy(r, 'dwg_view_use'), on: r.dwg_view_use === 'o' }"
              >
                <input
                  type="checkbox"
                  :checked="r.dwg_view_use === 'o'"
                  :disabled="busy(r, 'dwg_view_use') || !r.activity_id"
                  title="도면 조회 사용 여부"
                  @change="save(r, 'dwg_view_use', $event.target.checked ? 'o' : '')"
                />
              </td>

              <!-- 리포트 사용여부 — 도면조회와 같은 짝이다 (화면 속성 중 'o' 한 글자로 쓰는 것) -->
              <td
                v-else-if="c.key === 'report_use'"
                class="ctr dwg"
                :class="{ busy: busy(r, 'report_use'), on: r.report_use === 'o' }"
              >
                <input
                  type="checkbox"
                  :checked="r.report_use === 'o'"
                  :disabled="busy(r, 'report_use') || !r.activity_id"
                  title="리포트 사용 여부"
                  @change="save(r, 'report_use', $event.target.checked ? 'o' : '')"
                />
              </td>

              <!-- 화면설계 문서 첨부 — 일감 배지와 같은 모양이다 (둘 다 그 줄에 딸린 것의 개수) -->
              <td v-else-if="c.key === 'file_cnt'" class="ctr task" :class="{ zero: !fileOf(r) }">
                <button
                  class="tbadge"
                  :class="{ has: fileOf(r) > 0 }"
                  :title="fileOf(r) ? `화면설계 문서 ${fileOf(r)}건 — 클릭하면 보기·추가` : '첨부 없음 — 클릭하면 추가'"
                  @click="openFiles(r)"
                >
                  <template v-if="fileOf(r)">📎 {{ fileOf(r) }}</template>
                  <template v-else>+</template>
                </button>
              </td>

              <!-- 우선순위: 클릭하면 선택 -->
              <td
                v-else-if="c.key === 'priority_order'"
                class="pick ctr"
                :class="{ busy: busy(r, 'priority_order') }"
                @click="startEdit(r, 'priority_order')"
              >
                <select
                  v-if="isEditing(r, 'priority_order')"
                  :value="r.priority_order ?? ''"
                  v-focus
                  @change="editing = null; save(r, 'priority_order', $event.target.value)"
                  @blur="editing = null"
                >
                  <option value="">(없음)</option>
                  <option v-for="p in PRIORITIES" :key="p" :value="p">{{ p }}</option>
                </select>
                <template v-else>{{ r.priority_order || '—' }}</template>
              </td>
              <td v-else-if="c.key === 'prog_type'" class="nowrap muted">{{ r.prog_type }}</td>
              <td v-else-if="c.key === 'trg_use_chk'" class="trg" :class="trgClass(r.trg_use_chk)" :title="r.trg_use_chk || ''">
                {{ r.trg_use_chk || '' }}
              </td>

              <!-- 일감 건수 — 클릭하면 일감 관리 다이얼로그 -->
              <td v-else-if="c.key === 'task_cnt'" class="ctr task" :class="{ zero: !taskOf(r).cnt }">
                <button
                  class="tbadge"
                  :class="{ open: taskOf(r).done < taskOf(r).cnt, alldone: taskOf(r).cnt && taskOf(r).done === taskOf(r).cnt }"
                  :title="taskOf(r).cnt ? `일감 ${taskOf(r).done}/${taskOf(r).cnt} 완료 — 클릭하면 관리` : '일감 없음 — 클릭하면 추가'"
                  :disabled="!r.activity_id"
                  @click="openTasks(r)"
                >
                  <template v-if="taskOf(r).cnt">{{ taskOf(r).done }}/{{ taskOf(r).cnt }}</template>
                  <template v-else>+</template>
                </button>
              </td>

              <!-- 계획진척률 — 착수도래 여부를 눈으로 확인할 수 있게 막대로 보여 준다 -->
              <td v-else-if="c.key === 'plan_rate'" class="prate">
                <template v-if="r.plan_rate != null">
                  <span class="bar"><i :style="{ width: r.plan_rate + '%' }" :class="{ full: r.plan_rate >= 100 }"></i></span>
                  <span class="pct">{{ r.plan_rate }}%</span>
                </template>
                <span v-else class="muted">—</span>
              </td>

              <!-- ProjectView 캐시 — 수집 전에는 전부 '—' 다 -->
              <!-- 현재단계 — ProjectView 화면과 같은 '(90%) PI검토' 모양으로 보여 준다.
                   누르면 ProjectView 일감 상세가 새 창으로 열린다. -->
              <td v-else-if="c.key === 'pv_status'" class="pv stage">
                <!-- 단계 값이 없어도 일감 코드만 있으면 눌러서 ProjectView 로 갈 수 있다.
                     단계는 수집해야 채워지지만, 일감을 열어 보는 일은 그와 무관하게 필요하다. -->
                <a
                  v-if="pvTaskUrl(r)"
                  class="chip link"
                  :class="r.pv_status ? stageClass(r.pv_status) : 'none'"
                  :href="pvTaskUrl(r)"
                  target="_blank"
                  rel="noopener noreferrer"
                  :title="stageTip(r) + ` · 누르면 ProjectView 일감 ${r.pv_task_code} 상세가 새 창으로 열립니다`"
                >{{ r.pv_status ? pvStageText(r) : r.pv_task_code }}</a>
                <!-- 일감 코드조차 없으면 열 곳이 없다 (캐시를 한 번도 수집하지 않은 건) -->
                <span v-else class="muted" :title="stageTip(r)">—</span>
              </td>
              <td v-else-if="c.key === 'pv_finish_rate'" class="num pv" :title="pvTip(r)">
                {{ r.pv_finish_rate == null ? '—' : r.pv_finish_rate + '%' }}
              </td>
              <td v-else-if="c.key === 'pv_actual_sdt'" class="pv" :class="{ diff: sdtDiff(r) }" :title="sdtDiff(r) ? `WBS ${r.plan_sdt_c || '(없음)'} ↔ PV ${r.pv_actual_sdt || '(없음)'}` : ''">
                {{ r.pv_actual_sdt || '—' }}
              </td>
              <td v-else-if="c.key === 'pv_task_cnt'" class="num pv">{{ r.pv_task_cnt ?? '—' }}</td>
              <td v-else-if="c.key === 'pv_task_edt'" class="pv">{{ r.pv_task_edt || '—' }}</td>
              <td v-else-if="c.key === 'pv_workers'" class="pv ell" :title="r.pv_workers || ''">{{ r.pv_workers || '—' }}</td>
              <td v-else-if="c.key === 'pv_node_empty'" class="num pv" :class="{ warn: r.pv_node_empty > 0 }"
                  :title="r.pv_node_cnt ? `워크플로 단계 ${r.pv_node_cnt}개 중 일자·담당자가 빈 것 ${r.pv_node_empty}개` : ''">
                {{ r.pv_node_empty ?? '—' }}
              </td>
              <td v-else-if="c.key === 'pv_snapshot_at'" class="pv sm">{{ (r.pv_snapshot_at || '').slice(0, 16) || '—' }}</td>
            </template>
          </tr>
          <tr v-if="!sortedRows.length && !state.rowsLoading">
            <td :colspan="visibleCols.length" class="muted" style="text-align: center; padding: 20px">데이터 없음</td>
          </tr>
        </tbody>
      </table>
    </div>

    <p class="muted note">
    </p>
  </section>

  <ColumnDialog v-if="colPanel" @close="colPanel = false" />
  <PvCollectDialog v-if="pvPanel" @close="pvPanel = false" @saved="loadRows()" />

  <!-- 추가된 뒤에는 목록·담당자·집계를 모두 다시 읽는다 (건수와 모듈 목록이 함께 바뀐다) -->
  <!-- 추가와 수정이 같은 창이다 (입력칸이 37개라 두 벌로 두면 한쪽만 고쳐진다).
       row 를 주면 수정, 안 주면 추가. -->
  <RowFormDialog v-if="addPanel" @close="addPanel = false" @created="onAdded" />
  <RowFormDialog v-if="editRow" :row="editRow" @close="editRow = null" @saved="onSaved" @deleted="onDeleted" />
  <SetIdDialog v-if="idRow" :row="idRow" @close="idRow = null" @saved="onIdSet" />

  <!-- 지금 목록에 보이는 행을 넘겨 준다 — 필터·정렬이 걸린 그대로가 대상이 된다 -->
  <TestStatusDialog v-if="testPanel" :rows="sortedRows" @close="testPanel = false" />

  <TaskDialog
    v-if="taskRow"
    :row="taskRow"
    :prefill="taskPrefill"
    @close="closeTasks"
    @changed="loadTaskCounts"
  />

  <!-- 메뉴명을 누른 자리에 뜨는 화면 열기 메뉴 (운영 / 개발) -->
  <ScreenMenu
    v-if="screenMenu"
    :row="screenMenu.row"
    :x="screenMenu.x"
    :y="screenMenu.y"
    @close="screenMenu = null"
  />

  <!-- Activity ID 를 누른 자리에 뜨는 ProjectView 메뉴 (작업 / 일감 / 단위테스트) -->
  <PvMenu
    v-if="pvMenu"
    :row="pvMenu.row"
    :x="pvMenu.x"
    :y="pvMenu.y"
    @close="pvMenu = null"
  />

  <!-- 화면설계 문서 — 올리거나 지우면 목록의 [첨부] 배지를 다시 센다 -->
  <RowFilesDialog
    v-if="fileRow"
    :row="fileRow"
    @close="fileRow = null"
    @changed="loadFileCounts"
  />
</template>

<style scoped>
/* 컬럼 고르기 패널 */
/* 컬럼 설정이 서버(사용자별)에 보관 중임을 알리는 작은 점 */
.synced { color: var(--done); font-weight: 700; margin-left: 3px; }
/* 아이콘만 있는 버튼 — 글자 버튼과 높이를 맞추고 가로만 줄인다 */
button.ico { padding: 4px 8px; font-size: 13px; line-height: 1.15; }
button.ico sup { font-size: 9px; margin-left: 1px; vertical-align: super; }
/* 해제 버튼은 <지금 무언가 걸려 있다> 는 신호이기도 하다 — 눈에 띄게 둔다 */
button.ico.warn { border-color: var(--warn); color: var(--warn); }
button.ico.warn:hover { background: var(--warn-soft); }
/* 대상추가만 글자를 달고 있다 — 아이콘 한 자로는 <무엇을> 추가하는지 전해지지 않는다 */
button.ico.addrow { font-size: 11.5px; font-weight: 600; white-space: nowrap; }
/* Activity ID 가 아직 없는 줄 — 빈 칸이 아니라 <채울 자리> 로 보이게 둔다 */
button.setid {
  padding: 0 6px; font-size: 10.5px; line-height: 17px;
  border-style: dashed; color: var(--warn); border-color: var(--warn); background: none;
}
button.setid:hover { background: var(--warn-soft); }
/* 메뉴명 칸의 수정 버튼 — 평소에는 흐리게 두고 줄에 손이 가면 또렷해진다.
   211줄 내내 또렷하면 정작 읽어야 할 메뉴명이 묻힌다. */
td.menunm { display: flex; align-items: center; gap: 4px; }
/* 메뉴명은 이제 누를 수 있는 것이다 — 버튼이지만 표의 글자처럼 보여야 줄이 시끄럽지 않다.
   누를 수 있다는 것은 가리켰을 때 밑줄로만 알린다. */
td.menunm .t {
  flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  border: 0; background: none; padding: 0; margin: 0;
  font: inherit; color: inherit; text-align: left; cursor: pointer;
}
td.menunm .t:hover { color: var(--accent); text-decoration: underline; }
button.editrow {
  flex: none; padding: 0 5px; font-size: 11px; line-height: 17px;
  border-color: transparent; background: none; color: var(--muted-3);
}
tbody tr:hover button.editrow { color: var(--muted); border-color: var(--line); }
button.editrow:hover { color: var(--accent); border-color: var(--accent); background: var(--panel); }
/* 목록이 길어도 필터줄과 컬럼 머리글은 항상 보이도록 고정한다.
   표 영역만 세로로 스크롤시키고(thead sticky), 필터줄은 뷰포트 상단에 붙인다. */
.bar {
  position: sticky;
  top: 0;
  z-index: 5;
  background: var(--panel);
  margin: -12px -14px 8px;
  padding: 10px 14px 8px;
  border-bottom: 1px solid var(--line);
  flex-wrap: wrap;
}
.bar .spacer { flex: 1; }
.fdesc { flex-basis: 100%; margin: 4px 0 0; font-weight: 400; color: var(--muted); }

/* 패널이 화면 끝까지 차지하고, 그 안에서 표만 스크롤한다.
   min-height:0 이 없으면 flex 항목이 내용 높이 아래로 줄지 않아 표가 화면을 넘어간다. */
.panel.rows { display: flex; flex-direction: column; overflow: hidden; margin-bottom: 0; }
.panel.rows > .scroll { flex: 1 1 auto; min-height: 0; overflow: auto; }
.panel.rows > .bar,
.panel.rows > .pvhint,
.panel.rows > .note { flex: none; }
/* 1행 = 컬럼명(정렬), 2행 = 컬럼 검색 필터. 둘 다 스크롤 시 고정한다. */
thead tr:first-child th {
  position: sticky;
  top: 0;
  z-index: 3;
  background: var(--panel);
}
thead tr.fltr th {
  position: sticky;
  top: 28px;
  z-index: 2;
  background: var(--panel);
  padding: 3px 5px;
  box-shadow: inset 0 -1px 0 var(--line);
}
thead tr.fltr input,
thead tr.fltr select {
  width: 100%;
  padding: 2px 5px;
  font-size: 11.5px;
  font-weight: 400;
  border: 1px solid var(--line);
  border-radius: 4px;
  background: var(--panel);
}
thead tr.fltr input.on,
thead tr.fltr select.on { border-color: var(--accent); background: var(--accent-soft); color: var(--accent); }
thead tr.fltr input:focus, thead tr.fltr select:focus { outline: none; border-color: var(--accent); }

.nowrap { white-space: nowrap; }
th.sortable { cursor: pointer; user-select: none; white-space: nowrap; }
th.sortable:hover { color: var(--accent); }
th.sortable.on { color: var(--accent); }
th .arw { font-size: 9px; margin-left: 3px; opacity: 0.4; }
th.sortable.on .arw { opacity: 1; }

/* 읽기 전용 일자 컬럼 — 실적(act)은 옅은 녹색 톤으로 계획과 구분 */
td.ro { white-space: nowrap; font-variant-numeric: tabular-nums; }
td.ro.act { background: var(--done-soft); }
td.pick.ctr select { width: 68px; }
td.pick { cursor: pointer; white-space: nowrap; }
td.pick:hover { background: var(--accent-soft); }
/* 미할당 셀은 비워 두되 옅은 빗금으로 표시해 한눈에 찾을 수 있게 한다 */
td.pick.none {
  background: repeating-linear-gradient(
    -45deg, transparent, transparent 5px, var(--surface) 5px, var(--surface) 10px
  );
}
td.pick.none:hover { background: var(--accent-soft); }
.blank { display: inline-block; min-width: 90px; }

/* 트리거 발화 — 길어서 한 줄로 줄이고 전체 내용은 툴팁으로 */
td.trg {
  max-width: 260px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
td.trg.none { color: var(--muted); }
td.trg.warn { color: var(--warn); }
td.trg.fire { color: var(--accent); font-weight: 600; }

/* 일감 건수 배지 */
td.task { text-align: center; }
.tbadge {
  min-width: 46px;
  padding: 1px 7px;
  border-radius: 10px;
  border: 1px solid var(--line);
  background: var(--panel);
  color: var(--muted);
  font-size: 11px;
  font-variant-numeric: tabular-nums;
  cursor: pointer;
}
.tbadge:hover { border-color: var(--accent); color: var(--accent); }
.tbadge.open { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); font-weight: 600; }
.tbadge.alldone { background: var(--done-soft); border-color: var(--done); color: var(--done); font-weight: 600; }
.tbadge:disabled { opacity: 0.35; cursor: not-allowed; }
/* 첨부가 있는 줄 — 일감의 '진행 중'과 같은 강조를 쓴다 (둘 다 <볼 것이 있다> 는 뜻) */
.tbadge.has { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); font-weight: 600; }
td.task.zero .tbadge { color: var(--muted-3); }
td.pick select { width: 150px; }
td.ctr { text-align: center; }
td.ctr input[type='checkbox'] { cursor: pointer; accent-color: var(--done); }
/* 재확인요청은 눈에 띄어야 하므로 켜진 칸을 주황으로 강조 */
td.recheck input[type='checkbox'] { accent-color: var(--warn); }
td.recheck.on { background: var(--warn-soft); box-shadow: inset 0 0 0 1px var(--warn-line); }
/* 대형DB준비여부 — 준비됨은 완료 계열과 같은 초록으로 */
td.dbready input[type='checkbox'] { accent-color: var(--done); }
td.dbready.on { background: var(--done-soft); box-shadow: inset 0 0 0 1px var(--done); }
td.busy { opacity: 0.45; }
/* ProjectView 캐시 컬럼 — 우리 값이 아니라는 것이 보이게 살짝 눌러 둔다 */
td.pv { background: var(--surface); color: var(--text); }
td.pv.sm { font-size: 11px; color: var(--muted); }
td.pv.warn { color: var(--warn); font-weight: 600; }
td.pv.diff { color: var(--warn); font-weight: 600; }
td.pv.ell { max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* 현재단계 — 단계 성격별로 색을 달리해 표를 훑을 때 눈에 걸리게 한다 */
td.pv.stage { white-space: nowrap; }
td.pv .chip {
  display: inline-block;
  padding: 1px 7px;
  border-radius: 10px;
  font-size: 11px;
  font-weight: 600;
  border: 1px solid transparent;
}
td.pv .chip.done   { background: var(--done-soft); border-color: var(--done); color: var(--done); }
td.pv .chip.review { background: var(--warn-soft); border-color: var(--warn-line); color: var(--warn); }
td.pv .chip.dev    { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); }
td.pv .chip.todo   { background: var(--fill); border-color: var(--line); color: var(--muted); }
/* 단계를 아직 모르는 건 — 일감 코드만 조용히 보여 준다 (눌러서 열 수는 있다) */
td.pv .chip.none { background: transparent; border-color: var(--line); color: var(--muted); font-weight: 400; }
/* 링크로 쓰이는 칩 — 누를 수 있다는 것이 보이게 한다 */
td.pv a.chip.link { text-decoration: none; cursor: pointer; }
td.pv a.chip.link:hover { filter: brightness(0.96); text-decoration: underline; }

/* Activity ID 링크 — 평소엔 본문 글자처럼 두고, 올렸을 때만 링크임을 알린다 */
a.pvlink { color: inherit; text-decoration: none; }
a.pvlink:hover { color: var(--accent); text-decoration: underline; }
/* 지연 — 지연 현황 화면과 같은 색을 쓴다 */
td.late { color: var(--warn); font-weight: 600; }
td.late sup { font-size: 9px; margin-left: 2px; font-weight: 400; }
select.late.on { border-color: var(--warn); color: var(--warn); }

/* 계획진척률 */
td.prate { white-space: nowrap; }
td.prate .bar {
  display: inline-block;
  width: 44px;
  height: 6px;
  background: var(--line-soft);
  border-radius: 3px;
  overflow: hidden;
  vertical-align: middle;
}
td.prate .bar i { display: block; height: 100%; background: var(--accent); }
td.prate .bar i.full { background: var(--done); }
td.prate .pct { margin-left: 5px; font-size: 11px; color: var(--muted); }
.pvhint {
  margin: -4px 0 10px;
  font-size: 11.5px;
  color: var(--muted);
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 6px;
  padding: 6px 10px;
}
.pvhint strong { color: var(--text); }
.pvhint a { color: var(--accent); }
/* 방금 추가한 건 안내 — 안내가 아니라 <할 일이 남은 줄> 이라 조금 더 눈에 띄게 둔다 */
.pvhint.addedbar { background: var(--done-soft); border-color: var(--done-line); color: var(--done); }
.pvhint.addedbar strong { color: var(--done); }
.pvhint.addedbar .lk { padding: 1px 7px; font-size: 11px; margin-left: 6px; }
/* 지운 안내는 초록(저장)과 같은 색일 수 없다 — 되돌릴 수 없는 일이다 */
.pvhint.gonebar { background: var(--danger-soft); border-color: var(--danger-line); color: var(--danger-text); }
.pvhint.gonebar strong { color: var(--danger-text); }
.pvhint.gonebar code { font-size: 11px; }
.pvhint.gonebar .lk { padding: 1px 7px; font-size: 11px; margin-left: 6px; }
td .nm { font-weight: 600; }
td .uid { color: var(--muted); font-size: 11px; margin-left: 5px; font-variant-numeric: tabular-nums; }
.note { margin: 8px 0 0; }
</style>
