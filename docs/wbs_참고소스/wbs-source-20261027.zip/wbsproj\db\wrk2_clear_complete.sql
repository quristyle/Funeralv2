-- 원장(hhip_wbs_wrk2)의 <완료> · <개발자완료> 체크를 모두 비운다.
--   complate_yn       = 완료
--   complate_real_yn  = 개발자완료
--
-- 대형(complate_big_yn · complate_real_big_yn)은 건드리지 않는다 — 지시에 없다.
--
-- wrk2 는 화면 단위라 activity_id 가 중복될 수 있어 키로 되돌릴 수 없다.
-- 그래서 표를 통째로 떠 둔다. 되돌릴 때는 백업 표에서 다시 채운다(아래 주석 참고).

begin;

-- 1) 통째로 백업 (같은 이름이 있으면 지우고 다시 뜬다)
drop table if exists public.hhip_wbs_wrk2_bak_complete;
create table public.hhip_wbs_wrk2_bak_complete as
    select * from public.hhip_wbs_wrk2;

-- 2) 비우기
update public.hhip_wbs_wrk2
   set complate_yn = null
 where complate_yn is not null;

update public.hhip_wbs_wrk2
   set complate_real_yn = null
 where complate_real_yn is not null;

commit;

-- 되돌리려면 (ctid 로 한 줄씩 맞출 수 없으므로 표를 통째로 되돌린다):
--   begin;
--   truncate public.hhip_wbs_wrk2;
--   insert into public.hhip_wbs_wrk2 select * from public.hhip_wbs_wrk2_bak_complete;
--   commit;
