-- ---------------------------------------------------------------------------
-- ProjectView cache, part 2 - workflow nodes.
--
-- Goal: sync a Rows.vue line against ProjectView in one shot -
--   progress rate / actual start date / tasks / task end date / task charger.
-- Part 1 (db/pv_cache.sql) covered the first two plus task identity.
-- This adds what the workflow screen needs so it stops re-reading everything.
-- ---------------------------------------------------------------------------

-- task level rollup
alter table public.hhip_wbs_pv_task add column if not exists pv_charger_id varchar(40);
alter table public.hhip_wbs_pv_task add column if not exists pv_charger_nm text;
alter table public.hhip_wbs_pv_task add column if not exists pv_status     text;

comment on column public.hhip_wbs_pv_task.pv_charger_id is 'ProjectView user id (USR-...) found on the task itself.';
comment on column public.hhip_wbs_pv_task.pv_status     is 'Current workflow stage name of the task.';

-- one row per workflow node of a task.
-- node_no is the position in the workflow array: node ids are not always present
-- and the order is what the screen shows.
create table if not exists public.hhip_wbs_pv_node (
  pv_task_id   varchar(60)  not null,
  node_no      integer      not null,
  node_id      varchar(60),
  stage_nm     text,
  node_dt      date,
  worker_id    varchar(40),
  worker_nm    text,
  updated_at   timestamp default now(),
  primary key (pv_task_id, node_no)
);

comment on table public.hhip_wbs_pv_node is 'ProjectView workflow nodes (stage / date / charger) per task. Cache only.';

create index if not exists ix_hhip_wbs_pv_node_task on public.hhip_wbs_pv_node (pv_task_id);
