# 자재 업무흐름 시나리오

> 출처: HHIP-자재-DE-09(업무흐름시나리오) V2.0 · 2026-10-07 추출
> 이 파일을 고치면 화면이 그대로 바뀝니다. 아래 **적는 법**만 지키면 됩니다.
>
> - `## 제목` 은 한 묶음(섹션)입니다.
> - 섹션 바로 아래 `형태:` 로 그리는 방식을 고릅니다 — `흐름`(차례대로) · `지도`(격자) · `표`(행렬). 안 적으면 `흐름`.
> - `### 코드 이름` 은 네모 한 칸입니다.  `@` 는 담당부서,  `-` 는 설명 줄,  `→` 는 다음 칸으로 가는 화살표 글씨입니다.
> - `A → B : 글씨` 는 칸과 칸 사이의 자료 흐름입니다 (지도에서 씁니다).
> - `표` 형태에서는 그냥 마크다운 표를 적으면 됩니다.

## 1. 업무 흐름 (Business Flow)
형태: 표

| Production Dep’t | Cost Control & Accounting Dep’t | Material Purchasing Dep’t | Supplier | Material Control Dep’t | Production Dep’t |
|---|---|---|---|---|---|
| Retrieval of stock |  | Receipt of POR |  | Inspection of material |  |
| Registration of POR | Control of budget | Request of estimation | Estimation | Warehousing | Warehousing confirmation |
| Request of POR approval |  | Selection of maker |  |  | Issue registration |
|  |  | Purchase approval |  |  | Issue sheet print |
|  |  | Print of purchase order sheet | Receiving an Order | Issue | Receipt of material |
|  |  |  | Delivered Goods | Closing of settlement |  |
| Registration of issue request sheet |  |  |  |  |  |
|  |  |  | Specification of Dealings (Delivery Note) | Print of Closing Report |  |
| Print of request sheet |  |  |  |  |  |
| Maker | Closing Report |  |  | Writing of account slip |  |
| Payment of cost |  |  |  |  |  |

## 2-1. 시스템 흐름 지도 (System Flow Map 1)
형태: 표

| Process | Domestic / Stock | Outfitting | Long term | Pipe Spool | Oversea(HMD) |
|---|---|---|---|---|---|
| Registration of POR | [2110] 일반재 요청 | [2110] 일반재 요청 |  | [2110] 일반재 요청 | [2110] 일반재 요청 |
| Receipt of POR | [2310] 일반재 POR 접수 | [2310] 일반재 POR 접수 |  |  |  |
| Quotation | [3110]견적<br>[I210]견적 승인<br>[web]1.2 View Request Detail<br>[web]1.3 Make QuOtatiOn | [3110]견적<br>[3170]승인 대기<br>[I210]견적 승인<br>[3D30]신규 견적용 POR 선택<br>[3D10]공급업체별 자재그룹 및 계약금액<br>[web]1.6 Make Oufitting Material Quotation |  | [3E10]PIPE SPOOL 단가 관리<br>[3E60]파이프 스풀 POR 리스트<br>[3E70]파이프 스풀 POR 견적 리스트<br>[I210]견적 승인<br>[web]1.2 View Request Detail<br>[web]1.3 Make Quotation | [3390]구매 발주량 검색<br>[3410]HMD 견적<br>[3440]HMD로부터 수정 견적 접수<br>[3610]HMD로부터 계약서 접수<br>[3640]계약서 비교 |
| Bidding | [3120]재견적<br>[3130]가격표시 (PI 견적)<br>[web]2.1 P/I Request List<br>[web]2.2 View P/I Request Detail<br>[web]2.3 Make P/I<br>[3150]입찰<br>[3160]재입찰<br>[web]3.1 Bidding Request List<br>[web]3.2 View Bidding Request<br>[web]3.3 Make Bidding | [3D40]견적 상세 정보<br>[3D50]견적 비교 |  | [3E90]파이프 스풀 견적 비교 |  |
| Purchase Order | [3180]구매 발주<br>[web]4.1 P.O. List<br>[web]4.2 View P.O. Detail<br>[web]4.3 Success List<br>[web]4.4 Success Detail<br>[web]4.5 Approved QuOtation | [3180]구매 발주<br>[3320]구매 발주 관리 (국내/해외)<br>[3B40]공급업체 및 제조업체에 PO 변경 요청 | [3010]장기 계약 자재 등록<br>[3360]장기 계약<br>[3B40]공급업체 및 제조업체에 PO 변경 요청 | [3180]구매 발주<br>[[web]90.4 Invoice Control | [3670]공급 계약<br>[I230]HMD 계약 승인<br>[I240]HMD에 POR 전송 승인 |

## 2-2. 시스템 흐름 지도 (System Flow Map 2)
형태: 표

| Process | Domestic | Korea 호선재 | Vietnam |
|---|---|---|---|
| Warehousing | [web]5.1 Delivery Note list<br>[web]5.2 Make Delivery note<br>[web]5.3 Delivery list by period<br>[web]5.4 Delivery Status by P.O<br>[web]5.5 Not yet Warehousing<br>[web]5.6 Warehousing by Period<br>[web]5.7 Delivery Plan Control<br>[4110]납품서별 입고<br>[4190]국내자재 입고 조회 | [4250]선적 스케줄 점검<br>[4220]B/L 접수<br>[4280]B/L 자재 상세 리스트<br>[4290]B/L 정보 점검<br>[4310]외자재 입고<br>[4320]일일 입고 리스트<br>[4330] 호선재 계약/POR별 입고 리스트<br>[4740]의장자재 입고 현황 | [web]5.2 Make Delivery note<br>[4250]선적 스케줄 점검<br>[4240]선적정보 점검<br>[4220]B/L 접수<br>[4280]B/L 자재 상세 리스트<br>[4290]B/L 정보 점검<br>[4310]외자재 입고<br>[4320]일일 입고 리스트<br>[4330] 호선재 계약/POR별 입고 리스트<br>[4740]의장자재 입고 현황 |
| Issue | [5120]POR 불출 예약 관리(POR Mat. RES)<br>[5180]창고별 배송 관리<br>[51B0]일반재 불출 확인 관리 | [5150]직불출<br>[5130]신조 배송(Delivery for New Building. RES)<br>[5110]재고 불출 예약 관리(Stock Mat. RES)<br>[5120]POR 불출 예약 관리(POR Mat. RES)<br>[5180]창고별 배송 관리[4740]의장자재 입고 현황<br>[51A0]예약 및 불출 현황<br>[51B0]일반재 불출 확인 관리<br>[3340]구매 발주 상태 검색 | [5150]직불출<br>[5130]신조 배송(Delivery for New Building. RES)<br>[5110]재고 불출 예약 관리(Stock Mat. RES)<br>[5120]POR 불출 예약 관리(POR Mat. RES)<br>[5180]창고별 배송 관리[4740]의장자재 입고 현황<br>[51A0]예약 및 불출 현황<br>[51B0]일반재 불출 확인 관리 |
| Closing of settlement | [7110]입고마감 관리(국내)<br>[7340]출고마감 관리<br>[7410]재고마감 관리 | [7210]입고마감 관리(해외)<br>[7340]출고마감 관리<br>[7410]재고마감 관리 | [7210]입고마감 관리(해외)<br>[7340]출고마감 관리<br>[7410]재고마감 관리 |

## M.0 전체 업무 지도 (Material Management Process)
형태: 지도

### M.1 Standard Information Mgt. (기준정보 관리)
@ Material Department
- Manage all standard information (Add new, modify, delete …)

### M.2 POR Management (구매발주요청 관리)
@ All Department
- All Dep’t make new Purchase Order Request(POR) and manage Purchase Order Request(POR). Then send POR to Material Dep’t.
- Admin Section of Material Dep’t check and receive POR. Then send to Purchase Section of Material Dep’t.
- Purchase Section of Material Dep’t can receive POR to make Purchase Order.
- Purchase Section of Material Dep’t can return POR back to Request Dep’t.

### M.3 PO Management (구매발주 관리)
@ Material Department
- Buyer NEGO with supplier
- Buyer input all PO information.
- Buyer must to wait approved of Manager.
- Buyer send contract to supplier.

### M.4 Domestic Warehousing Mgt. (국내자재 입고 관리)
@ Material Department
- Buyer check delivery of material and compare it with the PO information.
- Finally, take material to stock and change stock material quantity.

### M.5 Issue Management (출고 관리)
@ All Department
- All department can make material reservation.
- Material department check reservation. If it’s OK, they will issue material for reservation department.

### M.6 Overseas Material Mgt. (해외자재 관리)
@ Material Department
- Manages oversea contract.
- Manages bill of leading.
- Manages oversea transportation fee.
- Declare custom sheet for customs post.
- Finally, make oversea warehousing information.

### M.7 Closing Management (마감 관리)
@ Material Department
- Make Domestic Closing in three time: 10th, 20th and end of month.
- Make Oversea Closing in two time: 15th end of month.
- Make issue Closing in two time: 15th and end of month.
- Make inventory Closing in two time: 15th and end of month.

### M.8 Subsidiary Material Mgt. (부자재 관리)
@ Material Department

### M.9 Personnel Equipment Mgt. (개인지급품 관리)
@ Material and Production dep’t

### M.10 STOCK Material Mgt. (STOCK재 관리)
@ Material and Production dep’t

### M.11 Steel Material Mgt. (강재 관리)
@ Material and Production dep’t

### M.12 Outside Repair Mgt. (사외수리 관리)
@ Material and Production dep’t

### M.13 Service Engineer POR Mgt. (서비스 엔지니어 POR 관리)
@ Material and Production dep’t

<!-- 모듈 사이 자료 흐름 — `보내는쪽 → 받는쪽 : 글씨` 로 적으면 지도 아래에 목록으로 나옵니다 -->
> 자료: Standard Info.
> 자료: POR Info.
> 자료: PO Info.
> 자료: Domestic material warehousing info. · Stock material info.
> 자료: Domestic material warehousing info.
> 자료: Issue info. · Inventory Info.
> 자료: Contract info. · Bill of leading info. · Custom sheet info. · Oversea warehousing info.
> 자료: Oversea warehousing info.

## 3.1 Standard Information Management (기준정보 관리)
형태: 흐름
> M.C.C.S. (자재분류코드) · Material Code (자재코드) · General STOCK material (일반STOCK재) · Check Qty. for STOCK material (STOCK재 점검 수량) · Material Item Code (품목분류코드) · Location/Section Code (위치/구역 코드) · HHIP Purchase Charger (HHIP 구매 담당자) · Purchase Charger (구매 담당자) · Customer Information (고객정보) · HMD Customer Information (HMD 고객정보) · Customer Information For Customs Declaration (세관신고용 고객정보)

### M.1.1 Standard Information Mgt. (기준정보 관리)
@ IT dep’t and Material dep’t
- IT dep’t and Material dep’t discuss which basic information need to standard
- Use coding method to standard basic information
- Standard information must be easy to understand and use in Material System
→ - Classify basic information · - Standard and code basic information

## 3.2 POR Management (구매 발주 요청 관리)
형태: 흐름
이웃: M.3 PO Management (구매 발주 관리)  @ Material dep’t

### M.2.1 POR Management (POR 관리)
@ Production, Accounting, Material dep’t
- Production dep’t check in the stock the materials they want to use.
- If there are no these materials in stock, they will make POR to request materials.
- Facility work material and material for Equip/Tools Repair must have Budget Control from Accounting dep’t
- Use Material Management System make POR by inputting all information about materials,...
- Then Production dep’t send POR to Material dep’t after getting signs from manager.
→ - List materials which want to request · -	Get permission from manager
→ List of POR to request materials

### M.2.2 Receive POR (POR 접수)
@ Material dep’t
- Admin section will collect Purchase Order Requisition Sheet send by Production Dep’t but not yet received.
- And these POR will be showed on Material System, too.
- Admin section only receive POR which get permission (get signs) from Material Control section.
→ List of POR received

### M.2.3 POR Receipt Management (POR 승인 관리)
@ Production & Material dep’t
- Purchase section (Material dep’t) check POR received by Admin section.
- If POR have some problems, Purchase section will return POR to the Production dep’t.
- If there are no problems, Purchase section will receive POR and choose the Purchase Charger (the buyer) to buy materials
- Can not modify information of POR which already received by Purchase section.
→ List of POR received
→ Return (some problem)

## 3.3 PO Management (구매 발주 관리)
형태: 흐름
이웃: M.4 Domestic Warehousing Mgt. (국내자재 입고 관리)  @ Material dep’t
이웃: M.2 POR Management (구매 발주 요청 관리)  @ Material dep’t
이웃: M.6 Oversea Material Mgt. (해외자재 관리)  @ Material dep’t
> List of POR received

### M.3.1 Make PO (PO 생성)
@ Material dep’t
- The Purchase Charger have to select maker(supplier) to buy materials
- After that Material dep’t input purchase order information such as : quantity, amount, condition of delivery, condition of payment,..
- Then, make purchase order information have status as ‘Waiting for approval’
→ - Selection of maker, request estimation, NEGO..
→ Purchase Order waiting for approval
→ Cancel ‘waiting for approval’ PO (to modify PO Info.)

### M.3.2 Manage PO (PO 관리)
@ Material dep’t
- If PO is waiting for approval, the Purchase Charger print out Purchase Approval Sheet and approve it.
- If PO was approved, the Purchase Charger print out Purchase Order Sheet and send it to the supplier. Can not modify information approved PO.
- The Purchase Charger can cancel ‘waiting for approval’ PO to modify PO information.
- The Purchase Charger can not cancel ‘approval’ PO.
→ Purchase Approval Sheet, Purchase Order Sheet

## 3.4 Domestic Warehousing Management (국내자재 입고 관리)
형태: 흐름
이웃: M.3 PO Management (구매 발주 관리)  @ Material dep’t
이웃: M.5 Issue Management (출고 관리)  @ Material dep’t
> Purchase Approval Sheet, Purchase Order Sheet

### M.4.1 Warehousing for domestic material (국내자재 입고)
@ Material dep’t
- Process warehousing classified by Purchase Charger
- Purchase Charger input warehouse quantity, warehouse amount, warehouse date, and location to warehouse materials.
- Material dep’t can cancel warehouse if materials not yet issued out.
→ - Collect Delivery Note from the supplier to warehouse domestic materials
→ List of material already warehoused

## 3.5 Issue Management (출고 관리)
형태: 흐름
이웃: M.4 Warehousing Mgt. (입고 관리)  @ Material dep’t
이웃: M.7 Closing Management (마감 관리)  @ Material dep’t
> List of material already warehoused

### M.5.1 Issue Reservation Management (출고예약관리)
@ Production dep’t and Material dep’t
- Retrieve all of POR materials and stock materials
- In case of POR, make a issue reservation warehoused POR. In case of STOCK, make a issue reservation after retrieving stock information classified by class, material code or material specification
- Reservation quantity must <= than warehouse quantity or stock quantity
- Print out Issue Request Sheet to get sign from Material dep’t
→ - Check materials already warehoused or materials remain in stock
→ Issue Request Sheet list
→ - Check remained material to return to Material dep’t

### M.5.2 Issue Confirm Management (출고확정관리)
@ Production dep’t and Material dep’t
- Retrieve all issue reservation not yet confirm.
- Based on Issue Request Sheet which was agreed to issue materials, Material dep’t will confirm them.
- Issue out materials for Production dep’t.

### M.5.3 Material Return (자재반환)
@ Production dep’t
- Retrieve materials which already issued out and remain after using by POR No or Reservation No or Issue ship.
- Select materials to return and input return quantity (total return quantity must <= issue quantity)
- Register to return materials
→ List of materials issued out
→ List of materials issued out
→ List of Return Material Sheet
→ List of Return Materials

### M.5.4 Material Return Confirmation (자재반환 확정)
@ Production dep’t and Material dep’t
- Retrieve all return materials not yet confirm.
- Based on Return Material Sheet which was agreed to return, Material dep’t will confirm them.
- After confirm return materials, stock information will be updated again

## 3.6 Overseas Material Management (해외자재 관리)
형태: 흐름
이웃: M.3 PO Management (구매 발주 관리)  @ Material dep’t
이웃: M.5 Issue Management (출고 관리)  @ Material dep’t
> - Collect all information when make contract with the supplier
> Purchase Approval Sheet, Purchase Order Sheet

### M.6.1 Supply Contract Management (공급업체계약관리)
@ Material dep’t
- Purchase Charger discuss with the supplier when make contract for oversea material.
- Create Contract No classified by Purchase Charger. There are 2 Contract No : HHIP Contract No and Supplier Contract No
- Input all contract information and check all items in the contract
- Then print out Contract Sheet and Firm Order

### M.6.2 B/L(Bill of Loading) Management (선하증권관리)
@ Material dep’t
- When deliver materials, supplier will send to Material dep’t shipping documents such as : B/L(Bill of Lading), Commercial Invoice, Packing List,…
- After Material dep’t receiving them, they will input all information into Material System
- Checking list of materials which supplier delivered (checking quantity, amount,..)

### M.6.3 Oversea Material Warehousing (해외자재 입고)
@ Material dep’t
- Retrieve information about arrival oversea material classified by B/L No
- Input warehouse date and location to warehouse oversea material
- Can direct issue oversea material when they arrive to HHIP

### M.6.4 Custom Declaration Sheet (세관신고서 작성)
@ Material dep’t
- When oversea material arrive, the Custom Office will check material list
- Then, the Custom section (Material dep’t) have to declare goods to pay custom fee
- Print out the Custom Declaration Sheet and send it to the Custom Office
→ Supplier
→ Contract Sheet and Firm Order
→ B/L Information
→ B/L Information
→ All information about arrival oversea material
→ List of material already warehoused

## 3.7 Closing Management (마감 관리)
형태: 흐름
이웃: M.5 Issue Management (출고 관리)  @ Material dep’t
> All warehouse information

### M.7.1 Warehouse Closing Mgt.(Domestic) (국내자재마감)
@ Material dep’t
- Warehouse closing for domestic material 3 times / month : 1st(date 1→10), 2nd(date 11 →20) and 3rd(date 21 → 31)
- Before closing, Admin section have to check warehouse information (warehouse quantity, amount, warehouse date, fee,..)
- Then they input exchange rate to close data

### M.7.2 Warehouse Closing Mgt.(Oversea) (해외자재마감)
@ Material dep’t
- Warehouse closing for oversea material 2 times / month : 1st(date 1 → 15), 2nd(date 15 → 31)
- Before closing, Admin section have to check warehouse information (warehouse quantity, amount, warehouse date, fee,..)
- Then they input exchange rate to close data
→ List of material already warehouse closing

### M.7.3 Closing Info. Final Confirm (마감정보 최종확정)
@ Material and Accounting dep’t
- Check all material already warehouse closing
- If there is no problem, Admin section will final close one time
- After final closing, Admin section will print out all documents and send them to Accounting dep’t
→ List of material already final warehouse closing

### M.7.4 Issue Closing Management (출고마감관리)
@ Material dep’t
- Issue closing 2 times / month : 1st(date 1 → 15), 2nd(date 15 → 31)
- Check all material already issued out (issue quantity, issue amount,..)
- If there is no problem, Admin section will close issue information

### M.7.5 Inventory Closing Management (재고마감관리)
@ Material dep’t
- Inventory closing 2 times / month : 1st(date 1 → 15), 2nd(date 15 → 31)
- Only closing inventory for material which already warehouse and issue closing
- Check inventory information of material (last remain quantity, warehouse quantity, issue quantity and now remain quantity,..)
- If there is no problem, Admin section will close stock information
→ List of material already issue closing
→ List of material already stock closing

## 3.8 Subsidiary Material Management (부자재 관리)
형태: 흐름

### M.8.1 Subsidiary Material Budget Code Mgt. (부자재 예산코드 관리)
@ Material dep’t
- List all subsidiary material budget used in Material System
- Classify subsidiary material budget by coding
→ - Classify subsidiary material budget
→ Subsidiary material budget information
→ - List of subsidiary material budget code

### M.8.2 Subsidiary Material Code Mgt. (부자재 코드 관리)
@ Material dep’t
- List all subsidiary material budget code used in Material System
- Classify subsidiary material code by subsidiary material budget code
- Can manage material code belong to/not belong to subsidiary material budget code
→ - Classify subsidiary material code
→ - List of subsidiary material code

## 3.9 Personnel Equipment Management (개인지급품 관리)
형태: 흐름

### M.9.1 Calculate issuing quantity of Personal equipment (개인지급품 출고수량 계산)
@ Production and Material dep’t
- First, Material dep’t classify personal equipment by coding and manage issuing rule of personal equipment
- Then, Production dep’t register to issue personal equipment based on issuing rule.
- Print out personal equipment request sheet and send them to Material dep’t
→ - List of personal equipment code
→ List of personal equipment request sheet

### M.9.2 Confirm Personal equipment (개인지급품 확정)
@ Production and Material dep’t
- Material dep’t retrieve personal equipment requests not yet issued by department, group and item
- If Material agree issuing, they will confirm the request sheet
- Then, they issue out personal equipment

## 3.10 STOCK Material Management (STOCK재 관리)
형태: 흐름

### M.10.1 STOCK Material Mgt. (STOCK재 관리)
@ Material dep’t
- List all material often used in company
- Material dep’t classify material belong or not belong to stock
- Manage information about stock material
→ - List all material often used in company
→ STOCK material Info.

### M.10.2 Request changing Surplus material to STOCK (잉여자재 STOCK 변경 요청)
@ Production and Material dep’t
- Production dep’t list and check all surplus materials (materials bought for ship, but ship already sail out and materials remain)
- Production dep’t can register surplus materials to stock to issue for another ship. It means that surplus materials become stock materials.
- Print out Request changing surplus material to stock sheet and send to Material dep’t
→ - List all surplus material
→ Request changing surplus material to stock sheet

### M.10.3 Confirm changing Surplus material to STOCK (잉여자재 STOCK 변경 확정)
@ Production and Material dep’t
- Material dep’t check all surplus material waiting changed to stock
- Based on Request changing surplus material to stock Sheet, Material dep’t will confirm
- After confirming, surplus material become stock materials. If Production want to use them again, they have to make Stock Issue Reservation.

## 3.11 Steel Material Management (강재 관리)
형태: 흐름

### M.11.1 Inventory Mgt. of Steel Plate (강판 재고 관리)
@ Material dep’t
- Material dep’t collect information of steel plate such as : how many arrival? How many issue? And now remain ?...by the Material system
- Material dep’t check the actual quantity remain
- Compare the remain quantity in the Material System with the actual remain
→ - All information about steel plate remain in stock
→ Steel Plate Inventory Info.

### M.11.2 Return Steel Plate after cut (절단 후 강판 반환)
@ Production dep’t
- Production dep’t select the steel plate they want to return
- They have to input the size of steel plate : thickness, width, length to return
- After registering, they have to print out Return Sheet (for Steel Plate after cutting) and send it to Material dep’t
→ - Collect remain steel plate after cutting
→ List of Return Steel Plate Sheet

### M.11.3 Confirm Return Steel Plate (강판 반환 확정)
@ Production and Material dep’t
- Material dep’t check all steel plate registering to return
- Based on Return Steel Plate Sheet, they will confirm
- After confirming, Production can make issue reservation returned steel plate if they want to use
→ List of returned steel plate already confirmed

### M.11.4 Issue Reservation (출고 예약)
@ Production and Material dep’t
- Production dep’t can search returned steel plate by thickness, width, length
- Production dep’t make issue reservation by inputting width and length of steel plate
- Then, print out Issue Sheet (Issue Remain Steel Plate) and send it to Material dep’t

### M.11.5 Issue Confirm (출고 확정)
@ Material dep’t
- Material dep’t check remain steel plate before issuing out
- Based on Issue Sheet (Issue Remain Steel Plate), they will confirm if they agree to issue
- After confirming, remain steel plate will issue for Production dep’t
→ List of Issue Sheet · (Issue Remain Steel Plate)

## 3.12 Outside Repair Management (사외수리 관리)
형태: 흐름

### M.12.1 Outside Repair Request (사외수리 요청)
@ Production dep’t
- Production dep’t check items need to repair outside.
- If these items can not repair in our company, Production dep’t will make Outside Repair Request
- After inputting information about the items, Production have to print out Outside Request Sheet to get signs and send it to Material dep’t
→ - List of items need to repair outside · -	Get permission from manager
→ Outside Repair Request Sheet

### M.12.2 Outside Repair receive POR (사외수리 POR 수신)
@ Material dep’t
- Admin section will collect Outside Repair Request Sheet send by Production Dep’t but not yet received.
- Admin section only receive Outside Repair Request Sheet which get permission (get full signs) from Material dep’t and SRM dep’t

### M.12.3 Outside Repair receipt Mgt. (사외수리 승인 관리)
@ Material dep’t
- Purchase section (Material dep’t) check Outside Repair POR received by Admin section.
- If Outside Repair POR have some problems, Purchase section will return it to the Production dep’t.
- If there are no problems, Purchase section will receive Outside Repair POR and choose the Purchase Charger (the buyer) to make Outside Repair PO(Purchase Order)
- Can not modify information of Outside Repair POR which already received by Purchase section.

### M.12.4 Outside Repair Purchase Order (사외수리 발주)
@ Production and Material dep’t
- The Purchase Charger have to select maker(supplier) to repair the items
- After that Purchase Charger input PO information such as : quantity, amount, condition of delivery, condition of payment,..
- Then, Purchase Charger print out Purchase Approval Sheet to get approval from manager
- After PO approved, print out Purchase Order Sheet to send to the supplier
- The supplier will repair items based on the condition in Purchase Order Sheet

### M.12.5 Outside Repair Work Completion (사외수리 작업 완료)
@ Production dep’t
- After supplier repair the items completely, they will delivery the items to Production dep’t
- Production dep’t have to check outside items
- Then, they have to make work completion to report the result of these outside repair items

### M.12.6 Outside Repair Closing (사외수리 마감)
@ Material and Accounting dep’t
- Outside repair closing 2 times / month : 1st(date 1→15), 2nd(date 15 → 31)
- Material dep’t receive outside repair work completion from Production dep’t
- To close data, Material dep’t must input Exchange Rate
- After closing, print out closing data and send them to Accounting dep’t
→ - Selection of maker, request estimation, NEGO..
→ List of Outside Repair Request Sheet already received by Admin section
→ List of Outside Repair Request Sheet already received by Purchase section
→ Return (some problem)
→ List of Purchase Approval Sheet and Purchase Order Sheet
→ List of outside repair items already completed

## 3.13 Service Engineer POR Management (서비스엔지니어 POR 관리)
형태: 흐름

### M.13.1 Service Engineer POR (서비스엔지니어 구매발주 요청)
@ Production dep’t
- Production dep’t check items need service engineer.
- If these items can not outside repair, Production dep’t will make POR to request service engineer.
- After inputting request information, Production have to print out Service Engineer Request Sheet to get approval and send it to Material dep’t
→ -	List of items need service engineer · -	Get permission from manager
→ List of Service Engineer POR

### M.13.2 Receive POR (for Admin) (관리부서 POR 수신)
@ Production and Material dep’t
- Admin section will collect Service Engineer Request Sheet send by Production Dep’t but not yet received.
- Admin section only receive Service Engineer Request Sheet which get permission (get full signs) from request dep’t and Material dep’t
→ List of Service Engineer POR
→ Return (some problem)
→ -	List of service engineer POR already closing

### M.13.3 Receive POR (for Purchase) (구매부서 POR 수신)
@ Material dep’t
- Purchase section (Material dep’t) check Service Engineer POR received by Admin section.
- If Service Engineer POR have some problems, Purchase section will return it to the Production dep’t.
- If there are no problems, Purchase section will receive Service Engineer POR and choose the Purchase Charger (the buyer) to make Service Engineer PO(Purchase Order)
- Can not modify information of Service Engineer POR which already received by Purchase section.
→ Send closing data to Accounting dep’t

### M.13.4 Service Engineer PO (서비스엔지니어 발주)
@ Material dep’t
- The Purchase Charger have to select maker(supplier) to repair the items
- After that Purchase Charger input PO information such as : monetary unit, payment condition, PO start date, PO Completion date,..
- Then, Purchase Charger print out Purchase Approval Sheet to get approval from manager
- After PO approved, print out Purchase Order Sheet to send to the supplier (service engineer)

### M.13.5 Closing Service Engineer (서비스엔지니어 마감)
@ Material and Accounting dep’t
- Service Engineer closing 2 times / month : 1st(date 1→15), 2nd(date 15 → 31)
- Material dep’t receive service engineer completion sheet from Production dep’t
- To close data, Material dep’t must input Exchange Rate
- After closing, print out closing data and send them to Accounting dep’t
→ - Selection of maker, request estimation, NEGO..
→ List of Outside Repair Request Sheet already received by Purchase section
→ List of Purchase Approval Sheet and Purchase Order Sheet

## 개정 이력
형태: 표

| 버전 | 변경일 | 변경 내용 | 작성자 | 승인자 |
|---|---|---|---|---|
| 1.0 | 2024.10.18 | 최초 작성 | 최영민 책임 | 선우도영 총괄 |
| 2.0 | 2025.11.04 | System Flow Map 추가 | 이상준 책임 | 선우도영 총괄 |
