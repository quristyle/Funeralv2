using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace WbsApi;

/// <summary>
/// 수빅 DB(ORAHHIP · M10) 커넥션을 <b>붙잡고 살면서</b> 묵은 세션을 정리한다 — [DB 세션 정리] 화면(#/orakill).
///
/// 개발 DB 의 <b>processes 한도</b>가 늘 차 있다(실측 317/320). 한 번 붙고 그대로 둔
/// PL/SQL Developer·iisexpress 가 전용서버 프로세스를 물고 놓지 않아, 새로 붙으려는 쪽이
/// <c>ORA-12516/12519</c> 로 튕긴다. 한 시간 넘게 논 세션을 끊어 자리를 비운다.
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>⚠️ 부를 때마다 새로 붙으면 안 된다 — 이것이 이 설계의 요점이다.</b>
/// 세션 정리가 필요한 때는 <b>이미 자리가 없는 때</b>라, 그때 새로 붙으려 하면 거절당한다.
/// 그래서 대시보드가 뜰 때 <b>미리 자리를 잡아 두고 꺼질 때까지 쥐고 있는다.</b>
/// 끊기면 될 때까지 다시 붙는다 — <c>tools/orasession/OraPool.java</c> 가 그 일을 한다.
///
/// <b>왜 Java 상주 프로그램인가.</b> 이 PC 에는 sqlplus 도 python-oracledb 도 없고,
/// 대시보드 API 는 <b>외부 패키지를 쓰지 않는다</b>(폐쇄망 · README [백엔드 — 외부 패키지 없음]).
/// Oracle 에 닿는 길은 <c>ojdbc8.jar</c> 하나뿐이다. 그 자바를 <b>한 번만 띄워 두고</b>
/// 표준입출력으로 명령을 주고받는다 — 매번 JVM 을 띄우면 커넥션을 쥐고 있을 수가 없다.
///
/// <b>⚠️ SQL 은 Java 쪽에 박혀 있다. 화면도 설정도 문장을 보내지 못한다.</b>
/// 이 기능이 쥔 권한은 <c>ALTER SYSTEM</c> 이다. 문장을 받게 만들면 그 권한으로 무엇이든
/// 돌릴 수 있는 구멍이 된다. 밖에서 정하는 것은 넷뿐이다 —
/// <b>얼마나 묵었나 · 사번만 볼까 · 개발팀을 뺄까 · 한 번에 몇 개</b>.
///
/// <b>⚠️ 자동 실행은 서버가 돈다. 다시 올라올 때 되살리지는 않는다.</b>
/// 화면 타이머로 만들면 탭을 닫는 순간 멈추고 두 사람이 열면 두 배로 돈다. 반대로,
/// 사람이 안 보는 배포 직후에 남의 세션 끊기가 저절로 다시 도는 것도 위험하다 —
/// 고른 간격만 기억해 두고 <b>꺼진 채로</b> 시작한다. 켜고 끌 때마다 로그에 남긴다.
/// </summary>
public static class OraKill
{
    private static string _dir = "";
    private static string _java = "java", _javac = "javac";
    private static string _url = "", _user = "", _pw = "", _keep = "";
    private static int _idle, _limit, _size, _beat, _timeoutMs;
    private static string _ready = "";

    private static int[] _choices = [30, 60, 300, 600];

    /// <summary>사번 세션만 볼지 (<c>osuser LIKE 'BP%'</c>).</summary>
    private static bool _bpOnly = true;

    /// <summary>개발팀(<c>Keep</c> 목록)을 뺄지. 끄면 개발팀 세션도 정리 대상이 된다.</summary>
    private static bool _keepTeam = true;

    private static int _auto, _lastChoice;
    private static string _autoBy = "";
    private static DateTimeOffset? _autoAt, _nextAt;

    private static Dictionary<string, object?>? _last;
    private static Dictionary<string, object?>? _pool;
    private static Dictionary<string, object?>? _users;
    private static readonly List<Dictionary<string, object?>> Log = [];
    private const int LogMax = 60;

    private static readonly SemaphoreSlim Gate = new(1, 1);
    private static string _stateFile = "";

    // ── 상주 프로세스 ────────────────────────────────────────────────────────
    private static Process? _proc;
    private static StreamWriter? _in;
    private static StreamReader? _out;
    private static readonly SemaphoreSlim Pipe = new(1, 1);
    private static int _starts;

    public static void Init(IConfiguration cfg, string contentRoot)
    {
        _url = cfg["OraSession:Url"] ?? "jdbc:oracle:thin:@//10.103.13.10:1521/ORAHHIP";
        _user = cfg["OraSession:User"] ?? "m10";
        _pw = cfg["OraSession:Password"] ?? "m10";
        _keep = cfg["OraSession:Keep"] ?? "";
        _idle = cfg.GetValue("OraSession:IdleSeconds", 3600);
        _limit = cfg.GetValue("OraSession:Limit", 50);
        _size = Math.Clamp(cfg.GetValue("OraSession:PoolSize", 2), 1, 8);
        _beat = Math.Clamp(cfg.GetValue("OraSession:HeartbeatSeconds", 20), 5, 300);
        _timeoutMs = cfg.GetValue("OraSession:TimeoutMs", 60000);
        _bpOnly = cfg.GetValue("OraSession:BpOnly", true);
        _keepTeam = cfg.GetValue("OraSession:KeepTeam", true);
        _java = cfg["OraSession:Java"] ?? "java";
        _javac = cfg["OraSession:Javac"] ?? "javac";

        var ch = (cfg["OraSession:Intervals"] ?? "30,60,300,600")
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(s => int.TryParse(s, out var v) ? v : 0).Where(v => v >= 10).ToArray();
        if (ch.Length > 0) _choices = ch;

        _dir = Path.Combine(contentRoot, "data", "orasession");
        _stateFile = Path.Combine(_dir, "auto.json");
        _ready = Prepare(contentRoot);

        // 지난 설정은 읽되 <자동은 켜지 않는다> (머리말 참고). 고른 간격만 기억한다.
        try
        {
            if (File.Exists(_stateFile))
            {
                using var d = JsonDocument.Parse(File.ReadAllText(_stateFile));
                var r = d.RootElement;
                if (r.TryGetProperty("seconds", out var s) && s.TryGetInt32(out var sec) && sec > 0)
                    _lastChoice = Allowed(sec);
                if (r.TryGetProperty("bponly", out var b) && b.ValueKind is JsonValueKind.True or JsonValueKind.False)
                    _bpOnly = b.GetBoolean();
                if (r.TryGetProperty("keepteam", out var k) && k.ValueKind is JsonValueKind.True or JsonValueKind.False)
                    _keepTeam = k.GetBoolean();
            }
        }
        catch { /* 못 읽으면 기본값으로 시작한다 */ }
    }

    /// <summary>실행에 필요한 것을 <c>api/data/orasession</c> 에 갖춘다 (자바 원본 · 드라이버 · 컴파일).</summary>
    private static string Prepare(string contentRoot)
    {
        try
        {
            Directory.CreateDirectory(_dir);
            var repo = Path.GetFullPath(Path.Combine(contentRoot, "..", "tools", "orasession", "OraPool.java"));
            var src = Path.Combine(_dir, "OraPool.java");
            var cls = Path.Combine(_dir, "OraPool.class");
            var jar = Path.Combine(_dir, "ojdbc8.jar");

            if (File.Exists(repo) && (!File.Exists(src) || File.GetLastWriteTimeUtc(repo) > File.GetLastWriteTimeUtc(src)))
                File.Copy(repo, src, true);
            if (!File.Exists(src)) return "OraPool.java 를 찾지 못했습니다 (tools/orasession).";
            if (!File.Exists(jar)) return $"ojdbc8.jar 이 없습니다 — {jar} 에 넣어 주세요.";

            if (!File.Exists(cls) || File.GetLastWriteTimeUtc(src) > File.GetLastWriteTimeUtc(cls))
            {
                var psi = new ProcessStartInfo(_javac, $"-encoding UTF-8 \"{src}\"")
                {
                    WorkingDirectory = _dir,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                };
                using var p = Process.Start(psi);
                var err = p!.StandardError.ReadToEnd();
                p.WaitForExit(60000);
                if (!File.Exists(cls)) return "javac 컴파일 실패 — " + Short(err);
            }
            return "";
        }
        catch (Exception e) { return Short(e.Message); }
    }

    private static int Allowed(int sec) => _choices.Contains(sec) ? sec : 0;

    private static string Short(string s) =>
        string.IsNullOrWhiteSpace(s) ? "" : (s.Length > 300 ? s[..300] : s).Replace("\r", " ").Replace("\n", " ");

    // ── 상주 프로세스 다루기 ─────────────────────────────────────────────────

    /// <summary>떠 있지 않으면 띄운다. 죽어 있으면 다시 띄운다 — 연결을 놓치지 않는 것이 이 기능의 전부다.</summary>
    private static void EnsureUp()
    {
        if (_proc is { HasExited: false }) return;
        if (_ready.Length > 0) return;

        try { _proc?.Dispose(); } catch { }
        var psi = new ProcessStartInfo(_java,
            $"-cp \".;ojdbc8.jar\" OraPool --url \"{_url}\" --user \"{_user}\" --pw \"{_pw}\""
          + $" --size {_size} --heartbeat {_beat}")
        {
            WorkingDirectory = _dir,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            // ⚠️ 들어가는 쪽도 UTF-8 로 못 박는다. 저쪽은 stdin 을 UTF-8 로 읽는데
            //    (OraPool.main), 이것을 비워 두면 C# 은 <콘솔 기본 코드페이지>(한글
            //    윈도에서 CP949)로 써 보낸다. 오랫동안 드러나지 않았던 까닭은 보내는 값이
            //    전부 ASCII 였기 때문이다 — 두 인코딩에서 바이트가 같다. 한글을 처음
            //    보낸 자리(locporrun 의 by=사람이름)에서 글자가 깨졌고, 오류는 나지 않았다.
            StandardInputEncoding = Encoding.UTF8,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8,
        };
        _proc = Process.Start(psi);
        if (_proc is null) return;
        _in = _proc.StandardInput;
        _out = _proc.StandardOutput;
        _starts++;
        // 자바가 토해 내는 경고는 읽어서 버린다 — 안 읽으면 파이프가 차서 프로세스가 멈춘다
        var p2 = _proc;
        _ = Task.Run(async () => { try { while (await p2.StandardError.ReadLineAsync() is not null) { } } catch { } });
        try { _out.ReadLine(); } catch { }   // {"ready":true}
        Console.WriteLine($"[ora/pool] {DateTime.Now:HH:mm:ss} 상주 프로그램 기동 ({_starts}번째) size={_size}");
    }

    /// <summary>명령 한 줄을 보내고 답 한 줄을 받는다. 죽어 있으면 다시 띄우고 한 번 더 해 본다.</summary>
    private static async Task<Dictionary<string, object?>> SendAsync(string line)
    {
        await Pipe.WaitAsync();
        try
        {
            for (var attempt = 0; attempt < 2; attempt++)
            {
                EnsureUp();
                if (_proc is null || _in is null || _out is null)
                    return Err(_ready.Length > 0 ? _ready : "상주 프로그램을 띄우지 못했습니다.");
                try
                {
                    await _in.WriteLineAsync(line);
                    await _in.FlushAsync();
                    var read = _out.ReadLineAsync();
                    if (await Task.WhenAny(read, Task.Delay(_timeoutMs)) != read)
                    {
                        // 답이 없다 — 붙잡고 있는 것이 고장났다고 보고 다시 띄운다
                        try { _proc.Kill(true); } catch { }
                        _proc = null;
                        continue;
                    }
                    var text = read.Result;
                    if (text is null) { _proc = null; continue; }   // 죽었다 → 다시 띄우고 한 번 더
                    using var doc = JsonDocument.Parse(text);
                    var row = new Dictionary<string, object?>();
                    foreach (var p in doc.RootElement.EnumerateObject())
                        row[p.Name] = p.Value.ValueKind switch
                        {
                            JsonValueKind.True => true,
                            JsonValueKind.False => false,
                            JsonValueKind.Number => p.Value.GetInt64(),
                            JsonValueKind.String => p.Value.GetString(),
                            JsonValueKind.Null => null,
                            _ => JsonSerializer.Deserialize<object>(p.Value.GetRawText()),
                        };
                    return row;
                }
                catch (Exception e)
                {
                    _proc = null;
                    if (attempt == 1) return Err(Short(e.Message));
                }
            }
            return Err("상주 프로그램이 응답하지 않습니다.");
        }
        finally { Pipe.Release(); }
    }

    private static Dictionary<string, object?> Err(string m) =>
        new() { ["ok"] = false, ["connected"] = false, ["error"] = m };

    /// <summary>
    /// 다른 화면이 <b>이 상주 연결을 빌려 쓰는</b> 통로.
    ///
    /// Oracle 에 닿는 길은 이 데몬 하나뿐이다(머리말 참고). 화면이 생길 때마다 따로 붙으면
    /// 정작 자리가 없을 때 그 화면들이 통째로 먹통이 되고, 자리를 더 먹어 세션 정리를
    /// <b>더 자주 필요하게</b> 만든다. 그래서 쥐고 있는 연결을 같이 쓴다.
    ///
    /// <b>⚠️ 문장이 아니라 명령 이름을 보낸다.</b> 이 연결은 DBA 권한으로 돈다 —
    /// SQL 은 <c>tools/orasession/OraPool.java</c> 안에 박혀 있어야 하고, 여기로 오는 것은
    /// 그 명령이 미리 정해 둔 <b>매개값</b>뿐이다. 값에 빈칸을 넣지 마라(저쪽이 공백으로 쪼갠다).
    ///
    /// <c>Gate</c> 를 잡는 까닭 — 세션 정리와 같은 줄에 세워 두 일이 겹치지 않게 한다.
    /// 쓰는 쪽: <c>api/LocPor.cs</c>.
    /// </summary>
    internal static async Task<Dictionary<string, object?>> CallAsync(string line)
    {
        await Gate.WaitAsync();
        try
        {
            var row = await SendAsync(line);
            _pool = Pick(row);
            return row;
        }
        finally { Gate.Release(); }
    }

    // ── 실행 ────────────────────────────────────────────────────────────────

    private static string Args(string? only) =>
        $"idle={_idle} limit={_limit}"
      + $" bponly={(_bpOnly ? "true" : "false")}"
      + $" keepteam={(_keepTeam ? "true" : "false")}"
      + (string.IsNullOrWhiteSpace(_keep) ? "" : $" keep={_keep}")
      + (only is null ? "" : $" only={only}");

    private static async Task<Dictionary<string, object?>> RunOnceAsync(string mode, string by, string? only = null)
    {
        await Gate.WaitAsync();
        try
        {
            var row = await SendAsync($"{mode} {Args(only)}");
            row["at"] = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss");
            row["mode"] = row.GetValueOrDefault("mode") ?? mode;
            row["by"] = by;
            _pool = Pick(row);
            return Remember(row);
        }
        finally { Gate.Release(); }
    }

    private static Dictionary<string, object?> Pick(Dictionary<string, object?> r) => new()
    {
        ["connected"] = r.GetValueOrDefault("connected"),
        ["live"] = r.GetValueOrDefault("live"),
        ["size"] = r.GetValueOrDefault("size"),
        ["reconnects"] = r.GetValueOrDefault("reconnects"),
        ["ok_ago"] = r.GetValueOrDefault("ok_ago"),
        ["last_error"] = r.GetValueOrDefault("last_error") ?? r.GetValueOrDefault("error"),
        ["starts"] = _starts,
        ["at"] = DateTimeOffset.Now.ToString("HH:mm:ss"),
    };

    private static Dictionary<string, object?> Remember(Dictionary<string, object?> row)
    {
        _last = row;
        var brief = new Dictionary<string, object?>();
        foreach (var k in new[] { "at", "mode", "by", "ok", "busy", "found", "ok_cnt", "fail_cnt",
                                  "total", "proc_cur", "proc_max", "error" })
            brief[k] = row.GetValueOrDefault(k);
        lock (Log)
        {
            Log.Insert(0, brief);
            while (Log.Count > LogMax) Log.RemoveAt(Log.Count - 1);
        }
        return row;
    }

    private static void Persist()
    {
        try
        {
            File.WriteAllText(_stateFile, JsonSerializer.Serialize(new
            {
                seconds = _auto,
                by = _autoBy,
                at = _autoAt?.ToString("o"),
                bponly = _bpOnly,
                keepteam = _keepTeam,
            }));
        }
        catch { /* 못 적어도 이번 기동 동안은 그대로 쓴다 */ }
    }

    private static object State() => new
    {
        ready = _ready.Length == 0,
        why = _ready,
        url = _url,
        user = _user,
        keep = _keep.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries),
        idle = _idle,
        limit = _limit,
        bponly = _bpOnly,
        keepteam = _keepTeam,
        choices = _choices,
        auto = _auto,
        last_choice = _lastChoice,
        auto_by = _autoBy,
        auto_at = _autoAt?.ToString("yyyy-MM-dd HH:mm:ss"),
        next_at = _auto > 0 ? _nextAt?.ToString("yyyy-MM-dd HH:mm:ss") : null,
        pool = _pool,
        users = _users,
        last = _last,
        log = Log.ToList(),
    };

    private static string Agent(HttpContext ctx)
    {
        var ua = ctx.Request.Headers.UserAgent.ToString();
        if (string.IsNullOrWhiteSpace(ua)) return "(없음)";
        return ua.Contains("Mozilla", StringComparison.Ordinal) ? "브라우저" : (ua.Length > 40 ? ua[..40] : ua);
    }

    // ────────────────────────────────────────────────────────────────────────

    public static void Map(WebApplication app, Func<IpGate.Result, bool> isSuper)
    {
        async Task<IResult?> DenyAsync(IpGate g, HttpContext ctx)
        {
            var me = await g.CheckAsync(ctx);
            return isSuper(me) ? null
                : Results.Json(new { error = "세션 정리는 Super 만 할 수 있습니다." }, statusCode: 403);
        }
        static async Task<string> WhoAsync(IpGate g, HttpContext ctx)
        {
            var me = await g.CheckAsync(ctx);
            return me.Name ?? me.BpId ?? "미상";
        }

        app.MapGet("/api/ora/state", () => Results.Ok(State()));

        app.MapPost("/api/ora/scan", async (IpGate g, HttpContext ctx) =>
            Results.Ok(new { run = await RunOnceAsync("scan", await WhoAsync(g, ctx)), state = State() }));

        app.MapPost("/api/ora/sweep", async (IpGate g, HttpContext ctx) =>
        {
            if (await DenyAsync(g, ctx) is { } no) return no;
            return Results.Ok(new { run = await RunOnceAsync("sweep", await WhoAsync(g, ctx)), state = State() });
        });

        // 한 건만 끊기 — 번호를 받아 바로 문장을 만들지 않는다. <조건을 다시 걸고>
        // 그 조건에 여전히 걸리는 세션일 때만 끊는다 (목록을 본 사이 다시 일할 수 있다).
        app.MapPost("/api/ora/kill", async (IpGate g, HttpContext ctx, JsonElement body) =>
        {
            if (await DenyAsync(g, ctx) is { } no) return no;
            var sid = body.TryGetProperty("sid", out var a) && a.TryGetInt64(out var v1) ? v1 : -1;
            var ser = body.TryGetProperty("serial", out var c) && c.TryGetInt64(out var v2) ? v2 : -1;
            if (sid < 0 || ser < 0) return Results.BadRequest(new { error = "sid · serial 이 필요합니다." });
            var run = await RunOnceAsync("sweep", await WhoAsync(g, ctx), $"{sid},{ser}");
            return Results.Ok(new { run, state = State() });
        });

        // 사번별 자리 차지 현황 — <조건을 하나도 걸지 않은> 전체 목록.
        // 정리 대상 목록과 쓰임새가 다르다: 저쪽은 <끊을 것>, 이쪽은 <지금 누가 얼마나 쓰나>.
        app.MapPost("/api/ora/users", async (IpGate g, HttpContext ctx) =>
        {
            await Gate.WaitAsync();
            try
            {
                var row = await SendAsync("users");
                _pool = Pick(row);
                _users = row;
                return Results.Ok(new { run = row, state = State() });
            }
            finally { Gate.Release(); }
        });

        // 한 스키마의 테이블 목록 — 계통도 화면(#/tables2)의 [테이블 찾기] 가 부른다.
        //
        // 이 화면과 상관없어 보이는 자리에 둔 까닭: Oracle 에 닿는 길이 이 데몬 하나뿐이다.
        // 지금 이 DB 는 processes 가 차 있어 <새 접속이 거절>되므로(README 참고), 목록 하나
        // 보자고 따로 붙는 길을 내면 정작 필요할 때 안 열린다. 쥐고 있는 연결을 같이 쓴다.
        //
        // 읽기만 하는 조회라 Super 를 요구하지 않는다. owner·검색어는 데몬이 바인드로 넘긴다.
        app.MapGet("/api/ora/tables", async (string? owner, string? q, int? limit) =>
        {
            await Gate.WaitAsync();
            try
            {
                // 공백은 명령 줄을 쪼개므로 받지 않는다 — 테이블 이름에 공백이 있을 일도 없다.
                var own = new string((owner ?? "M20").Where(char.IsLetterOrDigit).ToArray()).ToUpperInvariant();
                var kw = new string((q ?? "").Where(c => char.IsLetterOrDigit(c) || c is '_' or '-').ToArray());
                var lim = Math.Clamp(limit ?? 300, 1, 2000);

                var cmd = $"tables owner={own} limit={lim}" + (kw.Length > 0 ? $" q={kw}" : "");
                var row = await SendAsync(cmd);
                _pool = Pick(row);
                return Results.Ok(new { run = row, state = State() });
            }
            finally { Gate.Release(); }
        });

        // 한 스키마의 패키지·프로시저 — 계통도에 <무엇이 이 표를 쓰는가> 를 함께 그릴 때 쓴다.
        app.MapGet("/api/ora/procs", async (string? owner, string? q, int? limit) =>
        {
            await Gate.WaitAsync();
            try
            {
                var own = new string((owner ?? "M20").Where(char.IsLetterOrDigit).ToArray()).ToUpperInvariant();
                var kw = new string((q ?? "").Where(c => char.IsLetterOrDigit(c) || c == '_').ToArray());
                var lim = Math.Clamp(limit ?? 300, 1, 2000);
                var cmd = $"procs owner={own} limit={lim}" + (kw.Length > 0 ? $" q={kw}" : "");
                var row = await SendAsync(cmd);
                _pool = Pick(row);
                return Results.Ok(new { run = row, state = State() });
            }
            finally { Gate.Release(); }
        });
        // 표 이름들이 어느 스키마에 있는지 — 계통도 화면이 <다른 스키마의 표>에 꼬리표를 붙인다.
        // 한 번에 묻는다. 48개를 하나씩 물으면 왕복이 48번이고 이 DB 는 그럴 여유가 없다.
        app.MapGet("/api/ora/table-owners", async (string? names) =>
        {
            await Gate.WaitAsync();
            try
            {
                // 이름은 영문·숫자·밑줄만. 공백은 명령 줄을 쪼개므로 받지 않는다.
                var list = (names ?? "")
                    .Split(',', StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => new string(x.Where(c => char.IsLetterOrDigit(c) || c is '_' or '$' or '#').ToArray()).ToUpperInvariant())
                    .Where(x => x.Length is > 0 and <= 30)
                    .Distinct().Take(500).ToArray();
                if (list.Length == 0) return Results.BadRequest(new { error = "쓸 수 있는 이름이 없습니다." });

                var row = await SendAsync("owners names=" + string.Join(",", list));
                _pool = Pick(row);
                return Results.Ok(new { run = row, state = State() });
            }
            finally { Gate.Release(); }
        });

        // 한 사번의 세션을 통째로 끊기 — 놀고 있든 일하고 있든 가리지 않는다.
        // ⚠️ 유휴 정리와 무게가 다르다. 화면에서 두 번 눌러야 여기까지 온다.
        app.MapPost("/api/ora/killuser", async (IpGate g, HttpContext ctx, JsonElement body) =>
        {
            if (await DenyAsync(g, ctx) is { } no) return no;
            var who = body.TryGetProperty("osuser", out var u) ? u.GetString() ?? "" : "";
            if (who.Length == 0) return Results.BadRequest(new { error = "osuser 가 필요합니다." });
            var by = await WhoAsync(g, ctx);
            Console.WriteLine($"[ora/killuser] {DateTime.Now:HH:mm:ss} osuser={who} by={by} ua={Agent(ctx)}");
            Dictionary<string, object?> run;
            await Gate.WaitAsync();
            try
            {
                run = await SendAsync($"killuser osuser={who}");
                run["at"] = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss");
                run["mode"] = "killuser";
                run["by"] = by;
                _pool = Pick(run);
                Remember(run);
            }
            finally { Gate.Release(); }
            return Results.Ok(new { run, state = State() });
        });

        // 대상 조건 — 사번만 볼지 · 개발팀을 뺄지. 보기와 끊기가 같은 값을 쓰도록 서버가 들고 있다.
        app.MapPut("/api/ora/options", async (IpGate g, HttpContext ctx, JsonElement body) =>
        {
            if (await DenyAsync(g, ctx) is { } no) return no;
            if (body.TryGetProperty("bponly", out var b) && b.ValueKind is JsonValueKind.True or JsonValueKind.False)
                _bpOnly = b.GetBoolean();
            if (body.TryGetProperty("keepteam", out var k) && k.ValueKind is JsonValueKind.True or JsonValueKind.False)
            {
                _keepTeam = k.GetBoolean();
                // 개발팀까지 대상에 넣는 것은 평소와 다른 선택이다 — 누가 언제 그랬는지 남긴다.
                Console.WriteLine($"[ora/opt] {DateTime.Now:HH:mm:ss} 개발팀 제외={_keepTeam}"
                                + $" by={await WhoAsync(g, ctx)} ua={Agent(ctx)}");
            }
            Persist();
            return Results.Ok(State());
        });

        app.MapPut("/api/ora/auto", async (IpGate g, HttpContext ctx, JsonElement body) =>
        {
            if (await DenyAsync(g, ctx) is { } no) return no;
            var sec = body.TryGetProperty("seconds", out var s) && s.TryGetInt32(out var v) ? v : 0;
            if (sec != 0 && Allowed(sec) == 0)
                return Results.BadRequest(new { error = "고를 수 있는 간격이 아닙니다: " + sec });

            _auto = sec;
            if (sec > 0) _lastChoice = sec;
            _autoBy = sec > 0 ? await WhoAsync(g, ctx) : "";
            _autoAt = sec > 0 ? DateTimeOffset.Now : null;
            _nextAt = sec > 0 ? DateTimeOffset.Now.AddSeconds(sec) : null;
            // 남의 세션을 자동으로 끊기 시작하는 순간이다 — 누가 언제 켰는지 반드시 남긴다.
            Console.WriteLine($"[ora/auto] {DateTime.Now:HH:mm:ss} {(sec > 0 ? $"켬 {sec}초" : "끔")}"
                            + $" by={_autoBy} ip={(await g.CheckAsync(ctx)).Ip} ua={Agent(ctx)}");
            Persist();
            return Results.Ok(State());
        });

        // 뜨자마자 커넥션을 잡는다 — 자리가 있을 때 미리 잡아 두는 것이 이 기능의 요점이다.
        app.Lifetime.ApplicationStarted.Register(() => _ = LoopAsync(app.Lifetime.ApplicationStopping));
        app.Lifetime.ApplicationStopping.Register(() =>
        {
            try { _proc?.Kill(true); } catch { }
        });
    }

    private static async Task LoopAsync(CancellationToken stop)
    {
        // 첫 연결은 바로 — 늦게 잡을수록 자리가 없을 확률이 올라간다
        try { _pool = Pick(await SendAsync("status")); } catch { }

        var beat = 0;
        while (!stop.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(1000, stop);

                // ① 연결 상태를 꾸준히 살핀다. 자바가 죽어 있으면 SendAsync 가 다시 띄운다.
                if (++beat >= 10)
                {
                    beat = 0;
                    try { _pool = Pick(await SendAsync("status")); } catch { }
                }

                // ② 자동 실행 — 1초마다 <지금이 그때인지>만 본다.
                //    Timer 를 간격으로 걸면 바꾼 값이 다음 한 바퀴 뒤에야 듣는다.
                if (_auto <= 0) { _nextAt = null; continue; }
                _nextAt ??= DateTimeOffset.Now.AddSeconds(_auto);
                if (DateTimeOffset.Now < _nextAt) continue;
                _nextAt = DateTimeOffset.Now.AddSeconds(_auto);
                await RunOnceAsync("sweep", $"자동({_auto}초)");
            }
            catch (OperationCanceledException) { return; }
            catch { /* 한 바퀴 실패로 멈추면 안 된다 */ }
        }
    }
}
