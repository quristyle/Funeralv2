-- ---------------------------------------------------------------------------
-- Per-user UI preferences (currently: which columns the detail list shows).
--
-- Why a table and not localStorage:
--   localStorage lives in ONE browser. The same person on another PC, or after
--   clearing site data, lost their column choice. Keyed by bp_id it follows the
--   person instead of the machine.
--
-- Who is "the user": IpGate resolves the caller's IP to dev_user.bp_id.
-- When it cannot (server-local, unregistered IP), the client keeps using
-- localStorage - so the feature degrades quietly instead of failing.
--
-- pref_val holds JSON as text. This driver binds everything as text and the
-- values are small, so json/jsonb would buy nothing here.
-- ---------------------------------------------------------------------------

create table if not exists public.dev_user_pref (
  bp_id      text      not null,
  pref_key   text      not null,
  pref_val   text,
  updated_at timestamp default now(),
  primary key (bp_id, pref_key)
);

comment on table public.dev_user_pref is 'Per-user UI preferences, keyed by dev_user.bp_id. JSON text in pref_val.';
