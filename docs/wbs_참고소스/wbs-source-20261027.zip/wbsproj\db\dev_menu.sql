-- 메뉴 권한 — 개발자별로 쓸 수 있는 화면을 지정한다.
--
-- 정책: <행이 없으면 허용>. 막고 싶은 것만 allow_yn='N' 으로 한 줄 남긴다.
--   · 지금 쓰는 사람들이 갑자기 잠기지 않는다 (아무 행도 없으므로 전원 전체 허용)
--   · 메뉴를 새로 만들어도 저절로 숨지 않는다 (행이 없으니 허용)
-- 화이트리스트로 쓰고 싶으면 권한 화면에서 [모두 끄기] 한 뒤 쓸 것만 켜면 된다.

create table if not exists public.dev_menu (
    menu_key   varchar(40) primary key,
    menu_nm    varchar(60),
    sort_order int         default 0,
    use_yn     varchar(1)  default 'Y',
    updated_at timestamptz default now()
);

comment on table public.dev_menu is '대시보드 메뉴 목록 (권한 화면이 보여 줄 대상)';

create table if not exists public.dev_user_menu (
    bp_id      varchar(40) not null,
    menu_key   varchar(40) not null,
    allow_yn   varchar(1)  not null default 'Y',
    updated_at timestamptz default now(),
    updated_by varchar(40),
    primary key (bp_id, menu_key)
);

comment on table public.dev_user_menu is
    '개발자별 메뉴 권한 — 행이 없으면 허용. allow_yn=N 인 줄만 막는다';

create index if not exists ix_dev_user_menu_bp on public.dev_user_menu (bp_id);

-- 지금 화면에 있는 메뉴를 넣어 둔다. 이름이 바뀌면 갱신한다.
insert into public.dev_menu (menu_key, menu_nm, sort_order) values
    ('summary', '요약',                      1),
    ('period',  '기간별 현황',                  2),
    ('users',   '개발자별 현황',                 3),
    ('modules', '모듈별 현황',                  4),
    ('progress','진척률 현황',                  5),
    ('delay',   '지연 현황',                   6),
    ('rows',    '상세 목록',                   7),
    ('ci',      '빌드 상태',                   8),
    ('glmon',   'GitLab 모니터링',             9),
    ('devui',   '로컬 개발서버',                10),
    ('libs',    '라이브러리 저장소',              11),
    ('orakill', 'DB 세션 정리',               12),
    ('iface',   '인터페이스 관리',               13),
    ('pvsync',  'ProjectView 동기화',        14),
    ('pvflow',  '워크플로 채우기',               15),
    ('mflow',   '업무흐름 시나리오',              16),
    ('flow',    '자재업무 흐름도',               17),
    ('tables',  '테이블 계통도',                18),
    ('pdflow',  'PD 설계 프로세스',             19),
    ('docs',    '개발자 정보',                 20),
    ('files',   '보관 파일',                  21),
    ('devusers','개발자 관리',                 22),
    ('perms',   '메뉴 권한',                  23),
    ('testfail','단위테스트 FAIL',             24),
    ('lshipchg','대형선 설계 변경이력',           25),
    ('tables2', '테이블 계통도 (편집)',           26)
on conflict (menu_key) do update
   set menu_nm    = excluded.menu_nm,
       sort_order = excluded.sort_order,
       updated_at = now();
