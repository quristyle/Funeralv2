using System.Text.Json;
using System.Text.RegularExpressions;

namespace WbsApi;

/// <summary>
/// 사내 Nexus 저장소에 무엇이 들어 있는지 본다 — [라이브러리 저장소] 화면(#/libs).
///
/// <b>왜 필요한가.</b> 18개 FE/BE 가 모두 같은 사내 라이브러리(<c>@dxb/core</c> ·
/// <c>com.hd:dxb-*</c>)에 핀돼 있다. 그런데 <b>저장소에 지금 무엇이 몇 버전 있는지,
/// 언제 누가 올렸는지</b> 볼 데가 없었다. 2026-10-07 오전에 <c>npm-private</c> 가 통째로
/// 비워졌다 다시 채워지는 동안 전 모듈 CI 가 같이 죽었는데, 그때도 <b>보고 판단할 화면이 없어</b>
/// curl 로 하나씩 두드려야 했다.
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>⚠️ <c>npm view</c> 로 판정하지 않는다 — 로컬 캐시를 탄다.</b>
/// <c>npm view @dxb/core versions --registry=…</c> 는 npm 의 메타 캐시가 있으면
/// <b>옛 목록을 그대로 보여 준다</b>(저장소가 비어 있어도 버전이 나온다). 그래서 이 파일은
/// 전부 <b>Nexus REST API 를 직접</b> 친다. 받는 것도 훨씬 많다 —
/// <b>파일 크기 · 올린 시각 · 올린 계정과 IP · 마지막 내려받은 시각 · 체크섬</b>은
/// <c>npm view</c> 로는 아예 볼 수 없는 값이다.
///
/// 쓰는 길은 셋이고, <b>쓰임새가 갈린다</b>.
///   ① <c>/service/rest/v1/repositories</c> — 저장소 목록(형식·종류).
///   ② <c>/service/rest/v1/components?repository=X</c> — 한 저장소를 <b>통째로</b> 훑는다.
///      한 쪽에 10건씩이라 <c>continuationToken</c> 으로 이어 받는다. 큰 저장소
///      (<c>maven-snapshots</c> 는 3000건 이상)는 <c>Nexus:MaxPages</c> 에서 끊고
///      <c>truncated</c> 로 <b>끊겼다는 사실을 화면에 밝힌다</b>.
///   ③ <c>/service/rest/v1/search?group=&amp;name=</c> — <b>찾을 것을 알 때</b> 쓴다.
///      [PMM 사용] 탭이 이것만 쓴다. 통째로 훑지 않으니 <c>npm-registry</c> 처럼
///      수천 건짜리 프록시에서도 즉답이 온다.
///
/// <b>dist-tag 는 ②로 알 수 없다.</b> 컴포넌트 API 는 <c>latest</c>/<c>alpha</c> 가 어느 버전을
/// 가리키는지 모른다. npm 형식일 때만 packument(<c>/repository/{repo}/{name}</c>)를 따로 읽어
/// <b>dist-tags 와 sha512 integrity</b>를 붙인다. integrity 는 lockfile 이 물고 있는 바로 그 값이라
/// <c>ERR_PNPM_TARBALL_INTEGRITY</c> 를 눈으로 대조할 수 있다(컴포넌트 API 는 sha1 만 준다).
/// scope 는 <c>%2f</c> 로 인코딩해야 한다.
///
/// ─────────────────────────────────────────────────────────────────────────────
/// <b>[PMM 사용] 탭은 로컬 체크아웃을 읽는다.</b> <c>DevRun.DeployTargets()</c> 가 아는
/// 프로젝트 중 <c>Nexus:ModuleRe</c>(기본 <c>^pmm\d{3}$</c>)에 걸리는 것만 골라
/// FE 는 <c>package.json</c>, BE 는 <c>build.gradle(.kts)</c>·<c>pom.xml</c> 에서
/// <b>직접 선언한 의존성</b>을 긁는다. 그 PC 에 체크아웃이 없으면 그 모듈은 빠진다 —
/// 화면이 <c>scanned</c> 로 <b>몇 개를 실제로 읽었는지</b> 함께 내려 준다.
///
/// <b>전이 의존성(transitive)은 보지 않는다.</b> lockfile·의존성 트리를 풀면 수천 건이 되고,
/// 이 화면이 답하려는 것은 <b>우리가 무엇에 못을 박아 두었나</b> 이기 때문이다.
/// BOM 이 버전을 쥐는 선언(<c>spring-boot-starter-web</c> 처럼 버전이 없는 줄)도 같은 까닭에 뺀다 —
/// 저장소에서 찾을 버전 자체가 없다.
///
/// <b>범위 표기(<c>^1.2.3</c>)는 풀지 않는다.</b> semver 해석기를 들이지 않았다.
/// PMM FE 는 전부 정확한 버전으로 핀돼 있어 실제로는 거의 걸리지 않고, 걸리면 화면이
/// <c>exact=false</c> 로 <b>범위라는 사실을 그대로 밝힌다</b>. 지어낸 해석보다 낫다고 보았다.
/// </summary>
public static partial class Nexus
{
    // 사내 호스트다. 프록시를 타면 엉뚱한 응답으로 가려진다 (DevDeploy 와 같은 까닭).
    private static readonly HttpClient Http =
        new(new HttpClientHandler { UseProxy = false }) { Timeout = TimeSpan.FromSeconds(30) };

    private static string _base = "";
    private static int _ttl, _usedTtl, _maxPages, _packument, _searchPages, _maxVersions;
    private static string _default = "";
    private static Regex _moduleRe = ModuleDefault();

    // 저장소 목록은 거의 바뀌지 않는다 — 따로 길게 잡는다
    private static List<Dictionary<string, object?>>? _repos;
    private static DateTimeOffset _reposAt = DateTimeOffset.MinValue;

    // 저장소 한 곳을 통째로 훑은 결과 (저장소 이름별)
    private static readonly Dictionary<string, (object Payload, DateTimeOffset At)> BrowseCache =
        new(StringComparer.OrdinalIgnoreCase);

    private static object? _used;
    private static DateTimeOffset _usedAt = DateTimeOffset.MinValue;

    private static readonly SemaphoreSlim Gate = new(1, 1);

    [GeneratedRegex(@"^pmm\d{3}$", RegexOptions.IgnoreCase)]
    private static partial Regex ModuleDefault();

    /// <summary>gradle 의 <c>implementation("g:a:v")</c> 류 — 버전이 붙은 줄만 잡는다.</summary>
    [GeneratedRegex(
        """(?:implementation|api|compileOnly|compileOnlyApi|runtimeOnly|annotationProcessor|providedRuntime|providedCompile|testImplementation|testRuntimeOnly|developmentOnly|enforcedPlatform|platform)\s*\(\s*["']([A-Za-z0-9_.\-]+):([A-Za-z0-9_.\-]+):([A-Za-z0-9_.+\-]+)["']""",
        RegexOptions.IgnoreCase)]
    private static partial Regex GradleDep();

    /// <summary>pom.xml 의 <c>&lt;dependency&gt;</c> 한 덩이.</summary>
    [GeneratedRegex(@"<dependency>(.*?)</dependency>", RegexOptions.Singleline | RegexOptions.IgnoreCase)]
    private static partial Regex PomDep();

    public static void Init(IConfiguration cfg)
    {
        _base = (cfg["Nexus:BaseUrl"] ?? "http://repo-hiway.hhigroup.kr/nexus").TrimEnd('/');
        _ttl = cfg.GetValue("Nexus:CacheSeconds", 300);
        _usedTtl = cfg.GetValue("Nexus:UsedCacheSeconds", 300);
        _maxPages = cfg.GetValue("Nexus:MaxPages", 60);
        _packument = cfg.GetValue("Nexus:Packument", 40);
        _searchPages = cfg.GetValue("Nexus:SearchPages", 4);
        _maxVersions = cfg.GetValue("Nexus:MaxVersions", 80);
        _default = cfg["Nexus:Default"] ?? "npm-private";

        var re = cfg["Nexus:ModuleRe"];
        if (!string.IsNullOrWhiteSpace(re))
            try { _moduleRe = new Regex(re, RegexOptions.IgnoreCase); } catch { /* 기본값을 쓴다 */ }

        var ms = cfg.GetValue("Nexus:TimeoutMs", 30000);
        if (ms is > 1000 and <= 120000) Http.Timeout = TimeSpan.FromMilliseconds(ms);
    }

    // ────────────────────────────────────────────────────────────────────────
    //  공통
    // ────────────────────────────────────────────────────────────────────────

    /// <summary>저장소가 안 열릴 때의 안내 — 화면이 빈 표 대신 까닭을 받는다.</summary>
    private sealed class Down(string msg) : Exception(msg);

    private static async Task<JsonDocument> GetAsync(string url)
    {
        HttpResponseMessage res;
        try { res = await Http.GetAsync(url); }
        catch (TaskCanceledException) { throw new Down($"저장소 응답이 없습니다 (제한시간 초과) — {_base}"); }
        catch (HttpRequestException e) { throw new Down($"저장소에 닿지 못했습니다 — {e.Message}"); }

        using (res)
        {
            var body = await res.Content.ReadAsStringAsync();
            if (!res.IsSuccessStatusCode)
                throw new Down((int)res.StatusCode switch
                {
                    401 or 403 => "저장소가 권한을 요구합니다 (익명 조회 불가).",
                    404 => "그런 저장소가 없습니다.",
                    _ => $"저장소 응답 HTTP {(int)res.StatusCode}",
                });
            try { return JsonDocument.Parse(body); }
            catch (JsonException) { throw new Down("저장소 응답을 읽지 못했습니다 (JSON 아님)."); }
        }
    }

    private static string? S(JsonElement e, string n) =>
        e.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    private static long L(JsonElement e, string n) =>
        e.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetInt64() : 0;

    /// <summary>ISO 문자열 → 보기 좋은 현지 시각. 못 읽으면 원문을 그대로 돌려준다.</summary>
    private static string? When(string? iso) =>
        iso is null ? null
        : DateTimeOffset.TryParse(iso, out var d) ? d.ToLocalTime().ToString("yyyy-MM-dd HH:mm")
        : iso;

    // ────────────────────────────────────────────────────────────────────────
    //  컴포넌트 한 건 → 화면이 쓸 모양
    // ────────────────────────────────────────────────────────────────────────

    /// <summary>체크섬 곁파일 — 용량에도 개수에도 넣지 않는다 (maven 은 한 버전에 15개까지 붙는다).</summary>
    private static bool IsSidecar(string path) =>
        path.EndsWith(".md5", StringComparison.OrdinalIgnoreCase)
        || path.EndsWith(".sha1", StringComparison.OrdinalIgnoreCase)
        || path.EndsWith(".sha256", StringComparison.OrdinalIgnoreCase)
        || path.EndsWith(".sha512", StringComparison.OrdinalIgnoreCase)
        || path.EndsWith(".asc", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// <b>실제로 쓰는 파일</b>을 고른다. maven 한 버전에는 jar · sources · javadoc · pom · module 이
    /// 함께 올라와, 전부 더하면 <c>217KB</c>(= javadoc) 처럼 <b>쓰지도 않는 것이 대표값</b>이 된다.
    /// 그래서 분류자(classifier) 없는 본체를 먼저 찾고, 없으면 가장 큰 것을 쓴다.
    /// </summary>
    private static JsonElement? MainAsset(List<JsonElement> assets, string format)
    {
        if (assets.Count == 0) return null;
        if (assets.Count == 1) return assets[0];

        if (format == "maven2")
        {
            JsonElement? pom = null;
            foreach (var a in assets)
            {
                if (!a.TryGetProperty("maven2", out var m) || m.ValueKind != JsonValueKind.Object) continue;
                var cls = S(m, "classifier");
                if (!string.IsNullOrEmpty(cls)) continue;              // sources · javadoc 은 본체가 아니다
                var ext = S(m, "extension") ?? "";
                if (ext is "jar" or "war" or "aar" or "ear" or "zip" or "tar.gz") return a;
                if (ext == "pom") pom = a;
            }
            // 본체 없이 pom 만 올라오는 것도 있다 (BOM · parent pom)
            if (pom is not null) return pom;
        }
        if (format == "npm")
            foreach (var a in assets)
                if ((S(a, "path") ?? "").EndsWith(".tgz", StringComparison.OrdinalIgnoreCase)) return a;

        return assets.OrderByDescending(a => L(a, "fileSize")).First();
    }

    /// <summary>컴포넌트(= 패키지의 한 버전) 하나를 화면용 한 줄로.</summary>
    private static Dictionary<string, object?> VerRow(JsonElement comp)
    {
        var format = S(comp, "format") ?? "";
        var assets = comp.TryGetProperty("assets", out var ar) && ar.ValueKind == JsonValueKind.Array
            ? ar.EnumerateArray().Where(a => !IsSidecar(S(a, "path") ?? "")).ToList()
            : [];

        var main = MainAsset(assets, format);
        var sum = assets.Sum(a => L(a, "fileSize"));

        string? sha1 = null;
        if (main is { } m && m.TryGetProperty("checksum", out var ck) && ck.ValueKind == JsonValueKind.Object)
            sha1 = S(ck, "sha1");

        var mod = main is null ? null : S(main.Value, "lastModified") ?? S(main.Value, "blobCreated");
        // 본체가 없으면(곁파일만 남은 이상한 상태) 아무 자산의 시각이라도 쓴다 — 빈 칸보다 낫다
        mod ??= assets.Select(a => S(a, "lastModified")).FirstOrDefault(x => x is not null);

        return new Dictionary<string, object?>
        {
            ["version"] = S(comp, "version") ?? "(버전 없음)",
            ["repository"] = S(comp, "repository"),
            ["size"] = main is null ? 0 : L(main.Value, "fileSize"),
            ["size_all"] = sum,
            ["assets"] = assets.Count,
            ["modified"] = When(mod),
            ["modified_at"] = mod,
            ["uploader"] = main is null ? null : S(main.Value, "uploader"),
            ["uploader_ip"] = main is null ? null : S(main.Value, "uploaderIp"),
            ["downloaded"] = When(main is null ? null : S(main.Value, "lastDownloaded")),
            ["sha1"] = sha1,
            ["integrity"] = null,                                   // npm packument 에서 뒤에 채운다
            ["url"] = main is null ? null : S(main.Value, "downloadUrl"),
            ["path"] = main is null ? null : S(main.Value, "path"),
        };
    }

    /// <summary>컴포넌트의 묶음 이름 — npm 은 <c>@scope/name</c>, maven 은 <c>group:artifact</c>.</summary>
    private static (string Key, string? Group, string Name) KeyOf(JsonElement comp)
    {
        var g = S(comp, "group");
        var n = S(comp, "name") ?? "";
        var f = S(comp, "format") ?? "";
        var key = f switch
        {
            "npm" => string.IsNullOrEmpty(g) ? n : $"@{g}/{n}",
            "maven2" or "nuget" when !string.IsNullOrEmpty(g) => $"{g}:{n}",
            _ => n,
        };
        return (key, g, n);
    }

    /// <summary>버전을 최신 등록순으로. 시각이 없으면 이름 역순으로 떨어뜨린다.</summary>
    private static List<Dictionary<string, object?>> SortVers(IEnumerable<Dictionary<string, object?>> v) =>
        [.. v.OrderByDescending(x => x["modified_at"] as string ?? "")
             .ThenByDescending(x => x["version"] as string ?? "", StringComparer.OrdinalIgnoreCase)];

    // ────────────────────────────────────────────────────────────────────────
    //  npm packument — dist-tags 와 sha512 integrity
    // ────────────────────────────────────────────────────────────────────────

    private sealed record Pack(
        Dictionary<string, string> Tags, Dictionary<string, string> Integrity,
        string? Description, string? Homepage, string? RepoUrl);

    private static async Task<Pack?> PackumentAsync(string repo, string pkgName)
    {
        try
        {
            // scope 의 '/' 는 반드시 %2f 로 — 그대로 두면 Nexus 가 다른 경로로 읽는다
            var enc = Uri.EscapeDataString(pkgName).Replace("%40", "@");
            using var doc = await GetAsync($"{_base}/repository/{repo}/{enc}");
            var r = doc.RootElement;

            var tags = new Dictionary<string, string>();
            if (r.TryGetProperty("dist-tags", out var dt) && dt.ValueKind == JsonValueKind.Object)
                foreach (var p in dt.EnumerateObject())
                    if (p.Value.ValueKind == JsonValueKind.String) tags[p.Name] = p.Value.GetString()!;

            var integ = new Dictionary<string, string>();
            string? desc = S(r, "description"), home = null, repoUrl = null;
            if (r.TryGetProperty("versions", out var vs) && vs.ValueKind == JsonValueKind.Object)
                foreach (var p in vs.EnumerateObject())
                {
                    if (p.Value.TryGetProperty("dist", out var d) && d.ValueKind == JsonValueKind.Object
                        && S(d, "integrity") is { } ig) integ[p.Name] = ig;
                    desc ??= S(p.Value, "description");
                    home ??= S(p.Value, "homepage");
                    if (repoUrl is null && p.Value.TryGetProperty("repository", out var rp)
                        && rp.ValueKind == JsonValueKind.Object) repoUrl = S(rp, "url");
                }
            return new Pack(tags, integ, desc, home, repoUrl);
        }
        catch { return null; }    // packument 는 덤이다 — 없다고 목록을 못 주면 곤란하다
    }

    /// <summary>npm 묶음들에 dist-tag·integrity·설명을 붙인다 (요청 수를 <c>Nexus:Packument</c> 로 끊는다).</summary>
    private static async Task EnrichNpmAsync(string repo, List<Dictionary<string, object?>> packages)
    {
        var targets = packages.Take(Math.Max(0, _packument)).ToList();
        if (targets.Count == 0) return;

        using var gate = new SemaphoreSlim(6, 6);
        await Task.WhenAll(targets.Select(async p =>
        {
            await gate.WaitAsync();
            try
            {
                var pk = await PackumentAsync(repo, (string)p["key"]!);
                if (pk is null) return;
                p["tags"] = pk.Tags;
                p["description"] = pk.Description;
                p["homepage"] = pk.Homepage;
                p["repo_url"] = pk.RepoUrl;
                foreach (var v in (List<Dictionary<string, object?>>)p["list"]!)
                    if (v["version"] is string ver && pk.Integrity.TryGetValue(ver, out var ig))
                        v["integrity"] = ig;
            }
            finally { gate.Release(); }
        }));
        if (packages.Count > targets.Count)
            foreach (var p in packages.Skip(targets.Count)) p["tags_skipped"] = true;
    }

    // ────────────────────────────────────────────────────────────────────────
    //  ① 저장소 목록
    // ────────────────────────────────────────────────────────────────────────

    private static async Task<List<Dictionary<string, object?>>> ReposAsync(bool force)
    {
        if (!force && _repos is not null && DateTimeOffset.UtcNow - _reposAt < TimeSpan.FromMinutes(10))
            return _repos;

        using var doc = await GetAsync($"{_base}/service/rest/v1/repositories");
        var list = doc.RootElement.EnumerateArray().Select(r => new Dictionary<string, object?>
        {
            ["name"] = S(r, "name"),
            ["format"] = S(r, "format"),
            ["type"] = S(r, "type"),
            ["url"] = S(r, "url"),
        }).ToList();

        // hosted(우리가 올린 것) 가 먼저다 — 이 화면이 보려는 것이 그쪽이다
        list.Sort((a, b) =>
        {
            int Rank(object? t) => (t as string) switch { "hosted" => 0, "group" => 1, _ => 2 };
            var r = Rank(a["type"]).CompareTo(Rank(b["type"]));
            if (r != 0) return r;
            r = string.CompareOrdinal(a["format"] as string, b["format"] as string);
            return r != 0 ? r : string.Compare(a["name"] as string, b["name"] as string,
                                               StringComparison.OrdinalIgnoreCase);
        });

        _repos = list;
        _reposAt = DateTimeOffset.UtcNow;
        return list;
    }

    // ────────────────────────────────────────────────────────────────────────
    //  ② 저장소 통째로 훑기
    // ────────────────────────────────────────────────────────────────────────

    private static async Task<object> BrowseAsync(string repo, bool force)
    {
        if (!force && BrowseCache.TryGetValue(repo, out var hit)
            && DateTimeOffset.UtcNow - hit.At < TimeSpan.FromSeconds(_ttl))
            return hit.Payload;

        var repos = await ReposAsync(false);
        var meta = repos.FirstOrDefault(r => string.Equals(r["name"] as string, repo, StringComparison.OrdinalIgnoreCase))
                   ?? throw new Down($"그런 저장소가 없습니다: {repo}");
        var format = meta["format"] as string ?? "";

        var comps = new List<JsonElement>();
        var docs = new List<JsonDocument>();          // JsonElement 는 문서가 살아 있어야 읽힌다
        string? token = null;
        var pages = 0;
        try
        {
            do
            {
                var url = $"{_base}/service/rest/v1/components?repository={Uri.EscapeDataString(repo)}"
                          + (token is null ? "" : $"&continuationToken={Uri.EscapeDataString(token)}");
                var doc = await GetAsync(url);
                docs.Add(doc);
                pages++;
                if (doc.RootElement.TryGetProperty("items", out var items) && items.ValueKind == JsonValueKind.Array)
                    comps.AddRange(items.EnumerateArray());
                token = S(doc.RootElement, "continuationToken");
            } while (token is not null && pages < _maxPages);

            var packages = new Dictionary<string, Dictionary<string, object?>>(StringComparer.OrdinalIgnoreCase);
            foreach (var c in comps)
            {
                var (key, g, n) = KeyOf(c);
                if (!packages.TryGetValue(key, out var p))
                    packages[key] = p = new Dictionary<string, object?>
                    {
                        ["key"] = key, ["group"] = g, ["name"] = n,
                        ["list"] = new List<Dictionary<string, object?>>(),
                    };
                ((List<Dictionary<string, object?>>)p["list"]!).Add(VerRow(c));
            }

            var rows = packages.Values.ToList();
            foreach (var p in rows)
            {
                var vs = SortVers((List<Dictionary<string, object?>>)p["list"]!);
                p["list"] = vs;
                p["versions"] = vs.Count;
                // 합계는 <본체>끼리 더한다. 줄마다 보여 주는 값과 같은 잣대여야
                // "2판 × 42KB 인데 합계가 589KB" 같은 앞뒤 안 맞는 표가 되지 않는다.
                // 디스크를 실제로 얼마나 먹는지는 size_all 쪽이라 따로 함께 준다.
                p["bytes"] = vs.Sum(v => (long)v["size"]!);
                p["bytes_all"] = vs.Sum(v => (long)v["size_all"]!);
                p["newest"] = vs.Count > 0 ? vs[0]["modified"] : null;
                p["newest_version"] = vs.Count > 0 ? vs[0]["version"] : null;
            }
            rows.Sort((a, b) => string.Compare(a["key"] as string, b["key"] as string,
                                               StringComparison.OrdinalIgnoreCase));

            if (format == "npm") await EnrichNpmAsync(repo, rows);

            var payload = new
            {
                repository = repo,
                format,
                type = meta["type"],
                url = meta["url"],
                at = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                pages,
                truncated = token is not null,
                max_pages = _maxPages,
                packument = format == "npm" ? _packument : (int?)null,
                total = new
                {
                    packages = rows.Count,
                    versions = rows.Sum(p => (int)p["versions"]!),
                    bytes = rows.Sum(p => (long)p["bytes"]!),
                    bytes_all = rows.Sum(p => (long)p["bytes_all"]!),
                },
                packages = rows,
            };

            BrowseCache[repo] = (payload, DateTimeOffset.UtcNow);
            return payload;
        }
        finally { foreach (var d in docs) d.Dispose(); }
    }

    // ────────────────────────────────────────────────────────────────────────
    //  ③ PMM001~018 이 쓰는 것
    // ────────────────────────────────────────────────────────────────────────

    /// <summary>한 모듈이 선언한 의존성 한 줄.</summary>
    private sealed record Want(string Eco, string Key, string? Group, string Name, string Spec,
                               string Module, string Tier, string Kind);

    private static void ScanNpm(string dir, string module, List<Want> into, List<string> bad)
    {
        var f = Path.Combine(dir, "package.json");
        if (!File.Exists(f)) { bad.Add($"{module} fe: package.json 없음"); return; }
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(f));
            foreach (var (prop, kind) in new[] { ("dependencies", "dep"), ("devDependencies", "dev") })
            {
                if (!doc.RootElement.TryGetProperty(prop, out var o) || o.ValueKind != JsonValueKind.Object) continue;
                foreach (var p in o.EnumerateObject())
                {
                    var spec = p.Value.ValueKind == JsonValueKind.String ? p.Value.GetString() ?? "" : "";
                    // workspace:·file:·git+ 는 저장소에 없는 것이다 — 찾으러 가 봐야 헛걸음이다
                    if (spec.Contains(':') && !spec.StartsWith("npm:", StringComparison.Ordinal)) continue;
                    var name = p.Name;
                    var (g, n) = name.StartsWith('@') && name.Contains('/')
                        ? (name[1..name.IndexOf('/')], name[(name.IndexOf('/') + 1)..])
                        : ((string?)null, name);
                    into.Add(new Want("npm", name, g, n, spec, module, "fe", kind));
                }
            }
        }
        catch (Exception e) { bad.Add($"{module} fe: {e.Message}"); }
    }

    private static void ScanMaven(string dir, string module, List<Want> into, List<string> bad)
    {
        var files = new[] { "build.gradle.kts", "build.gradle", "pom.xml" }
            .Select(n => Path.Combine(dir, n)).Where(File.Exists).ToList();
        if (files.Count == 0) { bad.Add($"{module} be: build.gradle(.kts)·pom.xml 없음"); return; }

        foreach (var f in files)
        {
            try
            {
                var text = File.ReadAllText(f);
                if (f.EndsWith(".xml", StringComparison.OrdinalIgnoreCase))
                {
                    foreach (Match m in PomDep().Matches(text))
                    {
                        string? Tag(string t) =>
                            Regex.Match(m.Groups[1].Value, $"<{t}>(.*?)</{t}>", RegexOptions.Singleline) is { Success: true } x
                                ? x.Groups[1].Value.Trim() : null;
                        var g = Tag("groupId"); var a = Tag("artifactId"); var v = Tag("version");
                        // 버전이 없으면 BOM 이 쥐고 있는 것이다. 저장소에서 찾을 값이 없으니 뺀다.
                        if (g is null || a is null || v is null || v.Contains('$')) continue;
                        into.Add(new Want("maven", $"{g}:{a}", g, a, v, module, "be", "dep"));
                    }
                }
                else
                {
                    foreach (Match m in GradleDep().Matches(text))
                    {
                        var g = m.Groups[1].Value; var a = m.Groups[2].Value; var v = m.Groups[3].Value;
                        into.Add(new Want("maven", $"{g}:{a}", g, a, v, module, "be", "dep"));
                    }
                }
            }
            catch (Exception e) { bad.Add($"{module} be: {e.Message}"); }
        }
    }

    /// <summary>
    /// 저장소에서 한 패키지를 찾는다 (③ search API — 통째로 훑지 않는다).
    ///
    /// <b>⚠️ 받은 것을 그대로 쓰면 안 된다.</b> <c>name=vite</c> 는 <c>vite</c> 뿐 아니라
    /// <c>@module-federation/vite</c> 까지 물어 온다 — Nexus 의 <c>name</c> 은 토큰 일치라
    /// <b>scope(group)가 다른 동명이인</b>이 섞인다. 그대로 두면 vite 의 <최신>이
    /// <c>1.20.1</c>(= module-federation 의 버전)로 둔갑한다. 그래서 group·name 을
    /// <b>글자 그대로 다시 맞춰 본다.</b>
    /// </summary>
    private static async Task<(List<Dictionary<string, object?>> Rows, bool Capped)> SearchAsync(
        string? group, string name)
    {
        var rows = new List<Dictionary<string, object?>>();
        var docs = new List<JsonDocument>();
        string? token = null;
        var pages = 0;
        try
        {
            do
            {
                var url = $"{_base}/service/rest/v1/search?name={Uri.EscapeDataString(name)}"
                          + (string.IsNullOrEmpty(group) ? "" : $"&group={Uri.EscapeDataString(group)}")
                          + (token is null ? "" : $"&continuationToken={Uri.EscapeDataString(token)}");
                var doc = await GetAsync(url);
                docs.Add(doc);
                pages++;
                if (doc.RootElement.TryGetProperty("items", out var items) && items.ValueKind == JsonValueKind.Array)
                    foreach (var c in items.EnumerateArray())
                    {
                        if (!string.Equals(S(c, "name"), name, StringComparison.OrdinalIgnoreCase)) continue;
                        var g = S(c, "group") ?? "";
                        if (!string.Equals(g, group ?? "", StringComparison.OrdinalIgnoreCase)) continue;
                        rows.Add(VerRow(c));
                    }
                token = S(doc.RootElement, "continuationToken");
            } while (token is not null && pages < _searchPages);
        }
        finally { foreach (var d in docs) d.Dispose(); }
        return (rows, token is not null);
    }

    /// <summary>
    /// 선언한 버전과 저장소의 버전이 <b>같은 것인지</b>. <c>^1.2.3</c> 같은 범위는 풀지 않는다 —
    /// 앞의 기호만 떼어 글자 그대로 맞춰 보고, 기호가 있었다는 사실(<c>exact=false</c>)을 남긴다.
    /// </summary>
    private static (string Bare, bool Exact) Spec(string spec)
    {
        var s = (spec ?? "").Trim();
        if (s.StartsWith("npm:", StringComparison.Ordinal))
        {
            var at = s.LastIndexOf('@');
            s = at > 4 ? s[(at + 1)..] : s[4..];
        }
        var exact = s.Length > 0 && (char.IsDigit(s[0]) || s[0] == 'v');
        return (s.TrimStart('^', '~', '=', 'v', '>', '<', ' '), exact);
    }

    private static async Task<object> UsedAsync(bool force)
    {
        if (!force && _used is not null && DateTimeOffset.UtcNow - _usedAt < TimeSpan.FromSeconds(_usedTtl))
            return _used;

        var wants = new List<Want>();
        var bad = new List<string>();
        var modules = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
        int fe = 0, be = 0;

        foreach (var (id, label, _, tier, dir) in DevRun.DeployTargets())
        {
            if (!_moduleRe.IsMatch(id)) continue;
            modules.Add(label);
            if (!Directory.Exists(dir)) { bad.Add($"{label} {tier}: 폴더 없음"); continue; }
            if (tier == "fe") { fe++; ScanNpm(dir, label, wants, bad); }
            else { be++; ScanMaven(dir, label, wants, bad); }
        }

        // 패키지별로 모은다 — 같은 것을 18개 모듈이 저마다 선언하고 있다
        var groups = wants
            .GroupBy(w => (w.Eco, w.Key), new EcoKeyCmp())
            .OrderBy(g => g.Key.Eco).ThenBy(g => g.Key.Key, StringComparer.OrdinalIgnoreCase)
            .ToList();

        var items = new Dictionary<string, object?>[groups.Count];
        using (var gate = new SemaphoreSlim(8, 8))
        {
            await Task.WhenAll(groups.Select(async (g, i) =>
            {
                await gate.WaitAsync();
                // 한 패키지가 안 나온다고 목록 전체를 못 주면 안 된다 — 그 줄만 까닭을 달고 남는다
                try { items[i] = await OneUsedAsync(g.Key.Eco, g.Key.Key, [.. g]); }
                catch (Exception e) { items[i] = Failed(g.Key.Eco, g.Key.Key, [.. g], e.Message); }
                finally { gate.Release(); }
            }));
        }

        var payload = new
        {
            at = DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss"),
            scanned = new
            {
                modules = modules.Count, fe, be,
                list = modules.ToList(),
                problems = bad,
            },
            total = new
            {
                packages = items.Length,
                found = items.Count(x => x["found"] is true),
                missing = items.Count(x => x["found"] is false && x["error"] is null),
            },
            items = items.ToList(),
        };
        _used = payload;
        _usedAt = DateTimeOffset.UtcNow;
        return payload;
    }

    private sealed class EcoKeyCmp : IEqualityComparer<(string Eco, string Key)>
    {
        public bool Equals((string Eco, string Key) a, (string Eco, string Key) b) =>
            a.Eco == b.Eco && string.Equals(a.Key, b.Key, StringComparison.OrdinalIgnoreCase);
        public int GetHashCode((string Eco, string Key) x) =>
            HashCode.Combine(x.Eco, x.Key.ToLowerInvariant());
    }

    private static List<Dictionary<string, object?>> WantRows(List<Want> ws) =>
        [.. ws.GroupBy(w => w.Spec)
              .OrderByDescending(g => g.Count())
              .Select(g => new Dictionary<string, object?>
              {
                  ["spec"] = g.Key,
                  ["exact"] = Spec(g.Key).Exact,
                  ["bare"] = Spec(g.Key).Bare,
                  ["kind"] = g.Any(w => w.Kind == "dep") ? "dep" : "dev",
                  ["modules"] = g.Select(w => w.Module).Distinct().OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList(),
              })];

    private static Dictionary<string, object?> Failed(string eco, string key, List<Want> ws, string err) =>
        new()
        {
            ["eco"] = eco, ["key"] = key, ["group"] = ws[0].Group, ["name"] = ws[0].Name,
            ["tier"] = ws[0].Tier, ["want"] = WantRows(ws),
            ["modules"] = ws.Select(w => w.Module).Distinct().Count(),
            ["found"] = false, ["error"] = err, ["list"] = new List<object>(),
        };

    private static async Task<Dictionary<string, object?>> OneUsedAsync(string eco, string key, List<Want> ws)
    {
        var (found, capped) = await SearchAsync(ws[0].Group, ws[0].Name);
        var vers = SortVers(found);
        var want = WantRows(ws);

        // 선언한 버전이 저장소의 어느 줄인지 표시해 둔다 (화면이 그 줄에 배지를 붙인다)
        var pinned = new HashSet<string>(want.Select(w => (string)w["bare"]!), StringComparer.OrdinalIgnoreCase);
        // Dictionary 의 인덱서는 없는 키에서 예외를 던진다 — 모든 줄에 값을 넣어 두고 읽는다
        foreach (var v in vers)
            v["used"] = v["version"] is string s && pinned.Contains(s);

        var hit = vers.FirstOrDefault(v => v["used"] is true);
        // 못 찾은 버전 = 저장소에 없는데 우리가 물고 있는 것. CI 가 깨지는 바로 그 상태다.
        var gone = want.Where(w => (bool)w["exact"]!
                                   && !vers.Any(v => string.Equals(v["version"] as string, (string)w["bare"]!,
                                                                   StringComparison.OrdinalIgnoreCase)))
                       .Select(w => (string)w["spec"]!).ToList();

        var repos = vers.Select(v => v["repository"] as string).Where(x => x is not null)
                        .Distinct().OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();

        // dist-tag 는 <우리가 올린> npm 저장소일 때만 읽는다.
        // 프록시(npm-registry)의 tag 는 바깥 레지스트리의 것이고, 거기 캐시된 몇 판만 보고
        // <최신>을 말하면 틀린 말이 된다. 그만큼 요청도 아낀다 (vue 의 packument 는 수 MB 다).
        Dictionary<string, string>? tags = null;
        if (eco == "npm")
        {
            var all = await ReposAsync(false);
            var hosted = repos.FirstOrDefault(r => all.Any(
                x => string.Equals(x["name"] as string, r, StringComparison.OrdinalIgnoreCase)
                     && (x["type"] as string) == "hosted"));
            if (hosted is not null && await PackumentAsync(hosted, key) is { } pk)
            {
                tags = pk.Tags;
                foreach (var v in vers)
                    if (v["version"] is string ver && pk.Integrity.TryGetValue(ver, out var ig))
                        v["integrity"] = ig;
            }
        }

        return new Dictionary<string, object?>
        {
            ["tags"] = tags,
            ["search_capped"] = capped,
            ["eco"] = eco,
            ["key"] = key,
            ["group"] = ws[0].Group,
            ["name"] = ws[0].Name,
            ["tier"] = ws[0].Tier,
            ["want"] = want,
            ["modules"] = ws.Select(w => w.Module).Distinct().Count(),
            ["found"] = vers.Count > 0,
            ["error"] = null,
            ["repos"] = repos,
            ["versions"] = vers.Count,
            ["newest"] = vers.Count > 0 ? vers[0]["version"] : null,
            ["newest_at"] = vers.Count > 0 ? vers[0]["modified"] : null,
            ["pinned_size"] = hit?["size"],
            ["pinned_at"] = hit?["modified"],
            // 선언한 버전이 최신인가 — 등록순으로 몇 번째인지. 0 이면 최신이다.
            ["behind"] = hit is null ? (int?)null : vers.IndexOf(hit),
            ["gone"] = gone,
            ["list"] = vers.Take(_maxVersions).ToList(),
            ["list_capped"] = vers.Count > _maxVersions,
        };
    }

    // ────────────────────────────────────────────────────────────────────────
    //  라우트
    // ────────────────────────────────────────────────────────────────────────

    public static void Map(WebApplication app)
    {
        // 설정값 — 화면이 기본 저장소와 주소를 서버에서 받아 간다 (하드코딩하지 않으려고)
        app.MapGet("/api/nexus/config", () => Results.Ok(new
        {
            @base = _base,
            @default = _default,
            max_pages = _maxPages,
            module_re = _moduleRe.ToString(),
        }));

        app.MapGet("/api/nexus/repos", async (bool? force) =>
        {
            try { return Results.Ok(new { @base = _base, repos = await ReposAsync(force == true) }); }
            catch (Down e) { return Results.Json(new { error = e.Message }, statusCode: 502); }
        });

        app.MapGet("/api/nexus/browse", async (string? repository, bool? force) =>
        {
            var repo = string.IsNullOrWhiteSpace(repository) ? _default : repository.Trim();
            // 한 저장소를 두 사람이 동시에 열면 같은 수십 쪽을 두 번 긁는다 — 한 줄로 세운다
            await Gate.WaitAsync();
            try { return Results.Ok(await BrowseAsync(repo, force == true)); }
            catch (Down e) { return Results.Json(new { error = e.Message, repository = repo }, statusCode: 502); }
            finally { Gate.Release(); }
        });

        app.MapGet("/api/nexus/used", async (bool? force) =>
        {
            try { return Results.Ok(await UsedAsync(force == true)); }
            catch (Down e) { return Results.Json(new { error = e.Message }, statusCode: 502); }
        });
    }
}
