-- 개발자 정보(dev_docs) — 섹션 하나에 HTML 을 <여러 장> 올릴 수 있게 한다.
--
-- 먼저 만든 꼴(db/dev_docs_iframe.sql)은 섹션 행에 iframe_file 한 칸을 달아 두는 방식이라
-- <한 섹션에 한 장> 이 구조로 못 박혀 있었다. 칸을 iframe_file2, iframe_file3 으로 늘리는
-- 길도 있지만, 그러면 장수를 늘릴 때마다 표를 고치고 조회문을 고쳐야 한다.
-- 올리는 것은 처음부터 <목록>이었으니 목록으로 둔다.
--
-- 한 섹션 안에서 보이는 차례는 sort_order 다 (화면의 탭 차례). 같으면 id 순 — 올린 차례.
--
-- 파일 자체는 그대로 api/data/doc_files/{doc_id}/ 안에 둔다. 달라진 것은 <그 폴더를 비우지
-- 않는다> 는 것뿐이다. 이름이 겹치면 올릴 때 꼬리번호를 붙인다(api/DocFiles.cs).

create table if not exists public.dev_doc_files (
    id          serial primary key
  , doc_id      integer not null references public.dev_docs(id) on delete cascade
  , file        text    not null              -- 실제로 저장한 이름 (폴더 안에서 겹치지 않는다)
  , name        text    not null              -- 올릴 때의 원래 이름 — 화면에 그대로 보여 준다
  , bytes       bigint  not null default 0
  , sort_order  integer not null default 100
  , uploaded_at timestamptz not null default now()
  , uploaded_by text
  , unique (doc_id, file)
);

create index if not exists ix_dev_doc_files_doc on public.dev_doc_files (doc_id, sort_order, id);

comment on table  public.dev_doc_files            is '개발자 정보 섹션에 올린 HTML 문서들 (iframe 으로 보여 준다)';
comment on column public.dev_doc_files.file       is '저장한 파일 이름 — api/data/doc_files/{doc_id}/ 안';
comment on column public.dev_doc_files.name       is '올릴 때의 원래 파일 이름';
comment on column public.dev_doc_files.sort_order is '섹션 안에서의 탭 차례. 같으면 올린 차례(id)';

-- 먼저 꼴로 올려 둔 것이 있으면 옮겨 담는다. 두 번 돌려도 같은 줄이 생기지 않는다.
do $$
begin
  if exists (select 1 from information_schema.columns
              where table_schema = 'public' and table_name = 'dev_docs'
                and column_name = 'iframe_file')
  then
    insert into public.dev_doc_files (doc_id, file, name, sort_order, uploaded_at, uploaded_by)
    select d.id, d.iframe_file, coalesce(d.iframe_name, d.iframe_file), 100
         , coalesce(d.iframe_at, now()), d.iframe_by
      from public.dev_docs d
     where d.iframe_file is not null
       and not exists (select 1 from public.dev_doc_files f
                        where f.doc_id = d.id and f.file = d.iframe_file);

    -- 옮겼으면 먼저 칸은 치운다. 남겨 두면 <어느 쪽이 참인지> 를 조회문마다 따져야 한다.
    alter table public.dev_docs drop column if exists iframe_file;
    alter table public.dev_docs drop column if exists iframe_name;
    alter table public.dev_docs drop column if exists iframe_at;
    alter table public.dev_docs drop column if exists iframe_by;
  end if;
end $$;
