@echo off
rem ============================================================
rem  start.cmd - bring the WBS dashboard up, with no console window
rem
rem    start.cmd              build the front bundle, then start
rem                           API (5080 / https 5443) and Vite (5173)
rem    start.cmd fg           same, but show the windows (debugging)
rem    start.cmd nobuild      skip BOTH builds - API and front.  It starts
rem                           api\bin\Release\net9.0\WbsApi.exe as it is, so a
rem                           C# change does NOT take effect.  Run
rem                           "dotnet build -c Release" in api\ first,
rem                           or drop the flag.
rem    start.cmd fg nobuild   both
rem
rem  Nothing stays on screen. What used to scroll in the two CMD
rem  windows now goes to logs\api.log and logs\web.log (stderr in
rem  logs\*.err.log).  Take it down with stop.cmd - closing this
rem  window no longer stops anything.
rem
rem  The real work is in tools\serve.ps1.  It is kept there because
rem  this file must stay ASCII: non-ASCII text in a .bat is parsed
rem  through the active console code page and gets corrupted
rem  whenever that page does not match the file encoding.  The .ps1
rem  is UTF-8 and holds the Korean text.
rem
rem  PMM dev servers (8200+N / 3200+N) are NOT touched here.  They
rem  are deliberately detached from the dashboard (api\DevRun.cs),
rem  so they keep running across a dashboard restart.  Stop them
rem  from the dashboard's [local dev server] screen instead.
rem ============================================================
setlocal

rem  Keep our own folder BEFORE the argument loop.  "shift" moves %0 as well,
rem  so after one shift "%~dp0" is the path of the first *argument* resolved
rem  against the current directory - not this script.  That made
rem  "start.cmd nobuild" look for tools\serve.ps1 under whatever folder the
rem  caller happened to be in, and fail there.  No argument, no shift, no bug:
rem  that is why plain "start.cmd" always worked.
set "HERE=%~dp0"

set "EXTRA="

:args
if "%~1"=="" goto run
if /i "%~1"=="fg"      set "EXTRA=%EXTRA% -Foreground"
if /i "%~1"=="nobuild" set "EXTRA=%EXTRA% -NoBuild"
shift
goto args

:run
powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%tools\serve.ps1" -Action start%EXTRA%
exit /b %ERRORLEVEL%
