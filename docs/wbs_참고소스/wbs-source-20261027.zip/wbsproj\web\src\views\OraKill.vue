<script setup>
import { computed, onUnmounted, ref } from 'vue'
import { api } from '../api'
import { state, useViewRefresh, isSuper } from '../store'
import RefreshBtn from '../components/RefreshBtn.vue'

// DB 세션 정리 — 개발 DB(ORAHHIP)의 묵은 세션을 끊어 processes 자리를 비운다 (api/OraKill.cs).
//
// ⚠️ 이 화면은 <남의 세션을 끊는다>. 그래서 셋을 지킨다.
//   ① 보기(조회)와 끊기(정리)를 갈라 둔다 — 끊기 전에 무엇이 걸리는지 먼저 보여 준다.
//   ② 끊기와 자동 켜기는 Super 만. 화면이 감추는 것과 별개로 서버도 막는다.
//   ③ 자동 실행은 <서버가> 돈다. 창을 닫아도 돌고 있다는 사실이 늘 보이게 띠를 세운다.

// ⚠️ 실행(조회·정리) 응답에도 state 가 딸려 오지만 <그대로 믿지 않는다>.
// 조회가 도는 동안 사람이 조건 스위치를 바꿨으면, 응답 안의 state 는 <바꾸기 전> 값이라
// 화면이 옛 조건으로 되돌아간다. 오류도 안 나고 스위치만 혼자 튕긴다(실제로 그랬다).
// 그래서 실행이 끝나면 서버에서 다시 읽는다.
const st = ref(null)
const run = ref(null)
const busy = ref('')
const msg = ref('')
let tick = null

const sec = (n) => (n == null ? '' : n >= 3600 ? `${Math.floor(n / 3600)}시간 ${Math.floor((n % 3600) / 60)}분` : n >= 60 ? `${Math.floor(n / 60)}분 ${n % 60}초` : `${n}초`)
const label = (n) => (n >= 60 ? `${n / 60}분` : `${n}초`)

async function load() {
  try {
    st.value = await api.oraState()
  } catch (e) {
    state.error = e.message
  }
}

async function doScan() {
  busy.value = 'scan'
  msg.value = ''
  try {
    const r = await api.oraScan()
    run.value = r.run
    await load()   // 응답에 딸려 온 state 를 믿지 않는다 (아래 주석 참고)
    msg.value = r.run.ok ? `조회 완료 — 대상 ${r.run.found ?? 0}건` : (r.run.error ?? '조회 실패')
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

// 묻지 않고 바로 끊는다. 자동·단건과 같은 규칙이다 — 창이 뜨면 손이 멈추고,
// 어차피 늘 「예」를 누르게 되어 확인이 아니라 걸림돌이 된다.
// 대신 끊기 전 상태를 문구로 남겨 <무엇을 끊었는지>는 알 수 있게 한다.
async function doSweep() {
  // 끊기 직전 화면에 떠 있던 건수. 서버는 조건을 다시 걸어 다시 고르므로 이 수와
  // 실제로 끊은 수는 다를 수 있다 — 그 차이가 보이도록 둘 다 적는다.
  const n = run.value?.mode === 'scan' ? run.value?.found : null
  busy.value = 'sweep'
  msg.value = ''
  try {
    const r = await api.oraSweep()
    run.value = r.run
    await load()   // 응답에 딸려 온 state 를 믿지 않는다 (아래 주석 참고)
    const gap = n != null && n !== (r.run.ok_cnt ?? 0) ? ` (조회 때 ${n}건)` : ''
    msg.value = r.run.ok
      ? `정리 완료 — 끊음 ${r.run.ok_cnt ?? 0}건${r.run.fail_cnt ? ` · 실패 ${r.run.fail_cnt}건` : ''}${gap}`
      : (r.run.error ?? '정리 실패')
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

// 사번(BP) 세션만 볼지. 보기와 끊기가 같은 값을 쓰도록 서버가 들고 있다 —
// 화면에만 두면 <본 것과 끊는 것>이 달라질 수 있다.
// 조건 스위치 — <조건만> 바꾼다. 조회는 하지 않는다.
//
// 누르자마자 조회까지 해 버리면 스위치가 아니라 <실행 단추>가 된다. 둘을 이어 놓으면
// 조건을 두 개 바꾸려 할 때 쓸데없이 두 번 조회하고, 그 사이 목록이 왔다 갔다 한다.
// 대신 <지금 보이는 목록이 바뀐 조건과 다르다>는 것을 아래에서 알려 준다(stale).
async function setOpt(patch, note) {
  busy.value = 'opt'
  msg.value = ''
  try {
    st.value = await api.oraOptions(patch)
    msg.value = note
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}
const setBpOnly = (v) =>
  setOpt({ bponly: v }, v ? '대상을 사번(BP)만 으로 바꿨습니다.' : '대상을 전체 계정으로 바꿨습니다 — 배치·서비스 계정도 들어옵니다.')
// 개발팀을 뺄지. 끄면 개발팀 세션도 끊긴다 — 평소와 다른 선택이라 문구로 분명히 밝힌다.
const setKeepTeam = (v) =>
  setOpt({ keepteam: v }, v ? '개발팀을 대상에서 뺐습니다.' : '⚠ 개발팀도 대상에 넣었습니다.')

// ---------- 사번별 전체 현황 ----------
//
// 정리 대상 목록과 쓰임새가 다르다. 저쪽은 <끊을 것>을 고르는 자리고 이쪽은
// <지금 누가 얼마나 쓰고 있나>를 통째로 보는 자리라, 조건을 하나도 걸지 않는다.
const all = ref(null)

/** 전체 세션에서 그 사번이 차지하는 몫(%) */
const share = (u) => (all.value?.total ? (u.procs / all.value.total) * 100 : 0)

// keepMsg: 끊은 직후의 새로고침에서 쓴다. 평소에는 알림 줄을 비우고 시작하지만,
// 끊고 나서 부르는 경우에는 그 줄이 <무엇을 끊었는지> 알려 주는 유일한 자리라 지우면 안 된다.
async function loadUsers(keepMsg = false) {
  busy.value = 'users'
  if (!keepMsg) msg.value = ''
  try {
    const r = await api.oraUsers()
    all.value = r.run
    await load()   // 응답에 딸려 온 state 를 믿지 않는다 (아래 주석 참고)
    // 실패는 keepMsg 와 상관없이 덮어쓴다 — 못 읽은 것을 숨기면 낡은 숫자를 그대로 믿게 된다
    if (!r.run.ok) msg.value = r.run.error ?? '사번별 현황을 읽지 못했습니다.'
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

/**
 * 한 사번을 통째로 끊기 — <b>한 번 누르면 바로</b> 실행된다.
 *
 * 한때 `한 번 더` 를 거치게 해 두었다. 이 단추만큼은 무게가 다르기 때문이다 —
 * 유휴 정리와 달리 <b>지금 일하고 있는 세션까지</b> 끊긴다. 그 한 박자를 빼라는 요청이라
 * 뺐다. 되돌릴 방법은 없으므로(끊긴 사람은 다시 접속해야 한다) 막는 대신 <b>남긴다</b> —
 * 끊고 난 뒤 몇 개를 끊었는지 알림 줄에 적고, 누가 언제 눌렀는지 `logs/api.log` 에 적는다.
 */
async function killUser(u) {
  busy.value = 'u' + u.osuser
  msg.value = ''
  try {
    const r = await api.oraKillUser(u.osuser)
    await load()   // 응답에 딸려 온 state 를 믿지 않는다 (아래 주석 참고)
    run.value = r.run
    const ok = r.run.ok_cnt ?? 0
    const bad = r.run.fail_cnt ?? 0
    msg.value = r.run.ok
      ? u.osuser + ' 세션 ' + ok + '개를 끊었습니다' + (bad ? ' · 실패 ' + bad : '') + '.'
      : (r.run.error ?? '끊지 못했습니다.')
    await loadUsers(true)   // 방금 적은 <무엇을 끊었는지> 를 지우지 않는다
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

/** 목록의 한 줄만 끊는다 */
async function killOne(c) {
  // 묻지 않고 바로 끊는다 — 한 줄짜리라 누를 때마다 창이 뜨면 손만 느려진다.
  // 대신 <무엇을 끊었는지> 를 알림 줄과 실행 기록에 남겨 눈으로 확인할 수 있게 한다.
  busy.value = 'one' + c.sid
  msg.value = ''
  try {
    const r = await api.oraKillOne(c.sid, c.serial)
    await load()   // 응답에 딸려 온 state 를 믿지 않는다 (아래 주석 참고)
    const k = (r.run.killed ?? [])[0]
    if (r.run.found === 0) {
      // 조건을 서버가 다시 걸었는데 안 걸렸다 = 그 사이 다시 쓰이기 시작했다는 뜻이다
      msg.value = `SID ${c.sid} 는 지금 조건에 걸리지 않습니다 — 그 사이 다시 쓰이기 시작했을 수 있습니다.`
    } else if (k?.ok) {
      // 묻지 않고 끊으므로 <무엇을 끊었는지> 는 여기서 분명히 밝힌다
      msg.value = `끊었습니다 — SID ${c.sid},${c.serial} · ${c.username} · ${c.osuser} · ${c.program}`
      run.value = {
        ...run.value,
        candidates: (run.value?.candidates ?? []).filter((x) => !(x.sid === c.sid && x.serial === c.serial)),
      }
    } else {
      msg.value = k?.error ?? '끊지 못했습니다.'
    }
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

async function setAuto(s) {
  // 묻지 않고 바로 켠다 — 켜져 있다는 사실은 위의 주황 띠가 늘 알리고, 중단도 한 번이면 된다
  busy.value = 'auto'
  msg.value = ''
  try {
    st.value = await api.oraAuto(s)
    msg.value = s > 0 ? `자동 실행 켬 — ${label(s)}마다` : '자동 실행을 껐습니다.'
  } catch (e) {
    msg.value = e.message
  } finally {
    busy.value = ''
  }
}

// 자동이 켜져 있으면 상태만 짧게 받아 온다 — 끊는 것은 서버가 하고 화면은 지켜보기만 한다
function poll(on) {
  clearInterval(tick)
  if (on) tick = setInterval(load, 3000)
}
const auto = computed(() => st.value?.auto ?? 0)
const last = computed(() => run.value ?? st.value?.last ?? null)
/** 사번별로 묶는다 — <누가 몇 자리를 쥐고 있고 그중 몇이 정리 대상인가> 가 한눈에 보여야 한다 */
const byUser = computed(() => {
  const m = new Map()
  for (const c of last.value?.candidates ?? []) {
    const k = c.osuser ?? '(없음)'
    if (!m.has(k)) m.set(k, { osuser: k, procs: c.procs ?? 0, tgt: 0, idle: 0, programs: new Set() })
    const g = m.get(k)
    g.tgt++
    g.idle = Math.max(g.idle, c.idle ?? 0)
    if (c.program) g.programs.add(c.program)
  }
  return [...m.values()].sort((a, b) => b.tgt - a.tgt || b.procs - a.procs)
})
/** 이번에 정리하면 비는 자리 수 */
const freeing = computed(() => (last.value?.candidates ?? []).length)

/**
 * 지금 보이는 목록이 <바뀐 조건>으로 뽑은 것인지.
 * 조건 스위치는 조회를 하지 않으므로, 어긋난 동안에는 그 사실을 분명히 밝혀야 한다 —
 * 옛 목록을 새 조건의 결과인 양 두면 보고 끊는 대상이 달라진다.
 */
const stale = computed(() => {
  const l = last.value
  if (!l || l.bponly === undefined || !st.value) return false
  return l.bponly !== st.value.bponly || l.keepteam !== st.value.keepteam
})

const procPct = computed(() => {
  const c = last.value?.proc_cur, m = last.value?.proc_max
  return c && m ? Math.round((c / m) * 100) : null
})

useViewRefresh(load)
load().then(() => { poll(true); loadUsers() })
onUnmounted(() => clearInterval(tick))
</script>

<template>
  <section class="panel head">
    <h2>
      DB 세션 정리
      <span class="hint">{{ st?.url }}<template v-if="st?.user"> · {{ st.user }}</template></span>
      <span class="spacer"></span>
      <RefreshBtn :fn="load" label="" title="상태 다시 읽기" />
    </h2>

    <p class="muted note">
      개발 DB 의 <strong>processes 한도</strong>가 차면 새로 붙는 쪽이
      <code>ORA-12516/12519</code> 로 튕깁니다. <strong>{{ sec(st?.idle) }}</strong> 넘게 놀고 있는
      세션을 끊어 자리를 비웁니다 (<code>ALTER SYSTEM DISCONNECT SESSION … IMMEDIATE</code>).
    </p>

    <p v-if="st && !st.ready" class="bad">실행 준비가 안 됐습니다 — {{ st.why }}</p>

    <!-- 미리 잡아 둔 커넥션 — 자리가 없을 때도 들어가 있으려고 붙잡고 있는 것이다 -->
    <div v-if="st?.pool" class="conn" :class="st.pool.connected ? 'ok' : 'bad'">
      <b>{{ st.pool.connected ? '연결 유지 중' : '연결 끊김 — 다시 붙는 중' }}</b>
      <span>커넥션 {{ st.pool.live ?? 0 }} / {{ st.pool.size ?? 0 }}</span>
      <span v-if="st.pool.ok_ago >= 0">마지막 확인 {{ st.pool.ok_ago }}초 전</span>
      <span v-if="st.pool.reconnects">재연결 {{ st.pool.reconnects }}회</span>
      <span v-if="st.pool.starts > 1">상주 재기동 {{ st.pool.starts }}회</span>
      <span v-if="!st.pool.connected && st.pool.last_error" class="e">{{ st.pool.last_error }}</span>
    </div>

    <!-- 자동이 돌고 있으면 늘 보이게. 창을 닫아도 돈다는 것을 여기서 알린다. -->
    <div v-if="auto > 0" class="armed">
      <b>자동 실행 중 · {{ label(auto) }}마다</b>
      <span class="w">창을 닫아도 서버에서 계속 돕니다</span>
      <span v-if="st?.next_at" class="n">다음 {{ st.next_at.slice(11) }}</span>
      <span v-if="st?.auto_by" class="n">켠 사람 {{ st.auto_by }}</span>
      <span class="spacer"></span>
      <button class="stop" :disabled="busy === 'auto'" @click="setAuto(0)">■ 중단</button>
    </div>

    <p v-if="!auto && st?.last_choice" class="muted resumed">
      지난 설정은 <b>{{ label(st.last_choice) }}</b> 였습니다 — 대시보드가 다시 올라오면
      <strong>자동 실행은 꺼진 채로 시작</strong>합니다. 사람이 보고 있지 않을 때 저절로 다시 끊기 시작하지 않도록 한 것입니다.
    </p>

    <div class="btns">
      <button :disabled="!!busy || !st?.ready" @click="doScan">
        {{ busy === 'scan' ? '조회 중…' : '◻ 조회만' }}
      </button>
      <button v-if="isSuper" class="go" :disabled="!!busy || !st?.ready" @click="doSweep">
        {{ busy === 'sweep' ? '정리 중…' : '✂ 지금 정리' }}
      </button>
      <span class="gap"></span>
      <!-- osuser LIKE 'BP%' 를 켜고 끈다. 끄면 배치·서비스 계정 세션까지 대상이 된다. -->
      <span class="lbl">대상</span>
      <button
        :class="{ on: st?.bponly }"
        :disabled="!isSuper || !!busy"
        title="사번(BP…)으로 접속한 세션만 봅니다"
        @click="setBpOnly(true)"
      >사번(BP)만</button>
      <button
        :class="{ on: st && !st.bponly, warnon: st && !st.bponly }"
        :disabled="!isSuper || !!busy"
        title="사번이 아닌 배치·서비스 계정 세션까지 모두 봅니다"
        @click="setBpOnly(false)"
      >전체 계정</button>

      <span class="gap"></span>
      <!-- 개발팀(BP33771 …)을 뺄지. 끄면 우리 팀 세션도 끊긴다 — 평소와 다른 선택이라 경고색으로 둔다. -->
      <span class="lbl">개발팀</span>
      <button
        :class="{ on: st?.keepteam }"
        :disabled="!isSuper || !!busy"
        :title="`개발팀은 건드리지 않습니다 — ${(st?.keep ?? []).join(' · ')}`"
        @click="setKeepTeam(true)"
      >제외</button>
      <button
        :class="{ on: st && !st.keepteam, warnon: st && !st.keepteam }"
        :disabled="!isSuper || !!busy"
        title="개발팀 세션도 정리 대상에 넣습니다 — 내 세션도 끊길 수 있습니다"
        @click="setKeepTeam(false)"
      >포함</button>

      <span class="gap"></span>
      <template v-if="isSuper">
        <span class="lbl">자동</span>
        <button :class="{ on: auto === 0 }" :disabled="!!busy" @click="setAuto(0)">끔</button>
        <button
          v-for="c in st?.choices ?? []"
          :key="c"
          :class="{ on: auto === c }"
          :disabled="!!busy || !st?.ready"
          @click="setAuto(c)"
        >{{ label(c) }}</button>
      </template>
      <span v-else class="muted sup">끊기·자동 실행은 Super 만 할 수 있습니다 (보기는 누구나).</span>
    </div>

    <p v-if="msg" class="msg" :class="{ bad: /실패|없|못/.test(msg) }">{{ msg }}</p>

    <!-- 조건 스위치는 조회를 하지 않는다. 어긋난 동안에는 그 사실을 분명히 밝힌다 —
         옛 목록을 새 조건의 결과인 양 두면 보고 끊는 대상이 달라진다. -->
    <p v-if="stale" class="stale">
      조건이 바뀌었습니다 — 아래 목록은 <b>바뀌기 전</b>의 것입니다.
      <button class="go" :disabled="!!busy" @click="doScan">◻ 이 조건으로 다시 조회</button>
    </p>
  </section>

  <!-- 지금 DB 상태 -->
  <section v-if="last" class="panel" :class="{ dim: stale }">
    <div class="cards">
      <div class="card" :class="{ warn: procPct != null && procPct >= 90 }">
        <div class="k">processes</div>
        <div class="v">{{ last.proc_cur ?? '-' }}<small> / {{ last.proc_max ?? '-' }}</small></div>
        <div class="b">{{ procPct != null ? procPct + '% 사용' : '' }}</div>
        <div v-if="procPct != null" class="gauge"><div class="bar" :style="{ width: Math.min(100, procPct) + '%' }"></div></div>
      </div>
      <div class="card">
        <div class="k">사용자 세션</div>
        <div class="v">{{ last.total ?? '-' }}</div>
        <div class="b">놀고 있음 {{ last.inactive ?? '-' }}</div>
      </div>
      <div class="card" :class="{ hit: (last.found ?? 0) > 0 }">
        <div class="k">정리 대상</div>
        <div class="v">{{ last.found ?? '-' }}</div>
        <div class="b">{{ sec(st?.idle) }} 넘게 논 세션</div>
      </div>
      <div class="card" :class="{ hit: freeing > 0 }">
        <div class="k">정리하면 비는 자리</div>
        <div class="v">{{ freeing || '-' }}<small v-if="freeing && last.proc_cur"> → {{ last.proc_cur - freeing }}/{{ last.proc_max }}</small></div>
        <div class="b">사번 {{ byUser.length }}명이 쥐고 있음</div>
      </div>
      <div class="card">
        <div class="k">마지막 실행</div>
        <div class="v sm">{{ last.at ?? '-' }}</div>
        <div class="b">
          {{ last.mode === 'sweep' ? '정리' : '조회' }}<template v-if="last.by"> · {{ last.by }}</template>
          <template v-if="last.mode === 'sweep'"> · 끊음 {{ last.ok_cnt ?? 0 }}</template>
        </div>
      </div>
    </div>

    <p v-if="last.busy" class="bad mt">
      DB 가 접속을 거절했습니다 (ORA-12516/12519) — 자리가 없어 들어가지 못했습니다.
      <strong>정리가 가장 필요한 상태</strong>입니다. 잠시 뒤 다시 누르면 대개 들어갑니다.
    </p>
    <p v-else-if="last.error" class="bad mt">{{ last.error }}</p>

    <p class="muted mt small">
      건드리지 않는 계정 — <code>SYS · SYSTEM · DBSNMP · SYSMAN</code>
      <template v-if="st?.keep?.length && st?.keepteam">, 그리고 개발팀 <code>{{ st.keep.join(' · ') }}</code></template>.
      <strong v-if="st && !st.keepteam" class="bad">개발팀도 대상에 들어 있습니다.</strong>
      <code>osuser</code> 가 <code>BP</code> 로 시작하는 세션만 봅니다. 한 번에 최대 {{ st?.limit }}건.
    </p>
  </section>

  <!-- 사번별 — 누가 몇 자리를 쥐고 있나 -->
  <section v-if="byUser.length" class="panel" :class="{ dim: stale }">
    <h2>사번별 <span class="hint">{{ byUser.length }}명 · 정리 대상 {{ freeing }}자리</span></h2>
    <div class="users">
      <div v-for="u in byUser" :key="u.osuser" class="u">
        <div class="nm">{{ u.osuser }}</div>
        <div class="n">
          <b>{{ u.tgt }}</b><small> / {{ u.procs }}자리</small>
        </div>
        <!-- 쥔 자리 중 이번에 끊길 몫 -->
        <div class="bar"><div class="fill" :style="{ width: Math.round((u.tgt / Math.max(1, u.procs)) * 100) + '%' }"></div></div>
        <div class="pg" :title="[...u.programs].join(' · ')">{{ [...u.programs].join(' · ') }}</div>
      </div>
    </div>
    <p class="muted small mt">
      <b>굵은 수</b>는 이번 조건에 걸린 세션, 뒤의 수는 그 사번이 지금 쥐고 있는 전체 자리입니다 —
      둘이 같으면 그 사람 접속이 통째로 정리됩니다.
    </p>
  </section>

  <!-- 대상 목록 -->
  <section v-if="last?.candidates?.length" class="panel" :class="{ dim: stale }">
    <h2>
      {{ last.mode === 'sweep' ? '끊은 세션' : '정리 대상' }}
      <span class="hint">{{ last.candidates.length }}건</span>
    </h2>
    <div class="scroll">
      <table>
        <thead>
          <tr>
            <th class="num">SID</th>
            <th class="num">SERIAL#</th>
            <th>DB 계정</th>
            <th>사번</th>
            <!-- 끊기는 사번 바로 옆이다 — 맨 오른쪽 끝에 두면 넓은 표에서 줄을 놓친다 -->
            <th v-if="isSuper" class="w-act"></th>
            <th>단말</th>
            <th>프로그램</th>
            <th class="num" title="이 사번이 지금 쥐고 있는 자리 수 (이번 대상 / 전체)">쥔 자리</th>
            <th class="num">놀고 있던 시간</th>
            <th>접속</th>
            <th v-if="last.mode === 'sweep'">결과</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="c in last.candidates" :key="c.sid + '-' + c.serial">
            <td class="num">{{ c.sid }}</td>
            <td class="num muted">{{ c.serial }}</td>
            <td>{{ c.username }}</td>
            <td><b>{{ c.osuser }}</b></td>
            <!-- 한 줄만 끊기 — 전부 끊기 전에 하나씩 보내고 싶을 때가 많다 -->
            <td v-if="isSuper" class="w-act">
              <button
                class="one"
                :disabled="!!busy"
                :title="`SID ${c.sid},${c.serial} 만 끊습니다`"
                @click="killOne(c)"
              >{{ busy === 'one' + c.sid ? '…' : '끊기' }}</button>
            </td>
            <td class="muted small">{{ c.machine }}</td>
            <td class="muted small">{{ c.program }}</td>
            <td class="num" :title="`${c.osuser} 가 쥔 자리 ${c.procs}개 중 이번 대상 ${c.tgt}개`">
              <b>{{ c.tgt }}</b><span class="muted"> / {{ c.procs }}</span>
            </td>
            <td class="num">{{ sec(c.idle) }}</td>
            <td class="muted small nowrap">{{ String(c.logon ?? '').slice(0, 16) }}</td>
            <td v-if="last.mode === 'sweep'">
              <span
                v-for="k in (last.killed ?? []).filter((x) => x.sid === c.sid && x.serial === c.serial)"
                :key="k.sid"
                class="tag"
                :class="k.ok ? 'ok' : 'bad'"
                :title="k.error ?? ''"
              >{{ k.ok ? '끊음' : '실패' }}</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <!-- 사번별 전체 현황 — 조건을 하나도 걸지 않은 목록 (지금 누가 얼마나 쓰고 있나) -->
  <section v-if="all?.users?.length" class="panel">
    <h2>
      사번별 전체 현황
      <span class="hint">
        세션 {{ all.total }}개 · {{ all.users.length }}명 ·
        processes {{ all.proc_cur }}/{{ all.proc_max }}
      </span>
      <span class="spacer"></span>
      <button :disabled="!!busy" @click="loadUsers">{{ busy === 'users' ? '읽는 중…' : '⟳ 다시' }}</button>
    </h2>
    <p class="muted small">
      <strong>조건을 걸지 않은 전체 목록</strong>입니다 — 위의 [정리 대상]과 달리 사번·유휴시간·개발팀을
      가리지 않고 <strong>지금 붙어 있는 모든 세션</strong>을 사번별로 묶었습니다.
    </p>

    <div class="scroll short">
      <table>
        <thead>
          <tr>
            <th>사번 (osuser)</th>
            <!-- 끊기는 사번 바로 옆이다 — 끊는 단위가 <사번> 이라 그 옆에 있어야 손이 안 헤맨다 -->
            <th v-if="isSuper" class="w-act2"></th>
            <th class="num">세션</th>
            <th class="w-share">비율</th>
            <th class="num">활성</th>
            <th class="num">비활성</th>
            <th class="num">최장 유휴</th>
            <th>DB 계정</th>
            <th>단말 · 프로그램</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="u in all.users" :key="u.osuser" :class="{ me: (st?.keep ?? []).includes(u.osuser) }">
            <td>
              <b>{{ u.osuser }}</b>
              <span v-if="(st?.keep ?? []).includes(u.osuser)" class="tag sc">개발팀</span>
            </td>
            <!-- 통째로 끊기 — 한 번 누르면 바로 실행된다 -->
            <td v-if="isSuper" class="w-act2">
              <button
                class="ux"
                :disabled="!!busy"
                :title="u.osuser + ' 의 세션 ' + u.procs + '개를 지금 일하는 것까지 전부 끊습니다'"
                @click="killUser(u)"
              >{{ busy === 'u' + u.osuser ? '…' : '⏻' }}</button>
            </td>
            <td class="num"><b>{{ u.procs }}</b></td>
            <td class="w-share">
              <div class="sh">
                <div class="shbar"><div class="shfill" :style="{ width: Math.max(1, share(u)) + '%' }"></div></div>
                <span class="shpct">{{ share(u).toFixed(1) }}%</span>
              </div>
            </td>
            <td class="num" :class="{ act: u.act }">{{ u.act || '' }}</td>
            <td class="num muted">{{ u.ina || '' }}</td>
            <td class="num muted">{{ sec(u.maxidle) }}</td>
            <td class="muted small">{{ u.username }}<small v-if="u.unames > 1"> 외 {{ u.unames - 1 }}</small></td>
            <td class="muted small">{{ u.machine }} · {{ u.program }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <p class="muted small mt">
      <code>⏻</code> 는 그 사번의 세션을 <strong>놀고 있든 일하고 있든 전부</strong> 끊습니다 —
      <strong>한 번 누르면 바로</strong> 실행되고 되돌릴 수 없습니다(끊긴 사람은 다시 접속해야 합니다).
      누른 기록은 <code>logs/api.log</code> 에 남습니다.
      <code>SYS · SYSTEM · DBSNMP · SYSMAN</code> 과 대시보드 자신의 세션은 어떤 경우에도 건드리지 않습니다.
    </p>
  </section>

  <!-- 실행 기록 -->
  <section v-if="st?.log?.length" class="panel">
    <h2>실행 기록 <span class="hint">최근 {{ st.log.length }}건</span></h2>
    <div class="scroll short">
      <table>
        <thead>
          <tr>
            <th class="nowrap">시각</th>
            <th>구분</th>
            <th>실행</th>
            <th class="num">대상</th>
            <th class="num">끊음</th>
            <th class="num">실패</th>
            <th class="num">processes</th>
            <th>비고</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(l, i) in st.log" :key="i">
            <td class="nowrap muted">{{ l.at }}</td>
            <td><span class="tag" :class="l.mode === 'sweep' ? 'sw' : 'sc'">{{ l.mode === 'sweep' ? '정리' : '조회' }}</span></td>
            <td class="muted small">{{ l.by }}</td>
            <td class="num">{{ l.found ?? '-' }}</td>
            <td class="num">{{ l.mode === 'sweep' ? (l.ok_cnt ?? 0) : '' }}</td>
            <td class="num" :class="{ bad: l.fail_cnt }">{{ l.fail_cnt || '' }}</td>
            <td class="num muted">{{ l.proc_cur != null ? `${l.proc_cur}/${l.proc_max}` : '' }}</td>
            <td class="small" :class="{ bad: l.ok === false }">
              {{ l.busy ? 'DB 거절 (자리 없음)' : (l.error ?? '') }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>

<style scoped>
h2 { display: flex; align-items: center; gap: 8px; }
h2 .spacer { flex: 1; }
.head { margin-bottom: 12px; }
.note { margin: 8px 0 0; font-size: 11.5px; }
.note code, .small code { background: var(--fill); border-radius: 3px; padding: 1px 5px; font-size: 11px; }
.msg { margin: 8px 0 0; font-size: 12px; color: var(--done); }
.msg.bad, .bad { color: var(--warn); }
.mt { margin: 10px 0 0; font-size: 11.5px; }
.small { font-size: 11px; }

/* 자동이 돌고 있다는 띠 — 이 화면에서 가장 먼저 보여야 하는 것 */
.armed {
  display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
  margin-top: 10px; padding: 7px 10px;
  border: 1px solid var(--warn); border-radius: var(--radius);
  background: var(--warn-soft); font-size: 11.5px;
}
.armed b { color: var(--warn); }
.armed .w { color: var(--muted); }
.armed .n { color: var(--muted); border-left: 1px solid var(--warn-line); padding-left: 8px; }
.armed .spacer { flex: 1; }
.armed .stop { border-color: var(--warn); color: var(--warn); font-size: 11px; padding: 2px 10px; }

.conn {
  display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
  margin-top: 10px; padding: 5px 10px; border-radius: var(--radius);
  font-size: 11.5px; border: 1px solid var(--line);
}
.conn.ok { border-color: var(--done-line); background: var(--done-soft); }
.conn.ok b { color: var(--done); }
.conn.bad { border-color: var(--warn); background: var(--warn-soft); }
.conn.bad b { color: var(--warn); }
.conn span { color: var(--muted); }
.conn .e { font-family: Consolas, 'Courier New', monospace; font-size: 10.5px; }

.stale {
  display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
  margin: 8px 0 0; padding: 5px 10px; font-size: 11.5px;
  border: 1px solid var(--warn-line); border-radius: var(--radius); background: var(--warn-soft);
}
.stale b { color: var(--warn); }
.stale .go { font-size: 11px; padding: 1px 9px; border-color: var(--warn); color: var(--warn); }
/* 조건과 어긋난 결과는 흐리게 — 지금 것이 아니라는 표시 */
.panel.dim { opacity: 0.5; }

.btns { display: flex; align-items: center; gap: 5px; flex-wrap: wrap; margin-top: 10px; }
.btns .gap { width: 12px; }
.btns .lbl { font-size: 11.5px; color: var(--muted); margin-right: 2px; }
.btns button { font-size: 12px; }
.btns button.go { border-color: var(--warn); color: var(--warn); }
.btns button.on { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
.btns .sup { font-size: 11.5px; }
.resumed { margin: 8px 0 0; font-size: 11.5px; }

.cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(165px, 1fr)); gap: 10px; }
.card { border: 1px solid var(--line); border-radius: var(--radius); background: var(--panel); padding: 9px 11px; }
.card.warn { border-color: var(--warn); }
.card.hit { border-color: var(--accent); }
.card .k { color: var(--muted); font-size: 11.5px; }
.card .v { font-size: 19px; font-weight: 600; margin-top: 1px; }
.card .v.sm { font-size: 13px; }
.card .v small { font-size: 12px; font-weight: 400; color: var(--muted); }
.card .b { font-size: 11px; color: var(--muted); margin-top: 2px; }
.card .gauge { margin-top: 5px; height: 3px; background: var(--fill); border-radius: 2px; overflow: hidden; }
.card .gauge .bar { height: 100%; background: var(--warn); }

.users { display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 8px; margin-top: 10px; }
.u { border: 1px solid var(--line); border-radius: var(--radius); padding: 7px 9px; background: var(--panel); }
.u .nm { font-weight: 600; font-size: 12.5px; }
.u .n { font-size: 12px; margin-top: 1px; }
.u .n b { font-size: 16px; color: var(--warn); }
.u .n small { color: var(--muted); }
.u .bar { height: 3px; background: var(--fill); border-radius: 2px; overflow: hidden; margin-top: 4px; }
.u .bar .fill { height: 100%; background: var(--warn); }
.u .pg { font-size: 10.5px; color: var(--muted); margin-top: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* 사번별 전체 현황 — 비율 막대 */
.w-share { width: 150px; }
.sh { display: flex; align-items: center; gap: 6px; }
.shbar { flex: 1; height: 6px; background: var(--fill); border-radius: 3px; overflow: hidden; }
.shfill { height: 100%; background: var(--accent); }
.shpct { font-size: 10.5px; color: var(--muted); font-variant-numeric: tabular-nums; min-width: 34px; text-align: right; }
td.act { color: var(--done); font-weight: 600; }
tr.me td { background: var(--accent-soft); }
.w-act2 { width: 34px; text-align: left; padding-left: 0; }
/* 통째로 끊기 — 평소엔 조용히, 한 번 누르면 빨갛게 서서 다시 누르기를 기다린다 */
.ux { font-size: 11px; padding: 1px 7px; color: var(--muted-3); border-color: transparent; background: none; }
tr:hover .ux { color: var(--warn); border-color: var(--line); }
.ux:hover:not(:disabled) { border-color: var(--warn); }

.scroll { max-height: calc(100vh - 460px); overflow: auto; }
.scroll.short { max-height: 280px; }
table { width: 100%; border-collapse: collapse; font-size: 12px; }
thead th { position: sticky; top: 0; background: var(--panel); z-index: 1; text-align: left; white-space: nowrap; }
td, th { padding: 4px 7px; border-bottom: 1px solid var(--line); }
.num { text-align: right; font-variant-numeric: tabular-nums; }
.nowrap { white-space: nowrap; }
.tag { font-size: 10.5px; border-radius: 3px; padding: 1px 6px; }
.tag.ok { color: var(--done); background: var(--done-soft); }
.tag.bad { color: var(--on-accent); background: var(--warn); }
.tag.sw { color: var(--warn); background: var(--warn-soft); }
.tag.sc { color: var(--muted); background: var(--fill); }
.w-act { width: 44px; text-align: left; padding-left: 0; }
/* 한 줄 끊기 — 평소엔 조용히, 줄에 손을 올리면 또렷하게 */
.one { font-size: 10.5px; padding: 1px 7px; color: var(--muted-3); border-color: transparent; background: none; }
tr:hover .one { color: var(--warn); border-color: var(--line); }
.one:hover:not(:disabled) { border-color: var(--warn); background: var(--warn-soft); }
/* 전체 계정을 보고 있을 때는 단추부터 경고색 — 사번 밖 세션까지 대상이라는 뜻이다 */
.btns button.warnon { background: var(--warn); border-color: var(--warn); color: var(--on-accent); }
</style>
