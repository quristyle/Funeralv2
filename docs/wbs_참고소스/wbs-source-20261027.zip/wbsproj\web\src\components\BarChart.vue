<script setup>
import { computed } from 'vue'

const props = defineProps({
  items: { type: Array, default: () => [] }, // [{ label, value, done, sub, key }]
  active: { type: String, default: null },
})
const emit = defineEmits(['pick'])

const max = computed(() => Math.max(1, ...props.items.map((i) => i.value)))
</script>

<template>
  <div class="bars">
    <div
      v-for="it in items"
      :key="it.key ?? it.label"
      class="row"
      :class="{ on: active === (it.key ?? it.label) }"
      @click="emit('pick', it.key ?? it.label)"
    >
      <div class="lab" :title="it.sub || it.label">{{ it.label }}</div>
      <div class="track">
        <div class="fill" :style="{ width: (it.value / max) * 100 + '%' }">
          <!-- 완료분은 같은 막대 안에 진한 색으로 겹쳐 표시 -->
          <div
            v-if="it.done"
            class="done"
            :style="{ width: (it.done / it.value) * 100 + '%' }"
            :title="`완료 ${it.done} / ${it.value}`"
          ></div>
        </div>
      </div>
      <div class="val">
        {{ it.value }}<span v-if="it.done" class="dn">✓{{ it.done }}</span>
      </div>
    </div>
    <div v-if="!items.length" class="muted">데이터 없음</div>
  </div>
</template>

<style scoped>
.bars { display: flex; flex-direction: column; gap: 3px; }
.row {
  display: grid;
  grid-template-columns: 84px 1fr 62px;
  align-items: center;
  gap: 8px;
  padding: 2px 4px;
  border-radius: 5px;
  cursor: pointer;
}
.row:hover { background: var(--surface); }
.row.on { background: var(--accent-soft); }
.lab { color: var(--muted); font-size: 11.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.row.on .lab { color: var(--accent); font-weight: 600; }
.track { background: var(--fill); border-radius: 3px; height: 14px; overflow: hidden; }
.fill { background: var(--accent); height: 100%; border-radius: 3px; transition: width 0.15s; }
.done { background: var(--done); height: 100%; border-radius: 3px 0 0 3px; }
.val { text-align: right; font-size: 12px; font-variant-numeric: tabular-nums; }
.dn { color: var(--done); font-size: 11px; margin-left: 4px; }
</style>
